# التحقق من V6.6.0

تم تنفيذ التحقق التالي في بيئة البناء:

- `python -m compileall -q app scripts`: ناجح.
- `python scripts/static_validate_v6.py`: ناجح ويشمل قواعد V6.6 الجديدة.
- اختبارات Static/Compatibility المختارة: `41 passed`.
- تم التحقق من وجود: صلاحية مشرف الجلسات فقط، مولد الجلسة المباشر، سجل المنتهية، استبعاد Blocklist من مدخلات الفحص، كتابة الاسم مع الرابط، والحصول على تعليقات المناقشة عبر `reply_to` في فحص الحسابات.

لم تعمل مجموعة Runtime الكاملة داخل بيئة البناء لأنها لا تحتوي `aiogram/Telethon/aiosqlite`. يجب تشغيل `./botctl.sh selfcheck` داخل `.venv` على Termux بعد `pip install -r requirements.txt`؛ هذه هي البيئة الفعلية التي ستشغّل البوت.
