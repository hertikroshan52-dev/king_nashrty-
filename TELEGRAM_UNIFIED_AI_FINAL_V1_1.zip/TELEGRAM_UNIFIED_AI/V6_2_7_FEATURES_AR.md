# V6.2.7

- يمنع Deferred-task stampede: لا تبقى مهمة asyncio نائمة لكل رابط مؤجل.
- أي Cursor مؤجل يُحفظ في SQLite ثم تنتهي مهمته فورًا.
- Coordinator واحد فقط يعيد جدولة الـ cursors عند حلول deferred_until.
- يحافظ على heartbeat أثناء الراحة والانتظار الطويل.
- يستمر فحص الروابط العادية وروابط الدعوة بدل خنق SQLite بآلاف المهام النائمة.
- يحافظ على V6.2.6 account ResolveUsername cooldown وعلى عدم تحويل FloodWait إلى final error.
