#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"

if command -v apt-get >/dev/null 2>&1 && [ "$(id -u)" = "0" ]; then
  export DEBIAN_FRONTEND=noninteractive
  apt-get update
  apt-get install -y \
    python3 python3-pip python3-venv python3-dev \
    build-essential pkg-config libffi-dev libssl-dev \
    ca-certificates curl unzip nano sqlite3
fi

command -v python3 >/dev/null 2>&1 || { echo "ERROR: python3 is required"; exit 1; }

python3 - <<'PY'
import sys
print("Python:", sys.version.split()[0])
if sys.version_info < (3, 12):
    raise SystemExit("Python 3.12+ is required")
if sys.version_info >= (3, 15):
    print("WARNING: Python 3.15+ has not been validated with this release.")
PY

if [ ! -d .venv ]; then
  python3 -m venv .venv
fi

. .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install --no-cache-dir -r requirements.txt

python -m compileall -q app scripts tests
python scripts/static_validate_v6.py
python scripts/static_validate_v7.py
python scripts/static_validate_v8.py

if [ ! -f .env ]; then
  cp .env.example .env
  chmod 600 .env 2>/dev/null || true
  echo "Created .env from .env.example"
fi

chmod +x botctl.sh start.sh UPGRADE_TO_V8_TERMUX.sh 2>/dev/null || true
echo "INSTALLATION COMPLETE"
echo "Next: edit .env, then run: ./botctl.sh selfcheck && ./botctl.sh start"
