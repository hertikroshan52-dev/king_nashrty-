# V6.0 FINAL — بنية الأداء

## Collector
- التجميع عملية Extraction فقط؛ لا يوجد Resolve/Validity check.
- عدة حسابات تجمع بالتوازي حسب `COLLECTOR_ACCOUNT_WORKERS`.
- Fast: `InputMessagesFilterUrl`.
- Deep: كل الرسائل ضمن النطاق الزمني.
- SQLite writes على دفعات مع WAL وGlobal Dedup.
- Job cursor للاستئناف، وCollection High-Water لخيار «الجديد فقط» بين المهام المختلفة.
- Source stats تسجل الرسائل والروابط والجديد والمكرر والأخطاء وQuality Score.
- إذا فشل حساب في مصدر مشترك، تُحرر مطالبة المصدر ليستطيع حساب آخر الوصول إليه إذا صادفه.

## Audit
نظام السرعة **ثابت حسب طلب المالك** ولا يستخدم V5 burst limiter:
- cohort = 10 حسابات.
- 4 روابط مختلفة لكل حساب في الدورة.
- حتى 40 رابطًا لكل cohort في الدورة.
- كل cohorts تبدأ العمل في الدورة نفسها.
- بعد الدورة: 120 ثانية راحة كاملة إذا بقي عمل.
- الرابط المنتهي الواضح يصنف فورًا؛ لا يستهلك بقية الحسابات لإعادة إثبات انتهائه.
- Temporary/FloodWait تبقى أخطاء مؤقتة وتخضع لمحاولات Retry، ولا تتحول خطأً إلى Expired.

## Memory
- Import الملفات Streaming.
- Database/Job/Audit exports Streaming/keyset pagination.
- Collector DB writes batch-based.
- Live/event processing يعتمد Global Dedup وقاعدة التسليم لمنع التكرار.

## الاستمرارية
- Pause/Resume.
- Crash recovery.
- Persistent FSM.
- Auto DB backup.
- Secure encrypted recovery bundle.
