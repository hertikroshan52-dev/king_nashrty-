# تحديث آمن إلى V6.2.6

1. أوقف واحفظ أي مهمة تعمل.
2. أوقف البوت وخذ backup.
3. استبدل الكود فقط مع استثناء `.env` و`.venv` و`data`.
4. شغّل `./botctl.sh migrate` ثم `./botctl.sh selfcheck`.
5. شغّل البوت ثم استكمل المهمة.

لا يحتاج هذا الإصدار إلى جدول DB جديد؛ account/method cooldown يستخدم `job_cursors` الموجود أصلًا.
