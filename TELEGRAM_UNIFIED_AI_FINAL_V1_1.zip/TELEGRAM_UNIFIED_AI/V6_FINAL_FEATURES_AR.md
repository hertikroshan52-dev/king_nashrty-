> **تنبيه V6.4.0:** هذا الملف توثيق تاريخي للنسخ القديمة متعددة التوكنات. النسخة الحالية تعمل بتوكن Bot واحد وقاعدة مشتركة، ويُضاف المشرفون من لوحة المالك. المرجع الحالي: `README_AR.md` و`V6_4_0_MULTI_SUPERVISOR_AR.md`.

# Telegram Link Collector & Auditor V6.0.1 — Final

## مبدأ النسخ المستقلة
- كل نسخة تعرض جميع الوظائف دائمًا؛ لا يوجد `INSTANCE_ROLE` ولا تقييد وظيفي حسب النسخة.
- المستخدم وحده يقرر هل يستخدم النسخة للتجميع العام أو حسب القسم أو للفحص أو لكل ذلك معًا.

## قواعد لا تتغير
1. **التجميع ليس فحصًا**: Collector يستخرج/يطبع/يطبع-normalize/deduplicate الروابط فقط ولا يرسل Resolve أو CheckInvite لمعرفة هل الرابط شغال أو منتهي.
2. **فحص Telegram ثابت**: كل 10 حسابات مجموعة؛ لكل حساب حتى 4 روابط مختلفة بالتوازي؛ بعد الموجة راحة 120 ثانية؛ ثم موجة جديدة.
3. **الرابط المنتهي**: استجابة Telegram الدائمة من نوع Invite/Username expired/invalid/not occupied تسجل الرابط مباشرة في `expired` في نفس المحاولة.
4. **لا انضمام تلقائي** ولا إرسال طلب انضمام أثناء Audit.

## إضافات V6
- تجميع القسم من الحسابات أو من مجموعة/قناة يحددها المستخدم.
- `الجديد فقط منذ آخر تجميع ناجح` عبر Collection High-Water Checkpoints.
- ذاكرة عمر الرابط: first seen / last seen / seen count + occurrences.
- Peer Registry يربط Telegram peer بالروابط/الأسماء التي تم حلها.
- Resolution Cache اختياري ومغلق افتراضيًا حتى لا يغير نمط الفحص المطلوب.
- Persistent FSM: خطوات الواجهة لا تضيع عند Restart.
- Streaming audit file import بدل تحميل الملف كاملًا إلى RAM.
- Streaming database/job export لتقليل استهلاك RAM.
- Source statistics وQuality Score.
- لوحة تحكم داخل Telegram.
- البحث عن رابط ومعرفة آخر ظهور وآخر فحص.
- Auto DB backup دوري.
- Secure encrypted recovery bundle عبر `./botctl.sh secure-backup`.
- Export لكل من مهام accounts وsources أثناء/بعد التنفيذ من النتائج الملتزم بها في DB.
- Audit source button ظاهر في الواجهة.
- Telegram public usernames تحافظ على حالة الأحرف في الرابط المخزن، مع dedup غير حساس لحالة الأحرف داخل ميزة اكتشاف Telegram الجديدة، والحفاظ على invite hash كما هو.
- Link/Delivery dedup + crash recovery + pause/resume + WAL + batch writes مع تحسينات V6.

## إضافات V6.1 النهائية

- خيار مستقل داخل فحص Telegram: **فحص + تجميع روابط Telegram الجديدة**.
- لا يتم دمج تجميع Telegram مع تجميع WhatsApp؛ كل وضع مستقل.
- الروابط المكتشفة تُقبل فقط إذا لم تكن موجودة مسبقًا في قاعدة `links`.
- النتائج تعرض وتصدر **القنوات (مشتركون)** منفصلة عن **المجموعات (أعضاء)**.
- جدول اكتشاف جديد غير هدّام: `telegram_audit_telegram_discovery`.
