from __future__ import annotations

import asyncio
import json
import logging
import re
import shutil

from aiogram import Bot, F, Router
from aiogram.enums import ChatMemberStatus, ChatType
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, FSInputFile, Message
from sqlalchemy import delete, func, select, update
from sqlalchemy.dialects.sqlite import insert

from app.config import get_settings
from app.db import SessionFactory
from app.keyboards import (
    CATEGORY_LABELS,
    SCOPE_LABELS,
    STATUS_LABELS,
    account_management_keyboard,
    audit_export_options_keyboard,
    back_menu,
    backup_menu_keyboard,
    backup_restore_confirm_keyboard,
    cancel_keyboard,
    category_keyboard,
    category_origin_keyboard,
    collection_scan_mode_keyboard,
    confirm_delete_account_keyboard,
    database_keyboard,
    destination_choice_keyboard,
    jobs_keyboard,
    join_limit_keyboard,
    join_source_keyboard,
    leave_join_confirm_keyboard,
    main_menu,
    reset_confirm_keyboard,
    reset_menu_keyboard,
    scope_keyboard,
    supervisor_management_keyboard,
    session_only_menu,
    session_extract_cancel_keyboard,
    v7_center_keyboard, session_center_keyboard, session_detail_keyboard, session_delete_confirm_keyboard,
    schedules_keyboard, workflows_keyboard, tags_keyboard, errors_keyboard,
    expired_links_keyboard,
    watches_keyboard,
    telegram_audit_engine_keyboard,
    telegram_audit_list_keyboard,
    telegram_audit_menu_keyboard,
    telegram_audit_mode_keyboard,
    telegram_audit_pacing_keyboard,
    telegram_audit_result_keyboard,
    telegram_audit_source_keyboard,
    telegram_audit_title_keyboard,
    telegram_audit_upload_keyboard,
    telegram_audit_verifier_keyboard,
    telegram_audit_whatsapp_scope_keyboard,
    telegram_audit_telegram_scope_keyboard,
    telegram_web_audit_result_keyboard,
    telegram_web_audit_source_keyboard,
)
from app.link_utils import extract_urls_from_text, inspect_collection_link, inspect_link
from app.models import Account, AdminActionLog, DestinationConfig, Job, JobCursor, JoinCandidate, Link, LinkOccurrence, WatchConfig, TelegramAudit, TelegramAuditInput, TelegramAuditResult, ScheduledTask, Workflow, EntityTag, SystemError, utcnow
from app.services.auditor import (
    add_audit_file_stream,
    add_audit_text,
    audit_summary,
    create_audit,
    discard_audit,
    export_audit,
    format_account_report,
    format_audit_summary,
    get_audit,
    list_audits,
    populate_audit_from_database,
    populate_audit_from_discovery,
    queue_audit_job,
    set_audit_title,
)
from app.services.audit_roles import get_verifier_account_ids, toggle_verifier_account
from app.services.backup import create_database_backup, list_backups, restore_latest_backup
from app.services.accounts import (
    account_belongs_to_operator,
    add_packages,
    convert_sqlite_session,
    export_session_packages,
    list_accounts,
    parse_session_packages,
    save_account,
)
from app.services.web_auditor import populate_account_audit_from_web_section, queue_web_audit_job
from app.services.joiner import count_leave_targets, seed_legacy_assignments_for_job
from app.services.join_planner import get_join_source_overview, stage_join_job
from app.services.session_extractor import begin_login, cancel_login, submit_code, submit_password
from app.services.expired_registry import expired_registry_count, import_expired_from_source, unblock_expired_url
from app.services.exporter import export_database, export_job
from app.services.owners import (
    add_supervisor,
    claim_first_owner,
    get_supervisor_ids,
    get_session_supervisor_ids,
    is_owner,
    is_primary_owner,
    is_session_supervisor,
    add_session_supervisor,
    remove_session_supervisor,
    remove_supervisor,
)
from app.services.publisher import BatchPublisher
from app.services.repository import register_link
from app.services.control_v7 import (
    session_event, session_health, set_session_active, delete_session_local,
    create_scheduled_task, list_scheduled_tasks, cancel_scheduled_task,
    create_preset_workflow, list_workflows, delete_workflow, run_workflow,
    add_tag, list_tags, global_search, list_system_errors, resolve_system_error,
    admin_audit_rows, diagnostics,
)
from app.services.resetter import reset_collected_data
from app.states import AddAccountState, DestinationState, JoinGroupsState, ManualLinksState, SearchState, SourceState, SupervisorState, TelegramAuditState, SessionExtractState, ExpiredLinksState, V7ScheduleState, V7WorkflowState, V7TagState, V7GlobalSearchState

settings = get_settings()
router = Router()
logger = logging.getLogger(__name__)
ALL_CATEGORIES = {"whatsapp", "twitter", "telegram", "other"}

AUDIT_EXPORT_SECTION_FOLDERS = {
    "channels": "01_قنوات_Telegram_مشتركون",
    "groups": "02_مجموعات_Telegram_اعضاء",
    "telegram_new": "03_روابط_Telegram_الجديدة",
    "whatsapp": "04_روابط_واتساب",
    "join_required": "05_روابط_تحتاج_انضمام_او_طلب_انضمام",
    "final_errors": "06_اخطاء_نهائية",
    "temporary_errors": "07_اخطاء_مؤقتة",
    "expired": "08_روابط_منتهية",
    "pump_ipo": "09_مجموعات_البامبات_والاكتتابات",
    "bots": "10_روابط_البوتات",
    "personal": "11_روابط_شخصية",
    "requires_account": "12_روابط_تحتاج_حسابات_لمعرفة_المعلومات",
    "unsupported": "13_روابط_Telegram_غير_مدعومة",
}


async def log_admin_action(user_id: int | None, action: str, detail: str | None = None) -> None:
    if user_id is None:
        return
    try:
        async with SessionFactory() as session:
            session.add(AdminActionLog(user_id=int(user_id), action=action[:80], detail=(detail or "")[:4000] or None))
            await session.commit()
    except Exception:
        logger.exception("Could not write admin action log: %s", action)


async def safe_answer(callback: CallbackQuery, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
    try:
        await callback.answer(*args, **kwargs)
    except Exception:
        # A callback may already have been answered when a shared renderer is reused.
        pass


@router.callback_query(F.data == "noop")
async def noop_callback(callback: CallbackQuery) -> None:
    await safe_answer(callback)


async def reject_non_owner(event: Message | CallbackQuery) -> bool:
    user_id = event.from_user.id if event.from_user else None
    if await is_owner(user_id):
        return False
    text = "هذا البوت خاص بمالكه فقط."
    if isinstance(event, CallbackQuery):
        await event.answer(text, show_alert=True)
    else:
        await event.answer(text)
    return True


async def reject_non_primary(event: Message | CallbackQuery) -> bool:
    user_id = event.from_user.id if event.from_user else None
    if await is_primary_owner(user_id):
        return False
    text = "هذه العملية متاحة للمالك الرئيسي فقط."
    if isinstance(event, CallbackQuery):
        await event.answer(text, show_alert=True)
    else:
        await event.answer(text)
    return True


async def reject_non_session_tool(event: Message | CallbackQuery) -> bool:
    user_id = event.from_user.id if event.from_user else None
    if await is_owner(user_id) or await is_session_supervisor(user_id):
        return False
    text = "لا تملك صلاحية استخراج جلسات Telethon."
    if isinstance(event, CallbackQuery):
        await event.answer(text, show_alert=True)
    else:
        await event.answer(text)
    return True


async def _menu_for_user(user_id: int) -> object:
    return main_menu() if await is_owner(user_id) else session_only_menu()


INVITE_SOURCE_RE = re.compile(
    r"^https?://(?:www\.)?(?:t\.me|telegram\.me)/(?:joinchat/|\+)[A-Za-z0-9_-]+/?$",
    re.I,
)
PUBLIC_SOURCE_RE = re.compile(
    r"^https?://(?:www\.)?(?:t\.me|telegram\.me)/([A-Za-z0-9_]{4,})/?$",
    re.I,
)


def parse_sources(text: str) -> list[str]:
    candidates = re.split(r"[\s,]+", text.strip())
    result: list[str] = []
    for raw in candidates:
        value = raw.strip().rstrip(".,;:!?)]}،؛؟")
        if not value:
            continue
        if value.startswith("@") and re.fullmatch(r"@[A-Za-z0-9_]{4,}", value):
            result.append(value)
            continue
        if value.lstrip("-").isdigit():
            result.append(value)
            continue
        if INVITE_SOURCE_RE.fullmatch(value):
            result.append(value.rstrip("/"))
            continue
        public = PUBLIC_SOURCE_RE.fullmatch(value)
        if public:
            result.append("@" + public.group(1))
    return list(dict.fromkeys(result))


async def resolve_chat(bot: Bot, value: str) -> int:
    candidate: str | int = value.strip()
    if isinstance(candidate, str) and re.match(r"https?://", candidate, re.I):
        match = PUBLIC_SOURCE_RE.fullmatch(candidate.rstrip("/"))
        if not match:
            raise ValueError(
                "أرسل رابط القناة العام المباشر فقط، أو رقم القناة الخاصة الذي يبدأ بـ -100. "
                "روابط الدعوة وروابط الرسائل لا تصلح كقناة وجهة للبوت."
            )
        candidate = "@" + match.group(1)
    elif isinstance(candidate, str) and candidate.lstrip("-").isdigit():
        candidate = int(candidate)
    chat = await bot.get_chat(candidate)
    return int(chat.id)


async def validate_destination(bot: Bot, chat_id: int) -> None:
    chat = await bot.get_chat(chat_id)
    me = await bot.get_me()
    member = await bot.get_chat_member(chat_id, me.id)
    if member.status not in {ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR}:
        raise ValueError(f"البوت ليس مشرفًا في {chat.title or chat.id}.")
    if chat.type == ChatType.CHANNEL and getattr(member, "can_post_messages", None) is False:
        raise ValueError(f"البوت لا يملك صلاحية نشر الرسائل في {chat.title or chat.id}.")


async def parse_destinations(bot: Bot, text: str) -> dict[str, int]:
    aliases = {
        "واتساب": "whatsapp",
        "whatsapp": "whatsapp",
        "تويتر": "twitter",
        "twitter": "twitter",
        "x": "twitter",
        "تليجرام": "telegram",
        "تلجرام": "telegram",
        "telegram": "telegram",
        "اخرى": "other",
        "أخرى": "other",
        "other": "other",
    }
    parsed: dict[str, int] = {}
    for line in text.splitlines():
        separator = "=" if "=" in line else ":" if ":" in line else None
        if not separator:
            continue
        key, value = line.split(separator, 1)
        category = aliases.get(key.strip().lower())
        if not category:
            continue
        chat_id = await resolve_chat(bot, value.strip())
        await validate_destination(bot, chat_id)
        parsed[category] = chat_id
    return parsed


async def get_destinations(owner_id: int) -> dict[str, int]:
    async with SessionFactory() as session:
        value = await session.scalar(
            select(DestinationConfig.destinations).where(DestinationConfig.owner_id == owner_id)
        )
    if not isinstance(value, dict):
        return {}
    return {str(key): int(chat_id) for key, chat_id in value.items()}


async def save_destinations(owner_id: int, destinations: dict[str, int]) -> None:
    async with SessionFactory() as session:
        await session.execute(
            insert(DestinationConfig)
            .values(owner_id=owner_id, destinations=destinations)
            .on_conflict_do_update(
                index_elements=[DestinationConfig.owner_id],
                set_={"destinations": destinations},
            )
        )
        await session.commit()


async def create_job(
    requested_by: int,
    *,
    mode: str,
    scope: str = "all",
    category: str | None = None,
    sources: list[str] | None = None,
    destinations: dict[str, int] | None = None,
    collection_scan_mode: str | None = None,
    initial_progress: dict[str, object] | None = None,
) -> Job:
    progress_data: dict[str, object] = dict(initial_progress or {})
    if collection_scan_mode in {"fast", "deep"}:
        progress_data["collection_scan_mode"] = collection_scan_mode
    async with SessionFactory() as session:
        job = Job(
            requested_by=requested_by,
            mode=mode,
            scope=scope,
            category=category,
            sources=sources or [],
            destinations=destinations or {},
            status="queued",
            progress=progress_data,
        )
        session.add(job)
        await session.commit()
        await session.refresh(job)
        return job


def destinations_prompt() -> str:
    return (
        "أرسل قنوات التجميع في أربع أسطر:\n\n"
        "واتساب=@whatsapp_links\n"
        "تويتر=@twitter_links\n"
        "تليجرام=@telegram_links\n"
        "اخرى=@other_links\n\n"
        "يمكن استخدام رقم القناة -100... للقنوات الخاصة. يجب أن يكون البوت مشرفًا بصلاحية النشر."
    )


@router.message(CommandStart())
async def start(message: Message, state: FSMContext) -> None:
    if not message.from_user:
        return
    user_id = int(message.from_user.id)
    if await is_session_supervisor(user_id) and not await is_owner(user_id):
        await state.clear()
        await message.answer(
            f"{settings.instance_name} — مشرف استخراج جلسات فقط\nصلاحيتك محصورة باستخراج جلسات Telethon.",
            reply_markup=session_only_menu(),
        )
        return
    was_authorized = await is_owner(user_id)
    authorized = await claim_first_owner(user_id)
    if not authorized:
        await message.answer("هذا الحساب غير مضاف ضمن مشرفي البوت.")
        return
    await state.clear()
    primary = await is_primary_owner(user_id)
    role = "المالك الرئيسي" if primary else "مشرف"
    owner_note = "\nتم اعتمادك مالكًا رئيسيًا للبوت." if primary and not settings.admin_ids and not was_authorized else ""
    await message.answer(
        f"{settings.instance_name} — {role}\nلوحة التحكم الرئيسية:" + owner_note,
        reply_markup=main_menu(),
    )


@router.message(Command("menu"))
async def menu_command(message: Message, state: FSMContext) -> None:
    if not message.from_user:
        return
    user_id = int(message.from_user.id)
    if not await is_owner(user_id) and not await is_session_supervisor(user_id):
        await message.answer("هذا البوت خاص بالمستخدمين المصرح لهم فقط.")
        return
    await state.clear()
    await message.answer("لوحة التحكم:", reply_markup=await _menu_for_user(user_id))


@router.callback_query(F.data == "menu")
async def menu_callback(callback: CallbackQuery, state: FSMContext) -> None:
    user_id = int(callback.from_user.id) if callback.from_user else 0
    if not await is_owner(user_id) and not await is_session_supervisor(user_id):
        await safe_answer(callback, "غير مصرح.", show_alert=True)
        return
    await state.clear()
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer("لوحة التحكم:", reply_markup=await _menu_for_user(user_id))


@router.callback_query(F.data == "cancel")
async def cancel(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    await state.clear()
    await safe_answer(callback, "تم الإلغاء")
    if callback.message:
        await callback.message.answer("لوحة التحكم الرئيسية:", reply_markup=main_menu())


@router.callback_query(F.data == "supervisors:menu")
async def supervisors_menu_handler(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_primary(callback):
        return
    await state.clear()
    ids = await get_supervisor_ids()
    session_ids = await get_session_supervisor_ids()
    await safe_answer(callback)
    text = "المشرفون الكاملون: " + (", ".join(map(str, ids)) if ids else "لا يوجد")
    text += "\nمشرفو استخراج الجلسات فقط: " + (", ".join(map(str, session_ids)) if session_ids else "لا يوجد")
    if callback.message:
        await callback.message.answer(text, reply_markup=supervisor_management_keyboard(ids, session_ids))


@router.callback_query(F.data == "supervisors:add")
async def supervisor_add_start(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_primary(callback):
        return
    await state.clear()
    await state.set_state(SupervisorState.waiting_user_id)
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            "أرسل Telegram User ID الرقمي للمشرف. بعد إضافته يضغط المشرف /start ويظهر له حسابه ولوحته المستقلة.",
            reply_markup=cancel_keyboard(),
        )


@router.message(SupervisorState.waiting_user_id, F.text)
async def supervisor_add_message(message: Message, state: FSMContext) -> None:
    if await reject_non_primary(message):
        return
    raw = (message.text or "").strip()
    if not raw.isdigit() or int(raw) <= 0:
        await message.answer("أرسل User ID رقميًا صحيحًا فقط.")
        return
    user_id = int(raw)
    created = await add_supervisor(user_id)
    await state.clear()
    ids = await get_supervisor_ids()
    await log_admin_action(message.from_user.id if message.from_user else None, "supervisor_add", f"user_id={user_id}")
    await message.answer(
        (f"تمت إضافة المشرف {user_id}. يمكنه الآن الضغط على /start."
         if created else f"المعرف {user_id} موجود بالفعل أو هو المالك الرئيسي."),
        reply_markup=supervisor_management_keyboard(ids, await get_session_supervisor_ids()),
    )


@router.callback_query(F.data.startswith("supervisors:remove:"))
async def supervisor_remove_handler(callback: CallbackQuery) -> None:
    if await reject_non_primary(callback):
        return
    user_id = int(callback.data.rsplit(":", 1)[1])
    removed = await remove_supervisor(user_id)
    if removed:
        # Revocation must stop operational access, not only hide the menu. Keep
        # historical rows for auditability, but disable sessions/watches and
        # prevent queued/running jobs from continuing under a revoked ID.
        async with SessionFactory() as session:
            await session.execute(update(Account).where(Account.operator_id == user_id).values(active=False))
            await session.execute(update(WatchConfig).where(WatchConfig.requested_by == user_id).values(enabled=False))
            await session.execute(
                update(Job)
                .where(Job.requested_by == user_id, Job.status == "queued")
                .values(status="cancelled", error="تم إلغاء المهمة بعد حذف صلاحية المشرف.", updated_at=utcnow())
            )
            await session.execute(
                update(Job)
                .where(
                    Job.requested_by == user_id,
                    Job.status.in_(["starting", "running", "pause_requested", "paused", "stopping"]),
                )
                .values(status="cancel_requested", error="تم طلب الإلغاء بعد حذف صلاحية المشرف.", updated_at=utcnow())
            )
            await session.execute(
                update(TelegramAudit)
                .where(
                    TelegramAudit.requested_by == user_id,
                    TelegramAudit.status.in_(["queued", "starting", "running", "pause_requested", "paused"]),
                )
                .values(status="cancel_requested", error="تم إيقاف الفحص بعد حذف صلاحية المشرف.", updated_at=utcnow())
            )
            await session.commit()
    ids = await get_supervisor_ids()
    await log_admin_action(callback.from_user.id if callback.from_user else None, "supervisor_remove", f"user_id={user_id}")
    await safe_answer(callback, "تم حذف المشرف." if removed else "تعذر حذف هذا المشرف.", show_alert=True)
    if callback.message:
        await callback.message.answer("إدارة المشرفين:", reply_markup=supervisor_management_keyboard(ids, await get_session_supervisor_ids()))


@router.callback_query(F.data == "supervisors:add_session_only")
async def supervisor_add_session_only_start(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_primary(callback):
        return
    await state.clear()
    await state.set_state(SupervisorState.waiting_session_user_id)
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            "أرسل Telegram User ID للمستخدم الذي تريد منحه صلاحية استخراج جلسات Telethon فقط. لن يرى التجميع أو الفحص أو قاعدة البيانات.",
            reply_markup=cancel_keyboard(),
        )


@router.message(SupervisorState.waiting_session_user_id, F.text)
async def supervisor_add_session_only_message(message: Message, state: FSMContext) -> None:
    if await reject_non_primary(message):
        return
    raw = (message.text or "").strip()
    if not raw.isdigit() or int(raw) <= 0:
        await message.answer("أرسل User ID رقميًا صحيحًا فقط.")
        return
    user_id = int(raw)
    created = await add_session_supervisor(user_id)
    await state.clear()
    await log_admin_action(message.from_user.id if message.from_user else None, "session_supervisor_add", f"user_id={user_id}")
    await message.answer(
        (f"تمت إضافة {user_id} كمشرف استخراج جلسات فقط. يضغط /start." if created else "المعرف موجود مسبقًا أو يملك صلاحية أعلى."),
        reply_markup=supervisor_management_keyboard(await get_supervisor_ids(), await get_session_supervisor_ids()),
    )


@router.callback_query(F.data.startswith("supervisors:remove_session:"))
async def supervisor_remove_session_only(callback: CallbackQuery) -> None:
    if await reject_non_primary(callback):
        return
    user_id = int(callback.data.rsplit(":", 1)[1])
    removed = await remove_session_supervisor(user_id)
    await cancel_login(user_id)
    await log_admin_action(callback.from_user.id if callback.from_user else None, "session_supervisor_remove", f"user_id={user_id}")
    await safe_answer(callback, "تم حذف صلاحية الجلسات." if removed else "المعرف غير موجود.", show_alert=True)
    if callback.message:
        await callback.message.answer("إدارة المشرفين:", reply_markup=supervisor_management_keyboard(await get_supervisor_ids(), await get_session_supervisor_ids()))


@router.callback_query(F.data.regexp(r"^join:export:\d+$"))
async def join_export_handler(callback: CallbackQuery, bot: Bot) -> None:
    if await reject_non_owner(callback):
        return
    if not await is_primary_owner(callback.from_user.id):
        await safe_answer(callback, "تصدير الروابط متاح للمالك الأساسي فقط.", show_alert=True)
        return
    await safe_answer(callback, "جارٍ تجهيز التقرير...")
    from app.services.join_export import export_join_job
    try:
        path = await export_join_job(int(callback.data.rsplit(":", 1)[1]), callback.from_user.id)
        await bot.send_document(callback.from_user.id, FSInputFile(path), caption="نتائج الانضمام: ملف لكل حالة وتقرير الحسابات والروابط.")
    except Exception as exc:
        if callback.message:
            await callback.message.answer(f"تعذر تصدير النتائج: {exc}")


@router.callback_query(F.data == "join:database")
async def join_database_start(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    overview = await get_join_source_overview(callback.from_user.id)
    if overview.database_audit_id is None or overview.database_count <= 0:
        await safe_answer(callback, "لا يوجد فحص مكتمل لقاعدة البيانات يحتوي روابط جاهزة للانضمام.", show_alert=True)
        return
    await state.clear()
    await state.update_data(join_source_kind="database", join_audit_id=int(overview.database_audit_id))
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            f"فحص قاعدة البيانات #{overview.database_audit_id}: {overview.database_count} رابطًا جاهزًا.\n"
            "اختر عدد الروابط الثابتة لكل حساب:",
            reply_markup=join_limit_keyboard(),
        )


@router.callback_query(F.data == "join:start")
async def join_groups_start(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    await state.clear()
    overview = await get_join_source_overview(callback.from_user.id)
    await safe_answer(callback)
    if callback.message:
        if overview.latest_audit_id is None:
            await callback.message.answer(
                "لا يوجد فحص Telegram مكتمل بعد. نفّذ فحص الروابط أولًا؛ قسم الانضمام لا يجمع ولا يفحص الروابط بنفسه.",
                reply_markup=main_menu(),
            )
            return
        await callback.message.answer(
            f"اختر مصدر الانضمام من نتائج الفحص #{overview.latest_audit_id}.\n"
            f"الجاهز: {overview.all_count} — مجموعات: {overview.groups_count} — قنوات: {overview.channels_count}.\n"
            "سيتم استخدام روابط مفحوصة محفوظة فقط، بدون إعادة فحص جماعي داخل قسم الانضمام.",
            reply_markup=join_source_keyboard(overview),
        )


@router.callback_query(F.data.regexp(r"^join:source:(all|groups|channels|database):\d+$"))
async def join_source_select(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    parts = str(callback.data).split(":")
    source_kind = parts[2]
    audit_id = int(parts[3])
    overview = await get_join_source_overview(callback.from_user.id)
    valid = False
    count = 0
    if source_kind == "database":
        valid = overview.database_audit_id == audit_id
        count = overview.database_count
    elif overview.latest_audit_id == audit_id:
        valid = True
        count = {"all": overview.all_count, "groups": overview.groups_count, "channels": overview.channels_count}[source_kind]
    if not valid or count <= 0:
        await safe_answer(callback, "هذا المصدر لم يعد متاحًا أو لا يحتوي روابط جاهزة.", show_alert=True)
        return
    await state.update_data(join_source_kind=source_kind, join_audit_id=audit_id)
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            f"المصدر يحتوي {count} رابطًا مفحوصًا جاهزًا.\n"
            "اختر التوزيع. كل رابط سيُحجز لحساب واحد فقط، والحساب الأخير يأخذ الباقي المتاح ضمن السعة.",
            reply_markup=join_limit_keyboard(),
        )


@router.callback_query(F.data.startswith("join:limit:"))
async def join_groups_limit_handler(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    try:
        per_account = int(callback.data.rsplit(":", 1)[1])
    except (TypeError, ValueError):
        per_account = 0
    if per_account not in {200, 500}:
        await safe_answer(callback, "خيار غير صالح.", show_alert=True)
        return
    data = await state.get_data()
    source_kind = str(data.get("join_source_kind") or "")
    audit_id = int(data.get("join_audit_id") or 0)
    if source_kind not in {"all", "groups", "channels", "database"} or audit_id <= 0:
        await safe_answer(callback, "اختر مصدر الروابط المفحوصة أولًا.", show_alert=True)
        return
    try:
        job = await stage_join_job(
            callback.from_user.id, audit_id=audit_id, source_kind=source_kind, per_account=per_account
        )
    except Exception as exc:
        await safe_answer(callback, str(exc)[:180], show_alert=True)
        return
    await state.clear()
    planned = dict(job.progress or {})
    await safe_answer(callback, "تم إنشاء مهمة الانضمام والتوزيع الثابت.", show_alert=True)
    if callback.message:
        await callback.message.answer(
            f"مهمة الانضمام #{job.id}\n"
            f"الموزع: {planned.get('join_assigned', 0)} رابطًا على {planned.get('join_accounts_planned', 0)} حسابًا.\n"
            f"الحد: {per_account} رابط لكل حساب.\n"
            f"غير موزع بسبب سعة الحسابات: {planned.get('join_unassigned_due_capacity', 0)}.\n"
            "قبل بدء الانضمام سيحفظ كل حساب نسخة من روابط حصته في الرسائل المحفوظة (Saved Messages).",
            reply_markup=main_menu(),
        )


@router.callback_query(F.data.startswith("leave:prepare:"))
async def leave_join_prepare(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    try:
        join_job_id = int(callback.data.rsplit(":", 1)[1])
    except (TypeError, ValueError):
        await safe_answer(callback, "رقم المهمة غير صالح.", show_alert=True)
        return
    async with SessionFactory() as session:
        join_job = await session.get(Job, join_job_id)
    if (
        join_job is None
        or join_job.mode != "join_groups"
        or int(join_job.requested_by) != int(callback.from_user.id)
    ):
        await safe_answer(callback, "مهمة الانضمام غير موجودة أو لا تخصك.", show_alert=True)
        return
    await seed_legacy_assignments_for_job(join_job)
    if join_job.status in {"queued", "starting", "running", "pause_requested", "stopping"}:
        await safe_answer(callback, "أوقف مهمة الانضمام قبل المغادرة.", show_alert=True)
        return
    count = await count_leave_targets(join_job_id)
    await safe_answer(callback)
    if callback.message:
        if count <= 0:
            await callback.message.answer(
                "لا توجد عضويات مسجلة قابلة للمغادرة في هذه المهمة.",
                reply_markup=main_menu(),
            )
            return
        await callback.message.answer(
            f"سيغادر البوت {count} عضوية مسجلة ضمن مهمة الانضمام #{join_job_id} فقط. "
            "لن يلمس أي مجموعة لم يسجلها البوت في هذه المهمة. العملية لا تحذف الحسابات أو الجلسات أو قاعدة الروابط.",
            reply_markup=leave_join_confirm_keyboard(join_job_id),
        )


@router.callback_query(F.data.startswith("leave:confirm:"))
async def leave_join_confirm(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    try:
        join_job_id = int(callback.data.rsplit(":", 1)[1])
    except (TypeError, ValueError):
        await safe_answer(callback, "رقم المهمة غير صالح.", show_alert=True)
        return
    async with SessionFactory() as session:
        join_job = await session.get(Job, join_job_id)
    if (
        join_job is None
        or join_job.mode != "join_groups"
        or int(join_job.requested_by) != int(callback.from_user.id)
    ):
        await safe_answer(callback, "مهمة الانضمام غير موجودة أو لا تخصك.", show_alert=True)
        return
    if join_job.status in {"queued", "starting", "running", "pause_requested", "stopping"}:
        await safe_answer(callback, "أوقف مهمة الانضمام قبل المغادرة.", show_alert=True)
        return
    count = await count_leave_targets(join_job_id)
    if count <= 0:
        await safe_answer(callback, "لا توجد عضويات متبقية للمغادرة.", show_alert=True)
        return
    cleanup_job = await create_job(
        callback.from_user.id,
        mode="leave_joined",
        scope="tracked",
        category="telegram",
        initial_progress={"source_join_job_id": join_job_id, "leave_total": count},
    )
    await log_admin_action(
        callback.from_user.id,
        "leave_join_task_confirmed",
        f"source_job={join_job_id};cleanup_job={cleanup_job.id};targets={count}",
    )
    await safe_answer(callback, "تم إنشاء مهمة المغادرة.", show_alert=True)
    if callback.message:
        await callback.message.answer(
            f"مهمة المغادرة #{cleanup_job.id} أُضيفت للطابور. الهدف: {count} عضوية من المهمة #{join_job_id}.",
            reply_markup=main_menu(),
        )


async def _send_generated_session(message: Message, bot: Bot, user_id: int, package: dict[str, object]) -> None:
    """Persist the newly authenticated account encrypted; never expose raw session credentials in chat."""
    account_data = {
        "session_string": str(package["session"]),
        "api_id": int(package["api_id"]),
        "api_hash": str(package["api_hash"]),
        "telegram_user_id": int(package["telegram_user_id"]),
        "phone": package.get("phone"),
        "username": package.get("username"),
        "display_name": str(package.get("label") or "حساب Telegram"),
    }
    account_id = await save_account(str(package.get("label") or "حساب Telegram"), account_data, int(user_id))
    await session_event(int(user_id), "session_created", account_id=account_id, detail=f"telegram_user_id={package.get('telegram_user_id')}")
    await bot.send_message(
        int(user_id),
        "✅ تم إنشاء جلسة Telethon وحفظها مشفرة داخل البوت.\n"
        f"الحساب المحلي: #{account_id}\n"
        f"Telegram ID: {package.get('telegram_user_id')}\n"
        f"Username: @{package.get('username') or '-'}\n\n"
        "🔐 لأمان الحساب لا يعرض V8 Session String أو API_HASH الخام داخل المحادثات أو السجلات. "
        "يمكنك فحص الجلسة وإيقافها أو حذفها محليًا من مركز الجلسات.",
    )


@router.callback_query(F.data == "session:generate")
async def session_generate_start(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_session_tool(callback):
        return
    if not callback.message or callback.message.chat.type != ChatType.PRIVATE:
        await safe_answer(callback, "استخراج الجلسة يعمل في المحادثة الخاصة فقط.", show_alert=True)
        return
    await cancel_login(callback.from_user.id)
    await state.clear()
    await state.set_state(SessionExtractState.waiting_phone)
    await safe_answer(callback)
    await callback.message.answer(
        "أرسل رقم حساب Telegram بالصيغة الدولية مثل +9677XXXXXXXX. سيطلب Telegram رمز تسجيل الدخول، وقد يطلب كلمة مرور التحقق بخطوتين. تُحذف الرسائل الحساسة بعد معالجتها قدر الإمكان.",
        reply_markup=session_extract_cancel_keyboard(),
    )


@router.message(SessionExtractState.waiting_phone, F.text)
async def session_generate_phone(message: Message, state: FSMContext) -> None:
    if await reject_non_session_tool(message):
        return
    if message.chat.type != ChatType.PRIVATE:
        return
    try:
        await begin_login(message.from_user.id, message.text or "")
        await state.set_state(SessionExtractState.waiting_code)
        await message.answer("أرسل رمز تسجيل الدخول الذي وصلك من Telegram. يمكنك كتابته بأرقام فقط.", reply_markup=session_extract_cancel_keyboard())
    except Exception as exc:
        await message.answer(f"تعذر إرسال رمز تسجيل الدخول: {exc}", reply_markup=session_extract_cancel_keyboard())
    finally:
        try:
            await message.delete()
        except Exception:
            pass


@router.message(SessionExtractState.waiting_code, F.text)
async def session_generate_code(message: Message, state: FSMContext, bot: Bot) -> None:
    if await reject_non_session_tool(message):
        return
    try:
        status, package = await submit_code(message.from_user.id, message.text or "")
        if status == "password":
            await state.set_state(SessionExtractState.waiting_password)
            await message.answer("الحساب محمي بالتحقق بخطوتين. أرسل كلمة مرور Telegram 2FA.", reply_markup=session_extract_cancel_keyboard())
            return
        await state.clear()
        if package:
            await _send_generated_session(message, bot, message.from_user.id, package)
            await message.answer("تمت العملية.", reply_markup=await _menu_for_user(message.from_user.id))
    except Exception as exc:
        await message.answer(f"تعذر تسجيل الدخول: {exc}", reply_markup=session_extract_cancel_keyboard())
    finally:
        try:
            await message.delete()
        except Exception:
            pass


@router.message(SessionExtractState.waiting_password, F.text)
async def session_generate_password(message: Message, state: FSMContext, bot: Bot) -> None:
    if await reject_non_session_tool(message):
        return
    try:
        package = await submit_password(message.from_user.id, message.text or "")
        await state.clear()
        await _send_generated_session(message, bot, message.from_user.id, package)
        await message.answer("تمت العملية.", reply_markup=await _menu_for_user(message.from_user.id))
    except Exception as exc:
        await message.answer(f"تعذر إكمال تسجيل الدخول: {exc}", reply_markup=session_extract_cancel_keyboard())
    finally:
        try:
            await message.delete()
        except Exception:
            pass


@router.callback_query(F.data == "session:cancel")
async def session_generate_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_session_tool(callback):
        return
    await cancel_login(callback.from_user.id)
    await state.clear()
    await safe_answer(callback, "تم إلغاء استخراج الجلسة.")
    if callback.message:
        await callback.message.answer("لوحة التحكم:", reply_markup=await _menu_for_user(callback.from_user.id))


@router.callback_query(F.data == "accounts:add")
async def add_account_start(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    await state.clear()
    await state.set_state(AddAccountState.waiting_session)
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            "أضف حساب Telethon بإحدى الطرق التالية:\n"
            "• StringSession كنص.\n"
            "• JSON لحساب واحد أو قائمة حسابات.\n"
            "• ملف .session.\n\n"
            "يتحقق البوت من الجلسة ويستخرج بيانات الحساب ثم يحفظ الجلسة وAPI_HASH مشفرين، "
            "ويحاول حذف الرسالة الحساسة بعد الحفظ.\n\n"
            "إذا استخدمت StringSession أو .session بدون بيانات API داخل الحزمة، اضبط TELEGRAM_API_ID وTELEGRAM_API_HASH في .env.",
            reply_markup=cancel_keyboard(),
        )


async def _finish_account_add(message: Message, state: FSMContext, results: list[tuple[int, str]]) -> None:
    await state.clear()
    lines = ["تمت إضافة/تحديث الحسابات:"] + [f"#{account_id} — {label}" for account_id, label in results]
    await message.answer("\n".join(lines), reply_markup=main_menu())
    try:
        await message.delete()
    except Exception:
        pass


@router.message(AddAccountState.waiting_session, F.document)
async def add_account_document(message: Message, state: FSMContext, bot: Bot) -> None:
    if await reject_non_owner(message):
        return
    if not message.document:
        return
    data = await state.get_data()
    file_name = message.document.file_name or "session.bin"
    safe_name = re.sub(r"[^A-Za-z0-9_.-]", "_", file_name)
    temp_path = settings.tmp_dir / f"{message.from_user.id}_{message.document.file_unique_id}_{safe_name}"
    try:
        await bot.download(message.document, destination=temp_path)
        if file_name.lower().endswith(".session"):
            account_data = await convert_sqlite_session(temp_path, None)
            account_id = await save_account(str(account_data.get("display_name") or "حساب"), account_data, message.from_user.id)
            results = [(account_id, str(account_data.get("display_name") or "حساب"))]
        else:
            text = temp_path.read_text(encoding="utf-8-sig")
            packages = parse_session_packages(text)
            results = await add_packages(packages, message.from_user.id)
        await _finish_account_add(message, state, results)
    except Exception as exc:
        logger.exception("Account upload failed")
        await message.answer(f"تعذر إضافة الحساب: {exc}")
    finally:
        temp_path.unlink(missing_ok=True)


@router.message(AddAccountState.waiting_session, F.text)
async def add_account_text(message: Message, state: FSMContext) -> None:
    if await reject_non_owner(message):
        return
    try:
        packages = parse_session_packages(message.text or "")
        results = await add_packages(packages, message.from_user.id)
        await _finish_account_add(message, state, results)
    except Exception as exc:
        logger.exception("Account text import failed")
        await message.answer(f"تعذر إضافة الحساب: {exc}")


async def _render_accounts_page(callback: CallbackQuery, page: int = 0) -> None:
    accounts = await list_accounts(callback.from_user.id)
    page_size = max(1, settings.accounts_page_size)
    max_page = max(0, (len(accounts) - 1) // page_size) if accounts else 0
    page = min(max(0, int(page)), max_page)
    start_index = page * page_size
    page_accounts = accounts[start_index:start_index + page_size]
    if not accounts:
        text = "لا توجد حسابات مضافة."
    else:
        lines = [f"الحسابات المضافة ({len(accounts)}/{settings.max_telethon_accounts}) — صفحة {page + 1}/{max_page + 1}:"]
        for account in page_accounts:
            status = "فعال" if account.active else "متوقف"
            username = f"@{account.username}" if account.username else "بدون معرف"
            health = account.health_status or "healthy"
            health_score = 100
            if health not in {"healthy", "ok"}:
                health_score -= 25
            health_score -= min(30, int(account.consecutive_errors or 0) * 5)
            health_score -= min(20, int(account.errors_count or 0) // 10)
            if account.flood_wait_until:
                health_score -= 30
            health_score = max(0, health_score)
            flood = f" — FloodWait حتى {account.flood_wait_until}" if account.flood_wait_until else ""
            error = f" — آخر خطأ: {account.last_error[:70]}" if account.last_error else ""
            lines.append(
                f"#{account.id} — {account.label} — {username} — {status} — الصحة: {health} ({health_score}/100) — "
                f"طلبات: {account.requests_count or 0} — أخطاء: {account.errors_count or 0}{flood}{error}"
            )
        text = "\n".join(lines)
    if callback.message:
        await callback.message.answer(text, reply_markup=account_management_keyboard(accounts, page, page_size))


@router.callback_query(F.data.regexp(r"^accounts:list(?::\d+)?$"))
async def accounts_list_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    page = 0
    if callback.data and callback.data.startswith("accounts:list:"):
        try:
            page = max(0, int(callback.data.rsplit(":", 1)[1]))
        except ValueError:
            page = 0
    await safe_answer(callback)
    await _render_accounts_page(callback, page)


@router.callback_query(F.data == "accounts:export_sessions")
async def export_account_sessions_handler(callback: CallbackQuery, bot: Bot) -> None:
    if await reject_non_owner(callback):
        return
    await safe_answer(callback, "تم إيقاف تصدير Session String الخام في V8 حفاظًا على أمان الحساب.", show_alert=True)
    if callback.message:
        await callback.message.answer("استخدم «مركز الجلسات الآمن» لإدارة جلساتك. النسخ الاحتياطية لا تعرض أسرار الجلسات داخل Telegram.", reply_markup=v7_center_keyboard())


@router.callback_query(F.data.startswith("account:toggle:"))
async def toggle_account(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    parts = callback.data.split(":")
    account_id = int(parts[2])
    page = int(parts[3]) if len(parts) > 3 and parts[3].isdigit() else 0
    async with SessionFactory() as session:
        account = await session.get(Account, account_id)
        if not account or not await account_belongs_to_operator(account, callback.from_user.id):
            await safe_answer(callback, "الحساب غير موجود ضمن حساباتك.", show_alert=True)
            return
        account.active = not account.active
        account.last_error = None
        await session.commit()
    await log_admin_action(callback.from_user.id if callback.from_user else None, "account_toggle", f"account_id={account_id}")
    await safe_answer(callback, "تم تحديث حالة الحساب.", show_alert=True)
    await _render_accounts_page(callback, page)


@router.callback_query(F.data.startswith("account:test:"))
async def test_account_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    parts = callback.data.split(":")
    account_id = int(parts[2])
    await safe_answer(callback, "جارٍ اختبار الاتصال...")
    try:
        from app.services.accounts import test_account_connection

        info = await test_account_connection(account_id, callback.from_user.id)
        username = f"@{info['username']}" if info.get("username") else "بدون معرف"
        text = (
            f"الحساب #{account_id} متصل بنجاح.\n"
            f"الاسم: {info.get('display_name') or 'غير متوفر'}\n"
            f"المعرف: {username}\n"
            f"Telegram ID: {info.get('telegram_user_id')}"
        )
    except Exception as exc:
        logger.exception("Account connection test failed")
        text = f"فشل اختبار الحساب #{account_id}: {exc}"
    if callback.message:
        await callback.message.answer(text, reply_markup=back_menu())


@router.callback_query(F.data.startswith("account:delete:"))
async def delete_account_confirm(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    parts = callback.data.split(":")
    account_id = int(parts[2])
    page = int(parts[3]) if len(parts) > 3 and parts[3].isdigit() else 0
    async with SessionFactory() as session:
        account = await session.get(Account, account_id)
    if not account or not await account_belongs_to_operator(account, callback.from_user.id):
        await safe_answer(callback, "الحساب غير موجود ضمن حساباتك.", show_alert=True)
        return
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            f"هل تريد حذف الحساب #{account_id} نهائيًا من قاعدة البوت؟",
            reply_markup=confirm_delete_account_keyboard(account_id, page),
        )


@router.callback_query(F.data.startswith("account:delete_confirm:"))
async def delete_account(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    parts = callback.data.split(":")
    account_id = int(parts[2])
    page = int(parts[3]) if len(parts) > 3 and parts[3].isdigit() else 0
    async with SessionFactory() as session:
        account = await session.get(Account, account_id)
        if not account or not await account_belongs_to_operator(account, callback.from_user.id):
            await safe_answer(callback, "الحساب غير موجود ضمن حساباتك.", show_alert=True)
            return
        await session.delete(account)
        await session.commit()
    await log_admin_action(callback.from_user.id if callback.from_user else None, "account_delete", f"account_id={account_id}")
    await safe_answer(callback, "تم حذف الحساب.", show_alert=True)
    await _render_accounts_page(callback, page)


@router.callback_query(F.data == "destinations:configure")
async def configure_destinations(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    await state.clear()
    await state.update_data(purpose="configure")
    await state.set_state(DestinationState.waiting_all_destinations)
    await safe_answer(callback, )
    if callback.message:
        await callback.message.answer(destinations_prompt(), reply_markup=cancel_keyboard())


@router.callback_query(F.data == "collect:accounts")
async def collect_accounts(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    await state.clear()
    await state.update_data(flow="accounts")
    await safe_answer(callback, )
    if callback.message:
        await callback.message.answer(
            "اختر طريقة التجميع:\n\n"
            "⚡ السريع: يبحث Telegram عن الرسائل التي تحتوي روابط فقط.\n"
            "🔎 العميق: يمسح كل الرسائل ويستخرج الروابط منها.",
            reply_markup=collection_scan_mode_keyboard("scan_accounts"),
        )


@router.callback_query(F.data.startswith("scan_accounts:"))
async def accounts_scan_mode(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    scan_mode = callback.data.split(":", 1)[1]
    if scan_mode not in {"fast", "deep"}:
        await safe_answer(callback, "خيار غير صالح.", show_alert=True)
        return
    await state.update_data(collection_scan_mode=scan_mode, flow="accounts")
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer("اختر الفترة الزمنية:", reply_markup=scope_keyboard("scope_accounts"))


@router.callback_query(F.data.startswith("scope_accounts:"))
async def accounts_scope(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    scope = callback.data.split(":", 1)[1]
    await state.update_data(scope=scope, flow="accounts")
    saved = await get_destinations(callback.from_user.id)
    await safe_answer(callback, )
    if callback.message:
        if ALL_CATEGORIES.issubset(saved):
            await callback.message.answer(
                "هل تريد استخدام قنوات التجميع المحفوظة؟",
                reply_markup=destination_choice_keyboard("dest_accounts"),
            )
        else:
            await state.update_data(purpose="accounts")
            await state.set_state(DestinationState.waiting_all_destinations)
            await callback.message.answer(destinations_prompt(), reply_markup=cancel_keyboard())


@router.callback_query(F.data.startswith("dest_accounts:"))
async def accounts_destination_choice(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    choice = callback.data.split(":", 1)[1]
    await safe_answer(callback, )
    if choice == "saved":
        data = await state.get_data()
        destinations = await get_destinations(callback.from_user.id)
        job = await create_job(
            callback.from_user.id,
            mode="accounts",
            scope=str(data.get("scope") or "all"),
            destinations=destinations,
            collection_scan_mode=str(data.get("collection_scan_mode") or "fast"),
        )
        await state.clear()
        if callback.message:
            await callback.message.answer(
                f"تم إنشاء مهمة التجميع #{job.id}. سيصلك إشعار عند اكتمالها.", reply_markup=main_menu()
            )
    else:
        await state.update_data(purpose="accounts")
        await state.set_state(DestinationState.waiting_all_destinations)
        if callback.message:
            await callback.message.answer(destinations_prompt(), reply_markup=cancel_keyboard())


@router.callback_query(F.data == "collect:category")
async def collect_category(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    await state.clear()
    await safe_answer(callback, )
    if callback.message:
        await callback.message.answer("اختر القسم المطلوب:", reply_markup=category_keyboard())


@router.callback_query(F.data.startswith("category:"))
async def select_category(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    category = callback.data.split(":", 1)[1]
    if category not in ALL_CATEGORIES:
        await safe_answer(callback, "قسم غير صالح.", show_alert=True)
        return
    await state.update_data(category=category, flow="category")
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            f"اختر مصدر تجميع قسم {CATEGORY_LABELS[category]}:",
            reply_markup=category_origin_keyboard(),
        )


@router.callback_query(F.data.startswith("category_origin:"))
async def category_origin_handler(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    origin = callback.data.split(":", 1)[1]
    if origin not in {"accounts", "sources"}:
        await safe_answer(callback, "خيار غير صالح.", show_alert=True)
        return
    await state.update_data(category_origin=origin, flow="category")
    data = await state.get_data()
    category = str(data.get("category") or "")
    await safe_answer(callback)
    if callback.message:
        prefix = "scan_category" if origin == "accounts" else "scan_category_sources"
        await callback.message.answer(
            f"اختر طريقة تجميع قسم {CATEGORY_LABELS.get(category, category)}:",
            reply_markup=collection_scan_mode_keyboard(prefix),
        )


@router.callback_query(F.data.startswith("scan_category_sources:"))
async def category_sources_scan_mode(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    scan_mode = callback.data.split(":", 1)[1]
    if scan_mode not in {"fast", "deep"}:
        await safe_answer(callback, "خيار غير صالح.", show_alert=True)
        return
    await state.update_data(collection_scan_mode=scan_mode, category_origin="sources")
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer("اختر الفترة الزمنية:", reply_markup=scope_keyboard("scope_category_sources"))


@router.callback_query(F.data.startswith("scope_category_sources:"))
async def category_sources_scope(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    scope = callback.data.split(":", 1)[1]
    await state.update_data(scope=scope, category_origin="sources")
    await safe_answer(callback)
    if callback.message:
        await state.set_state(SourceState.waiting_sources)
        await callback.message.answer(
            "أرسل الآن روابط/معرفات/أرقام المجموعات أو القنوات المصدر، كل مصدر في سطر.\n"
            "سيتم حفظ روابط القسم المختار مباشرة في قاعدة البيانات المشتركة بدون الحاجة إلى قناة استقبال.",
            reply_markup=cancel_keyboard(),
        )


@router.callback_query(F.data.startswith("dest_category_sources:"))
async def category_sources_destination_choice(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    choice = callback.data.split(":", 1)[1]
    data = await state.get_data()
    category = str(data["category"])
    await safe_answer(callback)
    if choice == "saved":
        saved = await get_destinations(callback.from_user.id)
        await state.update_data(selected_destination=int(saved[category]), category_origin="sources")
        await state.set_state(SourceState.waiting_sources)
        if callback.message:
            await callback.message.answer(
                "أرسل الآن روابط/معرفات/أرقام المجموعات أو القنوات المصدر، كل مصدر في سطر.\n"
                "سيتم استخراج القسم المختار فقط بدون فحص صلاحية الروابط.",
                reply_markup=cancel_keyboard(),
            )
    else:
        await state.set_state(DestinationState.waiting_single_destination)
        if callback.message:
            await callback.message.answer(
                f"أرسل رابط/معرف/رقم قناة {CATEGORY_LABELS[category]} التي ستستقبل الروابط.",
                reply_markup=cancel_keyboard(),
            )


@router.callback_query(F.data.startswith("scan_category:"))
async def category_scan_mode(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    scan_mode = callback.data.split(":", 1)[1]
    if scan_mode not in {"fast", "deep"}:
        await safe_answer(callback, "خيار غير صالح.", show_alert=True)
        return
    await state.update_data(collection_scan_mode=scan_mode)
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer("اختر الفترة الزمنية:", reply_markup=scope_keyboard("scope_category"))


@router.callback_query(F.data.startswith("scope_category:"))
async def category_scope(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    scope = callback.data.split(":", 1)[1]
    await state.update_data(scope=scope)
    data = await state.get_data()
    category = str(data["category"])
    await state.update_data(purpose="category_accounts_destination")
    await safe_answer(callback, )
    if callback.message:
        await state.set_state(DestinationState.waiting_single_destination)
        await callback.message.answer(
            f"أرسل الآن رابط/معرف/رقم قناة Telegram التي تريد نشر روابط قسم {CATEGORY_LABELS[category]} إليها.\n"
            "هذه القناة تخص هذه المهمة فقط ولن تُحفظ كإعداد دائم.",
            reply_markup=cancel_keyboard(),
        )


@router.callback_query(F.data.startswith("dest_category:"))
async def category_destination_choice(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    choice = callback.data.split(":", 1)[1]
    data = await state.get_data()
    category = str(data["category"])
    await safe_answer(callback, )
    if choice == "saved":
        saved = await get_destinations(callback.from_user.id)
        job = await create_job(
            callback.from_user.id,
            mode="accounts",
            scope=str(data.get("scope") or "all"),
            category=category,
            destinations={category: saved[category]},
            collection_scan_mode=str(data.get("collection_scan_mode") or "fast"),
        )
        await state.clear()
        if callback.message:
            await callback.message.answer(f"تم إنشاء مهمة {CATEGORY_LABELS[category]} #{job.id}.", reply_markup=main_menu())
    else:
        await state.set_state(DestinationState.waiting_single_destination)
        if callback.message:
            await callback.message.answer(
                f"أرسل رابط/معرف/رقم قناة {CATEGORY_LABELS[category]}.", reply_markup=cancel_keyboard()
            )


@router.message(DestinationState.waiting_all_destinations)
async def all_destinations_message(message: Message, state: FSMContext, bot: Bot) -> None:
    if await reject_non_owner(message):
        return
    try:
        destinations = await parse_destinations(bot, message.text or "")
        missing = ALL_CATEGORIES - set(destinations)
        if missing:
            raise ValueError("القنوات الناقصة: " + ", ".join(CATEGORY_LABELS[item] for item in sorted(missing)))
        await save_destinations(message.from_user.id, destinations)
        data = await state.get_data()
        purpose = str(data.get("purpose") or "configure")
        if purpose == "accounts":
            job = await create_job(
                message.from_user.id,
                mode="accounts",
                scope=str(data.get("scope") or "all"),
                destinations=destinations,
                collection_scan_mode=str(data.get("collection_scan_mode") or "fast"),
            )
            text = f"تم حفظ القنوات وإنشاء مهمة التجميع #{job.id}."
        else:
            text = "تم حفظ قنوات التجميع الأربع والتحقق من صلاحيات البوت."
        await state.clear()
        await message.answer(text, reply_markup=main_menu())
    except Exception as exc:
        await message.answer(f"تعذر حفظ قنوات التجميع: {exc}")


@router.message(DestinationState.waiting_single_destination)
async def single_destination_message(message: Message, state: FSMContext, bot: Bot) -> None:
    if await reject_non_owner(message):
        return
    try:
        data = await state.get_data()
        category = str(data["category"])
        chat_id = await resolve_chat(bot, message.text or "")
        await validate_destination(bot, chat_id)
        if str(data.get("purpose") or "") == "category_accounts_destination":
            job = await create_job(
                message.from_user.id,
                mode="accounts",
                scope=str(data.get("scope") or "all"),
                category=category,
                destinations={category: chat_id},
                collection_scan_mode=str(data.get("collection_scan_mode") or "fast"),
            )
            await state.clear()
            await message.answer(
                f"تم إنشاء مهمة {CATEGORY_LABELS[category]} #{job.id}.\n"
                "ستُحفظ الروابط في قاعدة البيانات، وسيُنشر الجديد أيضًا إلى قناة هذه المهمة.",
                reply_markup=main_menu(),
            )
            return

        # Backward-compatible path for old inline messages from pre-6.5 builds.
        saved = await get_destinations(message.from_user.id)
        saved[category] = chat_id
        await save_destinations(message.from_user.id, saved)
        if str(data.get("category_origin") or "accounts") == "sources":
            await state.update_data(selected_destination=chat_id, category_origin="sources")
            await state.set_state(SourceState.waiting_sources)
            await message.answer(
                "أرسل الآن روابط/معرفات/أرقام المجموعات أو القنوات المصدر، كل مصدر في سطر.\n"
                "سيتم استخراج القسم المختار فقط بدون فحص صلاحية الروابط.",
                reply_markup=cancel_keyboard(),
            )
        else:
            job = await create_job(
                message.from_user.id,
                mode="accounts",
                scope=str(data.get("scope") or "all"),
                category=category,
                destinations={category: chat_id},
                collection_scan_mode=str(data.get("collection_scan_mode") or "fast"),
            )
            await state.clear()
            await message.answer(f"تم إنشاء مهمة {CATEGORY_LABELS[category]} #{job.id}.", reply_markup=main_menu())
    except Exception as exc:
        await message.answer(f"تعذر إنشاء المهمة: {exc}")


@router.callback_query(F.data == "collect:sources")
async def collect_sources(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    await state.clear()
    await safe_answer(callback, )
    if callback.message:
        await callback.message.answer(
            "اختر طريقة مسح المصادر:",
            reply_markup=collection_scan_mode_keyboard("scan_sources"),
        )


@router.callback_query(F.data.startswith("scan_sources:"))
async def sources_scan_mode(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    scan_mode = callback.data.split(":", 1)[1]
    if scan_mode not in {"fast", "deep"}:
        await safe_answer(callback, "خيار غير صالح.", show_alert=True)
        return
    await state.update_data(collection_scan_mode=scan_mode)
    await state.set_state(SourceState.waiting_sources)
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            "أرسل روابط/معرفات/أرقام القنوات أو المجموعات المصدر، كل مصدر في سطر.\n\n"
            "سيتم استخراج الروابط منها فقط دون فحص صلاحيتها. يمكن لاحقًا تصدير نتائج المهمة.",
            reply_markup=cancel_keyboard(),
        )


@router.message(SourceState.waiting_sources)
async def sources_message(message: Message, state: FSMContext) -> None:
    if await reject_non_owner(message):
        return
    sources = parse_sources(message.text or "")
    if not sources:
        await message.answer("لم أجد روابط أو معرفات مصادر صالحة.")
        return
    data = await state.get_data()
    category = str(data.get("category") or "").strip() or None
    if str(data.get("category_origin") or "") == "sources" and category:
        job = await create_job(
            message.from_user.id, mode="sources", scope=str(data.get("scope") or "all"),
            category=category, sources=sources, destinations={},
            collection_scan_mode=str(data.get("collection_scan_mode") or "fast"),
        )
        text = (
            f"تم إنشاء مهمة تجميع {CATEGORY_LABELS[category]} من المصادر #{job.id}. "
            f"عدد المصادر: {len(sources)}.\n"
            "سيتم حفظ الروابط في قاعدة البيانات فقط، ولن يتم فحص صلاحيتها أثناء التجميع."
        )
    else:
        saved = await get_destinations(message.from_user.id)
        job = await create_job(
            message.from_user.id, mode="sources", sources=sources, destinations=saved,
            collection_scan_mode=str(data.get("collection_scan_mode") or "fast"),
        )
        text = f"تم إنشاء مهمة تجميع المصادر #{job.id}. عدد المصادر: {len(sources)}. بدون فحص صلاحية الروابط."
    await state.clear()
    await message.answer(text, reply_markup=main_menu())


@router.callback_query(F.data == "manual:start")
async def manual_start(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    await state.clear()
    await state.set_state(ManualLinksState.waiting_links)
    await safe_answer(callback, )
    if callback.message:
        await callback.message.answer(
            "أرسل رابطًا واحدًا أو عدة روابط. سيُحفظ الجديد مباشرة في قاعدة البيانات المشتركة، "
            "وسيُبلغك البوت بالمكرر والمرفوض.",
            reply_markup=cancel_keyboard(),
        )


@router.message(ManualLinksState.waiting_links)
async def manual_links(message: Message, state: FSMContext, bot: Bot) -> None:
    if await reject_non_owner(message):
        return
    text = (message.text or message.caption or "").strip()
    urls = extract_urls_from_text(text)
    if not urls:
        await message.answer("لم أجد روابط HTTP/HTTPS في الرسالة.")
        return
    counts = {
        "new": 0,
        "duplicate": 0,
        "phone": 0,
        "telegram_message": 0,
        "invalid": 0,
        "expired_blocklist": 0,
    }
    category_counts = {key: 0 for key in ALL_CATEGORIES}
    for raw_url in urls:
        inspection = inspect_collection_link(raw_url)
        if not inspection.link:
            reason = inspection.reason or "invalid"
            counts[reason] = counts.get(reason, 0) + 1
            continue
        clean = inspection.link
        registration = await register_link(
            clean,
            origin="manual",
            job_id=None,
            account_id=None,
            chat_id=message.chat.id,
            message_id=message.message_id,
            message_date=message.date,
        )
        if registration.blocked or registration.link is None:
            counts["expired_blocklist"] += 1
        elif registration.created:
            counts["new"] += 1
            category_counts[clean.category] += 1
        else:
            counts["duplicate"] += 1
    await state.clear()
    lines = [
        "انتهت معالجة الروابط اليدوية:",
        f"الجديدة: {counts['new']}",
        f"المكررة سابقًا: {counts['duplicate']}",
        f"المرفوضة بسبب رقم هاتف: {counts['phone']}",
        f"روابط رسائل تليجرام المستبعدة: {counts['telegram_message']}",
        f"روابط Telegram المنتهية المحظورة دائمًا: {counts['expired_blocklist']}",
        f"غير الصالحة: {counts['invalid']}",
        "الحفظ: قاعدة البيانات المشتركة فقط",
    ]
    for category in ("whatsapp", "twitter", "telegram", "other"):
        if category_counts[category]:
            lines.append(f"{CATEGORY_LABELS[category]}: {category_counts[category]}")
    await message.answer("\n".join(lines), reply_markup=main_menu())


@router.callback_query(F.data.startswith("continue:"))
async def continue_completed_job(callback: CallbackQuery) -> None:
    """Requeue the SAME completed collection task in incremental mode.

    Job cursors are cleared, while the global collection high-water marks are
    retained. Therefore the next run reads only messages newer than the last
    successful scan and never repeats already committed URLs.
    """
    if await reject_non_owner(callback):
        return
    job_id = int(callback.data.split(":", 1)[1])
    async with SessionFactory() as session:
        job = await session.get(Job, job_id)
        if (
            not job
            or job.requested_by != callback.from_user.id
            or job.mode not in {"accounts", "sources", "join_groups"}
            or job.status not in {"completed", "completed_with_errors", "failed"}
        ):
            await safe_answer(callback, "المهمة غير متاحة للاستكمال.", show_alert=True)
            return

        old_progress = dict(job.progress or {})
        preserved: dict[str, object] = {
            "continuation_runs": int(old_progress.get("continuation_runs", 0) or 0) + 1,
        }
        if old_progress.get("collection_scan_mode") in {"fast", "deep"}:
            preserved["collection_scan_mode"] = old_progress["collection_scan_mode"]
        if job.mode == "join_groups":
            preserved["join_per_account"] = int(old_progress.get("join_per_account", 200) or 200)
            preserved["join_delay_seconds"] = max(180, int(old_progress.get("join_delay_seconds", 180) or 180))

        await session.execute(delete(JobCursor).where(JobCursor.job_id == job.id))
        job.scope = "new"
        job.status = "queued"
        job.progress = preserved
        job.error = None
        job.started_at = None
        job.finished_at = None
        job.paused_at = None
        job.updated_at = utcnow()
        await session.commit()

    await safe_answer(callback, "تمت جدولة الاستكمال من آخر نقطة ناجحة.", show_alert=True)
    if callback.message:
        await callback.message.answer(
            f"المهمة #{job_id} ستفحص الجديد فقط من آخر تجميع ناجح، بنفس رقم المهمة ودون إعادة الروابط القديمة.",
            reply_markup=main_menu(),
        )


@router.callback_query(F.data == "watches:list")
async def list_watches(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    async with SessionFactory() as session:
        watches = list(
            (
                await session.scalars(
                    select(WatchConfig)
                    .where(WatchConfig.requested_by == callback.from_user.id)
                    .order_by(WatchConfig.id.desc())
                )
            ).all()
        )
    await safe_answer(callback, )
    if watches:
        lines = ["مهام الاستمرار:"]
        for watch in watches:
            cats = ", ".join(CATEGORY_LABELS.get(c, c) for c in watch.categories)
            lines.append(f"#{watch.id} — {'فعال' if watch.enabled else 'متوقف'} — {cats}")
        text = "\n".join(lines)
    else:
        text = "لا توجد مهام استمرار."
    if callback.message:
        await callback.message.answer(text, reply_markup=watches_keyboard(watches))


@router.callback_query(F.data.startswith("watch:toggle:"))
async def toggle_watch(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    watch_id = int(callback.data.rsplit(":", 1)[1])
    async with SessionFactory() as session:
        watch = await session.get(WatchConfig, watch_id)
        if not watch or watch.requested_by != callback.from_user.id:
            await safe_answer(callback, "المتابعة غير موجودة.", show_alert=True)
            return
        watch.enabled = not watch.enabled
        await session.commit()
    await safe_answer(callback, "تم تحديث المتابعة.", show_alert=True)
    await list_watches(callback)


@router.callback_query(F.data == "jobs:list")
async def jobs_list(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    primary = await is_primary_owner(callback.from_user.id)
    async with SessionFactory() as session:
        stmt = select(Job)
        if not primary:
            stmt = stmt.where(Job.requested_by == callback.from_user.id)
        jobs = list((await session.scalars(stmt.order_by(Job.id.desc()).limit(30))).all())
    await safe_answer(callback, )
    if jobs:
        lines = ["آخر المهام:"]
        for job in jobs:
            progress = job.progress or {}
            if job.mode == "telegram_audit":
                checked = progress.get("checked", progress.get("inputs", 0) if job.status == "completed" else 0)
                total = progress.get("total", progress.get("inputs", 0))
                extra = f"{checked}/{total}"
                if progress.get("links_per_minute"):
                    extra += f" — {progress.get('links_per_minute')} رابط/د"
            elif job.mode == "join_groups":
                extra = (
                    f"موزع {progress.get('join_assigned', 0)} / "
                    f"ناجح {progress.get('join_joined', 0)} / "
                    f"طلبات {progress.get('join_requested', 0)} / "
                    f"أخطاء {progress.get('join_errors', 0)}"
                )
            else:
                mode_value = str(progress.get("collection_scan_mode") or "")
                mode_label = "⚡ سريع" if mode_value == "fast" else ("🔎 عميق" if mode_value == "deep" else "")
                extra = f"جديد {progress.get('new_links', 0)} / مكرر {progress.get('duplicate_links', 0)}"
                if mode_label:
                    extra = f"{mode_label} — {extra}"
            owner_suffix = f" — المشرف {job.requested_by}" if primary else ""
            lines.append(
                f"#{job.id} — {job.mode} — {STATUS_LABELS.get(job.status, job.status)} — {extra}{owner_suffix}"
            )
        text = "\n".join(lines)
    else:
        text = "لا توجد مهام."
    if callback.message:
        await callback.message.answer(text, reply_markup=jobs_keyboard(jobs))


@router.callback_query(F.data.startswith("job:pause:"))
async def pause_job(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    job_id = int(callback.data.rsplit(":", 1)[1])
    async with SessionFactory() as session:
        job = await session.get(Job, job_id)
        if not job or job.requested_by != callback.from_user.id or job.status not in {"starting", "running"}:
            await safe_answer(callback, "لا يمكن إيقاف هذه المهمة مؤقتًا.", show_alert=True)
            return
        job.status = "pause_requested"
        job.updated_at = utcnow()
        if job.audit_id:
            audit = await session.get(TelegramAudit, job.audit_id)
            if audit:
                audit.status = "pause_requested"
                audit.updated_at = utcnow()
        await session.commit()
    await safe_answer(callback, "تم طلب الإيقاف المؤقت. سيحفظ البوت آخر نقطة مكتملة أولًا.", show_alert=True)


@router.callback_query(F.data.startswith("job:resume:"))
async def resume_job(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    job_id = int(callback.data.rsplit(":", 1)[1])
    async with SessionFactory() as session:
        job = await session.get(Job, job_id)
        if not job or job.requested_by != callback.from_user.id or job.status != "paused":
            await safe_answer(callback, "المهمة ليست متوقفة مؤقتًا.", show_alert=True)
            return
        job.status = "queued"
        job.error = None
        job.paused_at = None
        job.finished_at = None
        job.updated_at = utcnow()
        if job.audit_id:
            audit = await session.get(TelegramAudit, job.audit_id)
            if audit:
                audit.status = "queued"
                audit.error = None
                audit.paused_at = None
                audit.finished_at = None
                audit.current_phase = "queued"
                audit.updated_at = utcnow()
        await session.commit()
    await safe_answer(callback, "تمت إعادة المهمة إلى الطابور وستستكمل من آخر checkpoint محفوظ.", show_alert=True)


@router.callback_query(F.data.startswith("job:cancel:"))
async def cancel_job(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    job_id = int(callback.data.rsplit(":", 1)[1])
    async with SessionFactory() as session:
        job = await session.get(Job, job_id)
        if not job or job.requested_by != callback.from_user.id or job.status not in {
            "queued", "starting", "running", "pause_requested", "paused", "stopping"
        }:
            await safe_answer(callback, "لا يمكن إلغاء المهمة.", show_alert=True)
            return
        immediate = job.status in {"queued", "paused"}
        job.status = "cancelled" if immediate else "cancel_requested"
        job.updated_at = utcnow()
        if immediate:
            job.finished_at = utcnow()
        if job.audit_id:
            audit = await session.get(TelegramAudit, job.audit_id)
            if audit and immediate:
                audit.status = "cancelled"
                audit.finished_at = utcnow()
                audit.updated_at = utcnow()
                audit.current_phase = "cancelled"
        await session.commit()
    await safe_answer(callback, "تم إلغاء المهمة." if immediate else "تم طلب إلغاء المهمة بأمان.", show_alert=True)


@router.callback_query(F.data.startswith("job:retry:"))
async def retry_job(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    job_id = int(callback.data.rsplit(":", 1)[1])
    async with SessionFactory() as session:
        job = await session.get(Job, job_id)
        if not job or job.requested_by != callback.from_user.id or job.status not in {
            "failed", "cancelled", "completed_with_errors"
        }:
            await safe_answer(callback, "المهمة غير قابلة للإعادة.", show_alert=True)
            return
        # Preserve progress and durable cursors. Idempotency constraints make a
        # retry continue rather than duplicate already committed work.
        job.status = "queued"
        job.error = None
        job.finished_at = None
        job.paused_at = None
        job.updated_at = utcnow()
        if job.audit_id:
            audit = await session.get(TelegramAudit, job.audit_id)
            if audit:
                audit.status = "queued"
                audit.finished_at = None
                audit.paused_at = None
                audit.error = None
                audit.current_phase = "queued"
                audit.updated_at = utcnow()
        await session.commit()
    await safe_answer(callback, "أعيدت المهمة إلى الطابور مع الاحتفاظ بالتقدم السابق.", show_alert=True)


async def _send_text_export_files(
    bot: Bot,
    chat_id: int,
    bundle,  # ExportBundle; kept untyped to avoid coupling the router to exporter internals.
    *,
    title: str,
) -> None:
    if not bundle.text_files:
        await bot.send_message(chat_id, f"{title}: لا توجد روابط قابلة للتصدير.")
        return

    await bot.send_message(
        chat_id,
        f"{title}\n"
        f"إجمالي الروابط: {bundle.total_links}\n"
        f"عدد الملفات: {len(bundle.text_files)}.",
    )
    for index, file_path in enumerate(bundle.text_files, start=1):
        category = file_path.stem.rsplit("_", 1)[0]
        caption = (
            f"{CATEGORY_LABELS.get(category, category)} - "
            f"ملف {index}/{len(bundle.text_files)}"
        )
        await bot.send_document(chat_id, FSInputFile(file_path), caption=caption)
        if settings.export_send_delay_seconds > 0:
            await asyncio.sleep(settings.export_send_delay_seconds)


async def _validate_export_job(callback: CallbackQuery, job_id: int) -> Job | None:
    async with SessionFactory() as session:
        job = await session.get(Job, job_id)
    if not job or job.requested_by != callback.from_user.id:
        await safe_answer(callback, "المهمة غير موجودة أو لا تملك صلاحيتها.", show_alert=True)
        return None
    return job


@router.callback_query(F.data.startswith("export:txt:"))
async def export_txt_callback(callback: CallbackQuery, bot: Bot) -> None:
    if await reject_non_primary(callback):
        return
    job_id = int(callback.data.rsplit(":", 1)[1])
    if not await _validate_export_job(callback, job_id):
        return
    await safe_answer(callback, "جارٍ إنشاء ملفات TXT.")
    bundle = await export_job(job_id)
    await _send_text_export_files(
        bot,
        callback.from_user.id,
        bundle,
        title=f"تصدير روابط المهمة #{job_id}",
    )


@router.callback_query(F.data.startswith("export:zip:"))
async def export_zip_callback(callback: CallbackQuery, bot: Bot) -> None:
    if await reject_non_primary(callback):
        return
    job_id = int(callback.data.rsplit(":", 1)[1])
    if not await _validate_export_job(callback, job_id):
        return
    await safe_answer(callback, "جارٍ إنشاء ملف ZIP.")
    bundle = await export_job(job_id)
    if not bundle.text_files:
        await bot.send_message(callback.from_user.id, "لا توجد روابط قابلة للتصدير في هذه المهمة.")
        return
    await bot.send_document(
        callback.from_user.id,
        FSInputFile(bundle.zip_path),
        caption=(
            f"ملف ZIP للمهمة #{job_id}\n"
            f"يحتوي {len(bundle.text_files)} ملف TXT و{bundle.total_links} رابطًا."
        ),
    )


# Backward compatibility with buttons created by older releases.
@router.callback_query(F.data.regexp(r"^export:\d+$"))
async def legacy_export_callback(callback: CallbackQuery, bot: Bot) -> None:
    if await reject_non_primary(callback):
        return
    job_id = int(callback.data.rsplit(":", 1)[1])
    if not await _validate_export_job(callback, job_id):
        return
    await safe_answer(callback, "جارٍ إنشاء ملفات TXT.")
    bundle = await export_job(job_id)
    await _send_text_export_files(
        bot,
        callback.from_user.id,
        bundle,
        title=f"تصدير روابط المهمة #{job_id}",
    )


@router.callback_query(F.data == "system:dashboard")
async def system_dashboard(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    operator_id = int(callback.from_user.id)
    operator_accounts = await list_accounts(operator_id)
    accounts_total = len(operator_accounts)
    accounts_active = sum(1 for account in operator_accounts if account.active)
    health_counts: dict[str, int] = {}
    for account in operator_accounts:
        key = str(account.health_status or "healthy")
        health_counts[key] = health_counts.get(key, 0) + 1
    async with SessionFactory() as session:
        jobs_running = int(await session.scalar(
            select(func.count(Job.id)).where(
                Job.requested_by == operator_id,
                Job.status.in_(["queued", "starting", "running", "pause_requested"]),
            )
        ) or 0)
        # The canonical link store is intentionally shared and globally deduplicated.
        # Supervisors may see only its count; actual link retrieval/export is owner-only.
        links_total = int(await session.scalar(select(func.count(Link.id))) or 0)
        audit_running = int(await session.scalar(
            select(func.count(TelegramAudit.id)).where(
                TelegramAudit.requested_by == operator_id,
                TelegramAudit.status.in_(["queued", "running", "paused"]),
            )
        ) or 0)
    usage = shutil.disk_usage(settings.data_dir)
    health = " | ".join(f"{status}={count}" for status, count in sorted(health_counts.items())) or "لا بيانات"
    text = (
        f"🚀 لوحة تحكم V8 — {settings.instance_name}\n"
        f"جميع الوظائف متاحة في هذه النسخة\n\n"
        f"الحسابات: {accounts_active}/{accounts_total} فعالة\n"
        f"صحة الحسابات: {health}\n"
        f"المهام النشطة/بالطابور: {jobs_running}\n"
        f"عمليات الفحص النشطة/الموقوفة: {audit_running}\n"
        f"إجمالي الروابط الفريدة: {links_total}\n"
        f"استخدام مساحة data: {(usage.used / max(1, usage.total)) * 100:.1f}%\n"
        f"المساحة الحرة: {usage.free / (1024**3):.2f} GB"
    )
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(text, reply_markup=main_menu())


@router.callback_query(F.data == "search:start")
async def search_start(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_primary(callback):
        return
    await state.clear()
    await state.set_state(SearchState.waiting_query)
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer("أرسل الرابط الذي تريد البحث عنه في ذاكرة البوت.", reply_markup=cancel_keyboard())


@router.message(SearchState.waiting_query)
async def search_link_message(message: Message, state: FSMContext) -> None:
    if await reject_non_primary(message):
        return
    inspection = inspect_link((message.text or "").strip())
    if not inspection.link:
        await message.answer("لم أتعرف على رابط صالح. أرسل رابطًا كاملًا.")
        return
    url = inspection.link.normalized
    async with SessionFactory() as session:
        link = await session.scalar(select(Link).where(Link.normalized_url == url))
        if not link:
            await state.clear()
            await message.answer(f"غير موجود في قاعدة البوت:\n{url}", reply_markup=main_menu())
            return
        occ = int(await session.scalar(select(func.count(LinkOccurrence.id)).where(LinkOccurrence.link_id == link.id)) or 0)
        latest = await session.scalar(
            select(TelegramAuditResult).where(TelegramAuditResult.normalized_url == url).order_by(TelegramAuditResult.checked_at.desc()).limit(1)
        )
    lines = [
        f"الرابط: {url}",
        f"القسم: {CATEGORY_LABELS.get(link.category, link.category)}",
        f"أول ظهور: {link.created_at}",
        f"آخر ظهور: {link.last_seen_at}",
        f"عدد مرات الرصد: {link.seen_count}",
        f"مصادر/رسائل مسجلة: {occ}",
    ]
    if latest:
        lines.extend([f"آخر فحص: {latest.status}", f"تاريخ الفحص: {latest.checked_at}"])
    await state.clear()
    await message.answer("\n".join(lines), reply_markup=main_menu())


@router.callback_query(F.data == "database:stats")
async def database_stats(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    async with SessionFactory() as session:
        total = int(await session.scalar(select(func.count(Link.id))) or 0)
        rows = (await session.execute(select(Link.category, func.count(Link.id)).group_by(Link.category))).all()
        origin_rows = (await session.execute(select(Link.origin, func.count(Link.id)).group_by(Link.origin))).all()
        join_filter = [] if await is_primary_owner(callback.from_user.id) else [JoinCandidate.requested_by == callback.from_user.id]
        join_pending = int(await session.scalar(
            select(func.count(JoinCandidate.id)).where(
                *join_filter,
                JoinCandidate.status.in_(["pending", "retry", "ready_group"]),
            )
        ) or 0)
    by_category = {category: int(count) for category, count in rows}
    by_origin = {origin: int(count) for origin, count in origin_rows}
    lines = [f"إجمالي الروابط الفريدة: {total}"]
    for category in ("whatsapp", "twitter", "telegram", "other"):
        lines.append(f"{CATEGORY_LABELS[category]}: {by_category.get(category, 0)}")
    lines.append(f"روابط بانتظار الانضمام: {join_pending}")
    lines.append("\nحسب المصدر:")
    for origin, count in sorted(by_origin.items()):
        lines.append(f"{origin}: {count}")
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer("\n".join(lines), reply_markup=database_keyboard())


@router.callback_query(F.data == "database:export_txt")
async def database_export_txt(callback: CallbackQuery, bot: Bot) -> None:
    if await reject_non_primary(callback):
        return
    await safe_answer(callback, "جارٍ تجهيز ملفات TXT.")
    bundle = await export_database()
    await _send_text_export_files(
        bot,
        callback.from_user.id,
        bundle,
        title="تصدير جميع الروابط الفريدة",
    )


@router.callback_query(F.data == "database:export_zip")
async def database_export_zip(callback: CallbackQuery, bot: Bot) -> None:
    if await reject_non_primary(callback):
        return
    await safe_answer(callback, "جارٍ تجهيز ملف ZIP.")
    bundle = await export_database()
    if not bundle.text_files:
        await bot.send_message(callback.from_user.id, "قاعدة الروابط فارغة.")
        return
    await bot.send_document(
        callback.from_user.id,
        FSInputFile(bundle.zip_path),
        caption=(
            "ملف ZIP لجميع الروابط الفريدة\n"
            f"يحتوي {len(bundle.text_files)} ملف TXT و{bundle.total_links} رابطًا."
        ),
    )


# Backward compatibility with the old database export button.
@router.callback_query(F.data == "database:export")
async def legacy_database_export(callback: CallbackQuery, bot: Bot) -> None:
    if await reject_non_primary(callback):
        return
    await safe_answer(callback, "جارٍ تجهيز ملفات TXT.")
    bundle = await export_database()
    await _send_text_export_files(
        bot,
        callback.from_user.id,
        bundle,
        title="تصدير جميع الروابط الفريدة",
    )






# ---------------------------------------------------------------------------
# Telegram-only audit and filtering


def _audit_options_from_parts(mode: str, scope: str, pacing: str) -> dict[str, object]:
    if mode == "web":
        return {
            "engine": "web",
            "collect_whatsapp": False,
            "collect_telegram": False,
            "telegram_scope": "none",
            "pacing": "web",
        }
    collect_telegram = mode == "tg"
    return {
        "engine": "accounts",
        "collect_whatsapp": mode == "wa",
        "whatsapp_scope": scope if mode == "wa" else "none",
        "collect_telegram": collect_telegram,
        "telegram_scope": scope if collect_telegram else "none",
        "telegram_auto_full_history": False,
        "pacing": "fixed",
    }


async def _queue_audit_for_engine(audit_id: int, owner_id: int, sources: list[str] | None = None):
    audit = await get_audit(audit_id)
    options = (audit.summary or {}).get("options", {}) if audit else {}
    engine = str(options.get("engine") or "accounts") if isinstance(options, dict) else "accounts"
    if engine == "web":
        if sources:
            raise ValueError("فحص المتصفح يقبل روابط مباشرة/ملفات/قاعدة البيانات، وليس مصادر Telegram تحتاج جلسة.")
        return await queue_web_audit_job(audit_id, owner_id)
    return await queue_audit_job(audit_id, owner_id, sources=sources)


@router.callback_query(F.data == "expired:menu")
async def expired_links_menu_handler(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_primary(callback):
        return
    await state.clear()
    count = await expired_registry_count()
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            f"سجل الروابط المنتهية الدائم: {count} رابط/هوية Telegram.\nأي رابط هنا يُستبعد من الفحص الجديد ومن إعادة التجميع مستقبلًا.",
            reply_markup=expired_links_keyboard(),
        )


@router.callback_query(F.data == "expired:import_source")
async def expired_links_import_start(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_primary(callback):
        return
    await state.clear()
    await state.set_state(ExpiredLinksState.waiting_source)
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            "أرسل رابط/معرف القناة أو المجموعة التي تحتوي روابط Telegram المنتهية من فحوصك القديمة. سيقرأ البوت رسائل الروابط فقط، ويضيفها إلى سجل المنتهية حتى لا تُفحص مرة أخرى.",
            reply_markup=cancel_keyboard(),
        )


@router.message(ExpiredLinksState.waiting_source, F.text)
async def expired_links_import_source(message: Message, state: FSMContext) -> None:
    if await reject_non_primary(message):
        return
    sources = parse_sources(message.text or "")
    if len(sources) != 1:
        await message.answer("أرسل مصدر Telegram واحدًا فقط: @username أو رابط t.me أو ID قابلًا للقراءة بالحساب.")
        return
    await message.answer("بدأ استيراد سجل الروابط المنتهية. يستخدم فلتر رسائل الروابط لتقليل القراءة غير الضرورية.")
    try:
        result = await import_expired_from_source(message.from_user.id, sources[0])
        await state.clear()
        await log_admin_action(message.from_user.id, "expired_registry_import", json.dumps(result, ensure_ascii=False))
        await message.answer(
            "اكتمل استيراد المنتهية:\n"
            f"الرسائل المقروءة: {result['messages']}\n"
            f"الروابط المستخرجة: {result['found']}\n"
            f"أضيفت للسجل: {result['added']}\n"
            f"كانت موجودة مسبقًا: {result['existing']}\n"
            f"مرفوضة/غير Telegram: {result['rejected']}",
            reply_markup=expired_links_keyboard(),
        )
    except Exception as exc:
        await message.answer(f"تعذر استيراد قناة المنتهية: {exc}", reply_markup=expired_links_keyboard())


@router.callback_query(F.data == "expired:restore")
async def expired_links_restore_start(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_primary(callback):
        return
    await state.clear()
    await state.set_state(ExpiredLinksState.waiting_restore_url)
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            "أرسل رابط Telegram الذي حُظر بالخطأ. سيُزال من سجل المنتهية ويصبح قابلًا للتجميع والفحص من جديد.",
            reply_markup=cancel_keyboard(),
        )


@router.message(ExpiredLinksState.waiting_restore_url, F.text)
async def expired_links_restore_message(message: Message, state: FSMContext) -> None:
    if await reject_non_primary(message):
        return
    try:
        removed, normalized_url = await unblock_expired_url(message.text or "")
    except ValueError as exc:
        await message.answer(str(exc), reply_markup=cancel_keyboard())
        return
    await state.clear()
    if removed:
        await log_admin_action(message.from_user.id, "expired_registry_restore", normalized_url)
        text = f"تمت استعادة الرابط وإزالته من سجل المنتهية:\n{normalized_url}"
    else:
        text = f"الرابط غير موجود في سجل المنتهية:\n{normalized_url}"
    await message.answer(text, reply_markup=expired_links_keyboard())


@router.callback_query(F.data == "audit:menu")
async def telegram_audit_menu_handler(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    await state.clear()
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            "فحص وتصفية روابط Telegram — نظامان مستقلان:\n\n"
            "🌐 فحص المتصفح: يفحص معاينة t.me العامة بدون حسابات، لكنه لا يعلن أن الرابط منتهٍ نهائيًا؛ الإشارات الغامضة تحتاج تأكيد حساب.\n"
            "👥 فحص الحسابات: 10 حسابات × 4 روابط لكل حساب × راحة 120 ثانية. تجميع سجل المحادثات أصبح خيارًا منفصلًا.\n\n"
            "كل تقرير يدعم استكمال روابط قاعدة البيانات الجديدة من آخر High-Water محفوظ.",
            reply_markup=telegram_audit_menu_keyboard(),
        )


@router.callback_query(F.data == "audit:new")
async def telegram_audit_new_handler(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    await state.clear()
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            "اختر نظام فحص روابط Telegram:\n\n"
            "🌐 المتصفح: سريع ولا يستخدم حسابات Telethon أو طلبات Telegram API.\n"
            "👥 الحسابات: النظام الحالي 10×4×120، مع اختيار مستقل لتجميع الروابط من المحادثات.",
            reply_markup=telegram_audit_engine_keyboard(),
        )


@router.callback_query(F.data == "audit:engine:accounts")
async def telegram_audit_account_engine_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer("اختر نوع فحص الحسابات:", reply_markup=telegram_audit_mode_keyboard())


@router.callback_query(F.data == "audit:engine:web")
async def telegram_audit_web_engine_handler(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    await state.set_state(TelegramAuditState.waiting_title)
    await state.update_data(audit_mode="web", audit_scope="all", audit_pacing="web")
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            "فحص المتصفح سيقرأ معاينة t.me العامة بسرعة وبدون حسابات. أرسل عنوانًا للتقرير أو استخدم العنوان التلقائي.",
            reply_markup=telegram_audit_title_keyboard("web", "all", "web"),
        )


@router.callback_query(F.data == "audit:mode:plain")
async def telegram_audit_plain_mode_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            "سيتم فحص صلاحية روابط Telegram وتصنيفها فقط، دون مسح تاريخ كل قناة أو مجموعة.\n\n"
            "نظام الفحص ثابت: كل 10 حسابات، وكل حساب 4 روابط مختلفة بالتوازي، ثم راحة دقيقتين.",
            reply_markup=telegram_audit_pacing_keyboard("plain", "all"),
        )


@router.callback_query(F.data == "audit:mode:wa")
async def telegram_audit_wa_mode_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            "اختر الفترة الزمنية لجمع روابط واتساب من المجموعات/القنوات التي يمكن قراءتها دون انضمام:",
            reply_markup=telegram_audit_whatsapp_scope_keyboard(),
        )


@router.callback_query(F.data == "audit:mode:tg")
async def telegram_audit_tg_mode_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            "اختر الفترة التي تريد مسحها داخل القنوات والمجموعات القابلة للقراءة. الوضع السريع يفحص رسائل الروابط فقط، والتعليقات متوقفة افتراضيًا:",
            reply_markup=telegram_audit_telegram_scope_keyboard(),
        )


@router.callback_query(F.data.startswith("audit:tg_scope:"))
async def telegram_audit_tg_scope_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    scope = callback.data.rsplit(":", 1)[1]
    if scope not in SCOPE_LABELS:
        await safe_answer(callback, "الفترة غير صالحة.", show_alert=True)
        return
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            f"جمع Telegram: {SCOPE_LABELS[scope]}. أكد نظام الفحص الثابت:",
            reply_markup=telegram_audit_pacing_keyboard("tg", scope),
        )


@router.callback_query(F.data.startswith("audit:wa_scope:"))
async def telegram_audit_wa_scope_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    scope = callback.data.rsplit(":", 1)[1]
    if scope not in SCOPE_LABELS:
        await safe_answer(callback, "الفترة غير صالحة.", show_alert=True)
        return
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            f"جمع واتساب: {SCOPE_LABELS[scope]}. أكد نظام الفحص الثابت:",
            reply_markup=telegram_audit_pacing_keyboard("wa", scope),
        )


@router.callback_query(F.data.startswith("audit:pacing:"))
async def telegram_audit_pacing_handler(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    parts = callback.data.split(":")
    if len(parts) != 5:
        await safe_answer(callback, "إعداد الفحص غير صالح.", show_alert=True)
        return
    _, _, mode, scope, pacing = parts
    await state.set_state(TelegramAuditState.waiting_title)
    await state.update_data(audit_mode=mode, audit_scope=scope, audit_pacing=pacing)
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            "أرسل اسم القسم أو عنوان الفحص. هذا الاسم سيظهر في التقرير وسيُستخدم في أسماء ملفات TXT/CSV/JSON/ZIP.\n"
            "مثال: القسم الثالث - روابط اليمن\n\n"
            "أو اضغط «استخدام عنوان تلقائي».",
            reply_markup=telegram_audit_title_keyboard(mode, scope, pacing),
        )


@router.callback_query(F.data.startswith("audit:title:auto:"))
async def telegram_audit_auto_title_handler(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    parts = callback.data.split(":")
    if len(parts) != 6:
        await safe_answer(callback, "إعداد العنوان غير صالح.", show_alert=True)
        return
    _, _, _, mode, scope, pacing = parts
    await state.update_data(audit_title="", audit_mode=mode, audit_scope=scope, audit_pacing=pacing)
    await state.set_state(None)
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            "اختر مصدر روابط Telegram المراد فحصها:",
            reply_markup=(
                telegram_web_audit_source_keyboard(mode, scope, pacing)
                if mode == "web" else telegram_audit_source_keyboard(mode, scope, pacing)
            ),
        )


@router.message(TelegramAuditState.waiting_title, F.text)
async def telegram_audit_title_message(message: Message, state: FSMContext) -> None:
    if await reject_non_owner(message):
        return
    title = " ".join((message.text or "").split()).strip()[:160]
    if not title:
        await message.answer("أرسل عنوانًا صالحًا للقسم أو استخدم زر العنوان التلقائي.")
        return
    data = await state.get_data()
    mode = str(data.get("audit_mode") or "plain")
    scope = str(data.get("audit_scope") or "all")
    pacing = str(data.get("audit_pacing") or "conservative")
    await state.update_data(audit_title=title)
    await state.set_state(None)
    await message.answer(
        f"عنوان الفحص: {title}\nاختر الآن مصدر روابط Telegram:",
        reply_markup=(
            telegram_web_audit_source_keyboard(mode, scope, pacing)
            if mode == "web" else telegram_audit_source_keyboard(mode, scope, pacing)
        ),
    )


@router.callback_query(F.data.regexp(r"^audit:verifiers(?::\d+)?$"))
async def telegram_audit_verifiers_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    accounts = await list_accounts(callback.from_user.id)
    verifier_ids = await get_verifier_account_ids(callback.from_user.id)
    page = 0
    if callback.data and callback.data.startswith("audit:verifiers:"):
        try:
            page = max(0, int(callback.data.rsplit(":", 1)[1]))
        except ValueError:
            page = 0
    await safe_answer(callback)
    if callback.message:
        if not accounts:
            await callback.message.answer("لا توجد حسابات. أضف الحسابات أولًا.", reply_markup=telegram_audit_menu_keyboard())
            return
        await callback.message.answer(
            "حدد أدوار الحسابات:\n\n"
            "📊 أساسي = يدخل في مقارنة عضوية المجموعات ويحدد التكرار بين حساباتك الأساسية.\n"
            "🛡 تحقق = يشارك في فحص الصلاحية، ويُستبعد من مقارنة العضوية بين الحسابات الأساسية.\n\n"
            "اضغط على الحساب لتبديل دوره.",
            reply_markup=telegram_audit_verifier_keyboard(accounts, verifier_ids, page, settings.accounts_page_size),
        )


@router.callback_query(F.data.startswith("audit:verifier_toggle:"))
async def telegram_audit_verifier_toggle_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    parts = callback.data.split(":")
    account_id = int(parts[2])
    page = int(parts[3]) if len(parts) > 3 and parts[3].isdigit() else 0
    accounts = await list_accounts(callback.from_user.id)
    account_ids = {int(account.id) for account in accounts}
    if account_id not in account_ids:
        await safe_answer(callback, "الحساب غير موجود.", show_alert=True)
        return
    enabled = await toggle_verifier_account(account_id, callback.from_user.id)
    verifier_ids = await get_verifier_account_ids(callback.from_user.id)
    if len(verifier_ids & account_ids) >= len(account_ids):
        # Never allow every account to become a verifier, because membership comparison needs a primary account.
        await toggle_verifier_account(account_id, callback.from_user.id)
        verifier_ids = await get_verifier_account_ids(callback.from_user.id)
        await safe_answer(callback, "يجب إبقاء حساب أساسي واحد على الأقل.", show_alert=True)
    else:
        await safe_answer(callback, "أصبح حساب تحقق." if enabled else "أصبح حسابًا أساسيًا.")
    if callback.message:
        await callback.message.edit_reply_markup(reply_markup=telegram_audit_verifier_keyboard(accounts, verifier_ids, page, settings.accounts_page_size))


@router.callback_query(F.data.startswith("audit:newsrc:"))
async def telegram_audit_new_source_handler(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    parts = callback.data.split(":")
    if len(parts) != 6:
        await safe_answer(callback, "إعداد المصدر غير صالح.", show_alert=True)
        return
    _, _, source_type, mode, scope, pacing = parts
    if source_type not in {"database", "files", "sources", "paste"}:
        await safe_answer(callback, "نوع المصدر غير صالح.", show_alert=True)
        return
    options = _audit_options_from_parts(mode, scope, pacing)
    state_data = await state.get_data()
    audit_title = " ".join(str(state_data.get("audit_title") or "").split()).strip()[:160]
    await state.clear()

    if source_type == "database":
        await safe_answer(callback, "جارٍ تجهيز روابط Telegram الموجودة في القاعدة...")
        audit = await create_audit(callback.from_user.id, "database", options=options, title=audit_title or "قاعدة روابط Telegram")
        await populate_audit_from_database(audit.id)
        try:
            job = await _queue_audit_for_engine(audit.id, callback.from_user.id)
        except Exception as exc:
            await discard_audit(audit.id, callback.from_user.id)
            if callback.message:
                await callback.message.answer(f"تعذر بدء الفحص: {exc}", reply_markup=telegram_audit_menu_keyboard())
            return
        if callback.message:
            refreshed = await get_audit(audit.id)
            await callback.message.answer(
                f"تم إنشاء فحص Telegram #{audit.id}. عدد الروابط: {refreshed.total_inputs if refreshed else 0}. مهمة #{job.id}.",
                reply_markup=main_menu(),
            )
        return

    if source_type == "files":
        audit = await create_audit(callback.from_user.id, "files", options=options, title=audit_title or "ملفات روابط Telegram")
        await state.set_state(TelegramAuditState.waiting_files)
        await state.update_data(audit_id=audit.id)
        await safe_answer(callback)
        if callback.message:
            await callback.message.answer(
                f"فحص #{audit.id}: أرسل ملفات TXT/CSV التي تحتوي روابط Telegram.\n"
                "يمكنك إرسال الملفات واحدًا بعد الآخر، ثم اضغط «ابدأ الفحص الآن».",
                reply_markup=telegram_audit_upload_keyboard(audit.id),
            )
        return

    await state.update_data(audit_options=options, audit_title=audit_title)
    if source_type == "sources":
        await state.set_state(TelegramAuditState.waiting_sources)
        await safe_answer(callback)
        if callback.message:
            await callback.message.answer(
                "أرسل روابط/معرفات المجموعات أو القنوات التي تحتوي روابط Telegram المراد تصفيتها، كل مصدر في سطر.",
                reply_markup=cancel_keyboard(),
            )
    else:
        await state.set_state(TelegramAuditState.waiting_paste)
        await safe_answer(callback)
        if callback.message:
            await callback.message.answer("الصق روابط Telegram المراد فحصها.", reply_markup=cancel_keyboard())


@router.message(TelegramAuditState.waiting_files, F.document)
async def telegram_audit_file_message(message: Message, state: FSMContext, bot: Bot) -> None:
    if await reject_non_owner(message):
        return
    if not message.document:
        return
    data = await state.get_data()
    audit_id = int(data.get("audit_id") or 0)
    audit = await get_audit(audit_id)
    if not audit or audit.requested_by != message.from_user.id or audit.status != "draft":
        await state.clear()
        await message.answer("انتهت جلسة رفع الملفات. ابدأ فحصًا جديدًا.", reply_markup=telegram_audit_menu_keyboard())
        return
    file_name = message.document.file_name or "links.txt"
    if not file_name.lower().endswith((".txt", ".csv")):
        await message.answer("أرسل ملف TXT أو CSV نصيًا فقط.", reply_markup=telegram_audit_upload_keyboard(audit_id))
        return
    if message.document.file_size and message.document.file_size > 25 * 1024 * 1024:
        await message.answer("حجم الملف أكبر من 25MB. قسّمه إلى ملفات أصغر.")
        return
    safe_name = re.sub(r"[^A-Za-z0-9_.-]", "_", file_name)
    temp_path = settings.tmp_dir / f"audit_{audit_id}_{message.document.file_unique_id}_{safe_name}"
    try:
        await bot.download(message.document, destination=temp_path)
        if not (audit.title or "").strip() or audit.title == "ملفات روابط Telegram":
            await set_audit_title(audit_id, re.sub(r"[_-]+", " ", file_name.rsplit(".", 1)[0]).strip() or f"فحص Telegram {audit_id}")
        added, duplicate, rejected = await add_audit_file_stream(audit_id, temp_path)
        refreshed = await get_audit(audit_id)
        await message.answer(
            f"تمت قراءة {file_name}:\n"
            f"روابط Telegram جديدة: {added}\n"
            f"مكررة داخل هذا الفحص: {duplicate}\n"
            f"روابط أخرى/مرفوضة: {rejected}\n"
            f"الإجمالي الحالي: {refreshed.total_inputs if refreshed else 0}",
            reply_markup=telegram_audit_upload_keyboard(audit_id),
        )
    except Exception as exc:
        logger.exception("Could not import audit file")
        await message.answer(f"تعذر قراءة الملف: {exc}", reply_markup=telegram_audit_upload_keyboard(audit_id))
    finally:
        temp_path.unlink(missing_ok=True)


@router.message(TelegramAuditState.waiting_files)
async def telegram_audit_file_non_document(message: Message, state: FSMContext) -> None:
    if await reject_non_owner(message):
        return
    data = await state.get_data()
    audit_id = int(data.get("audit_id") or 0)
    await message.answer("أرسل ملف TXT/CSV، أو اضغط «ابدأ الفحص الآن» عند الانتهاء.", reply_markup=telegram_audit_upload_keyboard(audit_id))


@router.callback_query(F.data.startswith("audit:run:"))
async def telegram_audit_run_handler(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    audit_id = int(callback.data.rsplit(":", 1)[1])
    try:
        job = await _queue_audit_for_engine(audit_id, callback.from_user.id)
        await log_admin_action(callback.from_user.id, "audit_queue", f"audit_id={audit_id}; job_id={job.id}")
    except Exception as exc:
        await safe_answer(callback, str(exc)[:180], show_alert=True)
        return
    await state.clear()
    await safe_answer(callback, "تمت إضافة الفحص إلى الطابور.")
    if callback.message:
        audit = await get_audit(audit_id)
        await callback.message.answer(
            f"بدأ تجهيز فحص Telegram #{audit_id}. عدد الروابط: {audit.total_inputs if audit else 0}.\n"
            f"مهمة التنفيذ #{job.id}. سيصلك التقرير تلقائيًا.",
            reply_markup=main_menu(),
        )


@router.callback_query(F.data.startswith("audit:discard:"))
async def telegram_audit_discard_handler(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_owner(callback):
        return
    audit_id = int(callback.data.rsplit(":", 1)[1])
    deleted = await discard_audit(audit_id, callback.from_user.id)
    await state.clear()
    await safe_answer(callback, "تم حذف الفحص." if deleted else "لا يمكن حذف هذا الفحص الآن.", show_alert=True)
    if callback.message:
        await callback.message.answer("فحص Telegram:", reply_markup=telegram_audit_menu_keyboard())


@router.message(TelegramAuditState.waiting_sources)
async def telegram_audit_sources_message(message: Message, state: FSMContext) -> None:
    if await reject_non_owner(message):
        return
    sources = parse_sources(message.text or "")
    if not sources:
        await message.answer("لم أجد روابط أو معرفات مصادر صالحة.")
        return
    data = await state.get_data()
    options = data.get("audit_options") if isinstance(data.get("audit_options"), dict) else {}
    audit_title = " ".join(str(data.get("audit_title") or "").split()).strip()[:160]
    auto_title = audit_title or (sources[0].replace("https://t.me/", "").replace("@", "") if sources else "مصادر Telegram")
    audit = await create_audit(message.from_user.id, "sources", options=options, title=auto_title)
    job = await _queue_audit_for_engine(audit.id, message.from_user.id, sources=sources)
    await state.clear()
    await message.answer(
        f"تم إنشاء فحص Telegram #{audit.id} من {len(sources)} مصدر. مهمة التنفيذ #{job.id}.\n"
        "سيقرأ البوت روابط Telegram من المصادر ثم يفحصها.",
        reply_markup=main_menu(),
    )


@router.message(TelegramAuditState.waiting_paste)
async def telegram_audit_paste_message(message: Message, state: FSMContext) -> None:
    if await reject_non_owner(message):
        return
    data = await state.get_data()
    options = data.get("audit_options") if isinstance(data.get("audit_options"), dict) else {}
    audit_title = " ".join(str(data.get("audit_title") or "").split()).strip()[:160]
    audit = await create_audit(message.from_user.id, "paste", options=options, title=audit_title or "روابط Telegram الملصقة")
    added, duplicate, rejected = await add_audit_text(audit.id, message.text or message.caption or "")
    if added == 0:
        await discard_audit(audit.id, message.from_user.id)
        await message.answer("لم أجد روابط Telegram صالحة للفحص.")
        return
    job = await _queue_audit_for_engine(audit.id, message.from_user.id)
    await state.clear()
    await message.answer(
        f"تم إنشاء فحص #{audit.id}: {added} رابط، مكرر {duplicate}، مرفوض {rejected}. مهمة #{job.id}.",
        reply_markup=main_menu(),
    )


@router.callback_query(F.data == "audit:list")
async def telegram_audit_list_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    audits = await list_audits(callback.from_user.id, 10)
    await safe_answer(callback)
    if callback.message:
        if not audits:
            await callback.message.answer("لا توجد تقارير فحص سابقة.", reply_markup=telegram_audit_menu_keyboard())
            return
        lines = ["آخر عمليات فحص Telegram:"]
        for audit in audits:
            title = f" — {audit.title}" if audit.title else ""
            lines.append(f"#{audit.id}{title} — {audit.status} — {audit.checked_inputs}/{audit.total_inputs}")
        await callback.message.answer("\n".join(lines), reply_markup=telegram_audit_list_keyboard(audits))


@router.callback_query(F.data.startswith("audit:view:"))
async def telegram_audit_view_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    audit_id = int(callback.data.rsplit(":", 1)[1])
    audit = await get_audit(audit_id)
    if not audit or audit.requested_by != callback.from_user.id:
        await safe_answer(callback, "التقرير غير موجود.", show_alert=True)
        return
    summary = await audit_summary(audit_id)
    await safe_answer(callback)
    if callback.message:
        options = (audit.summary or {}).get("options", {}) if isinstance(audit.summary, dict) else {}
        engine = str(options.get("engine") or "accounts") if isinstance(options, dict) else "accounts"
        keyboard = telegram_web_audit_result_keyboard(audit_id) if engine == "web" else telegram_audit_result_keyboard(audit_id)
        await callback.message.answer(format_audit_summary(summary), reply_markup=keyboard)


async def _send_audit_text_files(
    bot: Bot, chat_id: int, audit_id: int, chunk_size: int = 0
) -> None:
    bundle = await export_audit(audit_id, chunk_size=chunk_size)
    if not bundle.text_files:
        await bot.send_message(chat_id, "لا توجد نتائج TXT قابلة للتصدير.")
        return
    await bot.send_message(
        chat_id,
        f"تصدير فحص Telegram #{audit_id}. عدد ملفات TXT: {len(bundle.text_files)}. "
        + ("ملف واحد لكل قسم." if not chunk_size else f"تقسيم كل {chunk_size} رابط لكل قسم."),
    )
    for index, path in enumerate(bundle.text_files, start=1):
        await bot.send_document(chat_id, FSInputFile(path), caption=f"{path.name} — {index}/{len(bundle.text_files)}")
        if settings.export_send_delay_seconds > 0:
            await asyncio.sleep(settings.export_send_delay_seconds)


@router.callback_query(F.data.startswith("audit:export_txt:"))
async def telegram_audit_export_txt_handler(callback: CallbackQuery, bot: Bot) -> None:
    if await reject_non_primary(callback):
        return
    audit_id = int(callback.data.rsplit(":", 1)[1])
    audit = await get_audit(audit_id)
    if not audit or audit.requested_by != callback.from_user.id:
        await safe_answer(callback, "الفحص غير موجود أو لا تملك صلاحية تصديره.", show_alert=True)
        return
    await safe_answer(callback, "جارٍ تجهيز ملفات النتائج...")
    await _send_audit_text_files(bot, callback.from_user.id, audit_id)


@router.callback_query(F.data.startswith("audit:export_options:"))
async def telegram_audit_export_options_handler(callback: CallbackQuery) -> None:
    if await reject_non_primary(callback):
        return
    audit_id = int(callback.data.rsplit(":", 1)[1])
    audit = await get_audit(audit_id)
    if not audit or audit.requested_by != callback.from_user.id:
        await safe_answer(callback, "الفحص غير موجود أو لا تملك صلاحية تصديره.", show_alert=True)
        return
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            "اختر تنسيق ملفات الفحص. الخيار يطبق على كل قسم مستقلًا:",
            reply_markup=audit_export_options_keyboard(audit_id),
        )


@router.callback_query(F.data.startswith("audit:export_split:"))
async def telegram_audit_export_split_handler(callback: CallbackQuery, bot: Bot) -> None:
    if await reject_non_primary(callback):
        return
    parts = callback.data.split(":")
    if len(parts) != 4:
        await safe_answer(callback, "خيار تصدير غير صالح.", show_alert=True)
        return
    audit_id = int(parts[2])
    chunk_size = int(parts[3])
    if chunk_size not in {0, 200, 1000}:
        await safe_answer(callback, "التقسيم يدعم 200 أو 1000 فقط.", show_alert=True)
        return
    audit = await get_audit(audit_id)
    if not audit or audit.requested_by != callback.from_user.id:
        await safe_answer(callback, "الفحص غير موجود أو لا تملك صلاحية تصديره.", show_alert=True)
        return
    await safe_answer(callback, "جارٍ تجهيز ملفات النتائج...")
    await _send_audit_text_files(bot, callback.from_user.id, audit_id, chunk_size=chunk_size)


@router.callback_query(F.data.startswith("audit:export_section:"))
async def telegram_audit_export_section_handler(callback: CallbackQuery, bot: Bot) -> None:
    if await reject_non_primary(callback):
        return
    parts = (callback.data or "").split(":")
    if len(parts) != 5:
        await safe_answer(callback, "خيار تصدير غير صالح.", show_alert=True)
        return
    audit_id = int(parts[2])
    section_key = parts[3]
    chunk_size = int(parts[4])
    folder = AUDIT_EXPORT_SECTION_FOLDERS.get(section_key)
    if folder is None or chunk_size not in {200, 1000}:
        await safe_answer(callback, "القسم أو حجم التقسيم غير صالح.", show_alert=True)
        return
    audit = await get_audit(audit_id)
    if not audit or audit.requested_by != callback.from_user.id:
        await safe_answer(callback, "الفحص غير موجود أو لا تملك صلاحية تصديره.", show_alert=True)
        return
    await safe_answer(callback, f"جارٍ تقسيم القسم إلى ملفات {chunk_size} رابط...")
    bundle = await export_audit(audit_id, chunk_size=chunk_size)
    selected = [
        path for path in bundle.text_files
        if path != bundle.directory and path.is_relative_to(bundle.directory)
        and path.relative_to(bundle.directory).parts
        and path.relative_to(bundle.directory).parts[0] == folder
    ]
    if not selected:
        if callback.message:
            await callback.message.answer("لا توجد ملفات لهذا القسم.")
        return
    if callback.message:
        await callback.message.answer(
            f"القسم: {folder} — التقسيم كل {chunk_size} رابط — عدد الملفات {len(selected)}."
        )
    for index, path in enumerate(selected, start=1):
        await bot.send_document(
            callback.from_user.id,
            FSInputFile(path),
            caption=f"{folder} — {index}/{len(selected)}",
        )
        if settings.export_send_delay_seconds > 0:
            await asyncio.sleep(settings.export_send_delay_seconds)


@router.callback_query(F.data.startswith("audit:continue_new:"))
async def telegram_audit_continue_new_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    audit_id = int(callback.data.rsplit(":", 1)[1])
    audit = await get_audit(audit_id)
    if not audit or audit.requested_by != callback.from_user.id:
        await safe_answer(callback, "الفحص غير موجود.", show_alert=True)
        return

    added = await populate_audit_from_database(audit_id)
    if added <= 0:
        await safe_answer(callback, "لا توجد روابط Telegram جديدة في قاعدة البيانات لهذا الفحص.", show_alert=True)
        return

    async with SessionFactory() as session:
        previous = await session.scalar(
            select(Job).where(Job.audit_id == audit_id).order_by(Job.id.desc()).limit(1)
        )
        sources = list(previous.sources or []) if previous else []
    try:
        job = await _queue_audit_for_engine(audit_id, callback.from_user.id, sources=sources)
    except Exception as exc:
        await safe_answer(callback, str(exc)[:180], show_alert=True)
        return
    await safe_answer(callback, f"أضيف {added} رابط جديد للفحص.", show_alert=True)
    if callback.message:
        await callback.message.answer(
            f"تم استكمال تقرير الفحص #{audit_id} بنفس التقرير. أضيف {added} رابط Telegram جديد، والمهمة الجديدة للتنفيذ #{job.id}.",
            reply_markup=main_menu(),
        )


@router.callback_query(F.data.startswith("audit:export_zip:"))
async def telegram_audit_export_zip_handler(callback: CallbackQuery, bot: Bot) -> None:
    if await reject_non_primary(callback):
        return
    audit_id = int(callback.data.rsplit(":", 1)[1])
    audit = await get_audit(audit_id)
    if not audit or audit.requested_by != callback.from_user.id:
        await safe_answer(callback, "الفحص غير موجود أو لا تملك صلاحية تصديره.", show_alert=True)
        return
    await safe_answer(callback, "جارٍ تجهيز ZIP شامل...")
    bundle = await export_audit(audit_id)
    await bot.send_document(
        callback.from_user.id,
        FSInputFile(bundle.zip_path),
        caption=(
            f"فحص Telegram #{audit_id}" + (f" — {audit.title}" if audit.title else "") + "\n"
            "يتضمن: القنوات (مشتركون)، المجموعات (أعضاء)، المجموعات التي تحتاج انضمامًا فعليًا للقراءة، "
            "روابط البوتات، المحادثات الخاصة، مجموعات البامبات/الاكتتابات، وبقية تقارير الفحص."
        ),
    )


@router.callback_query(F.data.startswith("audit:web_to_accounts:"))
async def telegram_web_section_to_accounts_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    parts = (callback.data or "").split(":")
    if len(parts) != 4:
        await safe_answer(callback, "طلب القسم غير صالح.", show_alert=True)
        return
    audit_id = int(parts[2])
    section = parts[3]
    try:
        target, added = await populate_account_audit_from_web_section(audit_id, callback.from_user.id, section)
        if added <= 0:
            await discard_audit(target.id, callback.from_user.id)
            await safe_answer(callback, "لا توجد روابط في هذا القسم.", show_alert=True)
            return
        job = await queue_audit_job(target.id, callback.from_user.id)
    except Exception as exc:
        await safe_answer(callback, str(exc)[:180], show_alert=True)
        return
    await safe_answer(callback, f"تم إرسال {added} رابط إلى فحص الحسابات.")
    if callback.message:
        await callback.message.answer(
            f"تم إنشاء فحص حسابات #{target.id} من قسم {section} في فحص المتصفح #{audit_id}.\n"
            f"عدد الروابط: {added}. مهمة #{job.id}.\n"
            "عند حل القنوات/المجموعات القابلة للقراءة سيعمل تجميع Telegram داخلها بالنظام الحالي.",
            reply_markup=main_menu(),
        )


@router.callback_query(F.data.startswith("audit:retry_errors:"))
async def telegram_audit_retry_errors_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    audit_id = int(callback.data.rsplit(":", 1)[1])
    audit = await get_audit(audit_id)
    if not audit or audit.requested_by != callback.from_user.id:
        await safe_answer(callback, "التقرير غير موجود.", show_alert=True)
        return
    summary = await audit_summary(audit_id)
    retry_count = (
        int(summary.get("error", 0) or 0)
        + int(summary.get("temporary_error", 0) or 0)
        + int(summary.get("restricted_access", 0) or 0)
    )
    if retry_count == 0:
        await safe_answer(callback, "لا توجد روابط مقيّدة أو أخطاء مؤقتة لإعادة فحصها.", show_alert=True)
        return
    try:
        job = await _queue_audit_for_engine(audit_id, callback.from_user.id)
    except Exception as exc:
        await safe_answer(callback, str(exc)[:180], show_alert=True)
        return
    await safe_answer(callback, "تمت إضافة إعادة الفحص إلى الطابور.", show_alert=True)
    if callback.message:
        await callback.message.answer(
            f"سيعيد البوت فحص الروابط المقيّدة والأخطاء في التقرير #{audit_id}. مهمة #{job.id}.\n"
            "إذا أضفت حساب تحقق جديدًا قبل إعادة الفحص فسيستخدمه تلقائيًا.",
            reply_markup=main_menu(),
        )


@router.callback_query(F.data.startswith("audit:scan_discovered:"))
async def telegram_audit_scan_discovered_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    source_audit_id = int(callback.data.rsplit(":", 1)[1])
    source = await get_audit(source_audit_id)
    if not source or source.requested_by != callback.from_user.id:
        await safe_answer(callback, "الفحص غير موجود.", show_alert=True)
        return

    options = _audit_options_from_parts("plain", "all", "fixed")
    target = await create_audit(
        callback.from_user.id,
        "telegram_discovery",
        options=options,
        title=f"روابط Telegram الجديدة من فحص #{source_audit_id}",
    )
    added = await populate_audit_from_discovery(source_audit_id, target.id)
    if added <= 0:
        await discard_audit(target.id, callback.from_user.id)
        await safe_answer(callback, "لا توجد روابط Telegram جديدة في هذا الفحص.", show_alert=True)
        return
    try:
        job = await _queue_audit_for_engine(target.id, callback.from_user.id)
    except Exception as exc:
        await discard_audit(target.id, callback.from_user.id)
        await safe_answer(callback, f"تعذر بدء فحص الروابط الجديدة: {exc}", show_alert=True)
        return
    await safe_answer(callback, f"بدأ فحص {added} رابطًا جديدًا.")
    if callback.message:
        await callback.message.answer(
            f"تم إنشاء فحص Telegram #{target.id} من {added} رابطًا جديدًا اكتشفها الفحص #{source_audit_id}.\n"
            "وسيعمل تجميع Telegram الكامل تلقائيًا مرة أخرى أثناء هذا الفحص.\n"
            f"مهمة #{job.id}.",
            reply_markup=main_menu(),
        )


@router.callback_query(F.data.startswith("audit:accounts_report:"))
async def telegram_audit_accounts_report_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback):
        return
    audit_id = int(callback.data.rsplit(":", 1)[1])
    audit = await get_audit(audit_id)
    if not audit or audit.requested_by != callback.from_user.id:
        await safe_answer(callback, "التقرير غير موجود.", show_alert=True)
        return
    summary = await audit_summary(audit_id)
    await safe_answer(callback)
    text = format_account_report(summary)
    if callback.message:
        while text:
            chunk = text[:3900]
            cut = chunk.rfind("\n")
            if cut > 1000:
                chunk = text[:cut]
            await callback.message.answer(chunk)
            text = text[len(chunk):].lstrip("\n")
        await callback.message.answer("خيارات التقرير:", reply_markup=telegram_audit_result_keyboard(audit_id))


@router.callback_query(F.data == "backup:menu")
async def backup_menu_handler(callback: CallbackQuery) -> None:
    if await reject_non_primary(callback):
        return
    backups = await list_backups(limit=5)
    lines = ["النسخ الاحتياطية:"]
    if backups:
        for item in backups:
            lines.append(f"• {item.path.name} — {item.size_bytes / 1024 / 1024:.2f} MB")
    else:
        lines.append("لا توجد نسخ بعد.")
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer("\n".join(lines), reply_markup=backup_menu_keyboard())


@router.callback_query(F.data == "backup:create")
async def backup_create_handler(callback: CallbackQuery, bot: Bot) -> None:
    if await reject_non_primary(callback):
        return
    await safe_answer(callback, "جارٍ إنشاء نسخة متسقة من قاعدة البيانات...")
    try:
        info = await create_database_backup()
        await bot.send_document(
            callback.from_user.id,
            FSInputFile(info.path),
            caption=f"نسخة قاعدة البيانات: {info.path.name}\nالحجم: {info.size_bytes / 1024 / 1024:.2f} MB",
        )
    except Exception as exc:
        logger.exception("Database backup failed")
        if callback.message:
            await callback.message.answer(f"تعذر إنشاء النسخة الاحتياطية: {exc}", reply_markup=backup_menu_keyboard())


@router.callback_query(F.data == "backup:restore_confirm")
async def backup_restore_confirm_handler(callback: CallbackQuery) -> None:
    if await reject_non_primary(callback):
        return
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            "سيتم أخذ نسخة أمان من القاعدة الحالية ثم استعادة أحدث Backup. يجب ألا توجد مهمة نشطة.",
            reply_markup=backup_restore_confirm_keyboard(),
        )


@router.callback_query(F.data == "backup:restore_latest")
async def backup_restore_latest_handler(callback: CallbackQuery) -> None:
    if await reject_non_primary(callback):
        return
    await log_admin_action(callback.from_user.id if callback.from_user else None, "backup_restore_requested")
    await safe_answer(callback, "جارٍ التحقق والاستعادة...", show_alert=True)
    try:
        info = await restore_latest_backup()
    except Exception as exc:
        logger.exception("Database restore failed")
        if callback.message:
            await callback.message.answer(f"تعذرت الاستعادة: {exc}", reply_markup=backup_menu_keyboard())
        return
    if callback.message:
        await callback.message.answer(
            f"تمت استعادة النسخة {info.path.name} والتحقق من قاعدة البيانات.",
            reply_markup=main_menu(),
        )


@router.callback_query(F.data == "reset:menu")
async def reset_menu_handler(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_primary(callback):
        return
    await state.clear()
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer(
            "اختر نوع إعادة الضبط:\n\n"
            "• حذف الروابط والمهام فقط: يمسح قاعدة الروابط، سجل المهام، عمليات الإرسال والمتابعات، "
            "مع الاحتفاظ بالحسابات وقنوات التجميع.\n\n"
            "• إعادة ضبط المصنع الآمنة: تحذف نتائج الفحوص والمهام والروابط والمتابعات وقنوات التجميع، "
            "لكنها تحتفظ بحسابات Telethon والجلسات وملف .env. ويتم أخذ Backup تلقائي قبلها.",
            reply_markup=reset_menu_keyboard(),
        )


@router.callback_query(F.data.in_({"reset:clear", "reset:factory"}))
async def reset_confirm_handler(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_primary(callback):
        return
    await state.clear()
    mode = callback.data.split(":", 1)[1]
    await safe_answer(callback)
    if not callback.message:
        return
    if mode == "factory":
        text = (
            "تحذير: سيتم حذف بيانات التشغيل والروابط والمهام والفحوص والمتابعات وقنوات التجميع بعد أخذ نسخة احتياطية تلقائيًا. "
            "حسابات Telethon والجلسات وملف .env ستبقى محفوظة."
        )
    else:
        text = (
            "سيتم حذف جميع الروابط المجمعة وسجل المهام وعمليات الإرسال والمتابعات فقط. "
            "ستبقى حسابات Telethon وقنوات التجميع محفوظة. لا يمكن التراجع عن العملية."
        )
    await callback.message.answer(text, reply_markup=reset_confirm_keyboard(mode))


@router.callback_query(F.data.startswith("reset:execute:"))
async def reset_execute_handler(callback: CallbackQuery, state: FSMContext) -> None:
    if await reject_non_primary(callback):
        return
    mode = callback.data.rsplit(":", 1)[1]
    if mode not in {"clear", "factory"}:
        await safe_answer(callback, "نوع إعادة الضبط غير صالح.", show_alert=True)
        return
    await log_admin_action(callback.from_user.id if callback.from_user else None, "reset_requested", f"kind={mode}")
    await safe_answer(callback, "جارٍ تنفيذ إعادة الضبط...", show_alert=True)
    try:
        result = await reset_collected_data(factory=mode == "factory")
    except Exception as exc:
        logger.exception("Bot reset failed")
        if callback.message:
            await callback.message.answer(f"تعذرت إعادة الضبط: {exc}", reply_markup=main_menu())
        return

    if mode == "factory" and not settings.admin_ids:
        # Keep the current operator in control when ADMIN_IDS is not configured.
        await claim_first_owner(callback.from_user.id)

    await state.clear()
    lines = [
        "تمت إعادة ضبط المصنع بنجاح." if mode == "factory" else "تم حذف الروابط والمهام بنجاح.",
        f"الروابط المحذوفة: {result.links}",
        f"المهام المحذوفة: {result.jobs}",
        f"المتابعات المحذوفة: {result.watches}",
        f"سجلات الإرسال المحذوفة: {result.deliveries}",
        f"تقارير فحص Telegram المحذوفة: {result.audits}",
    ]
    if mode == "factory":
        lines.extend([
            f"إعدادات قنوات التجميع المحذوفة: {result.destinations}",
            "تم الاحتفاظ بحسابات Telethon والجلسات المشفرة. توجد نسخة احتياطية في data/backups.",
        ])
    else:
        lines.append("يمكنك بدء تجميع جديد مباشرة بالحسابات والقنوات المحفوظة.")
    if callback.message:
        await callback.message.answer("\n".join(lines), reply_markup=main_menu())


@router.message(Command("help"))
async def help_command(message: Message) -> None:
    if await reject_non_owner(message):
        return
    await message.answer(
        "استخدم /menu لفتح لوحة التحكم.\n"
        "ابدأ بإضافة جلسات الحسابات. في التجميع من كل الحسابات سيطلب البوت قناة الاستقبال الخاصة بالمهمة فقط، "
        "أما التجميع من مصدر محدد فيحفظ مباشرة في قاعدة البيانات. وللفحص استخدم زر فحص وتصفية روابط Telegram.",
        reply_markup=main_menu(),
    )


# ---------------------------------------------------------------------------
# V7 Integrated Control Center
# ---------------------------------------------------------------------------
@router.callback_query(F.data == "v7:center")
async def v7_center_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback): return
    await safe_answer(callback)
    if callback.message:
        await callback.message.answer("🧭 V8 Control Center\nالجلسات والجدولة والـWorkflows والبحث والأخطاء والتشخيص في مكان واحد.", reply_markup=v7_center_keyboard())


@router.callback_query(F.data == "session:center")
async def session_center_handler(callback: CallbackQuery) -> None:
    if await reject_non_session_tool(callback): return
    accounts = await list_accounts(callback.from_user.id)
    health = await session_health(callback.from_user.id)
    good = sum(1 for row in health if row["score"] >= 80)
    text = f"🔐 مركز جلساتك\nالحسابات: {len(accounts)} | صحة 80+: {good}\nكل جلسة مرتبطة بالمشرف الذي أنشأها ولا تُعرض أسرارها الخام."
    await safe_answer(callback)
    if callback.message: await callback.message.answer(text, reply_markup=session_center_keyboard(accounts))


@router.callback_query(F.data.startswith("session:view:"))
async def session_view_handler(callback: CallbackQuery) -> None:
    if await reject_non_session_tool(callback): return
    account_id = int(callback.data.rsplit(":",1)[1])
    async with SessionFactory() as session:
        account = await session.get(Account, account_id)
    if not account or not await account_belongs_to_operator(account, callback.from_user.id):
        await safe_answer(callback,"هذه الجلسة ليست ضمن جلساتك.",show_alert=True); return
    score = next((x["score"] for x in await session_health(callback.from_user.id) if x["id"]==account_id),0)
    text = f"🔐 الجلسة #{account.id}\nالاسم: {account.label}\nTelegram ID: {account.telegram_user_id}\nUsername: @{account.username or '-'}\nالحالة: {'فعالة' if account.active else 'متوقفة'}\nالصحة: {score}/100\nآخر خطأ: {account.last_error or '-'}"
    await safe_answer(callback)
    if callback.message: await callback.message.answer(text, reply_markup=session_detail_keyboard(account_id, bool(account.active)))


@router.callback_query(F.data.startswith("session:test:"))
async def session_test_handler(callback: CallbackQuery) -> None:
    if await reject_non_session_tool(callback): return
    account_id = int(callback.data.rsplit(":",1)[1])
    await safe_answer(callback,"جارٍ فحص الجلسة...")
    try:
        from app.services.accounts import test_account_connection
        info = await test_account_connection(account_id, callback.from_user.id)
        await session_event(callback.from_user.id,"session_test_ok",account_id=account_id)
        text = f"✅ الجلسة #{account_id} متصلة\nTelegram ID: {info.get('telegram_user_id')}\nUsername: @{info.get('username') or '-'}"
    except Exception as exc:
        await session_event(callback.from_user.id,"session_test_failed",account_id=account_id,detail=str(exc))
        text = f"❌ فشل فحص الجلسة #{account_id}: {exc}"
    if callback.message: await callback.message.answer(text, reply_markup=session_center_keyboard(await list_accounts(callback.from_user.id)))


@router.callback_query(F.data.startswith("session:toggle:"))
async def session_toggle_handler(callback: CallbackQuery) -> None:
    if await reject_non_session_tool(callback): return
    account_id = int(callback.data.rsplit(":",1)[1])
    async with SessionFactory() as session:
        account = await session.get(Account, account_id)
    if not account or not await account_belongs_to_operator(account,callback.from_user.id):
        await safe_answer(callback,"الجلسة ليست لك.",show_alert=True); return
    ok = await set_session_active(callback.from_user.id,account_id,not bool(account.active))
    await safe_answer(callback,"تم تحديث الحالة." if ok else "تعذر تحديث الجلسة.",show_alert=True)
    if callback.message: await callback.message.answer("مركز الجلسات:",reply_markup=session_center_keyboard(await list_accounts(callback.from_user.id)))


@router.callback_query(F.data.startswith("session:delete_confirm:"))
async def session_delete_confirm_handler(callback: CallbackQuery) -> None:
    if await reject_non_session_tool(callback): return
    account_id=int(callback.data.rsplit(":",1)[1])
    async with SessionFactory() as session: account=await session.get(Account,account_id)
    if not account or not await account_belongs_to_operator(account,callback.from_user.id):
        await safe_answer(callback,"الجلسة ليست لك.",show_alert=True); return
    await safe_answer(callback)
    if callback.message: await callback.message.answer("سيُحذف سجل الجلسة المشفر من هذا البوت فقط. هذا لا يلغي أجهزة Telegram الأخرى.",reply_markup=session_delete_confirm_keyboard(account_id))


@router.callback_query(F.data.startswith("session:delete:"))
async def session_delete_handler(callback: CallbackQuery) -> None:
    if await reject_non_session_tool(callback): return
    account_id=int(callback.data.rsplit(":",1)[1]); ok=await delete_session_local(callback.from_user.id,account_id)
    await safe_answer(callback,"تم الحذف المحلي." if ok else "تعذر الحذف.",show_alert=True)
    if callback.message: await callback.message.answer("مركز الجلسات:",reply_markup=session_center_keyboard(await list_accounts(callback.from_user.id)))


@router.callback_query(F.data == "v7:health")
async def v7_health_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback): return
    rows=await session_health(callback.from_user.id); lines=["🩺 صحة الحسابات"]
    for row in rows[:50]: lines.append(f"#{row['id']} {row['label']} — {row['score']}/100 — {'ON' if row['active'] else 'OFF'} — {row['health_status']}")
    if not rows: lines.append("لا توجد حسابات.")
    await safe_answer(callback)
    if callback.message: await callback.message.answer("\n".join(lines),reply_markup=v7_center_keyboard())


@router.callback_query(F.data == "v7:schedules")
async def v7_schedules_handler(callback: CallbackQuery) -> None:
    if await reject_non_owner(callback): return
    tasks=await list_scheduled_tasks(callback.from_user.id); await safe_answer(callback)
    lines=["⏰ المهام المجدولة"]+[f"#{t.id} {t.title} — {t.status} — {t.next_run_at}" for t in tasks[:15]]
    if callback.message: await callback.message.answer("\n".join(lines),reply_markup=schedules_keyboard(tasks))


@router.callback_query(F.data.startswith("v7:schedule:reminder:"))
async def v7_schedule_reminder_start(callback: CallbackQuery,state:FSMContext) -> None:
    if await reject_non_owner(callback): return
    delay=int(callback.data.rsplit(":",1)[1]); await state.set_state(V7ScheduleState.waiting_reminder_text); await state.update_data(v7_delay=delay)
    await safe_answer(callback)
    if callback.message: await callback.message.answer("أرسل نص التذكير.",reply_markup=cancel_keyboard())


@router.message(V7ScheduleState.waiting_reminder_text,F.text)
async def v7_schedule_reminder_text(message:Message,state:FSMContext)->None:
    if await reject_non_owner(message): return
    data=await state.get_data(); row=await create_scheduled_task(message.from_user.id,"reminder","تذكير",int(data.get("v7_delay") or 3600),payload={"text":message.text or "تذكير"}); await state.clear()
    await message.answer(f"✅ تم إنشاء التذكير #{row.id}.",reply_markup=v7_center_keyboard())


@router.callback_query(F.data == "v7:schedule:backup:86400")
async def v7_schedule_backup(callback:CallbackQuery)->None:
    if await reject_non_owner(callback): return
    row=await create_scheduled_task(callback.from_user.id,"backup","Backup بعد 24 ساعة",86400); await safe_answer(callback,f"تمت الجدولة #{row.id}",show_alert=True)


@router.callback_query(F.data == "v7:schedule:health_daily")
async def v7_schedule_health_daily(callback:CallbackQuery)->None:
    if await reject_non_owner(callback): return
    row=await create_scheduled_task(callback.from_user.id,"health","Health يومي",86400,interval_seconds=86400); await safe_answer(callback,f"تمت الجدولة #{row.id}",show_alert=True)


@router.callback_query(F.data.startswith("v7:schedule_cancel:"))
async def v7_schedule_cancel(callback:CallbackQuery)->None:
    if await reject_non_owner(callback): return
    task_id=int(callback.data.rsplit(":",1)[1]); ok=await cancel_scheduled_task(callback.from_user.id,task_id); await safe_answer(callback,"تم الإلغاء." if ok else "غير موجود.",show_alert=True)


@router.callback_query(F.data == "v7:workflows")
async def v7_workflows_handler(callback:CallbackQuery)->None:
    if await reject_non_owner(callback): return
    rows=await list_workflows(callback.from_user.id); await safe_answer(callback)
    text="🔁 Workflows\n"+"\n".join(f"#{w.id} {w.name} — runs={w.run_count}" for w in rows[:15])
    if callback.message: await callback.message.answer(text,reply_markup=workflows_keyboard(rows))


@router.callback_query(F.data.startswith("v7:wf_create:"))
async def v7_workflow_create(callback:CallbackQuery)->None:
    if await reject_non_owner(callback): return
    preset=callback.data.rsplit(":",1)[1]; wf=await create_preset_workflow(callback.from_user.id,preset); await safe_answer(callback,f"تم إنشاء Workflow #{wf.id}",show_alert=True)
    if callback.message: await callback.message.answer("Workflows:",reply_markup=workflows_keyboard(await list_workflows(callback.from_user.id)))


@router.callback_query(F.data.startswith("v7:wf_run:"))
async def v7_workflow_run(callback:CallbackQuery,bot:Bot)->None:
    if await reject_non_owner(callback): return
    wf_id=int(callback.data.rsplit(":",1)[1]); await safe_answer(callback,"جارٍ إطلاق Workflow...")
    try: messages=await run_workflow(wf_id,callback.from_user.id,bot); text="✅ "+("\n".join(messages) or "تم التنفيذ")
    except Exception as exc: text=f"❌ تعذر Workflow: {exc}"
    if callback.message: await callback.message.answer(text,reply_markup=v7_center_keyboard())


@router.callback_query(F.data.startswith("v7:wf_schedule:"))
async def v7_workflow_schedule(callback:CallbackQuery)->None:
    if await reject_non_owner(callback): return
    wf_id=int(callback.data.rsplit(":",1)[1])
    rows=await list_workflows(callback.from_user.id)
    if not any(int(w.id)==wf_id for w in rows):
        await safe_answer(callback,"Workflow غير موجود.",show_alert=True); return
    task=await create_scheduled_task(callback.from_user.id,"workflow",f"Workflow #{wf_id} يومي",86400,interval_seconds=86400,payload={"workflow_id":wf_id})
    await safe_answer(callback,f"تمت جدولة Workflow يوميًا — Task #{task.id}",show_alert=True)


@router.callback_query(F.data.startswith("v7:wf_delete:"))
async def v7_workflow_delete(callback:CallbackQuery)->None:
    if await reject_non_owner(callback): return
    wf_id=int(callback.data.rsplit(":",1)[1]); ok=await delete_workflow(callback.from_user.id,wf_id); await safe_answer(callback,"تم الحذف." if ok else "غير موجود.",show_alert=True)


@router.callback_query(F.data == "v7:tags")
async def v7_tags_handler(callback:CallbackQuery)->None:
    if await reject_non_owner(callback): return
    rows=await list_tags(callback.from_user.id); await safe_answer(callback)
    if callback.message: await callback.message.answer("🏷 Tags الخاصة بك",reply_markup=tags_keyboard(rows))


@router.callback_query(F.data == "v7:tag_add")
async def v7_tag_add_start(callback:CallbackQuery,state:FSMContext)->None:
    if await reject_non_owner(callback): return
    await state.set_state(V7TagState.waiting_tag); await safe_answer(callback)
    if callback.message: await callback.message.answer("أرسل بصيغة: النوع | المفتاح | tag | ملاحظة اختيارية\nمثال: source | @channel | وظائف | مصدر مهم",reply_markup=cancel_keyboard())


@router.message(V7TagState.waiting_tag,F.text)
async def v7_tag_add_message(message:Message,state:FSMContext)->None:
    if await reject_non_owner(message): return
    parts=[x.strip() for x in (message.text or "").split("|",3)]
    if len(parts)<3: await message.answer("الصيغة غير صحيحة."); return
    row=await add_tag(message.from_user.id,parts[0],parts[1],parts[2],parts[3] if len(parts)>3 else None); await state.clear(); await message.answer(f"✅ أضيف Tag #{row.id}",reply_markup=v7_center_keyboard())


@router.callback_query(F.data == "v7:search")
async def v7_search_start(callback:CallbackQuery,state:FSMContext)->None:
    if await reject_non_owner(callback): return
    await state.set_state(V7GlobalSearchState.waiting_query); await safe_answer(callback)
    if callback.message: await callback.message.answer("أرسل كلمة/رابط/اسم/رقم للبحث في الحسابات والروابط والمهام والـTags.",reply_markup=cancel_keyboard())


@router.message(V7GlobalSearchState.waiting_query,F.text)
async def v7_search_message(message:Message,state:FSMContext)->None:
    if await reject_non_owner(message): return
    result=await global_search(message.from_user.id,message.text or ""); await state.clear(); lines=["🔎 نتائج البحث"]
    for section,rows in result.items():
        lines.append(f"\n{section}:"); lines.extend(rows or ["-"])
    await message.answer("\n".join(lines)[:3900],reply_markup=v7_center_keyboard())


@router.callback_query(F.data == "v7:errors")
async def v7_errors_handler(callback:CallbackQuery)->None:
    if await reject_non_owner(callback): return
    rows=await list_system_errors(callback.from_user.id,primary=await is_primary_owner(callback.from_user.id)); await safe_answer(callback)
    text="⚠️ الأخطاء المفتوحة\n"+"\n".join(f"#{e.id} [{e.component}] {e.message[:100]}" for e in rows[:20])
    if callback.message: await callback.message.answer(text or "لا توجد أخطاء",reply_markup=errors_keyboard(rows))


@router.callback_query(F.data.startswith("v7:error_resolve:"))
async def v7_error_resolve(callback:CallbackQuery)->None:
    if await reject_non_owner(callback): return
    error_id=int(callback.data.rsplit(":",1)[1]); ok=await resolve_system_error(error_id, callback.from_user.id); await safe_answer(callback,"تم الإغلاق." if ok else "غير موجود.",show_alert=True)


@router.callback_query(F.data == "v7:auditlog")
async def v7_auditlog_handler(callback:CallbackQuery)->None:
    if await reject_non_owner(callback): return
    rows=await admin_audit_rows(callback.from_user.id,primary=await is_primary_owner(callback.from_user.id)); await safe_answer(callback)
    lines=["🧾 سجل الإدارة"]+[f"#{r.id} user={r.user_id} {r.action} — {(r.detail or '')[:100]}" for r in rows[:30]]
    if callback.message: await callback.message.answer("\n".join(lines)[:3900],reply_markup=v7_center_keyboard())


@router.callback_query(F.data == "v7:diag")
async def v7_diag_handler(callback:CallbackQuery)->None:
    if await reject_non_owner(callback): return
    text=await diagnostics(callback.from_user.id); await safe_answer(callback)
    if callback.message: await callback.message.answer(text,reply_markup=v7_center_keyboard())
