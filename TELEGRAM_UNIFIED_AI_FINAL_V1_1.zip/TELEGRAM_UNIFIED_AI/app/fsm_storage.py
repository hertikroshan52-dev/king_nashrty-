from __future__ import annotations

from typing import Any

from aiogram.fsm.state import State
from aiogram.fsm.storage.base import BaseStorage, StorageKey
from sqlalchemy import delete, select
from sqlalchemy.dialects.sqlite import insert

from app.db import SessionFactory
from app.models import FSMRecord, utcnow


def _key(key: StorageKey) -> str:
    parts = [
        str(getattr(key, "bot_id", "")),
        str(getattr(key, "chat_id", "")),
        str(getattr(key, "user_id", "")),
        str(getattr(key, "thread_id", "") or ""),
        str(getattr(key, "business_connection_id", "") or ""),
        str(getattr(key, "destiny", "default") or "default"),
    ]
    return ":".join(parts)


class SQLiteFSMStorage(BaseStorage):
    """Small persistent FSM storage backed by the same SQLite database.

    Conversation state survives restarts, which is useful during account import,
    audit file upload, destination setup and source-selection flows.
    """

    async def set_state(self, key: StorageKey, state: State | str | None = None) -> None:
        storage_key = _key(key)
        state_value = state.state if isinstance(state, State) else state
        async with SessionFactory() as session:
            if state_value is None:
                row = await session.get(FSMRecord, storage_key)
                if row and not (row.data or {}):
                    await session.delete(row)
                elif row:
                    row.state = None
                    row.updated_at = utcnow()
            else:
                await session.execute(
                    insert(FSMRecord)
                    .values(storage_key=storage_key, state=str(state_value), data={}, updated_at=utcnow())
                    .on_conflict_do_update(
                        index_elements=[FSMRecord.storage_key],
                        set_={"state": str(state_value), "updated_at": utcnow()},
                    )
                )
            await session.commit()

    async def get_state(self, key: StorageKey) -> str | None:
        async with SessionFactory() as session:
            return await session.scalar(select(FSMRecord.state).where(FSMRecord.storage_key == _key(key)))

    async def set_data(self, key: StorageKey, data: dict[str, Any]) -> None:
        storage_key = _key(key)
        clean = dict(data or {})
        async with SessionFactory() as session:
            if not clean:
                row = await session.get(FSMRecord, storage_key)
                if row and row.state is None:
                    await session.delete(row)
                elif row:
                    row.data = {}
                    row.updated_at = utcnow()
            else:
                await session.execute(
                    insert(FSMRecord)
                    .values(storage_key=storage_key, state=None, data=clean, updated_at=utcnow())
                    .on_conflict_do_update(
                        index_elements=[FSMRecord.storage_key],
                        set_={"data": clean, "updated_at": utcnow()},
                    )
                )
            await session.commit()

    async def get_data(self, key: StorageKey) -> dict[str, Any]:
        async with SessionFactory() as session:
            value = await session.scalar(select(FSMRecord.data).where(FSMRecord.storage_key == _key(key)))
        return dict(value) if isinstance(value, dict) else {}

    async def get_value(self, storage_key: StorageKey, dict_key: str, default: Any = None) -> Any:
        data = await self.get_data(storage_key)
        return data.get(dict_key, default)

    async def set_value(self, storage_key: StorageKey, dict_key: str, value: Any) -> None:
        data = await self.get_data(storage_key)
        if value is None:
            data.pop(dict_key, None)
        else:
            data[dict_key] = value
        await self.set_data(storage_key, data)

    async def close(self) -> None:
        return None
