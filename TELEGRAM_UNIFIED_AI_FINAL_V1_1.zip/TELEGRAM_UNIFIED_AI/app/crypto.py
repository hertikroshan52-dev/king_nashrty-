from __future__ import annotations

from cryptography.fernet import Fernet, InvalidToken

from app.config import get_settings


class SessionCipher:
    def __init__(self) -> None:
        settings = get_settings()
        key = settings.session_encryption_key
        if not key:
            if settings.key_file.exists():
                key = settings.key_file.read_text(encoding="utf-8").strip()
            else:
                key = Fernet.generate_key().decode("ascii")
                settings.key_file.write_text(key, encoding="utf-8")
                try:
                    settings.key_file.chmod(0o600)
                except OSError:
                    pass
        try:
            self._fernet = Fernet(key.encode("ascii"))
        except (ValueError, TypeError) as exc:
            raise RuntimeError("SESSION_ENCRYPTION_KEY غير صالح.") from exc

    def encrypt(self, value: str) -> str:
        return self._fernet.encrypt(value.encode("utf-8")).decode("ascii")

    def decrypt(self, value: str) -> str:
        try:
            return self._fernet.decrypt(value.encode("ascii")).decode("utf-8")
        except InvalidToken as exc:
            raise RuntimeError("تعذر فك تشفير بيانات الجلسة. لا تحذف ملف data/.session_key.") from exc
