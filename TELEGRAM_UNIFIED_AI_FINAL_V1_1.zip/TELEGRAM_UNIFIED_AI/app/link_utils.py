from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from telethon.tl.types import MessageEntityTextUrl, MessageEntityUrl

# Fast scanner support: besides ordinary http(s) URLs, also catch common bare
# Telegram/WhatsApp links that users paste without a scheme.
BARE_LINK_HOST_RE = r"(?:t\.me|telegram\.me|telegram\.dog|chat\.whatsapp\.com|wa\.me|api\.whatsapp\.com|whatsapp\.com)"
URL_RE = re.compile(
    rf"(?i)(?<![\w@])(?:(?:https?://|www\.)[^\s<>\[\]{{}}\"']+|{BARE_LINK_HOST_RE}/[^\s<>\[\]{{}}\"']+)"
)
TRAILING_PUNCTUATION = ".,;:!?)]}،؛؟»"
EXPLICIT_PHONE_RE = re.compile(r"(?i)(?:tel:|phone:|mobile:|callto:|%2b\d|\+\d(?:[\s()._-]*\d){6,})")
FORMATTED_PHONE_RE = re.compile(r"(?<!\d)\d{2,4}(?:[\s()._-]+\d{2,4}){2,}(?!\d)")
PHONE_QUERY_KEYS = {"phone", "tel", "telephone", "mobile", "number", "msisdn", "wa"}
PHONE_PATH_WORDS = {"phone", "tel", "telephone", "mobile", "call", "contact"}
COMMON_TRACKING_KEYS = {
    "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "fbclid", "gclid", "igshid"
}

WHATSAPP_HOSTS = {"chat.whatsapp.com", "wa.me", "api.whatsapp.com", "whatsapp.com", "www.whatsapp.com"}
TWITTER_HOSTS = {"twitter.com", "www.twitter.com", "mobile.twitter.com", "x.com", "www.x.com", "t.co"}
TELEGRAM_HOSTS = {"t.me", "www.t.me", "telegram.me", "www.telegram.me", "telegram.dog"}

HOST_ALIASES = {
    "www.t.me": "t.me",
    "telegram.me": "t.me",
    "www.telegram.me": "t.me",
    "telegram.dog": "t.me",
    "twitter.com": "x.com",
    "www.twitter.com": "x.com",
    "mobile.twitter.com": "x.com",
    "www.x.com": "x.com",
    "www.whatsapp.com": "whatsapp.com",
}

TELEGRAM_RESERVED_PATHS = {
    "addstickers", "addemoji", "addlist", "share", "proxy", "socks", "login", "invoice",
    "setlanguage", "bg", "iv", "contact", "boost", "giftcode", "nft", "m", "apps",
}
TELEGRAM_BOT_QUERY_KEYS = {"start", "startgroup", "startapp", "game", "attach"}


@dataclass(frozen=True, slots=True)
class CleanLink:
    original: str
    normalized: str
    category: str
    url_hash: str


@dataclass(frozen=True, slots=True)
class LinkInspection:
    link: CleanLink | None
    reason: str | None = None


def _ensure_scheme(url: str) -> str:
    value = url.strip().rstrip(TRAILING_PUNCTUATION)
    low = value.lower()
    if low.startswith("www."):
        return "https://" + value
    if re.match(rf"(?i)^{BARE_LINK_HOST_RE}/", value):
        return "https://" + value
    return value


def contains_phone_number(url: str) -> bool:
    decoded = url.replace("%2B", "+").replace("%2b", "+").replace("%20", " ")
    try:
        parts = urlsplit(_ensure_scheme(decoded))
    except ValueError:
        return False
    host = (parts.hostname or "").lower()
    segments = [segment for segment in parts.path.split("/") if segment]
    # Invite hashes may contain long digit runs and separators. Only a purely
    # numeric +path is a Telegram phone contact; mixed hashes are opaque.
    if host in TELEGRAM_HOSTS and segments:
        if segments[0].startswith('+') and not segments[0][1:].isdigit():
            return False
        if segments[0].lower() == 'joinchat' and len(segments) == 2:
            return False
    if host == 'chat.whatsapp.com' and len(segments) == 1:
        return False
    if EXPLICIT_PHONE_RE.search(decoded) or FORMATTED_PHONE_RE.search(decoded):
        return True

    # WhatsApp direct-message URLs are personal phone links and are not collected.
    if host in {"wa.me", "api.whatsapp.com"}:
        if any(segment.isdigit() and 7 <= len(segment) <= 16 for segment in segments):
            return True

    for key, value in parse_qsl(parts.query, keep_blank_values=True):
        if key.lower() in PHONE_QUERY_KEYS and re.search(r"\d{7,}", value):
            return True

    for index, segment in enumerate(segments):
        if segment.lower() in PHONE_PATH_WORDS and index + 1 < len(segments):
            if re.fullmatch(r"\+?\d{7,16}", segments[index + 1]):
                return True
    return False


def is_telegram_message_link(url: str) -> bool:
    try:
        parts = urlsplit(_ensure_scheme(url))
    except ValueError:
        return False
    if (parts.hostname or "").lower() not in TELEGRAM_HOSTS:
        return False
    segments = [segment for segment in parts.path.split("/") if segment]
    if not segments:
        return False
    if segments[0].lower() == "c" and len(segments) >= 3 and segments[1].isdigit() and segments[2].isdigit():
        return True
    if segments[0].lower() == "s" and len(segments) >= 3 and segments[-1].isdigit():
        return True
    if len(segments) >= 2 and segments[-1].isdigit():
        return True
    query = dict(parse_qsl(parts.query, keep_blank_values=True))
    return "comment" in query or "thread" in query


def classify_url(url: str) -> str:
    host = (urlsplit(_ensure_scheme(url)).hostname or "").lower()
    if host in WHATSAPP_HOSTS or host.endswith(".whatsapp.com"):
        return "whatsapp"
    if host in TWITTER_HOSTS or host.endswith(".twitter.com") or host.endswith(".x.com"):
        return "twitter"
    if host in TELEGRAM_HOSTS or host.endswith(".telegram.me"):
        return "telegram"
    return "other"


def normalize_url(url: str) -> str | None:
    prepared = _ensure_scheme(url)
    try:
        parts = urlsplit(prepared)
        port = parts.port
    except ValueError:
        return None
    if parts.scheme.lower() not in {"http", "https"} or not parts.hostname:
        return None

    host = HOST_ALIASES.get(parts.hostname.lower().rstrip("."), parts.hostname.lower().rstrip("."))
    netloc = host if port in (None, 80, 443) else f"{host}:{port}"
    path = parts.path or ""
    if path == "/":
        path = ""
    elif path.endswith("/"):
        path = path.rstrip("/")

    query_items = [
        (key, value)
        for key, value in parse_qsl(parts.query, keep_blank_values=True)
        if key.lower() not in COMMON_TRACKING_KEYS
    ]
    query_items.sort(key=lambda item: (item[0], item[1]))

    # Group/channel invite links should canonicalize to one URL regardless of
    # app-specific decoration parameters.
    if host == "chat.whatsapp.com" or (host == "whatsapp.com" and path.lower().startswith("/channel/")):
        query_items = []

    # Telegram public usernames are case-insensitive.  Canonicalizing only the
    # direct username form fixes duplicates such as /Example and /example while
    # preserving case-sensitive invite hashes.  Decorative query parameters on
    # group/channel links are removed, but bot launch parameters are retained so
    # the collection filter can still reject bot/deep-link URLs.
    if host == "t.me":
        segments = [segment for segment in path.split("/") if segment]
        if len(segments) == 1:
            first = segments[0]
            if re.fullmatch(r"[A-Za-z0-9_]{4,}", first):
                path = "/" + first.lower()
                if not ({key.lower() for key, _value in query_items} & TELEGRAM_BOT_QUERY_KEYS):
                    query_items = []
            elif first.startswith("+") and len(first) > 1:
                query_items = []
        elif len(segments) == 2 and segments[0].lower() == "joinchat" and segments[1]:
            path = "/joinchat/" + segments[1]
            query_items = []

    query = urlencode(query_items, doseq=True)
    return urlunsplit(("https", netloc, path, query, ""))


def telegram_identity_key(url: str) -> str:
    """Return a durable identity key for Telegram collection/blocklist dedup.

    Public usernames are case-insensitive. Invite hashes are case-sensitive, and
    both modern ``+hash`` and legacy ``joinchat/hash`` forms map to the same key.
    Other Telegram URLs fall back to their normalized URL.
    """
    normalized = normalize_url(url) or url.strip()
    try:
        parts = urlsplit(_ensure_scheme(normalized))
    except ValueError:
        return f"url:{normalized}"
    host = HOST_ALIASES.get((parts.hostname or "").lower().rstrip("."), (parts.hostname or "").lower().rstrip("."))
    if host != "t.me":
        return f"url:{normalized}"
    segments = [segment for segment in parts.path.split("/") if segment]
    if len(segments) == 1:
        first = segments[0]
        if first.startswith("+") and len(first) > 1:
            return f"invite:{first[1:]}"
        if re.fullmatch(r"[A-Za-z0-9_]{4,}", first):
            return f"public:{first.lower()}"
    if len(segments) == 2 and segments[0].lower() == "joinchat" and segments[1]:
        return f"invite:{segments[1]}"
    return f"url:{normalized}"


def inspect_link(url: str) -> LinkInspection:
    normalized = normalize_url(url)
    if not normalized:
        return LinkInspection(None, "invalid")
    if contains_phone_number(normalized):
        return LinkInspection(None, "phone")
    if is_telegram_message_link(normalized):
        return LinkInspection(None, "telegram_message")
    category = classify_url(normalized)
    return LinkInspection(
        CleanLink(
            original=url.strip(),
            normalized=normalized,
            category=category,
            url_hash=hashlib.sha256(normalized.encode("utf-8")).hexdigest(),
        )
    )


def _telegram_collection_reason(normalized: str) -> str | None:
    parts = urlsplit(normalized)
    if (parts.hostname or "").lower() != "t.me":
        return "telegram_service"
    segments = [segment for segment in parts.path.split("/") if segment]
    if not segments:
        return "telegram_service"

    first = segments[0]
    low = first.lower()
    if low in TELEGRAM_RESERVED_PATHS:
        return "telegram_service"

    # Private invite links are valid collection targets.
    if first.startswith("+") and len(first) > 1 and len(segments) == 1:
        return None
    if low == "joinchat" and len(segments) == 2 and segments[1]:
        return None

    # Collection targets should be direct public usernames only. Message/topic
    # links and Telegram service paths are filtered before reaching the DB.
    if len(segments) != 1:
        return "telegram_service"
    if first.isdigit():
        return "telegram_personal_numeric"
    if low.endswith("_bot") or low.endswith("bot"):
        return "telegram_bot_like"

    query_keys = {key.lower() for key, _value in parse_qsl(parts.query, keep_blank_values=True)}
    if query_keys & TELEGRAM_BOT_QUERY_KEYS:
        return "telegram_bot_like"
    return None


def _whatsapp_collection_reason(normalized: str) -> str | None:
    parts = urlsplit(normalized)
    host = (parts.hostname or "").lower()
    segments = [segment for segment in parts.path.split("/") if segment]

    # Group invites: chat.whatsapp.com/<invite>. Channels are also non-personal
    # destinations and may be useful to the section collector.
    if host == "chat.whatsapp.com" and segments:
        return None
    if host == "whatsapp.com" and len(segments) >= 2 and segments[0].lower() == "channel":
        return None

    # Direct wa.me / send?phone / personal-contact links are deliberately excluded.
    if host in {"wa.me", "api.whatsapp.com"}:
        return "whatsapp_personal"
    return "whatsapp_non_group"


def inspect_collection_link(url: str, target_category: str | None = None) -> LinkInspection:
    """Inspect a URL specifically for collection jobs.

    Collection is intentionally stricter than the audit input parser:
    * Telegram: direct group/channel candidates and invite links only; message,
      service and obvious bot/numeric-person links are excluded.
    * WhatsApp: group invite/channel links only; phone/direct-message links are excluded.
    * Other categories retain the normal URL inspection rules.

    Definitive Telegram entity classification (group/channel/person/bot/expired)
    remains the job of the audit engine so collection stays fast.
    """
    inspected = inspect_link(url)
    if not inspected.link:
        return inspected
    link = inspected.link
    if target_category and link.category != target_category:
        return LinkInspection(None, "other_category")
    if link.category == "telegram":
        reason = _telegram_collection_reason(link.normalized)
        if reason:
            return LinkInspection(None, reason)
    elif link.category == "whatsapp":
        reason = _whatsapp_collection_reason(link.normalized)
        if reason:
            return LinkInspection(None, reason)
    return inspected


def clean_link(url: str) -> CleanLink | None:
    return inspect_link(url).link


def clean_collection_link(url: str, target_category: str | None = None) -> CleanLink | None:
    return inspect_collection_link(url, target_category).link


def extract_urls_from_text(text: str) -> list[str]:
    return _unique_urls(match.group(0) for match in URL_RE.finditer(text or ""))


def extract_urls_from_message(message: object) -> list[str]:
    text = getattr(message, "message", None) or getattr(message, "text", None) or ""
    entities = getattr(message, "entities", None) or []
    found: list[str] = []

    get_entities_text = getattr(message, "get_entities_text", None)
    entity_pairs = []
    if callable(get_entities_text):
        try:
            entity_pairs = list(get_entities_text())
        except Exception:
            entity_pairs = []

    if entity_pairs:
        for entity, entity_text in entity_pairs:
            if isinstance(entity, MessageEntityTextUrl):
                found.append(entity.url)
            elif isinstance(entity, MessageEntityUrl):
                found.append(entity_text)
    else:
        for entity in entities:
            if isinstance(entity, MessageEntityTextUrl):
                found.append(entity.url)
            elif isinstance(entity, MessageEntityUrl):
                found.append(text[entity.offset : entity.offset + entity.length])

    reply_markup = getattr(message, "reply_markup", None)
    for row in getattr(reply_markup, "rows", None) or []:
        for button in getattr(row, "buttons", None) or []:
            button_url = getattr(button, "url", None)
            if button_url:
                found.append(button_url)

    webpage = getattr(getattr(message, "media", None), "webpage", None)
    webpage_url = getattr(webpage, "url", None)
    if webpage_url:
        found.append(webpage_url)

    found.extend(match.group(0) for match in URL_RE.finditer(text))
    return _unique_urls(found)


def _unique_urls(values) -> list[str]:  # type: ignore[no-untyped-def]
    result: list[str] = []
    seen: set[str] = set()
    for item in values:
        value = str(item).strip().rstrip(TRAILING_PUNCTUATION)
        if value and value not in seen:
            seen.add(value)
            result.append(value)
    return result
