from __future__ import annotations

import re
import shutil
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

CATEGORY_ORDER = ["whatsapp", "twitter", "telegram", "other"]
CATEGORY_FILE_LABELS = {
    "whatsapp": "قسم_واتساب",
    "twitter": "قسم_تويتر_X",
    "telegram": "قسم_Telegram",
    "other": "قسم_الروابط_الاخرى",
}


def safe_export_name(value: str, fallback: str = "export", max_bytes: int = 80) -> str:
    text = " ".join(str(value or fallback).split()).strip() or fallback
    text = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", text)
    text = re.sub(r"\s+", "_", text).strip("._ ") or fallback
    encoded = text.encode("utf-8")
    if len(encoded) <= max_bytes:
        return text
    encoded = encoded[:max_bytes]
    while encoded:
        try:
            return encoded.decode("utf-8").rstrip("._ ") or fallback
        except UnicodeDecodeError:
            encoded = encoded[:-1]
    return fallback


@dataclass(frozen=True, slots=True)
class ExportBundle:
    directory: Path
    text_files: tuple[Path, ...]
    zip_path: Path
    total_links: int


def build_export(
    rows: Iterable[Sequence[str]],
    name: str,
    chunk_size: int,
    *,
    export_root: Path,
) -> ExportBundle:
    if chunk_size < 1:
        raise ValueError("chunk_size must be at least 1")

    export_root.mkdir(parents=True, exist_ok=True)
    name = safe_export_name(name, "export")
    export_dir = export_root / name
    if export_dir.exists():
        shutil.rmtree(export_dir)
    export_dir.mkdir(parents=True, exist_ok=True)

    grouped: dict[str, list[str]] = {category: [] for category in CATEGORY_ORDER}
    seen: set[str] = set()
    for category, url in rows:
        category = str(category)
        url = str(url).strip()
        if not url or url in seen:
            continue
        seen.add(url)
        grouped.setdefault(category, []).append(url)

    text_files: list[Path] = []
    for category in CATEGORY_ORDER:
        urls = grouped.get(category, [])
        if not urls:
            continue
        for index in range(0, len(urls), chunk_size):
            chunk = urls[index : index + chunk_size]
            number = index // chunk_size + 1
            section = safe_export_name(CATEGORY_FILE_LABELS.get(category, category), category)
            file_path = export_dir / f"{name}__{section}__part_{number:04d}.txt"
            file_path.write_text("\n".join(chunk) + "\n", encoding="utf-8")
            text_files.append(file_path)

    zip_path = export_root / f"{name}__تصدير.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for file_path in text_files:
            archive.write(file_path, arcname=file_path.name)

    return ExportBundle(
        directory=export_dir,
        text_files=tuple(text_files),
        zip_path=zip_path,
        total_links=len(seen),
    )
