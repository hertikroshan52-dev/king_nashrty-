from aiogram.fsm.state import State, StatesGroup


class AddAccountState(StatesGroup):
    waiting_session = State()


class DestinationState(StatesGroup):
    waiting_all_destinations = State()
    waiting_single_destination = State()


class SourceState(StatesGroup):
    waiting_sources = State()


class ManualLinksState(StatesGroup):
    waiting_links = State()


class TelegramAuditState(StatesGroup):
    waiting_title = State()
    waiting_files = State()
    waiting_sources = State()
    waiting_paste = State()


class SearchState(StatesGroup):
    waiting_query = State()


class SupervisorState(StatesGroup):
    waiting_user_id = State()
    waiting_session_user_id = State()


class SessionExtractState(StatesGroup):
    waiting_phone = State()
    waiting_code = State()
    waiting_password = State()


class ExpiredLinksState(StatesGroup):
    waiting_source = State()
    waiting_restore_url = State()


class JoinGroupsState(StatesGroup):
    waiting_source = State()


class V7ScheduleState(StatesGroup):
    waiting_reminder_text = State()


class V7WorkflowState(StatesGroup):
    waiting_name = State()


class V7TagState(StatesGroup):
    waiting_tag = State()


class V7GlobalSearchState(StatesGroup):
    waiting_query = State()
