from __future__ import annotations

import asyncio
import logging
import shutil
from logging.handlers import RotatingFileHandler

from aiogram import Bot, Dispatcher
from aiogram.types import FSInputFile
from sqlalchemy import func, select, update

from app.bot import router
from app.config import get_settings
from app.db import SessionFactory, init_db
from app.keyboards import continue_keyboard, export_keyboard, main_menu, telegram_audit_result_keyboard, telegram_web_audit_result_keyboard
from app.fsm_storage import SQLiteFSMStorage
from app.models import Account, Job, TelegramAudit, utcnow
from app.services.auditor import export_audit, format_audit_summary, mark_audit_failed_from_job, process_telegram_audit_job
from app.services.backup import create_database_backup
from app.services.web_auditor import process_web_audit_job
from app.services.joiner import process_join_groups_job, process_leave_join_job
from app.services.owners import get_owner_ids, is_owner, is_primary_owner
from app.services.control_v7 import claim_due_tasks, finish_scheduled_task, session_health, run_workflow, record_system_error
from app.services.scanner import (
    ClientManager,
    JobCancelled,
    JobPaused,
    claim_next_job,
    finish_job,
    process_accounts_job,
    process_sources_job,
)

settings = get_settings()
logger = logging.getLogger(__name__)


def configure_logging() -> None:
    level = getattr(logging, settings.log_level.upper(), logging.INFO)
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s")
    root = logging.getLogger()
    root.setLevel(level)
    root.handlers.clear()

    console = logging.StreamHandler()
    console.setFormatter(formatter)
    root.addHandler(console)

    for filename, logger_name, file_level in [
        ("app.log", None, level),
        ("audit.log", "app.services.auditor", level),
        ("errors.log", "app", logging.ERROR),
    ]:
        handler = RotatingFileHandler(
            settings.logs_dir / filename,
            maxBytes=max(100_000, settings.log_max_bytes),
            backupCount=max(1, settings.log_backup_count),
            encoding="utf-8",
        )
        handler.setLevel(file_level)
        handler.setFormatter(formatter)
        target = root if logger_name is None else logging.getLogger(logger_name)
        target.addHandler(handler)
    logging.getLogger("telethon").setLevel(
        getattr(logging, settings.telethon_log_level.upper(), logging.WARNING)
    )


async def pause_active_jobs_for_shutdown() -> None:
    now = utcnow()
    async with SessionFactory() as session:
        await session.execute(
            update(Job)
            .where(Job.status.in_(["starting", "running", "pause_requested", "stopping"]))
            .values(status="paused", paused_at=now, updated_at=now, heartbeat_at=now, error="توقف البوت بأمان ويمكن استكمال المهمة.")
        )
        await session.execute(
            update(TelegramAudit)
            .where(TelegramAudit.status.in_(["starting", "running", "pause_requested", "stopping"]))
            .values(status="paused", paused_at=now, updated_at=now, current_phase="paused")
        )
        await session.commit()


async def automatic_backup_loop() -> None:
    hours = max(1, int(settings.automatic_backup_hours))
    while True:
        try:
            await asyncio.sleep(hours * 3600)
            info = await create_database_backup(prefix="auto")
            logger.info("Automatic backup created: %s", info.path)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Automatic backup failed")


async def health_alert_loop(manager: ClientManager, bot: Bot) -> None:
    """Low-noise alerts: notify only when a material condition changes."""
    previous: set[str] = set()
    interval = max(60, int(settings.health_alert_interval_seconds))
    while True:
        try:
            await asyncio.sleep(interval)
            if not settings.health_alerts:
                continue
            issues: set[str] = set()
            async with SessionFactory() as session:
                total_active = int(await session.scalar(
                    select(func.count(Account.id)).where(Account.active.is_(True))
                ) or 0)
            connected = sum(1 for client in manager.clients.values() if client.is_connected())
            if total_active and connected < total_active:
                issues.add(f"حسابات غير متصلة: {total_active - connected} من {total_active}")
            usage = shutil.disk_usage(settings.data_dir)
            used_percent = (usage.used / max(1, usage.total)) * 100.0
            if used_percent >= max(1, int(settings.disk_alert_percent)):
                issues.add(f"مساحة القرص المستخدمة مرتفعة: {used_percent:.1f}%")

            new_issues = issues - previous
            if new_issues:
                text = "⚠️ تنبيه V8 — " + settings.instance_name + "\n" + "\n".join(sorted(new_issues))
                for owner_id in await get_owner_ids():
                    try:
                        await bot.send_message(owner_id, text)
                    except Exception:
                        logger.exception("Could not send health alert to %s", owner_id)
            if previous and not issues:
                for owner_id in await get_owner_ids():
                    try:
                        await bot.send_message(owner_id, f"✅ عادت حالة {settings.instance_name} إلى طبيعتها.")
                    except Exception:
                        logger.exception("Could not send health recovery alert to %s", owner_id)
            previous = issues
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Health alert loop failed")


async def account_refresh_loop(manager: ClientManager) -> None:
    while True:
        try:
            await manager.refresh()
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Account refresh failed")
        await asyncio.sleep(settings.account_refresh_seconds)


def _accounts_summary(job_id: int, progress: dict) -> str:
    lines = [
        f"انتهت مهمة تجميع الحسابات #{job_id}.",
        f"الحسابات: {progress.get('accounts_done', 0)}/{progress.get('accounts_total', 0)}",
        f"وضع المسح: {'سريع — رسائل الروابط فقط' if progress.get('scan_mode') == 'fast_url_filter' else 'عميق — قراءة الرسائل'}",
        f"حسابات التجميع المتوازية: {progress.get('collector_workers', 1)}",
        f"المجموعات والقنوات المفحوصة: {progress.get('dialogs', 0)}",
        f"رسائل الروابط المفحوصة: {progress.get('messages_with_links', 0)}",
        f"الروابط الجديدة: {progress.get('new_links', 0)}",
        f"الروابط المكررة والمتجاهلة: {progress.get('duplicate_links', 0)}",
        f"الروابط المرفوضة: {progress.get('rejected_links', 0)}",
        f"الروابط المرسلة: {progress.get('sent_links', 0)}",
    ]
    if progress.get("delivery_failed"):
        lines.append(f"فشل إرسال: {progress.get('delivery_failed', 0)}")
    if progress.get("dialog_errors"):
        lines.append(f"مصادر تعذر فحصها: {progress.get('dialog_errors', 0)}")
    if progress.get("flood_waits"):
        lines.append(f"مرات انتظار Telegram: {progress.get('flood_waits', 0)}")
    if progress.get("reconnects"):
        lines.append(f"إعادات اتصال الحسابات: {progress.get('reconnects', 0)}")
    if progress.get("account_errors"):
        lines.append(f"حسابات تعذر إكمالها: {progress.get('account_errors', 0)}")
    return "\n".join(lines)


def _collection_accounts_report(progress: dict) -> str:
    report = progress.get("account_report") or {}
    if not isinstance(report, dict) or not report:
        return ""
    lines = ["تقرير حسابات التجميع:"]
    for account_id, row in report.items():
        if not isinstance(row, dict):
            continue
        status = str(row.get("status") or "-")
        status_label = {"completed": "✅ اكتمل", "error": "❌ خطأ", "paused": "⏸ متوقف", "running": "⏳ يعمل", "pending": "⌛ منتظر"}.get(status, status)
        lines.append(
            f"#{account_id} — {row.get('label', 'حساب')} — {status_label} | "
            f"محادثات {row.get('dialogs', 0)} | رسائل {row.get('messages', 0)} | جديد {row.get('new_links', 0)}"
        )
    return "\n".join(lines)


async def _send_long_text(bot: Bot, chat_id: int, text: str) -> None:
    if not text:
        return
    limit = 3500
    current = ""
    for line in text.splitlines():
        candidate = (current + "\n" + line).strip() if current else line
        if len(candidate) > limit and current:
            await bot.send_message(chat_id, current)
            current = line
        else:
            current = candidate
    if current:
        await bot.send_message(chat_id, current)


def _sources_summary(job_id: int, progress: dict) -> str:
    lines = [
        f"انتهت مهمة تجميع المصادر #{job_id}.",
        f"المصادر: {progress.get('sources_done', 0)}/{progress.get('sources_total', 0)}",
        f"وضع المسح: {'سريع — رسائل الروابط فقط' if progress.get('scan_mode') == 'fast_url_filter' else 'عميق — قراءة الرسائل'}",
        f"رسائل الروابط المفحوصة: {progress.get('messages_with_links', 0)}",
        f"الروابط الجديدة المسجلة: {progress.get('new_links', 0)}",
        f"الروابط الموجودة سابقًا: {progress.get('duplicate_links', 0)}",
        f"الروابط المرفوضة/خارج القسم: {progress.get('rejected_links', 0)}",
        f"الروابط المرسلة: {progress.get('sent_links', 0)}",
    ]
    if progress.get("source_errors"):
        lines.append(f"مصادر تعذر فحصها: {progress.get('source_errors', 0)}")
    return "\n".join(lines)


def _join_summary(job_id: int, progress: dict) -> str:
    per_account = int(progress.get("join_per_account", 200) or 200)
    lines = [
        f"انتهت مهمة الانضمام #{job_id}.",
        f"التوزيع الثابت: {progress.get('join_assigned', 0)} رابطًا — حتى {per_account} لكل حساب.",
        f"تمت معالجة: {progress.get('join_processed', 0)}",
        f"انضمام ناجح: {progress.get('join_joined', 0)}",
        f"عضو مسبقًا: {progress.get('join_already', 0)}",
        f"طلبات انضمام: {progress.get('join_requested', 0)}",
        f"محظور/مطرود قبل الانضمام: {progress.get('join_banned', 0)}",
        f"لم تثبت العضوية بعد الانضمام: {progress.get('join_removed_after_join', 0)}",
        f"روابط منتهية: {progress.get('join_expired', 0)}",
        f"أخطاء: {progress.get('join_errors', 0)}",
        f"FloodWait: {progress.get('join_flood_waits', 0)}",
        f"روابط توقفت بسبب حد عضويات الحساب: {progress.get('join_account_limit_links', 0)}",
        f"نُسخت إلى Saved Messages: {progress.get('join_saved_messages_backed_up', 0)}",
        f"أخطاء نسخ Saved Messages: {progress.get('join_saved_messages_errors', 0)}",
        f"روابط غير معالجة: {progress.get('join_pending', 0)}",
    ]
    report = progress.get("account_report") or {}
    if isinstance(report, dict) and report:
        lines.append("\nتقرير كل حساب:")
        for account_id, row in report.items():
            if not isinstance(row, dict):
                continue
            lines.append(
                f"#{account_id} — {row.get('label', 'حساب')} — "
                f"موزع {row.get('assigned', 0)} / معالج {row.get('processed', 0)} / "
                f"ناجح {row.get('completed_memberships', 0)} — {row.get('status', '-')}"
            )
    return "\n".join(lines)


def _leave_summary(job_id: int, progress: dict) -> str:
    return "\n".join([
        f"انتهت مهمة مغادرة العضويات #{job_id}.",
        f"العضويات المستهدفة: {progress.get('leave_total', 0)}",
        f"تمت المغادرة: {progress.get('leave_completed', 0)}",
        f"كانت مغادرة مسبقًا: {progress.get('leave_already', 0)}",
        f"أخطاء: {progress.get('leave_errors', 0)}",
        f"FloodWait: {progress.get('leave_flood_waits', 0)}",
    ])


async def job_loop(manager: ClientManager, bot: Bot) -> None:
    while True:
        try:
            job = await claim_next_job()
            if not job:
                await asyncio.sleep(settings.worker_poll_seconds)
                continue
            try:
                if not await is_owner(int(job.requested_by)):
                    await finish_job(job.id, status="cancelled", error="مالك المهمة لم يعد ضمن مستخدمي البوت المصرح لهم.")
                    continue
                await manager.refresh()
                if job.mode == "accounts":
                    progress = await process_accounts_job(job, manager, bot)
                    has_warnings = bool(progress.get("delivery_failed") or progress.get("dialog_errors"))
                    status = "completed_with_errors" if has_warnings else "completed"
                    await finish_job(job.id, status=status)
                    await bot.send_message(
                        job.requested_by,
                        _accounts_summary(job.id, progress),
                        reply_markup=continue_keyboard(job.id),
                    )
                    await _send_long_text(bot, job.requested_by, _collection_accounts_report(progress))
                elif job.mode == "sources":
                    progress = await process_sources_job(job, manager, bot)
                    status = "completed_with_errors" if progress.get("source_errors") else "completed"
                    await finish_job(job.id, status=status)
                    await bot.send_message(
                        job.requested_by,
                        _sources_summary(job.id, progress),
                        reply_markup=export_keyboard(job.id),
                    )
                elif job.mode == "join_groups":
                    progress = await process_join_groups_job(job, manager)
                    status = "completed_with_errors" if (
                        progress.get("join_errors") or progress.get("join_incomplete_accounts")
                    ) else "completed"
                    await finish_job(job.id, status=status)
                    await _send_long_text(bot, job.requested_by, _join_summary(job.id, progress))
                    await bot.send_message(job.requested_by, "إجراءات مهمة الانضمام:", reply_markup=continue_keyboard(job.id))
                elif job.mode == "leave_joined":
                    progress = await process_leave_join_job(job, manager)
                    status = "completed_with_errors" if progress.get("leave_errors") else "completed"
                    await finish_job(job.id, status=status)
                    await bot.send_message(
                        job.requested_by,
                        _leave_summary(job.id, progress),
                        reply_markup=main_menu(),
                    )
                elif job.mode == "telegram_web_audit":
                    progress = await process_web_audit_job(job)
                    status = "completed_with_errors" if progress.get("temporary_error") else "completed"
                    progress["status"] = status
                    await finish_job(job.id, status=status)
                    await bot.send_message(
                        job.requested_by,
                        format_audit_summary(progress),
                        reply_markup=telegram_web_audit_result_keyboard(int(progress["audit_id"])),
                    )
                    if await is_primary_owner(int(job.requested_by)):
                        try:
                            bundle = await export_audit(int(progress["audit_id"]))
                            await bot.send_document(
                                job.requested_by,
                                FSInputFile(bundle.zip_path),
                                caption=(
                                    f"نتائج فحص المتصفح #{progress['audit_id']}\n"
                                    "كل قسم في ملف TXT مستقل، مع التقرير الكامل داخل ZIP."
                                ),
                            )
                        except Exception:
                            logger.exception("Could not auto-export web audit %s", progress.get("audit_id"))
                elif job.mode == "telegram_audit":
                    progress = await process_telegram_audit_job(job, manager)
                    status = "completed_with_errors" if (
                        progress.get("error") or progress.get("restricted_access")
                        or progress.get("whatsapp_scan_errors") or progress.get("telegram_scan_errors")
                    ) else "completed"
                    progress["status"] = status
                    await finish_job(job.id, status=status)
                    await bot.send_message(
                        job.requested_by,
                        format_audit_summary(progress),
                        reply_markup=telegram_audit_result_keyboard(int(progress["audit_id"])),
                    )
                    # Only the primary owner may receive link exports. Supervisors
                    # get the audit summary and may continue the same audit with new
                    # links, but no link file is delivered to them.
                    if await is_primary_owner(int(job.requested_by)):
                        try:
                            bundle = await export_audit(int(progress["audit_id"]))
                            await bot.send_document(
                                job.requested_by,
                                FSInputFile(bundle.zip_path),
                                caption=(
                                    f"ملفات نتائج فحص Telegram #{progress['audit_id']} — V8.0\n"
                                    "ملف TXT واحد لكل قسم افتراضيًا. من زر خيارات التصدير يمكن اختيار تقسيم 200 أو 1000 رابط."
                                ),
                            )
                        except Exception:
                            # Export delivery must never turn an already-completed audit
                            # into a failed job. The result buttons can re-export it later.
                            logger.exception("Could not auto-export Telegram audit %s", progress.get("audit_id"))
                else:
                    raise RuntimeError(f"نوع مهمة غير معروف: {job.mode}")
            except JobPaused as exc:
                if job.mode in {"telegram_audit", "telegram_web_audit"}:
                    await mark_audit_failed_from_job(job, str(exc), status="paused")
                await finish_job(job.id, status="paused", error=str(exc))
                try:
                    await bot.send_message(
                        job.requested_by,
                        f"تم إيقاف المهمة #{job.id} مؤقتًا. يمكنك استكمالها من شاشة العمليات دون فقدان النتائج.",
                        reply_markup=main_menu(),
                    )
                except Exception:
                    logger.exception("Could not notify owner about paused job")
            except JobCancelled as exc:
                if job.mode in {"telegram_audit", "telegram_web_audit"}:
                    await mark_audit_failed_from_job(job, str(exc), status="cancelled")
                job_still_exists = await finish_job(job.id, status="cancelled", error=str(exc))
                if job_still_exists:
                    await bot.send_message(job.requested_by, f"تم إلغاء المهمة #{job.id}.", reply_markup=main_menu())
            except Exception as exc:
                async with SessionFactory() as session:
                    persisted_status = await session.scalar(select(Job.status).where(Job.id == job.id))
                if persisted_status in {"completed", "completed_with_errors"}:
                    logger.exception("Job %s completed, but notification failed", job.id)
                    continue
                logger.exception("Job %s failed", job.id)
                try:
                    await record_system_error("job", str(exc), requested_by=int(job.requested_by), detail=f"job_id={job.id}; mode={job.mode}")
                except Exception:
                    logger.exception("Could not persist V7 job error")
                if job.mode in {"telegram_audit", "telegram_web_audit"}:
                    await mark_audit_failed_from_job(job, str(exc))
                await finish_job(job.id, status="failed", error=str(exc)[:4000])
                try:
                    await bot.send_message(
                        job.requested_by,
                        f"فشلت المهمة #{job.id}: {exc}",
                        reply_markup=main_menu(),
                    )
                except Exception:
                    logger.exception("Could not notify owner about job failure")
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Worker loop error")
            await asyncio.sleep(settings.worker_poll_seconds)


async def v7_scheduler_loop(bot: Bot) -> None:
    """Durable V7 scheduler. Tasks are claimed in SQLite and survive restarts."""
    while True:
        try:
            tasks = await claim_due_tasks(limit=10)
            if not tasks:
                await asyncio.sleep(5)
                continue
            for task in tasks:
                error = None
                try:
                    if not await is_owner(int(task.requested_by)):
                        raise RuntimeError("المشرف لم يعد مصرحًا له.")
                    if task.task_type == "reminder":
                        await bot.send_message(int(task.requested_by), f"⏰ {task.payload.get('text') or task.title}")
                    elif task.task_type == "backup":
                        info = await create_database_backup(prefix="scheduled")
                        await bot.send_message(int(task.requested_by), f"💾 تم إنشاء النسخة المجدولة: {info.path.name}")
                    elif task.task_type == "health":
                        rows = await session_health(int(task.requested_by))
                        await bot.send_message(int(task.requested_by), f"🩺 Health: {len(rows)} حساب | صحة 80+: {sum(1 for r in rows if r['score'] >= 80)}")
                    elif task.task_type == "workflow":
                        workflow_id = int(task.payload.get("workflow_id") or 0)
                        await run_workflow(workflow_id, int(task.requested_by), bot)
                    else:
                        raise RuntimeError(f"نوع Scheduled Task غير معروف: {task.task_type}")
                except Exception as exc:
                    error = str(exc)
                    logger.exception("Scheduled task %s failed", task.id)
                    await record_system_error("scheduler", str(exc), requested_by=int(task.requested_by), detail=f"task_id={task.id}")
                await finish_scheduled_task(int(task.id), error=error)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.exception("V7 scheduler loop failed")
            try:
                await record_system_error("scheduler_loop", str(exc))
            except Exception:
                pass
            await asyncio.sleep(5)


async def main() -> None:
    configure_logging()
    await init_db(recover_interrupted=True)
    bot = Bot(settings.bot_token)
    dispatcher = Dispatcher(storage=SQLiteFSMStorage())
    dispatcher.include_router(router)
    manager = ClientManager(bot)
    await manager.start()
    await manager.refresh()

    refresh_task = asyncio.create_task(account_refresh_loop(manager), name="account-refresh")
    worker_count = max(1, min(32, int(settings.job_workers)))
    worker_tasks = [
        asyncio.create_task(job_loop(manager, bot), name=f"job-worker-{index + 1}")
        for index in range(worker_count)
    ]
    backup_task = asyncio.create_task(automatic_backup_loop(), name="automatic-backup")
    health_task = asyncio.create_task(health_alert_loop(manager, bot), name="health-alerts")
    scheduler_task = asyncio.create_task(v7_scheduler_loop(bot), name="v7-scheduler")
    try:
        await dispatcher.start_polling(bot, close_bot_session=False)
    finally:
        await pause_active_jobs_for_shutdown()
        refresh_task.cancel()
        for task in worker_tasks:
            task.cancel()
        backup_task.cancel()
        health_task.cancel()
        scheduler_task.cancel()
        await asyncio.gather(refresh_task, *worker_tasks, backup_task, health_task, scheduler_task, return_exceptions=True)
        await manager.close()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
