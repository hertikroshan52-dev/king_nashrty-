from __future__ import annotations

import asyncio


# Blocks writes only while a destructive reset transaction is running.
reset_in_progress = asyncio.Event()

# Prevents stale in-memory watch configurations from recreating links after reset.
# ClientManager clears it after refreshing watches from the database.
live_handlers_suspended = asyncio.Event()
