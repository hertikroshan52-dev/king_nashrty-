from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from sqlalchemy import BigInteger, Boolean, DateTime, ForeignKey, Index, Integer, JSON, String, Text, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class AppSetting(Base):
    __tablename__ = "app_settings"

    key: Mapped[str] = mapped_column(String(80), primary_key=True)
    value: Mapped[Any] = mapped_column(JSON)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class Account(Base):
    __tablename__ = "accounts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    operator_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True, index=True)
    label: Mapped[str] = mapped_column(String(120))
    telegram_user_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    phone: Mapped[str | None] = mapped_column(String(40), nullable=True)
    username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    api_id: Mapped[int] = mapped_column(Integer)
    encrypted_api_hash: Mapped[str] = mapped_column(Text)
    encrypted_session: Mapped[str] = mapped_column(Text)
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)

    # Persisted account health. This deliberately lives in the DB so a restart
    # does not forget that an account is cooling down or unhealthy.
    health_status: Mapped[str] = mapped_column(String(24), default="healthy", index=True)
    flood_wait_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_success_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_error_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    requests_count: Mapped[int] = mapped_column(Integer, default=0)
    errors_count: Mapped[int] = mapped_column(Integer, default=0)
    consecutive_errors: Mapped[int] = mapped_column(Integer, default=0)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class AccountMembership(Base):
    __tablename__ = "account_memberships"
    __table_args__ = (
        UniqueConstraint("account_id", "peer_id", name="uq_account_membership_peer"),
        Index("ix_membership_peer", "peer_id"),
        Index("ix_membership_account_refreshed", "account_id", "refreshed_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("accounts.id", ondelete="CASCADE"), index=True)
    peer_id: Mapped[int] = mapped_column(BigInteger)
    peer_type: Mapped[str | None] = mapped_column(String(24), nullable=True)
    title: Mapped[str | None] = mapped_column(Text, nullable=True)
    username: Mapped[str | None] = mapped_column(String(80), nullable=True)
    refreshed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)


class DestinationConfig(Base):
    __tablename__ = "destination_configs"

    owner_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    destinations: Mapped[dict[str, int]] = mapped_column(JSON, default=dict)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class Job(Base):
    __tablename__ = "jobs"
    __table_args__ = (
        Index("ix_job_status_id", "status", "id"),
        Index("ix_job_audit", "audit_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    requested_by: Mapped[int] = mapped_column(BigInteger, index=True)
    mode: Mapped[str] = mapped_column(String(32), index=True)  # accounts | sources | telegram_audit
    scope: Mapped[str] = mapped_column(String(16), default="all")
    category: Mapped[str | None] = mapped_column(String(32), nullable=True)
    audit_id: Mapped[int | None] = mapped_column(ForeignKey("telegram_audits.id", ondelete="SET NULL"), nullable=True)
    sources: Mapped[list[str]] = mapped_column(JSON, default=list)
    destinations: Mapped[dict[str, int]] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(24), default="queued", index=True)
    progress: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)
    heartbeat_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    paused_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class JobCursor(Base):
    """Durable cursor used by long scans.

    A cursor is keyed by job + source key. For source scans the source key is the
    source URL/username. For account scans it is ``account:<id>:dialog:<id>``.
    ``offset_id`` is the last Telegram message id that has already been committed.
    """

    __tablename__ = "job_cursors"
    __table_args__ = (
        UniqueConstraint("job_id", "cursor_key", name="uq_job_cursor_key"),
        Index("ix_job_cursor_status", "job_id", "status"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    job_id: Mapped[int] = mapped_column(ForeignKey("jobs.id", ondelete="CASCADE"), index=True)
    cursor_key: Mapped[str] = mapped_column(String(512))
    offset_id: Mapped[int] = mapped_column(BigInteger, default=0)
    status: Mapped[str] = mapped_column(String(24), default="pending", index=True)
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class CollectionCheckpoint(Base):
    __tablename__ = "collection_checkpoints"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source_key: Mapped[str] = mapped_column(String(512), unique=True, index=True)
    high_water_message_id: Mapped[int] = mapped_column(BigInteger, default=0)
    category: Mapped[str | None] = mapped_column(String(16), nullable=True, index=True)
    last_scan_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_status: Mapped[str | None] = mapped_column(String(24), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class SourceStat(Base):
    __tablename__ = "source_stats"
    __table_args__ = (UniqueConstraint("source_key", "category", name="uq_source_stat_key_category"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source_key: Mapped[str] = mapped_column(String(512), index=True)
    category: Mapped[str] = mapped_column(String(16), default="all", index=True)
    scans: Mapped[int] = mapped_column(Integer, default=0)
    messages_scanned: Mapped[int] = mapped_column(Integer, default=0)
    links_found: Mapped[int] = mapped_column(Integer, default=0)
    new_links: Mapped[int] = mapped_column(Integer, default=0)
    duplicate_links: Mapped[int] = mapped_column(Integer, default=0)
    errors: Mapped[int] = mapped_column(Integer, default=0)
    quality_score: Mapped[int] = mapped_column(Integer, default=0)
    last_scan_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class Link(Base):
    __tablename__ = "links"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    original_url: Mapped[str] = mapped_column(Text)
    normalized_url: Mapped[str] = mapped_column(Text, unique=True)
    url_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    category: Mapped[str] = mapped_column(String(16), index=True)
    origin: Mapped[str] = mapped_column(String(16), default="account", index=True)
    first_job_id: Mapped[int | None] = mapped_column(ForeignKey("jobs.id", ondelete="SET NULL"), nullable=True)
    first_source_account_id: Mapped[int | None] = mapped_column(ForeignKey("accounts.id", ondelete="SET NULL"), nullable=True)
    first_source_chat_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    first_source_message_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    first_source_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    seen_count: Mapped[int] = mapped_column(Integer, default=1)


class TelegramExpiredLinkBlocklist(Base):
    """Durable tombstone for definitively dead Telegram links.

    The active ``links`` row is deleted after an audit confirms expiration, but
    this compact identity record remains so future collectors never re-add the
    same username/invite merely because it appears again in old chat history.
    """

    __tablename__ = "telegram_expired_link_blocklist"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    identity_key: Mapped[str] = mapped_column(String(640), unique=True, index=True)
    normalized_url: Mapped[str] = mapped_column(Text)
    reason: Mapped[str] = mapped_column(String(64), default="expired")
    first_audit_id: Mapped[int | None] = mapped_column(ForeignKey("telegram_audits.id", ondelete="SET NULL"), nullable=True)
    last_audit_id: Mapped[int | None] = mapped_column(ForeignKey("telegram_audits.id", ondelete="SET NULL"), nullable=True)
    first_blocked_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    last_blocked_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    rediscovered_count: Mapped[int] = mapped_column(Integer, default=0)


class LinkOccurrence(Base):
    __tablename__ = "link_occurrences"
    __table_args__ = (
        UniqueConstraint("link_id", "source_account_id", "source_chat_id", "source_message_id", name="uq_link_occurrence_source"),
        Index("ix_link_occurrence_link_date", "link_id", "seen_at"),
        Index("ix_link_occurrence_chat", "source_chat_id", "seen_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    link_id: Mapped[int] = mapped_column(ForeignKey("links.id", ondelete="CASCADE"), index=True)
    job_id: Mapped[int | None] = mapped_column(ForeignKey("jobs.id", ondelete="SET NULL"), nullable=True, index=True)
    source_account_id: Mapped[int | None] = mapped_column(ForeignKey("accounts.id", ondelete="SET NULL"), nullable=True)
    source_chat_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    source_message_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    source_message_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)


class JobLink(Base):
    __tablename__ = "job_links"
    __table_args__ = (UniqueConstraint("job_id", "link_id", name="uq_job_link"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    job_id: Mapped[int] = mapped_column(ForeignKey("jobs.id", ondelete="CASCADE"), index=True)
    link_id: Mapped[int] = mapped_column(ForeignKey("links.id", ondelete="CASCADE"), index=True)
    was_new: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Delivery(Base):
    __tablename__ = "deliveries"
    __table_args__ = (
        UniqueConstraint("link_id", "destination_chat_id", name="uq_link_destination"),
        Index("ix_delivery_destination_status", "destination_chat_id", "status"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    link_id: Mapped[int] = mapped_column(ForeignKey("links.id", ondelete="CASCADE"), index=True)
    destination_chat_id: Mapped[int] = mapped_column(BigInteger)
    job_id: Mapped[int | None] = mapped_column(ForeignKey("jobs.id", ondelete="SET NULL"), nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="sending", index=True)
    telegram_message_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class WatchConfig(Base):
    __tablename__ = "watch_configs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    requested_by: Mapped[int] = mapped_column(BigInteger, index=True)
    destinations: Mapped[dict[str, int]] = mapped_column(JSON, default=dict)
    categories: Mapped[list[str]] = mapped_column(JSON, default=lambda: ["whatsapp", "twitter", "telegram", "other"])
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    source_job_id: Mapped[int | None] = mapped_column(ForeignKey("jobs.id", ondelete="SET NULL"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class JoinCandidate(Base):
    """Telegram group/channel link staged for rate-limited joining.

    Candidates are scoped to the operator who created the join task. The global
    Link table remains shared/deduplicated across all operators.
    """

    __tablename__ = "join_candidates"
    __table_args__ = (
        UniqueConstraint("requested_by", "normalized_url", name="uq_join_candidate_operator_url"),
        Index("ix_join_candidate_operator_status", "requested_by", "status", "id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    requested_by: Mapped[int] = mapped_column(BigInteger, index=True)
    original_url: Mapped[str] = mapped_column(Text)
    normalized_url: Mapped[str] = mapped_column(Text)
    source_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(24), default="pending", index=True)
    assigned_account_id: Mapped[int | None] = mapped_column(ForeignKey("accounts.id", ondelete="SET NULL"), nullable=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)
    joined_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class JoinAssignment(Base):
    """Durable per-job assignment of one candidate to one Telegram account.

    V7 stored the last assigned account directly on ``join_candidates``.  That
    made retries, resume, per-account quotas and task-scoped cleanup ambiguous.
    V8 keeps the candidate pool intact and records every decision here.
    """

    __tablename__ = "join_assignments"
    __table_args__ = (
        UniqueConstraint("job_id", "candidate_id", name="uq_join_assignment_job_candidate"),
        Index("ix_join_assignment_job_account_status", "job_id", "account_id", "status"),
        Index("ix_join_assignment_operator_status", "requested_by", "status", "id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    job_id: Mapped[int] = mapped_column(ForeignKey("jobs.id", ondelete="CASCADE"), index=True)
    requested_by: Mapped[int] = mapped_column(BigInteger, index=True)
    candidate_id: Mapped[int] = mapped_column(ForeignKey("join_candidates.id", ondelete="CASCADE"), index=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("accounts.id", ondelete="CASCADE"), index=True)
    status: Mapped[str] = mapped_column(String(32), default="pending", index=True)
    peer_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True, index=True)
    peer_type: Mapped[str | None] = mapped_column(String(24), nullable=True)
    title: Mapped[str | None] = mapped_column(Text, nullable=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    next_retry_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    saved_message_sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    saved_message_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    legacy_imported: Mapped[bool] = mapped_column(Boolean, default=False)
    joined_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    left_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class TelegramPeer(Base):
    __tablename__ = "telegram_peers"

    peer_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    peer_type: Mapped[str | None] = mapped_column(String(24), nullable=True, index=True)
    title: Mapped[str | None] = mapped_column(Text, nullable=True)
    username: Mapped[str | None] = mapped_column(String(80), nullable=True, index=True)
    first_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)


class TelegramPeerAlias(Base):
    __tablename__ = "telegram_peer_aliases"
    __table_args__ = (UniqueConstraint("normalized_url", name="uq_peer_alias_url"), Index("ix_peer_alias_peer", "peer_id"))

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    peer_id: Mapped[int] = mapped_column(ForeignKey("telegram_peers.peer_id", ondelete="CASCADE"), index=True)
    normalized_url: Mapped[str] = mapped_column(Text)
    first_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class TelegramResolutionCache(Base):
    __tablename__ = "telegram_resolution_cache"

    normalized_url: Mapped[str] = mapped_column(Text, primary_key=True)
    status: Mapped[str] = mapped_column(String(32), index=True)
    peer_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True, index=True)
    peer_type: Mapped[str | None] = mapped_column(String(24), nullable=True)
    title: Mapped[str | None] = mapped_column(Text, nullable=True)
    username: Mapped[str | None] = mapped_column(String(80), nullable=True)
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    error_class: Mapped[str | None] = mapped_column(String(32), nullable=True)
    checked_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)


class FSMRecord(Base):
    __tablename__ = "fsm_records"

    storage_key: Mapped[str] = mapped_column(String(320), primary_key=True)
    state: Mapped[str | None] = mapped_column(String(160), nullable=True)
    data: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class AdminActionLog(Base):
    __tablename__ = "admin_action_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    action: Mapped[str] = mapped_column(String(80), index=True)
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)


class TelegramAudit(Base):
    __tablename__ = "telegram_audits"
    __table_args__ = (
        Index("ix_audit_status_updated", "status", "updated_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    requested_by: Mapped[int] = mapped_column(BigInteger, index=True)
    source_type: Mapped[str] = mapped_column(String(24), index=True)  # database | files | sources | paste
    title: Mapped[str | None] = mapped_column(String(160), nullable=True)
    status: Mapped[str] = mapped_column(String(24), default="draft", index=True)
    total_inputs: Mapped[int] = mapped_column(Integer, default=0)
    checked_inputs: Mapped[int] = mapped_column(Integer, default=0)
    last_processed_input_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    current_account_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    current_phase: Mapped[str | None] = mapped_column(String(48), nullable=True)
    summary: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)
    paused_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class TelegramAuditInput(Base):
    __tablename__ = "telegram_audit_inputs"
    __table_args__ = (
        UniqueConstraint("audit_id", "normalized_url", name="uq_audit_input_url"),
        Index("ix_audit_input_audit_id_id", "audit_id", "id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    audit_id: Mapped[int] = mapped_column(ForeignKey("telegram_audits.id", ondelete="CASCADE"), index=True)
    original_url: Mapped[str] = mapped_column(Text)
    normalized_url: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class TelegramAuditResult(Base):
    __tablename__ = "telegram_audit_results"
    __table_args__ = (
        UniqueConstraint("audit_id", "input_id", name="uq_audit_result_input"),
        Index("ix_audit_result_status", "audit_id", "status"),
        Index("ix_audit_result_peer", "audit_id", "peer_id"),
        Index("ix_audit_result_retry", "audit_id", "status", "next_retry_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    audit_id: Mapped[int] = mapped_column(ForeignKey("telegram_audits.id", ondelete="CASCADE"), index=True)
    input_id: Mapped[int] = mapped_column(ForeignKey("telegram_audit_inputs.id", ondelete="CASCADE"), index=True)
    normalized_url: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(32), index=True)
    peer_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    peer_type: Mapped[str | None] = mapped_column(String(24), nullable=True)
    title: Mapped[str | None] = mapped_column(Text, nullable=True)
    username: Mapped[str | None] = mapped_column(String(80), nullable=True)
    account_ids: Mapped[list[int]] = mapped_column(JSON, default=list)
    account_labels: Mapped[list[str]] = mapped_column(JSON, default=list)
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    error_class: Mapped[str | None] = mapped_column(String(32), nullable=True)
    attempt_count: Mapped[int] = mapped_column(Integer, default=1)
    next_retry_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    checked_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class TelegramAuditTelegramDiscovery(Base):
    """Telegram links discovered while auditing another Telegram chat.

    Rows are written only when the URL was globally new to the main ``links``
    table.  This gives each audit a dedicated discovery export while the main
    link database remains the single deduplication authority.
    """

    __tablename__ = "telegram_audit_telegram_discovery"
    __table_args__ = (
        UniqueConstraint("audit_id", "normalized_url", name="uq_audit_telegram_discovery_url"),
        Index("ix_audit_telegram_discovery_audit", "audit_id"),
        Index("ix_audit_telegram_discovery_link", "link_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    audit_id: Mapped[int] = mapped_column(ForeignKey("telegram_audits.id", ondelete="CASCADE"), index=True)
    link_id: Mapped[int] = mapped_column(ForeignKey("links.id", ondelete="CASCADE"), index=True)
    normalized_url: Mapped[str] = mapped_column(Text)
    source_telegram_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    source_peer_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    source_account_id: Mapped[int | None] = mapped_column(ForeignKey("accounts.id", ondelete="SET NULL"), nullable=True)
    source_message_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    source_message_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class TelegramAuditWhatsapp(Base):
    __tablename__ = "telegram_audit_whatsapp"
    __table_args__ = (
        UniqueConstraint("audit_id", "normalized_url", name="uq_audit_whatsapp_url"),
        Index("ix_audit_whatsapp_audit", "audit_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    audit_id: Mapped[int] = mapped_column(ForeignKey("telegram_audits.id", ondelete="CASCADE"), index=True)
    normalized_url: Mapped[str] = mapped_column(Text)
    source_telegram_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    source_peer_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    source_account_id: Mapped[int | None] = mapped_column(ForeignKey("accounts.id", ondelete="SET NULL"), nullable=True)
    source_message_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    source_message_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


# --- V7 control-plane models -------------------------------------------------
class ScheduledTask(Base):
    __tablename__ = "scheduled_tasks"
    __table_args__ = (
        Index("ix_scheduled_task_due", "status", "next_run_at"),
        Index("ix_scheduled_task_owner", "requested_by", "id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    requested_by: Mapped[int] = mapped_column(BigInteger, index=True)
    task_type: Mapped[str] = mapped_column(String(40), index=True)
    title: Mapped[str] = mapped_column(String(160))
    payload: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(24), default="scheduled", index=True)
    next_run_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    interval_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)
    last_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class Workflow(Base):
    __tablename__ = "workflows"
    __table_args__ = (Index("ix_workflow_owner", "requested_by", "id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    requested_by: Mapped[int] = mapped_column(BigInteger, index=True)
    name: Mapped[str] = mapped_column(String(160))
    steps: Mapped[list[dict[str, Any]]] = mapped_column(JSON, default=list)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    run_count: Mapped[int] = mapped_column(Integer, default=0)
    last_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class EntityTag(Base):
    __tablename__ = "entity_tags"
    __table_args__ = (
        UniqueConstraint("requested_by", "entity_type", "entity_key", "tag", name="uq_entity_tag_owner_key"),
        Index("ix_entity_tag_lookup", "requested_by", "tag"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    requested_by: Mapped[int] = mapped_column(BigInteger, index=True)
    entity_type: Mapped[str] = mapped_column(String(32), index=True)
    entity_key: Mapped[str] = mapped_column(String(512), index=True)
    tag: Mapped[str] = mapped_column(String(80), index=True)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class SystemError(Base):
    __tablename__ = "system_errors"
    __table_args__ = (
        Index("ix_system_error_open", "resolved", "created_at"),
        Index("ix_system_error_owner", "requested_by", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    requested_by: Mapped[int | None] = mapped_column(BigInteger, nullable=True, index=True)
    component: Mapped[str] = mapped_column(String(80), index=True)
    severity: Mapped[str] = mapped_column(String(16), default="error", index=True)
    message: Mapped[str] = mapped_column(Text)
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    resolved: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class SessionEvent(Base):
    __tablename__ = "session_events"
    __table_args__ = (Index("ix_session_event_owner", "operator_id", "created_at"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    operator_id: Mapped[int] = mapped_column(BigInteger, index=True)
    account_id: Mapped[int | None] = mapped_column(ForeignKey("accounts.id", ondelete="SET NULL"), nullable=True)
    event: Mapped[str] = mapped_column(String(64), index=True)
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
