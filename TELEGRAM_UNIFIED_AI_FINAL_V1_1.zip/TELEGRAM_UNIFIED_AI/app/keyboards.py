from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

CATEGORY_LABELS = {
    "whatsapp": "واتساب",
    "twitter": "تويتر / X",
    "telegram": "تليجرام",
    "other": "روابط أخرى",
}

SCOPE_LABELS = {
    "new": "الجديد فقط منذ آخر تجميع ناجح",
    "all": "كل الروابط منذ إنشاء المصادر",
    "30d": "آخر شهر",
    "14d": "آخر أسبوعين",
    "7d": "آخر أسبوع",
    "3d": "آخر 3 أيام",
    "24h": "آخر 24 ساعة",
}

STATUS_LABELS = {
    "queued": "في الانتظار",
    "starting": "يبدأ",
    "running": "يعمل",
    "pause_requested": "طلب إيقاف مؤقت",
    "paused": "متوقف مؤقتًا",
    "stopping": "جارٍ الإيقاف",
    "cancel_requested": "طلب إلغاء",
    "cancelled": "ملغي",
    "completed": "مكتمل",
    "completed_with_errors": "مكتمل بتحذيرات",
    "failed": "فشل",
}


def main_menu() -> InlineKeyboardMarkup:
    # V6.4: one Bot Token, many authorized supervisors. General collection
    # buttons were removed; category collection now owns both source choices.
    rows: list[list[InlineKeyboardButton]] = [
        [InlineKeyboardButton(text="1 - إضافة حسابات Telethon", callback_data="accounts:add")],
        [InlineKeyboardButton(text="🔐 مركز الجلسات الآمن", callback_data="session:center")],
        [InlineKeyboardButton(text="🧭 مركز V8 المتكامل", callback_data="v7:center")],
        [InlineKeyboardButton(text="2 - تجميع حسب القسم", callback_data="collect:category")],
        [InlineKeyboardButton(text="3 - استقبال روابط جديدة يدويًا", callback_data="manual:start")],
        [InlineKeyboardButton(text="4 - فحص وتصفية روابط Telegram", callback_data="audit:menu")],
        [InlineKeyboardButton(text="5 - الانضمام إلى المجموعات", callback_data="join:start")],
        [InlineKeyboardButton(text="🗑️ سجل الروابط المنتهية — للمالك", callback_data="expired:menu")],
        [InlineKeyboardButton(text="👤 إضافة/إدارة المشرفين — للمالك", callback_data="supervisors:menu")],
        [
            InlineKeyboardButton(text="الحسابات", callback_data="accounts:list"),
            InlineKeyboardButton(text="المهام", callback_data="jobs:list"),
        ],
        [
            InlineKeyboardButton(text="الاستمرار المباشر", callback_data="watches:list"),
            InlineKeyboardButton(text="قاعدة الروابط", callback_data="database:stats"),
        ],
        [
            InlineKeyboardButton(text="🚀 لوحة التحكم", callback_data="system:dashboard"),
            InlineKeyboardButton(text="🔍 البحث — للمالك", callback_data="search:start"),
        ],
        [InlineKeyboardButton(text="💾 النسخ الاحتياطي والاستعادة — للمالك", callback_data="backup:menu")],
        [InlineKeyboardButton(text="⚠️ إعادة ضبط البوت — للمالك", callback_data="reset:menu")],
        [InlineKeyboardButton(text="🧠 مساعد الذكاء الاصطناعي — التجميع والتصفية", callback_data="hub:collector_ai")],
        [InlineKeyboardButton(text="🏠 العودة لاختيار البوت", callback_data="hub:home")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def back_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="القائمة الرئيسية", callback_data="menu")]]
    )


def cancel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="إلغاء", callback_data="cancel")]]
    )


def scope_keyboard(prefix: str) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=label, callback_data=f"{prefix}:{value}")] for value, label in SCOPE_LABELS.items()]
    rows.append([InlineKeyboardButton(text="إلغاء", callback_data="cancel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def collection_scan_mode_keyboard(prefix: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="⚡ تجميع سريع — رسائل الروابط فقط", callback_data=f"{prefix}:fast")],
            [InlineKeyboardButton(text="🔎 تجميع عميق — مسح كل الرسائل", callback_data=f"{prefix}:deep")],
            [InlineKeyboardButton(text="إلغاء", callback_data="cancel")],
        ]
    )


def category_keyboard() -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=label, callback_data=f"category:{value}")] for value, label in CATEGORY_LABELS.items()]
    rows.append([InlineKeyboardButton(text="إلغاء", callback_data="cancel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def category_origin_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="👥 التجميع من كل الحسابات", callback_data="category_origin:accounts")],
            [InlineKeyboardButton(text="📥 التجميع من مجموعة/قناة أحددها", callback_data="category_origin:sources")],
            [InlineKeyboardButton(text="إلغاء", callback_data="cancel")],
        ]
    )


def destination_choice_keyboard(prefix: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="استخدام القنوات المحفوظة", callback_data=f"{prefix}:saved")],
            [InlineKeyboardButton(text="إدخال/تحديث القنوات", callback_data=f"{prefix}:new")],
            [InlineKeyboardButton(text="إلغاء", callback_data="cancel")],
        ]
    )


def continue_keyboard(job_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="استمرار التجميع للروابط الجديدة", callback_data=f"continue:{job_id}")],
            [InlineKeyboardButton(text="القائمة الرئيسية", callback_data="menu")],
        ]
    )


def export_keyboard(job_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🔄 استكمال الجديد", callback_data=f"continue:{job_id}")],
            [InlineKeyboardButton(text="📤 تصدير TXT — للمالك", callback_data=f"export:txt:{job_id}")],
            [InlineKeyboardButton(text="ملف ZIP شامل — للمالك", callback_data=f"export:zip:{job_id}")],
            [InlineKeyboardButton(text="القائمة الرئيسية", callback_data="menu")],
        ]
    )


def account_management_keyboard(accounts, page: int = 0, page_size: int = 10) -> InlineKeyboardMarkup:  # type: ignore[no-untyped-def]
    total = len(accounts)
    page_size = max(1, int(page_size))
    max_page = max(0, (total - 1) // page_size) if total else 0
    page = min(max(0, int(page)), max_page)
    start = page * page_size
    page_accounts = accounts[start:start + page_size]
    rows: list[list[InlineKeyboardButton]] = []
    for account in page_accounts:
        toggle_text = "إيقاف" if account.active else "تفعيل"
        rows.append(
            [
                InlineKeyboardButton(text=f"اختبار #{account.id}", callback_data=f"account:test:{account.id}:{page}"),
                InlineKeyboardButton(text=f"{toggle_text} #{account.id}", callback_data=f"account:toggle:{account.id}:{page}"),
                InlineKeyboardButton(text=f"حذف #{account.id}", callback_data=f"account:delete:{account.id}:{page}"),
            ]
        )
    if total > page_size:
        nav: list[InlineKeyboardButton] = []
        if page > 0:
            nav.append(InlineKeyboardButton(text="⬅️ السابق", callback_data=f"accounts:list:{page - 1}"))
        nav.append(InlineKeyboardButton(text=f"{page + 1}/{max_page + 1}", callback_data="noop"))
        if page < max_page:
            nav.append(InlineKeyboardButton(text="التالي ➡️", callback_data=f"accounts:list:{page + 1}"))
        rows.append(nav)
    rows.append([InlineKeyboardButton(text="إضافة حساب", callback_data="accounts:add")])
    rows.append([InlineKeyboardButton(text="🔐 إدارة الجلسات", callback_data="session:center")])
    rows.append([InlineKeyboardButton(text="القائمة الرئيسية", callback_data="menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def confirm_delete_account_keyboard(account_id: int, page: int = 0) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="تأكيد الحذف", callback_data=f"account:delete_confirm:{account_id}:{page}")],
            [InlineKeyboardButton(text="تراجع", callback_data=f"accounts:list:{page}")],
        ]
    )


def watches_keyboard(watches) -> InlineKeyboardMarkup:  # type: ignore[no-untyped-def]
    rows: list[list[InlineKeyboardButton]] = []
    for watch in watches[:20]:
        action = "إيقاف" if watch.enabled else "تشغيل"
        rows.append([InlineKeyboardButton(text=f"{action} المتابعة #{watch.id}", callback_data=f"watch:toggle:{watch.id}")])
    rows.append([InlineKeyboardButton(text="القائمة الرئيسية", callback_data="menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def jobs_keyboard(jobs) -> InlineKeyboardMarkup:  # type: ignore[no-untyped-def]
    rows: list[list[InlineKeyboardButton]] = []
    for job in jobs[:12]:
        buttons: list[InlineKeyboardButton] = []
        if job.status in {"starting", "running"}:
            buttons.append(InlineKeyboardButton(text=f"⏸ إيقاف #{job.id}", callback_data=f"job:pause:{job.id}"))
            buttons.append(InlineKeyboardButton(text=f"⛔ إلغاء #{job.id}", callback_data=f"job:cancel:{job.id}"))
        elif job.status == "queued":
            buttons.append(InlineKeyboardButton(text=f"⛔ إلغاء #{job.id}", callback_data=f"job:cancel:{job.id}"))
        elif job.status == "paused":
            buttons.append(InlineKeyboardButton(text=f"▶️ استكمال #{job.id}", callback_data=f"job:resume:{job.id}"))
            buttons.append(InlineKeyboardButton(text=f"⛔ إلغاء #{job.id}", callback_data=f"job:cancel:{job.id}"))
        elif job.status in {"failed", "cancelled", "completed_with_errors"}:
            buttons.append(InlineKeyboardButton(text=f"🔁 إعادة/استكمال #{job.id}", callback_data=f"job:retry:{job.id}"))

        if job.status in {"completed", "completed_with_errors", "failed"} and job.mode in {"accounts", "sources", "join_groups"}:
            buttons.append(InlineKeyboardButton(text=f"🔄 الجديد #{job.id}", callback_data=f"continue:{job.id}"))
        if job.mode == "join_groups" and job.status in {"completed", "completed_with_errors", "failed", "cancelled"}:
            buttons.append(InlineKeyboardButton(text=f"🧹 مغادرة #{job.id}", callback_data=f"leave:prepare:{job.id}"))

        if job.mode == "join_groups":
            buttons.append(InlineKeyboardButton(text=f"📤 نتائج الانضمام #{job.id}", callback_data=f"join:export:{job.id}"))

        # Export is available from committed DB rows at any lifecycle state.
        if job.mode in {"sources", "accounts"}:
            buttons.append(InlineKeyboardButton(text=f"📤 TXT #{job.id}", callback_data=f"export:txt:{job.id}"))
        if job.mode == "telegram_audit" and (job.audit_id or str(job.category or "").startswith("audit:")):
            audit_id = str(job.audit_id or str(job.category).split(":", 1)[1])
            buttons.append(InlineKeyboardButton(text=f"📊 فحص #{audit_id}", callback_data=f"audit:view:{audit_id}"))
        if buttons:
            rows.append(buttons)
    rows.append([InlineKeyboardButton(text="القائمة الرئيسية", callback_data="menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def database_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="انضمام من آخر فحص لقاعدة البيانات", callback_data="join:database")],
            [InlineKeyboardButton(text="TXT — ملف واحد لكل قسم", callback_data="database:export_txt")],
            [InlineKeyboardButton(text="ملف ZIP شامل", callback_data="database:export_zip")],
            [InlineKeyboardButton(text="💾 نسخة احتياطية الآن", callback_data="backup:create")],
            [InlineKeyboardButton(text="حذف الروابط والمهام", callback_data="reset:clear")],
            [InlineKeyboardButton(text="⚠️ إعادة ضبط المصنع", callback_data="reset:factory")],
            [InlineKeyboardButton(text="القائمة الرئيسية", callback_data="menu")],
        ]
    )


def reset_menu_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="حذف الروابط والمهام فقط", callback_data="reset:clear")],
            [InlineKeyboardButton(text="⚠️ إعادة ضبط مصنع كاملة", callback_data="reset:factory")],
            [InlineKeyboardButton(text="تراجع", callback_data="menu")],
        ]
    )


def reset_confirm_keyboard(mode: str) -> InlineKeyboardMarkup:
    if mode == "factory":
        confirm_text = "نعم، أعد ضبط بيانات التشغيل"
    else:
        confirm_text = "نعم، احذف الروابط والمهام"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=confirm_text, callback_data=f"reset:execute:{mode}")],
            [InlineKeyboardButton(text="إلغاء", callback_data="menu")],
        ]
    )


def backup_menu_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="💾 إنشاء نسخة Database", callback_data="backup:create")],
            [InlineKeyboardButton(text="♻️ استعادة أحدث نسخة", callback_data="backup:restore_confirm")],
            [InlineKeyboardButton(text="القائمة الرئيسية", callback_data="menu")],
        ]
    )


def backup_restore_confirm_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="نعم، استعد أحدث نسخة", callback_data="backup:restore_latest")],
            [InlineKeyboardButton(text="تراجع", callback_data="backup:menu")],
        ]
    )


def telegram_audit_menu_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="بدء فحص جديد", callback_data="audit:new")],
            [InlineKeyboardButton(text="آخر تقارير الفحص", callback_data="audit:list")],
            [InlineKeyboardButton(text="القائمة الرئيسية", callback_data="menu")],
        ]
    )


def telegram_audit_engine_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🌐 فحص بواسطة المتصفح — سريع وبدون حسابات", callback_data="audit:engine:web")],
            [InlineKeyboardButton(text="👥 فحص بواسطة الحسابات — النظام الحالي", callback_data="audit:engine:accounts")],
            [InlineKeyboardButton(text="رجوع", callback_data="audit:menu")],
        ]
    )


def telegram_audit_mode_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="فحص روابط Telegram", callback_data="audit:mode:plain")],
            [InlineKeyboardButton(text="فحص + تجميع روابط Telegram", callback_data="audit:mode:tg")],
            [InlineKeyboardButton(text="فحص + تجميع روابط واتساب", callback_data="audit:mode:wa")],
            [InlineKeyboardButton(text="رجوع", callback_data="audit:menu")],
        ]
    )


def telegram_audit_whatsapp_scope_keyboard() -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=label, callback_data=f"audit:wa_scope:{value}")] for value, label in SCOPE_LABELS.items() if value != "new"]
    rows.append([InlineKeyboardButton(text="رجوع", callback_data="audit:new")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def telegram_audit_telegram_scope_keyboard() -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=label, callback_data=f"audit:tg_scope:{value}")] for value, label in SCOPE_LABELS.items() if value != "new"]
    rows.append([InlineKeyboardButton(text="رجوع", callback_data="audit:new")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def telegram_audit_pacing_keyboard(mode: str, scope: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(
                text="✅ النظام الثابت: كل 10 حسابات × 4 روابط ثم راحة دقيقتين",
                callback_data=f"audit:pacing:{mode}:{scope}:fixed",
            )],
            [InlineKeyboardButton(text="رجوع", callback_data="audit:new")],
        ]
    )


def telegram_audit_title_keyboard(mode: str, scope: str, pacing: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="استخدام عنوان تلقائي", callback_data=f"audit:title:auto:{mode}:{scope}:{pacing}")],
            [InlineKeyboardButton(text="رجوع", callback_data="audit:new")],
        ]
    )


def telegram_web_audit_source_keyboard(mode: str = "web", scope: str = "all", pacing: str = "web") -> InlineKeyboardMarkup:
    suffix = f"{mode}:{scope}:{pacing}"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="استخدام روابط Telegram الموجودة بقاعدة البوت", callback_data=f"audit:newsrc:database:{suffix}")],
            [InlineKeyboardButton(text="رفع ملفات TXT/CSV", callback_data=f"audit:newsrc:files:{suffix}")],
            [InlineKeyboardButton(text="لصق روابط مباشرة", callback_data=f"audit:newsrc:paste:{suffix}")],
            [InlineKeyboardButton(text="رجوع", callback_data="audit:new")],
        ]
    )


def telegram_audit_source_keyboard(mode: str, scope: str, pacing: str) -> InlineKeyboardMarkup:
    suffix = f"{mode}:{scope}:{pacing}"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="استخدام روابط Telegram الموجودة بقاعدة البوت", callback_data=f"audit:newsrc:database:{suffix}")],
            [InlineKeyboardButton(text="رفع ملفات TXT/CSV", callback_data=f"audit:newsrc:files:{suffix}")],
            [InlineKeyboardButton(text="استخراج روابط Telegram من مجموعات/قنوات", callback_data=f"audit:newsrc:sources:{suffix}")],
            [InlineKeyboardButton(text="لصق روابط مباشرة", callback_data=f"audit:newsrc:paste:{suffix}")],
            [InlineKeyboardButton(text="رجوع", callback_data="audit:new")],
        ]
    )


def telegram_audit_verifier_keyboard(accounts, verifier_ids: set[int], page: int = 0, page_size: int = 10) -> InlineKeyboardMarkup:  # type: ignore[no-untyped-def]
    total = len(accounts)
    page_size = max(1, int(page_size))
    max_page = max(0, (total - 1) // page_size) if total else 0
    page = min(max(0, int(page)), max_page)
    start = page * page_size
    rows: list[list[InlineKeyboardButton]] = []
    for account in accounts[start:start + page_size]:
        is_verifier = int(account.id) in verifier_ids
        text = f"🛡 تحقق #{account.id}" if is_verifier else f"📊 أساسي #{account.id}"
        rows.append([InlineKeyboardButton(text=text, callback_data=f"audit:verifier_toggle:{account.id}:{page}")])
    if total > page_size:
        nav: list[InlineKeyboardButton] = []
        if page > 0:
            nav.append(InlineKeyboardButton(text="⬅️ السابق", callback_data=f"audit:verifiers:{page - 1}"))
        nav.append(InlineKeyboardButton(text=f"{page + 1}/{max_page + 1}", callback_data="noop"))
        if page < max_page:
            nav.append(InlineKeyboardButton(text="التالي ➡️", callback_data=f"audit:verifiers:{page + 1}"))
        rows.append(nav)
    rows.append([InlineKeyboardButton(text="إضافة حساب جديد", callback_data="accounts:add")])
    rows.append([InlineKeyboardButton(text="رجوع", callback_data="audit:menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def telegram_audit_upload_keyboard(audit_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="ابدأ الفحص الآن", callback_data=f"audit:run:{audit_id}")],
            [InlineKeyboardButton(text="إلغاء هذا الفحص", callback_data=f"audit:discard:{audit_id}")],
            [InlineKeyboardButton(text="القائمة الرئيسية", callback_data="menu")],
        ]
    )


def telegram_audit_result_keyboard(audit_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📤 TXT — ملف واحد لكل قسم — للمالك", callback_data=f"audit:export_txt:{audit_id}")],
            [InlineKeyboardButton(text="✂️ تقسيم قسم محدد 200/1000 — للمالك", callback_data=f"audit:export_options:{audit_id}")],
            [InlineKeyboardButton(text="📦 ZIP Snapshot شامل — للمالك", callback_data=f"audit:export_zip:{audit_id}")],
            [InlineKeyboardButton(text="🔄 استكمال الفحص بالروابط الجديدة", callback_data=f"audit:continue_new:{audit_id}")],
            [InlineKeyboardButton(text="عرض تقرير الحسابات", callback_data=f"audit:accounts_report:{audit_id}")],
            [InlineKeyboardButton(text="إعادة فحص المقيّدة والأخطاء", callback_data=f"audit:retry_errors:{audit_id}")],
            [InlineKeyboardButton(text="🔍 فحص روابط Telegram الجديدة", callback_data=f"audit:scan_discovered:{audit_id}")],
            [InlineKeyboardButton(text="فحص جديد", callback_data="audit:new")],
            [InlineKeyboardButton(text="القائمة الرئيسية", callback_data="menu")],
        ]
    )


def telegram_web_audit_result_keyboard(audit_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📤 TXT — كل أقسام الفحص — للمالك", callback_data=f"audit:export_txt:{audit_id}")],
            [InlineKeyboardButton(text="✂️ تقسيم قسم محدد 200/1000 — للمالك", callback_data=f"audit:export_options:{audit_id}")],
            [InlineKeyboardButton(text="📦 ZIP شامل — للمالك", callback_data=f"audit:export_zip:{audit_id}")],
            [InlineKeyboardButton(text="🔄 فحص روابط قاعدة البيانات الجديدة بالمتصفح", callback_data=f"audit:continue_new:{audit_id}")],
            [InlineKeyboardButton(text="👥 فحص القنوات بالحسابات + تجميع داخلها", callback_data=f"audit:web_to_accounts:{audit_id}:channels")],
            [InlineKeyboardButton(text="👥 فحص المجموعات بالحسابات + تجميع داخلها", callback_data=f"audit:web_to_accounts:{audit_id}:groups")],
            [InlineKeyboardButton(text="👥 فحص الروابط التي تحتاج حسابات", callback_data=f"audit:web_to_accounts:{audit_id}:requires_account")],
            [InlineKeyboardButton(text="👥 إعادة تحقق المنتهية بالحسابات", callback_data=f"audit:web_to_accounts:{audit_id}:expired")],
            [InlineKeyboardButton(text="👥 فحص البوتات بالحسابات", callback_data=f"audit:web_to_accounts:{audit_id}:bots")],
            [InlineKeyboardButton(text="👥 فحص الروابط الشخصية بالحسابات", callback_data=f"audit:web_to_accounts:{audit_id}:personal")],
            [InlineKeyboardButton(text="👥 فحص البامبات/الاكتتابات بالحسابات", callback_data=f"audit:web_to_accounts:{audit_id}:pump_ipo")],
            [InlineKeyboardButton(text="فحص جديد", callback_data="audit:new")],
            [InlineKeyboardButton(text="القائمة الرئيسية", callback_data="menu")],
        ]
    )


def telegram_audit_list_keyboard(audits) -> InlineKeyboardMarkup:  # type: ignore[no-untyped-def]
    rows: list[list[InlineKeyboardButton]] = []
    for audit in audits[:10]:
        short_title = (str(getattr(audit, "title", "") or "").strip()[:24])
        label = f"#{audit.id} {short_title}" if short_title else f"#{audit.id}"
        rows.append([
            InlineKeyboardButton(text=f"تقرير {label}", callback_data=f"audit:view:{audit.id}"),
            InlineKeyboardButton(text=f"TXT {label}", callback_data=f"audit:export_txt:{audit.id}"),
        ])
    rows.append([InlineKeyboardButton(text="فحص جديد", callback_data="audit:menu")])
    rows.append([InlineKeyboardButton(text="القائمة الرئيسية", callback_data="menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def supervisor_management_keyboard(supervisor_ids: list[int], session_supervisor_ids: list[int] | None = None) -> InlineKeyboardMarkup:
    session_supervisor_ids = session_supervisor_ids or []
    rows: list[list[InlineKeyboardButton]] = [
        [InlineKeyboardButton(text="➕ إضافة مشرف كامل", callback_data="supervisors:add")],
        [InlineKeyboardButton(text="🔐 إضافة مشرف جلسات فقط", callback_data="supervisors:add_session_only")],
    ]
    for user_id in supervisor_ids[:30]:
        rows.append([
            InlineKeyboardButton(text=f"مشرف كامل {user_id}", callback_data="noop"),
            InlineKeyboardButton(text="حذف", callback_data=f"supervisors:remove:{user_id}"),
        ])
    for user_id in session_supervisor_ids[:30]:
        rows.append([
            InlineKeyboardButton(text=f"جلسات فقط {user_id}", callback_data="noop"),
            InlineKeyboardButton(text="حذف", callback_data=f"supervisors:remove_session:{user_id}"),
        ])
    rows.append([InlineKeyboardButton(text="القائمة الرئيسية", callback_data="menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def session_only_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔐 مركز جلساتي", callback_data="session:center")],
        [InlineKeyboardButton(text="➕ إنشاء جلسة جديدة", callback_data="session:generate")],
        [InlineKeyboardButton(text="إلغاء عملية استخراج نشطة", callback_data="session:cancel")],
    ])


def session_extract_cancel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="إلغاء", callback_data="session:cancel")],
    ])


def expired_links_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📥 استيراد من قناة/مجموعة", callback_data="expired:import_source")],
        [InlineKeyboardButton(text="♻️ استعادة رابط محظور", callback_data="expired:restore")],
        [InlineKeyboardButton(text="القائمة الرئيسية", callback_data="menu")],
    ])


def join_source_keyboard(overview=None) -> InlineKeyboardMarkup:  # type: ignore[no-untyped-def]
    rows: list[list[InlineKeyboardButton]] = []
    if overview is not None and overview.latest_audit_id is not None:
        aid = int(overview.latest_audit_id)
        rows.append([InlineKeyboardButton(
            text=f"✅ الروابط المفحوصة الجاهزة ({overview.all_count})",
            callback_data=f"join:source:all:{aid}",
        )])
        rows.append([InlineKeyboardButton(
            text=f"👥 المجموعات المفحوصة ({overview.groups_count})",
            callback_data=f"join:source:groups:{aid}",
        )])
        rows.append([InlineKeyboardButton(
            text=f"📢 القنوات المفحوصة ({overview.channels_count})",
            callback_data=f"join:source:channels:{aid}",
        )])
    if overview is not None and overview.database_audit_id is not None:
        rows.append([InlineKeyboardButton(
            text=f"🗃 فحص قاعدة البيانات ({overview.database_count})",
            callback_data=f"join:source:database:{int(overview.database_audit_id)}",
        )])
    rows.append([InlineKeyboardButton(text="إلغاء", callback_data="cancel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def join_limit_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="200 رابط ثابت لكل حساب", callback_data="join:limit:200")],
            [InlineKeyboardButton(text="500 رابط ثابت لكل حساب", callback_data="join:limit:500")],
            [InlineKeyboardButton(text="إلغاء", callback_data="cancel")],
        ]
    )


def leave_join_confirm_keyboard(join_job_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text=f"⚠️ نعم، غادر عضويات المهمة #{join_job_id}",
            callback_data=f"leave:confirm:{join_job_id}",
        )],
        [InlineKeyboardButton(text="تراجع", callback_data="jobs:list")],
    ])


def audit_export_options_keyboard(audit_id: int) -> InlineKeyboardMarkup:
    sections = [
        ("channels", "القنوات"),
        ("groups", "المجموعات"),
        ("telegram_new", "Telegram الجديدة"),
        ("whatsapp", "واتساب"),
        ("join_required", "تحتاج انضمام/طلب"),
        ("final_errors", "الأخطاء النهائية"),
        ("temporary_errors", "الأخطاء المؤقتة"),
        ("expired", "المنتهية"),
        ("pump_ipo", "البامبات/الاكتتابات"),
        ("bots", "البوتات"),
        ("personal", "الشخصية"),
        ("requires_account", "تحتاج حسابات لمعرفة المعلومات"),
        ("unsupported", "غير المدعومة"),
    ]
    rows: list[list[InlineKeyboardButton]] = [
        [InlineKeyboardButton(text="ملف واحد لكل قسم", callback_data=f"audit:export_split:{audit_id}:0")],
        [
            InlineKeyboardButton(text="كل الأقسام × 200", callback_data=f"audit:export_split:{audit_id}:200"),
            InlineKeyboardButton(text="كل الأقسام × 1000", callback_data=f"audit:export_split:{audit_id}:1000"),
        ],
    ]
    for key, label in sections:
        rows.append([
            InlineKeyboardButton(text=label, callback_data="noop"),
            InlineKeyboardButton(text="200", callback_data=f"audit:export_section:{audit_id}:{key}:200"),
            InlineKeyboardButton(text="1000", callback_data=f"audit:export_section:{audit_id}:{key}:1000"),
        ])
    rows.append([InlineKeyboardButton(text="رجوع", callback_data=f"audit:view:{audit_id}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


# --- V7 keyboards ------------------------------------------------------------
def v7_center_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔐 مركز الجلسات", callback_data="session:center"), InlineKeyboardButton(text="🩺 صحة الحسابات", callback_data="v7:health")],
        [InlineKeyboardButton(text="⏰ الجدولة", callback_data="v7:schedules"), InlineKeyboardButton(text="🔁 Workflows", callback_data="v7:workflows")],
        [InlineKeyboardButton(text="🏷 Tags", callback_data="v7:tags"), InlineKeyboardButton(text="🔎 البحث الشامل", callback_data="v7:search")],
        [InlineKeyboardButton(text="⚠️ مركز الأخطاء", callback_data="v7:errors"), InlineKeyboardButton(text="🧾 سجل الإدارة", callback_data="v7:auditlog")],
        [InlineKeyboardButton(text="🧰 Diagnostics", callback_data="v7:diag")],
        [InlineKeyboardButton(text="القائمة الرئيسية", callback_data="menu")],
    ])


def session_center_keyboard(accounts) -> InlineKeyboardMarkup:  # type: ignore[no-untyped-def]
    rows = [[InlineKeyboardButton(text="➕ إنشاء جلسة جديدة", callback_data="session:generate")]]
    for account in accounts[:30]:
        state = "🟢" if account.active else "⚪"
        rows.append([
            InlineKeyboardButton(text=f"{state} #{account.id} {account.label[:20]}", callback_data=f"session:view:{account.id}"),
            InlineKeyboardButton(text="🧪 فحص", callback_data=f"session:test:{account.id}"),
        ])
    rows.append([InlineKeyboardButton(text="القائمة الرئيسية", callback_data="menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def session_detail_keyboard(account_id: int, active: bool) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🧪 اختبار الاتصال", callback_data=f"session:test:{account_id}")],
        [InlineKeyboardButton(text="⏸ إيقاف محلي" if active else "▶️ تفعيل", callback_data=f"session:toggle:{account_id}")],
        [InlineKeyboardButton(text="🗑 حذف الجلسة محليًا", callback_data=f"session:delete_confirm:{account_id}")],
        [InlineKeyboardButton(text="رجوع للجلسات", callback_data="session:center")],
    ])


def session_delete_confirm_keyboard(account_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="نعم، احذف السجل المشفر محليًا", callback_data=f"session:delete:{account_id}")],
        [InlineKeyboardButton(text="تراجع", callback_data=f"session:view:{account_id}")],
    ])


def schedules_keyboard(tasks) -> InlineKeyboardMarkup:  # type: ignore[no-untyped-def]
    rows = [
        [InlineKeyboardButton(text="⏰ تذكير بعد ساعة", callback_data="v7:schedule:reminder:3600")],
        [InlineKeyboardButton(text="💾 Backup بعد 24 ساعة", callback_data="v7:schedule:backup:86400")],
        [InlineKeyboardButton(text="🩺 Health يوميًا", callback_data="v7:schedule:health_daily")],
    ]
    for task in tasks[:12]:
        if task.status == "scheduled":
            rows.append([InlineKeyboardButton(text=f"⛔ #{task.id} {task.title[:25]}", callback_data=f"v7:schedule_cancel:{task.id}")])
    rows.append([InlineKeyboardButton(text="رجوع V8", callback_data="v7:center")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def workflows_keyboard(workflows) -> InlineKeyboardMarkup:  # type: ignore[no-untyped-def]
    rows = [
        [InlineKeyboardButton(text="➕ Workflow Telegram الجديد", callback_data="v7:wf_create:telegram_new")],
        [InlineKeyboardButton(text="➕ Workflow كل الروابط الجديدة", callback_data="v7:wf_create:all_new")],
        [InlineKeyboardButton(text="➕ Workflow صحة + Backup", callback_data="v7:wf_create:health_backup")],
    ]
    for wf in workflows[:12]:
        rows.append([
            InlineKeyboardButton(text=f"▶️ #{wf.id} {wf.name[:16]}", callback_data=f"v7:wf_run:{wf.id}"),
            InlineKeyboardButton(text="⏰ يومي", callback_data=f"v7:wf_schedule:{wf.id}"),
            InlineKeyboardButton(text="🗑", callback_data=f"v7:wf_delete:{wf.id}"),
        ])
    rows.append([InlineKeyboardButton(text="رجوع V8", callback_data="v7:center")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def tags_keyboard(tags) -> InlineKeyboardMarkup:  # type: ignore[no-untyped-def]
    rows = [[InlineKeyboardButton(text="➕ إضافة Tag", callback_data="v7:tag_add")]]
    for tag in tags[:20]:
        rows.append([InlineKeyboardButton(text=f"🏷 {tag.tag} — {tag.entity_type}:{tag.entity_key[:24]}", callback_data="noop")])
    rows.append([InlineKeyboardButton(text="رجوع V8", callback_data="v7:center")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def errors_keyboard(errors) -> InlineKeyboardMarkup:  # type: ignore[no-untyped-def]
    rows = []
    for err in errors[:20]:
        rows.append([InlineKeyboardButton(text=f"✅ إغلاق #{err.id} {err.component[:20]}", callback_data=f"v7:error_resolve:{err.id}")])
    rows.append([InlineKeyboardButton(text="رجوع V8", callback_data="v7:center")])
    return InlineKeyboardMarkup(inline_keyboard=rows)
