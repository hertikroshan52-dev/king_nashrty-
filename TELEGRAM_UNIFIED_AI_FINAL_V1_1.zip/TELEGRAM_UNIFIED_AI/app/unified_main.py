"""Unified Telegram app: both admin panels share exactly one aiogram poller."""
from __future__ import annotations

import asyncio
import os
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
os.umask(0o077)  # New databases, keys and images stay private to the Linux user.
load_dotenv(ROOT / ".env", override=False)

# Explicit owner prevents the collector's first-message ownership fallback.
owner = os.environ.get("OWNER_ID", "").strip()
admin_ids = os.environ.get("ADMIN_IDS", "").strip()
if not owner and admin_ids:
    owner = admin_ids.split(",")[0].strip()
    os.environ["OWNER_ID"] = owner
if not owner or not owner.isdecimal():
    raise SystemExit("❌ ضع OWNER_ID الرقمي في .env أولاً.")
if not admin_ids:
    os.environ["ADMIN_IDS"] = owner
elif owner not in [part.strip() for part in admin_ids.split(",")]:
    raise SystemExit("❌ يجب أن يكون OWNER_ID ضمن ADMIN_IDS في .env.")

# No cross-talk between the databases of the two legacy applications.
os.environ.setdefault("PUBLISHER_DATA_DIR", str(ROOT / "data" / "publisher"))
os.environ.setdefault("PUBLISHER_DB_NAME", str(Path(os.environ["PUBLISHER_DATA_DIR"]) / "bot_database.db"))

from aiogram import Bot, Dispatcher

from app.bot import router
from app.db import init_db
from app.fsm_storage import SQLiteFSMStorage
from app.main import (
    configure_logging,
    account_refresh_loop,
    automatic_backup_loop,
    health_alert_loop,
    job_loop,
    pause_active_jobs_for_shutdown,
    v7_scheduler_loop,
)
from app.config import get_settings
from app.services.scanner import ClientManager
from app.unified_hub import HubMiddleware, UnifiedHub


async def main():
    settings = get_settings()
    configure_logging()
    await init_db(recover_interrupted=True)
    bot = Bot(settings.bot_token)
    dp = Dispatcher(storage=SQLiteFSMStorage())
    dp.include_router(router)
    hub = UnifiedHub(settings.bot_token, settings.data_dir / "hub_state.sqlite3")
    try:
        await hub.start()
    except Exception:
        await bot.session.close()
        raise
    dp.update.outer_middleware(HubMiddleware(hub))
    manager = ClientManager(bot)
    tasks = []
    try:
        await manager.start()
        await manager.refresh()
        tasks.append(asyncio.create_task(account_refresh_loop(manager), name="account-refresh"))
        workers = max(1, min(32, int(settings.job_workers)))
        for idx in range(workers):
            tasks.append(asyncio.create_task(job_loop(manager, bot), name=f"job-worker-{idx+1}"))
        tasks.append(asyncio.create_task(automatic_backup_loop(), name="automatic-backup"))
        tasks.append(asyncio.create_task(health_alert_loop(manager, bot), name="health-alerts"))
        tasks.append(asyncio.create_task(v7_scheduler_loop(bot), name="v7-scheduler"))
        await dp.start_polling(bot, close_bot_session=False)
    finally:
        await pause_active_jobs_for_shutdown()
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        await manager.close()
        await hub.stop()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
