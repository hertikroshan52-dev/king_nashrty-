from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


PROJECT_ROOT = Path(__file__).resolve().parent.parent
ENV_FILE = PROJECT_ROOT / ".env"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=ENV_FILE,
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    bot_token: str = Field(validation_alias=AliasChoices("BOT_TOKEN", "bot_token"))
    admin_ids_csv: str = Field(default="", validation_alias="ADMIN_IDS")

    telegram_api_id: int | None = Field(
        default=None,
        validation_alias=AliasChoices("TELEGRAM_API_ID", "API_ID", "telegram_api_id"),
    )
    telegram_api_hash: str | None = Field(
        default=None,
        validation_alias=AliasChoices("TELEGRAM_API_HASH", "API_HASH", "telegram_api_hash"),
    )

    session_encryption_key: str | None = None
    database_url: str = "sqlite+aiosqlite:///data/collector.db"
    data_dir: Path = Path("data")

    # V6.4 runs one bot process with one primary owner plus supervisors.
    instance_name: str = "Telegram Link V8.2 FIXED JOIN"

    worker_poll_seconds: float = 2.0
    # Different supervisors can run one task each in parallel. claim_next_job()
    # guarantees that one supervisor never has two active jobs at the same time.
    job_workers: int = 8
    account_refresh_seconds: float = 20.0
    collector_reconnect_attempts: int = 3
    collector_reconnect_base_seconds: float = 2.0
    collector_reconnect_max_seconds: float = 30.0
    max_concurrent_accounts: int = 10  # legacy alias; collector_account_workers is preferred
    collector_account_workers: int = 20
    collector_fast_scan: bool = True
    collector_db_batch_links: int = 500
    collector_checkpoint_messages: int = 500
    max_telethon_accounts: int = 100
    accounts_page_size: int = 10
    exhaustive_link_scan: bool = False  # False = Telegram server-side URL filter (fast)
    deduplicate_dialogs_across_accounts: bool = True
    progress_update_every_messages: int = 1000
    live_queue_max: int = 5000
    live_workers: int = 4
    publish_batch_max_links: int = 35
    publish_batch_max_chars: int = 3500
    publish_delay_seconds: float = 1.0
    max_flood_wait_seconds: int = 3600

    # Audit engine. All throughput controls are configurable and no large input
    # collection is loaded into memory at once.
    audit_request_delay_seconds: float = 0.05
    audit_request_jitter_seconds: float = 0.10
    audit_progress_every: int = 25
    audit_max_flood_wait_seconds: int = 900
    audit_source_message_check_every: int = 250
    audit_db_batch_size: int = 500
    audit_batch_size: int = 40
    audit_batch_pause_seconds: float = 0.0
    audit_workers: int = 40  # compatibility; V6 uses cohort scheduler
    # Browser/web-preview audit: no Telethon accounts are used for these HTTP checks.
    web_audit_workers: int = 12
    web_audit_per_host: int = 6
    web_audit_batch_size: int = 250
    web_audit_timeout_seconds: float = 15.0
    audit_account_group_size: int = 10
    audit_links_per_account_cycle: int = 4
    audit_group_rest_seconds: float = 120.0
    audit_use_resolution_cache: bool = False
    audit_cache_valid_hours: int = 6
    audit_cache_expired_hours: int = 1
    audit_membership_workers: int = 8
    audit_speed_window_seconds: int = 300
    # Legacy V5 compatibility only. The V6 audit scheduler DOES NOT use these values.
    audit_account_burst_links: int = 3
    audit_account_rest_seconds: float = 90.0
    audit_retry_max_attempts: int = 3
    audit_retry_base_seconds: float = 2.0
    audit_retry_max_seconds: float = 60.0
    # V6.2.4: public username resolution (contacts.resolveUsername) has its own
    # conservative per-account pacing. Telegram's exact request limits are dynamic;
    # any server-provided FloodWait always overrides this local minimum.
    audit_public_resolve_min_interval_seconds: float = 3.0
    audit_floodwait_safety_seconds: float = 2.0
    audit_account_error_threshold: int = 10
    audit_account_circuit_breaker_seconds: int = 300
    membership_cache_ttl_seconds: int = 21600
    audit_whatsapp_message_delay_seconds: float = 0.0
    audit_whatsapp_fast_scan: bool = True
    audit_whatsapp_workers: int = 4
    audit_whatsapp_max_messages_per_chat_all: int = 0
    whatsapp_default_scope: str = "7d"

    # Telegram-link discovery while auditing. This is a separate mode from
    # WhatsApp discovery and stores only URLs that are globally new to ``links``.
    audit_telegram_message_delay_seconds: float = 0.0
    audit_telegram_fast_scan: bool = True
    audit_telegram_workers: int = 10
    audit_scan_discussion_comments: bool = False
    audit_telegram_max_messages_per_chat_all: int = 0
    telegram_discovery_default_scope: str = "7d"

    # Destructive expiration cleanup is opt-in.  The default leaves results in
    # the audit report so an owner can confirm or restore them safely.
    audit_auto_purge_expired: bool = False

    # Join/leave pacing.  Server-provided FloodWait values always take priority.
    join_delay_seconds: int = 180
    join_inspect_delay_seconds: float = 3.0
    join_classify_workers: int = 4
    join_max_attempts: int = 3
    leave_delay_seconds: int = 30

    # Crash/restart recovery.
    auto_resume_jobs: bool = True
    stale_job_seconds: int = 120

    # Export/backup.
    export_chunk_size: int = Field(default=1000, validation_alias=AliasChoices("EXPORT_LINKS_PER_FILE", "EXPORT_CHUNK_SIZE"))
    export_send_delay_seconds: float = 0.4
    backup_keep_count: int = 10
    automatic_backup_hours: int = 24
    maintenance_retention_days: int = 14
    health_alert_interval_seconds: int = 300
    disk_alert_percent: int = 90
    health_alerts: bool = True

    # Logging.
    log_level: str = "INFO"
    log_max_bytes: int = 5_000_000
    log_backup_count: int = 5
    telethon_log_level: str = "WARNING"

    @property
    def admin_ids(self) -> list[int]:
        result: list[int] = []
        for item in self.admin_ids_csv.split(","):
            item = item.strip()
            if item and item.lstrip("-").isdigit():
                result.append(int(item))
        return result

    @property
    def exports_dir(self) -> Path:
        path = self.data_dir / "exports"
        path.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def tmp_dir(self) -> Path:
        path = self.data_dir / "tmp"
        path.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def backups_dir(self) -> Path:
        path = self.data_dir / "backups"
        path.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def logs_dir(self) -> Path:
        path = self.data_dir / "logs"
        path.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def key_file(self) -> Path:
        return self.data_dir / ".session_key"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    settings = Settings()
    settings.data_dir.mkdir(parents=True, exist_ok=True)
    settings.exports_dir.mkdir(parents=True, exist_ok=True)
    settings.tmp_dir.mkdir(parents=True, exist_ok=True)
    settings.backups_dir.mkdir(parents=True, exist_ok=True)
    settings.logs_dir.mkdir(parents=True, exist_ok=True)
    return settings
