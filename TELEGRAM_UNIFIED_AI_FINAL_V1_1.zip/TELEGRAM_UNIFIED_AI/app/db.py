from __future__ import annotations

import logging
import re

from sqlalchemy import event, select, text, update
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.config import get_settings
from app.models import Base, Job, TelegramAudit, utcnow

settings = get_settings()
logger = logging.getLogger(__name__)
engine = create_async_engine(settings.database_url, pool_pre_ping=True)
SessionFactory = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


if settings.database_url.startswith("sqlite"):
    @event.listens_for(engine.sync_engine, "connect")
    def _sqlite_pragmas(dbapi_connection, _connection_record) -> None:  # type: ignore[no-untyped-def]
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA synchronous=NORMAL")
        cursor.execute("PRAGMA busy_timeout=30000")
        cursor.close()


_SQLITE_ADDITIONS: dict[str, dict[str, str]] = {
    "join_assignments": {"next_retry_at": "DATETIME", "saved_message_sent_at": "DATETIME", "saved_message_error": "TEXT"},
    "accounts": {
        "operator_id": "BIGINT",
        "health_status": "VARCHAR(24) NOT NULL DEFAULT 'healthy'",
        "flood_wait_until": "DATETIME",
        "last_success_at": "DATETIME",
        "last_error_at": "DATETIME",
        "requests_count": "INTEGER NOT NULL DEFAULT 0",
        "errors_count": "INTEGER NOT NULL DEFAULT 0",
        "consecutive_errors": "INTEGER NOT NULL DEFAULT 0",
    },
    "jobs": {
        "audit_id": "INTEGER REFERENCES telegram_audits(id) ON DELETE SET NULL",
        "updated_at": "DATETIME",
        "heartbeat_at": "DATETIME",
        "paused_at": "DATETIME",
    },
    "telegram_audits": {
        "title": "VARCHAR(160)",
        "last_processed_input_id": "BIGINT",
        "current_account_id": "INTEGER",
        "current_phase": "VARCHAR(48)",
        "updated_at": "DATETIME",
        "paused_at": "DATETIME",
    },
    "links": {
        "last_seen_at": "DATETIME",
        "seen_count": "INTEGER NOT NULL DEFAULT 1",
    },
    "telegram_audit_results": {
        "error_class": "VARCHAR(32)",
        "attempt_count": "INTEGER NOT NULL DEFAULT 1",
        "next_retry_at": "DATETIME",
    },
}


async def _sqlite_table_columns(connection, table_name: str) -> set[str]:  # type: ignore[no-untyped-def]
    rows = (await connection.execute(text(f'PRAGMA table_info("{table_name}")'))).mappings().all()
    return {str(row["name"]) for row in rows}


async def _migrate_sqlite_schema() -> None:
    """Small, idempotent migration layer for upgrades from v3.x.

    The project intentionally does not require Alembic on Termux. New installs
    are created from ORM metadata; existing SQLite databases receive additive
    ALTER TABLE migrations without deleting any data.
    """
    if not settings.database_url.startswith("sqlite"):
        return
    async with engine.begin() as connection:
        existing_tables = set((await connection.execute(text("SELECT name FROM sqlite_master WHERE type='table'"))).scalars())
        for table_name, additions in _SQLITE_ADDITIONS.items():
            if table_name not in existing_tables:
                continue
            columns = await _sqlite_table_columns(connection, table_name)
            for column_name, ddl in additions.items():
                if column_name not in columns:
                    logger.info("Migrating SQLite: add %s.%s", table_name, column_name)
                    await connection.execute(text(f'ALTER TABLE "{table_name}" ADD COLUMN "{column_name}" {ddl}'))

        # Additive indexes. SQLite IF NOT EXISTS keeps this idempotent.
        index_sql = [
            "CREATE INDEX IF NOT EXISTS ix_job_status_id ON jobs(status, id)",
            "CREATE INDEX IF NOT EXISTS ix_job_audit ON jobs(audit_id)",
            "CREATE INDEX IF NOT EXISTS ix_audit_status_updated ON telegram_audits(status, updated_at)",
            "CREATE INDEX IF NOT EXISTS ix_audit_input_audit_id_id ON telegram_audit_inputs(audit_id, id)",
            "CREATE INDEX IF NOT EXISTS ix_audit_result_retry ON telegram_audit_results(audit_id, status, next_retry_at)",
            "CREATE INDEX IF NOT EXISTS ix_account_health_status ON accounts(health_status)",
            "CREATE INDEX IF NOT EXISTS ix_accounts_operator_id ON accounts(operator_id)",
            "CREATE INDEX IF NOT EXISTS ix_join_candidate_operator_status ON join_candidates(requested_by, status, id)",
            "CREATE INDEX IF NOT EXISTS ix_links_last_seen_at ON links(last_seen_at)",
            "CREATE INDEX IF NOT EXISTS ix_collection_checkpoint_source ON collection_checkpoints(source_key)",
            "CREATE INDEX IF NOT EXISTS ix_resolution_cache_expiry ON telegram_resolution_cache(expires_at)",
        ]
        for sql in index_sql:
            await connection.execute(text(sql))

        # Backfill additive timestamp columns and explicit Job→Audit relation.
        await connection.execute(text("UPDATE jobs SET updated_at = COALESCE(updated_at, created_at)"))
        await connection.execute(text("UPDATE telegram_audits SET updated_at = COALESCE(updated_at, created_at)"))
        await connection.execute(text("UPDATE links SET last_seen_at = COALESCE(last_seen_at, created_at), seen_count = COALESCE(seen_count, 1)"))
        rows = (await connection.execute(text(
            "SELECT id, category FROM jobs WHERE audit_id IS NULL AND mode='telegram_audit' AND category LIKE 'audit:%'"
        ))).all()
        for job_id, category in rows:
            match = re.fullmatch(r"audit:(\d+)", str(category or ""))
            if match:
                await connection.execute(
                    text("UPDATE jobs SET audit_id=:audit_id WHERE id=:job_id"),
                    {"audit_id": int(match.group(1)), "job_id": int(job_id)},
                )


async def _recover_interrupted_jobs() -> None:
    """Make stale process-local states recoverable after a restart."""
    now = utcnow()
    resume_status = "queued" if settings.auto_resume_jobs else "paused"
    interrupted = {"starting", "running", "pause_requested", "stopping"}
    async with SessionFactory() as session:
        await session.execute(
            update(Job)
            .where(Job.status.in_(interrupted))
            .values(
                status=resume_status,
                paused_at=None if settings.auto_resume_jobs else now,
                heartbeat_at=now,
                updated_at=now,
                error="تمت استعادة المهمة بعد إعادة تشغيل البوت؛ ستستكمل من البيانات المحفوظة.",
            )
        )
        audit_status = "queued" if settings.auto_resume_jobs else "paused"
        await session.execute(
            update(TelegramAudit)
            .where(TelegramAudit.status.in_(interrupted))
            .values(status=audit_status, paused_at=None if settings.auto_resume_jobs else now, updated_at=now)
        )
        await session.commit()


async def init_db(*, recover_interrupted: bool = False) -> None:
    """Initialize/migrate the database without mutating live job state.

    Recovery of interrupted process-local states must happen only during the
    real bot process startup. Maintenance commands such as ``status``,
    ``backup`` and ``migrate`` may run while the bot is alive; they must never
    rewrite a genuinely-running job back to ``queued``.
    """
    # create_all first creates any brand-new tables such as job_cursors.
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)
    await _migrate_sqlite_schema()
    if recover_interrupted:
        await _recover_interrupted_jobs()
