"""Telegram multi-account link collector."""
