from __future__ import annotations

import asyncio
import csv
import json
import logging
import re
import random
import shutil
import time
import zipfile
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

from sqlalchemy import and_, case, delete, func, or_, select, update
from sqlalchemy.dialects.sqlite import insert
from telethon.errors import FloodWaitError
from telethon.errors.rpcbaseerrors import RPCError
from telethon.tl.functions.messages import CheckChatInviteRequest
from telethon.tl.types import Channel, Chat, ChatInvite, ChatInviteAlready, ChatInvitePeek, InputMessagesFilterUrl, User
from telethon.utils import get_peer_id

from app.config import get_settings
from app.db import SessionFactory
from app.link_utils import extract_urls_from_message, extract_urls_from_text, inspect_collection_link, inspect_link, telegram_identity_key
from app.models import (
    Account,
    AccountMembership,
    Job,
    JobCursor,
    Link,
    TelegramAudit,
    TelegramAuditInput,
    TelegramAuditResult,
    TelegramAuditTelegramDiscovery,
    TelegramAuditWhatsapp,
    TelegramExpiredLinkBlocklist,
    TelegramPeer,
    TelegramPeerAlias,
    TelegramResolutionCache,
    utcnow,
)
from app.services.repository import BatchLinkSource, register_links_batch

logger = logging.getLogger(__name__)
settings = get_settings()

INVITE_RE = re.compile(
    r"^https?://(?:www\.)?(?:t\.me|telegram\.me)/(?:joinchat/|\+)([A-Za-z0-9_-]+)/?$",
    re.I,
)
PUBLIC_RE = re.compile(
    r"^https?://(?:www\.)?(?:t\.me|telegram\.me)/([A-Za-z0-9_]{4,})/?$",
    re.I,
)
RESERVED_PUBLIC_PATHS = {
    "addstickers", "addemoji", "addlist", "share", "proxy", "socks", "login", "invoice",
    "setlanguage", "bg", "iv", "contact", "boost", "giftcode", "nft", "m", "apps",
}

PUMP_IPO_TITLE_RE = re.compile(
    r"(?:بامب(?:ات)?|بمب(?:ات)?|اكتتاب(?:ات)?|طرح\s+(?:أولي|اول[يى])|"
    r"\bpump(?!kin)[a-z0-9_-]*\b|\b(?:ipo|ico|ido|ieo)\b|"
    r"\bpre[-\s]?sale\b|\btoken[-\s]?sale\b|\blaunchpad\b)",
    re.I,
)

VALID_PEER_RESULT_STATUSES = {"joined_unique", "joined_duplicate", "unjoined", "join_request"}

AUDIT_STATUS_LABELS = {
    "joined_unique": "موجودة بحساب واحد",
    "joined_duplicate": "مكررة بين الحسابات",
    "expired": "روابط منتهية/غير صالحة",
    "personal": "روابط شخصية",
    "bot": "بوتات Telegram",
    "unjoined": "صالحة ولم يتم الانضمام إليها",
    "join_request": "تحتاج طلب انضمام",
    "restricted_access": "الوصول مقيّد أو يحتاج تحقق",
    "unsupported": "روابط Telegram غير مدعومة",
    "temporary_error": "خطأ مؤقت قابل لإعادة المحاولة",
    "error": "خطأ نهائي بعد المحاولات",
    "web_visible": "مرئي في معاينة الويب",
    "requires_account": "يحتاج حسابات لمعرفة المعلومات",
}


@dataclass(frozen=True, slots=True)
class AuditExportBundle:
    directory: Path
    text_files: tuple[Path, ...]
    report_files: tuple[Path, ...]
    zip_path: Path
    total_results: int


@dataclass(slots=True)
class MembershipInfo:
    account_ids: set[int]
    title: str | None = None
    username: str | None = None
    peer_type: str | None = None


class TelegramDiscoveryDeferred(Exception):
    """Internal control-flow signal for a discovery request delayed by Telegram.

    A FloodWait is pacing metadata, not evidence that the source URL is invalid.
    The scheduler catches this outside the per-account lock so other discovery
    work for the same account can continue while this cursor waits.
    """

    def __init__(self, wait_seconds: float, *, method: str, detail: str) -> None:
        self.wait_seconds = max(1.0, float(wait_seconds))
        self.method = str(method or "Telegram")
        self.detail = str(detail or "FloodWait")
        super().__init__(self.detail)


class AccountBurstLimiter:
    """Small per-account burst limiter for Telegram resolution requests.

    Each account may reserve ``burst_links`` requests, then it becomes unavailable
    for ``rest_seconds`` while the audit continues with other accounts. This is
    intentionally separate from Telegram FloodWait/circuit-breaker cooldowns.
    """

    def __init__(self, burst_links: int, rest_seconds: float) -> None:
        self.burst_links = max(1, int(burst_links))
        self.rest_seconds = max(0.0, float(rest_seconds))
        self._used: dict[int, int] = defaultdict(int)
        self._rest_until: dict[int, float] = {}

    def _refresh(self, account_id: int, now: float | None = None) -> float:
        now = time.monotonic() if now is None else now
        until = float(self._rest_until.get(account_id, 0.0))
        if until and until <= now:
            self._rest_until.pop(account_id, None)
            self._used[account_id] = 0
            return 0.0
        return until

    def is_available(self, account_id: int, now: float | None = None) -> bool:
        now = time.monotonic() if now is None else now
        return self._refresh(account_id, now) <= now

    def reserve(self, account_id: int, now: float | None = None) -> bool:
        """Reserve one request slot without sleeping. Returns False while resting."""
        now = time.monotonic() if now is None else now
        if not self.is_available(account_id, now):
            return False
        used = int(self._used.get(account_id, 0)) + 1
        self._used[account_id] = used
        if used >= self.burst_links and self.rest_seconds > 0:
            # The current request is allowed; subsequent requests use another
            # account until this account's rest period expires.
            self._rest_until[account_id] = now + self.rest_seconds
        return True

    def wait_seconds(self, account_id: int, now: float | None = None) -> float:
        now = time.monotonic() if now is None else now
        until = self._refresh(account_id, now)
        return max(0.0, until - now)

    def resting_count(self) -> int:
        now = time.monotonic()
        return sum(1 for account_id in list(self._rest_until) if self.wait_seconds(account_id, now) > 0)


def _clean_telegram_urls(values: Iterable[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for raw in values:
        inspection = inspect_link(raw)
        if not inspection.link or inspection.link.category != "telegram":
            continue
        url = inspection.link.normalized
        if url in seen:
            continue
        seen.add(url)
        result.append(url)
    return result


def extract_telegram_urls_from_text(text: str) -> list[str]:
    return _clean_telegram_urls(extract_urls_from_text(text or ""))


async def create_audit(
    requested_by: int,
    source_type: str,
    options: dict[str, Any] | None = None,
    title: str | None = None,
) -> TelegramAudit:
    async with SessionFactory() as session:
        # For non-database input audits, "continue with new DB links" should begin
        # from the moment this audit was created rather than importing the entire
        # historical database on its first continuation. Database-source audits
        # intentionally start at zero and populate the historical set once.
        db_high_water = 0
        if source_type != "database":
            db_high_water = int(await session.scalar(select(func.max(Link.id))) or 0)
        audit = TelegramAudit(
            requested_by=requested_by,
            source_type=source_type,
            title=(title or "").strip()[:160] or None,
            status="draft",
            summary={
                "options": dict(options or {}),
                "database_high_water_link_id": db_high_water,
            },
        )
        session.add(audit)
        await session.commit()
        await session.refresh(audit)
        return audit


async def set_audit_title(audit_id: int, title: str) -> None:
    clean = " ".join((title or "").split()).strip()[:160]
    if not clean:
        return
    async with SessionFactory() as session:
        await session.execute(
            update(TelegramAudit).where(TelegramAudit.id == audit_id).values(title=clean, updated_at=utcnow())
        )
        await session.commit()


async def add_audit_urls(audit_id: int, urls: Iterable[str]) -> tuple[int, int]:
    cleaned = _clean_telegram_urls(urls)
    if not cleaned:
        return 0, 0

    # V6.6 permanent expired registry: never spend web/Telethon checks again
    # on identities the owner already marked expired.
    allowed: list[str] = []
    blocked = 0
    for start in range(0, len(cleaned), 1000):
        part = cleaned[start:start + 1000]
        keys = {url: telegram_identity_key(url) for url in part}
        async with SessionFactory() as session:
            blocked_keys = set((await session.scalars(
                select(TelegramExpiredLinkBlocklist.identity_key).where(
                    TelegramExpiredLinkBlocklist.identity_key.in_(list(keys.values()))
                )
            )).all())
        for url in part:
            if keys[url] in blocked_keys:
                blocked += 1
            else:
                allowed.append(url)
    if not allowed:
        return 0, len(cleaned)

    async with SessionFactory() as session:
        before = int(
            await session.scalar(select(func.count(TelegramAuditInput.id)).where(TelegramAuditInput.audit_id == audit_id))
            or 0
        )
        for start in range(0, len(allowed), 1000):
            rows = [
                {"audit_id": audit_id, "original_url": url, "normalized_url": url}
                for url in allowed[start : start + 1000]
            ]
            await session.execute(
                insert(TelegramAuditInput)
                .values(rows)
                .on_conflict_do_nothing(index_elements=[TelegramAuditInput.audit_id, TelegramAuditInput.normalized_url])
            )
        await session.commit()
        after = int(
            await session.scalar(select(func.count(TelegramAuditInput.id)).where(TelegramAuditInput.audit_id == audit_id))
            or 0
        )
        await session.execute(update(TelegramAudit).where(TelegramAudit.id == audit_id).values(total_inputs=after))
        await session.commit()
    return after - before, blocked + len(allowed) - (after - before)


async def add_audit_text(audit_id: int, text: str) -> tuple[int, int, int]:
    raw_urls = extract_urls_from_text(text or "")
    telegram_urls = _clean_telegram_urls(raw_urls)
    added, duplicate = await add_audit_urls(audit_id, telegram_urls)
    rejected = max(0, len(raw_urls) - len(telegram_urls))
    return added, duplicate, rejected


async def add_audit_file_stream(audit_id: int, path: Path, batch_lines: int = 2000) -> tuple[int, int, int]:
    """Stream TXT/CSV audit input without loading the whole file into RAM."""
    added_total = duplicate_total = rejected_total = 0
    buffer: list[str] = []

    async def flush() -> None:
        nonlocal added_total, duplicate_total, rejected_total, buffer
        if not buffer:
            return
        text = "\n".join(buffer)
        raw_urls = extract_urls_from_text(text)
        telegram_urls = _clean_telegram_urls(raw_urls)
        added, duplicate = await add_audit_urls(audit_id, telegram_urls)
        added_total += added
        duplicate_total += duplicate
        rejected_total += max(0, len(raw_urls) - len(telegram_urls))
        buffer = []

    with path.open("r", encoding="utf-8-sig", errors="ignore") as handle:
        for line in handle:
            buffer.append(line)
            if len(buffer) >= max(100, int(batch_lines)):
                await flush()
    await flush()
    return added_total, duplicate_total, rejected_total


async def populate_audit_from_database(audit_id: int) -> int:
    """Append only Telegram links newer than this audit's DB high-water mark.

    The first database-backed population scans from link id 0. Future
    ``continue new`` calls resume from ``database_high_water_link_id`` so a
    multi-million-row database is not re-read from the beginning.
    """
    async with SessionFactory() as session:
        audit = await session.get(TelegramAudit, audit_id)
        if not audit:
            raise ValueError("تقرير الفحص غير موجود.")
        summary = dict(audit.summary or {})
        last_id = int(summary.get("database_high_water_link_id", 0) or 0)

    total = 0
    high_water = last_id
    batch_size = max(100, settings.audit_db_batch_size)
    while True:
        async with SessionFactory() as session:
            rows = (
                await session.execute(
                    select(Link.id, Link.normalized_url)
                    .where(Link.category == "telegram", Link.id > high_water)
                    .order_by(Link.id)
                    .limit(batch_size)
                )
            ).all()
        if not rows:
            break
        high_water = int(rows[-1][0])
        added, _ = await add_audit_urls(audit_id, [str(row[1]) for row in rows])
        total += added

    if high_water != last_id:
        async with SessionFactory() as session:
            audit = await session.get(TelegramAudit, audit_id)
            if audit:
                summary = dict(audit.summary or {})
                summary["database_high_water_link_id"] = high_water
                audit.summary = summary
                audit.updated_at = utcnow()
                await session.commit()
    return total


async def populate_audit_from_discovery(source_audit_id: int, target_audit_id: int) -> int:
    """Populate a new audit only with Telegram URLs discovered by a previous audit.

    This powers the recursive workflow: audit A discovers globally-new links,
    the user can audit exactly those links as audit B, and B automatically
    performs the same full-history Telegram discovery again.
    """
    total = 0
    last_id = 0
    batch_size = max(100, settings.audit_db_batch_size)
    while True:
        async with SessionFactory() as session:
            rows = (
                await session.execute(
                    select(TelegramAuditTelegramDiscovery.id, TelegramAuditTelegramDiscovery.normalized_url)
                    .where(
                        TelegramAuditTelegramDiscovery.audit_id == source_audit_id,
                        TelegramAuditTelegramDiscovery.id > last_id,
                    )
                    .order_by(TelegramAuditTelegramDiscovery.id)
                    .limit(batch_size)
                )
            ).all()
        if not rows:
            break
        last_id = int(rows[-1][0])
        added, _ = await add_audit_urls(target_audit_id, [str(row[1]) for row in rows])
        total += added
    return total


async def get_audit(audit_id: int) -> TelegramAudit | None:
    async with SessionFactory() as session:
        return await session.get(TelegramAudit, audit_id)


async def list_audits(owner_id: int, limit: int = 10) -> list[TelegramAudit]:
    async with SessionFactory() as session:
        return list(
            (
                await session.scalars(
                    select(TelegramAudit)
                    .where(TelegramAudit.requested_by == owner_id)
                    .order_by(TelegramAudit.id.desc())
                    .limit(limit)
                )
            ).all()
        )


async def discard_audit(audit_id: int, owner_id: int) -> bool:
    async with SessionFactory() as session:
        audit = await session.get(TelegramAudit, audit_id)
        if not audit or audit.requested_by != owner_id or audit.status not in {"draft", "failed", "cancelled"}:
            return False
        await session.delete(audit)
        await session.commit()
        return True


async def queue_audit_job(audit_id: int, owner_id: int, sources: list[str] | None = None) -> Job:
    active_states = {"queued", "starting", "running", "pause_requested", "paused", "stopping"}
    async with SessionFactory() as session:
        audit = await session.get(TelegramAudit, audit_id)
        if not audit or audit.requested_by != owner_id:
            raise ValueError("مهمة الفحص غير موجودة.")
        input_count = int(
            await session.scalar(select(func.count(TelegramAuditInput.id)).where(TelegramAuditInput.audit_id == audit_id))
            or 0
        )
        if audit.source_type != "sources" and input_count == 0:
            raise ValueError("لا توجد روابط Telegram في هذا الفحص.")
        existing = await session.scalar(
            select(Job).where(Job.audit_id == audit_id, Job.status.in_(active_states)).order_by(Job.id.desc()).limit(1)
        )
        if existing:
            raise ValueError(f"الفحص مرتبط بالفعل بالمهمة #{existing.id} وحالتها {existing.status}.")

        # A user-triggered final verification gives only unresolved rows a fresh
        # retry budget. Successful/permanent classifications are never deleted.
        if audit.status in {"completed", "completed_with_errors", "failed", "cancelled"}:
            # Final verification must actually make exhausted transient errors
            # selectable again, not only reset their attempt counter.
            await session.execute(
                update(TelegramAuditResult)
                .where(
                    TelegramAuditResult.audit_id == audit_id,
                    TelegramAuditResult.status == "error",
                )
                .values(status="temporary_error", attempt_count=0, next_retry_at=None)
            )
            await session.execute(
                update(TelegramAuditResult)
                .where(
                    TelegramAuditResult.audit_id == audit_id,
                    TelegramAuditResult.status.in_(["temporary_error", "restricted_access"]),
                )
                .values(attempt_count=0, next_retry_at=None)
            )

        audit.status = "queued"
        audit.total_inputs = input_count
        audit.error = None
        audit.finished_at = None
        audit.paused_at = None
        audit.current_phase = "queued"
        audit.updated_at = utcnow()
        job = Job(
            requested_by=owner_id,
            mode="telegram_audit",
            scope="all",
            category=f"audit:{audit_id}",
            audit_id=audit_id,
            sources=sources or [],
            status="queued",
            progress={"audit_id": audit_id, "inputs": input_count, "checked": audit.checked_inputs},
        )
        session.add(job)
        await session.commit()
        await session.refresh(job)
        return job


def _audit_id_from_job(job: Job) -> int:
    if getattr(job, "audit_id", None):
        return int(job.audit_id)
    value = str(job.category or "")
    if not value.startswith("audit:"):
        raise ValueError("مهمة فحص Telegram لا تحتوي معرف الفحص.")
    return int(value.split(":", 1)[1])


def _peer_type(entity: Any) -> str:
    if isinstance(entity, User):
        return "bot" if bool(getattr(entity, "bot", False)) else "user"
    if isinstance(entity, Channel):
        return "channel" if bool(getattr(entity, "broadcast", False)) else "group"
    if isinstance(entity, Chat):
        return "group"
    return type(entity).__name__.lower()


def _group_requires_join_for_read(row: Any) -> bool:
    """Return True when a group link is valid but content cannot be read without joining.

    Invite metadata can identify a group and its title without granting message-history
    access.  We keep these links out of the normal readable-groups export and place
    them in a dedicated join-required export.  ChatInvitePeek/public entities that
    expose a peer id remain in the readable/previewable group bucket.
    """
    if str(getattr(row, "peer_type", "") or "") != "group":
        return False
    status = str(getattr(row, "status", "") or "")
    if status == "join_request":
        return True
    if status == "unjoined" and getattr(row, "peer_id", None) is None:
        return True
    if status == "restricted_access":
        return True
    return False


def _strict_requested_export_bucket(row: Any) -> str | None:
    """Return the exclusive user-facing Telegram entity export bucket.

    The split is intentionally based on Telegram's resolved ``peer_type`` only:
    ``channel`` means a broadcast channel with subscribers, while ``group`` means
    a basic group or megagroup with members.  A URL can never be returned as both.
    Join-required groups stay group-only but use their dedicated bucket.
    """
    peer_type = str(getattr(row, "peer_type", "") or "")
    status = str(getattr(row, "status", "") or "")
    eligible = VALID_PEER_RESULT_STATUSES | {"restricted_access", "web_visible"}
    if status not in eligible:
        return None
    if peer_type == "channel":
        return "channels"
    if peer_type == "group":
        return "groups_join_required" if _group_requires_join_for_read(row) else "groups"
    return None



def _is_pump_or_ipo_group(row: Any) -> bool:
    if str(getattr(row, "peer_type", "") or "") not in {"group", "channel"}:
        return False
    if str(getattr(row, "status", "") or "") not in VALID_PEER_RESULT_STATUSES | {"restricted_access", "web_visible"}:
        return False
    haystack = " ".join(
        str(value or "") for value in (
            getattr(row, "title", None), getattr(row, "username", None), getattr(row, "detail", None)
        )
    )
    return bool(PUMP_IPO_TITLE_RE.search(haystack))


async def purge_expired_links_from_main_database(audit_id: int) -> int:
    """Delete definitively expired audit URLs from the active link database.

    Audit result rows are retained as the immutable report of what was checked, but
    the dead URL is removed from ``links`` (and its cascading operational rows),
    Telegram peer aliases, and the resolution cache so it is no longer an active
    collected link.
    """
    async with SessionFactory() as session:
        urls = list((await session.scalars(
            select(TelegramAuditResult.normalized_url).where(
                TelegramAuditResult.audit_id == audit_id,
                TelegramAuditResult.status == "expired",
            )
        )).all())
    if not urls:
        return 0

    # Tombstone every definitively dead identity *before* deleting the active
    # link row. This survives restarts/upgrades and prevents old chat history
    # from resurrecting the same username/invite into ``links`` later.
    now = utcnow()
    block_values: list[dict[str, Any]] = []
    seen_block_keys: set[str] = set()
    for url in urls:
        key = telegram_identity_key(str(url))
        if key in seen_block_keys:
            continue
        seen_block_keys.add(key)
        block_values.append({
            "identity_key": key,
            "normalized_url": str(url),
            "reason": "expired",
            "first_audit_id": audit_id,
            "last_audit_id": audit_id,
            "first_blocked_at": now,
            "last_blocked_at": now,
            "rediscovered_count": 0,
        })
    if block_values:
        async with SessionFactory() as session:
            stmt = insert(TelegramExpiredLinkBlocklist).values(block_values)
            stmt = stmt.on_conflict_do_update(
                index_elements=[TelegramExpiredLinkBlocklist.identity_key],
                set_={
                    "normalized_url": stmt.excluded.normalized_url,
                    "reason": "expired",
                    "last_audit_id": audit_id,
                    "last_blocked_at": now,
                },
            )
            await session.execute(stmt)
            await session.commit()

    deleted_link_ids: set[int] = set()
    for start in range(0, len(urls), 100):
        batch = [str(value) for value in urls[start:start + 100]]
        link_conditions: list[Any] = []
        alias_conditions: list[Any] = []
        cache_conditions: list[Any] = []
        for url in batch:
            public = PUBLIC_RE.fullmatch(url)
            invite = INVITE_RE.fullmatch(url)
            if public:
                canonical = f"https://t.me/{public.group(1).lower()}"
                link_conditions.append(func.lower(Link.normalized_url) == canonical)
                alias_conditions.append(func.lower(TelegramPeerAlias.normalized_url) == canonical)
                cache_conditions.append(func.lower(TelegramResolutionCache.normalized_url) == canonical)
            elif invite:
                invite_hash = invite.group(1)
                aliases = [f"https://t.me/+{invite_hash}", f"https://t.me/joinchat/{invite_hash}"]
                link_conditions.append(Link.normalized_url.in_(aliases))
                alias_conditions.append(TelegramPeerAlias.normalized_url.in_(aliases))
                cache_conditions.append(TelegramResolutionCache.normalized_url.in_(aliases))
            else:
                link_conditions.append(Link.normalized_url == url)
                alias_conditions.append(TelegramPeerAlias.normalized_url == url)
                cache_conditions.append(TelegramResolutionCache.normalized_url == url)

        async with SessionFactory() as session:
            if link_conditions:
                ids = list((await session.scalars(
                    select(Link.id).where(Link.category == "telegram", or_(*link_conditions))
                )).all())
                if ids:
                    deleted_link_ids.update(int(value) for value in ids)
                    await session.execute(delete(Link).where(Link.id.in_(ids)))
            if alias_conditions:
                await session.execute(delete(TelegramPeerAlias).where(or_(*alias_conditions)))
            if cache_conditions:
                await session.execute(delete(TelegramResolutionCache).where(or_(*cache_conditions)))
            await session.commit()
    return len(deleted_link_ids)


def _entity_title(entity: Any) -> str | None:
    title = getattr(entity, "title", None)
    if title:
        return str(title)
    name = " ".join(
        part for part in [getattr(entity, "first_name", None), getattr(entity, "last_name", None)] if part
    ).strip()
    return name or None


def _rpc_code(exc: BaseException) -> str:
    pieces = [exc.__class__.__name__, str(getattr(exc, "message", "")), str(exc)]
    return " ".join(pieces).upper()


def _is_dead_link_error(exc: BaseException) -> bool:
    code = _rpc_code(exc)
    dead_markers = (
        "INVITE_HASH_EXPIRED",
        "INVITE_HASH_INVALID",
        "INVITEHASH_EXPIRED",
        "INVITEHASH_INVALID",
        "USERNAME_NOT_OCCUPIED",
        "USERNAMENOTOCCUPIED",
        "USERNAME_INVALID",
        "USERNAMEINVALID",
    )
    if any(marker in code for marker in dead_markers):
        return True
    # Telethon get_entity() may raise a plain ValueError for a public username
    # that no longer exists. That is URL validity, not an account failure.
    return ('NO USER HAS "' in code) and (' AS USERNAME' in code)


def _is_access_restriction_error(exc: BaseException) -> bool:
    code = _rpc_code(exc)
    markers = (
        "CHANNEL_PRIVATE",
        "CHANNELPRIVATE",
        "CHAT_FORBIDDEN",
        "CHATFORBIDDEN",
        "USER_BANNED_IN_CHANNEL",
        "USERBANNEDINCHANNEL",
        "CHANNEL_INVALID",
        "CHANNELINVALID",
        "CHAT_ADMIN_REQUIRED",
        "CHATADMINREQUIRED",
        "INVITE_REQUEST_SENT",
        "INVITEREQUESTSENT",
    )
    return any(marker in code for marker in markers)


def _audit_options(audit: TelegramAudit) -> dict[str, Any]:
    summary = audit.summary or {}
    options = summary.get("options") if isinstance(summary, dict) else None
    return dict(options) if isinstance(options, dict) else {}


def _pacing(options: dict[str, Any]) -> tuple[float, float, int, float]:
    profile = str(options.get("pacing") or "conservative")
    factor = 0.65 if profile == "balanced" else 1.0
    return (
        max(0.0, settings.audit_request_delay_seconds * factor),
        max(0.0, settings.audit_request_jitter_seconds * factor),
        max(1, settings.audit_batch_size),
        max(0.0, settings.audit_batch_pause_seconds * factor),
    )


async def _paced_sleep(options: dict[str, Any], checked: int = 0) -> None:
    base, jitter, batch_size, batch_pause = _pacing(options)
    delay = max(0.0, base + random.uniform(0.0, max(0.0, jitter)))
    if delay:
        await asyncio.sleep(delay)
    if checked and batch_size > 0 and checked % batch_size == 0 and batch_pause > 0:
        await asyncio.sleep(batch_pause)


def _available_clients(
    clients: list[tuple[int, Any]],
    cooldowns: dict[int, float],
    resolver_offset: int = 0,
    burst_limiter: AccountBurstLimiter | None = None,
) -> list[tuple[int, Any]]:
    if not clients:
        return []
    now = time.monotonic()
    ordered = clients[resolver_offset % len(clients):] + clients[:resolver_offset % len(clients)]
    return [
        (account_id, client)
        for account_id, client in ordered
        if cooldowns.get(account_id, 0.0) <= now
        and (burst_limiter is None or burst_limiter.is_available(account_id, now))
    ]


async def _wait_for_any_client(
    clients: list[tuple[int, Any]],
    cooldowns: dict[int, float],
    burst_limiter: AccountBurstLimiter | None = None,
    job_id: int | None = None,
) -> None:
    if not clients:
        raise RuntimeError("لا توجد حسابات Telegram متاحة لفحص الروابط.")

    while True:
        if job_id is not None:
            await _ensure_job_active(job_id)

        if _available_clients(clients, cooldowns, burst_limiter=burst_limiter):
            return

        now = time.monotonic()
        waits: list[float] = []
        for account_id, _client in clients:
            flood_wait = max(0.0, float(cooldowns.get(account_id, 0.0)) - now)
            pace_wait = burst_limiter.wait_seconds(account_id, now) if burst_limiter is not None else 0.0
            wait = max(flood_wait, pace_wait)
            if wait > 0:
                waits.append(wait)

        # Re-check frequently so Pause/Cancel remains responsive. Never convert
        # a link to an error merely because every account is temporarily resting.
        sleep_for = min(15.0, max(1.0, min(waits))) if waits else 1.0
        await asyncio.sleep(sleep_for)


async def _save_whatsapp_links(
    audit_id: int,
    source_url: str,
    account_id: int,
    entity: Any,
    client: Any,
    scope: str,
    job_id: int,
    *,
    manager: Any | None = None,
    cursor_key: str | None = None,
) -> tuple[int, int]:
    """Collect WhatsApp links for the requested time scope with resume support.

    WhatsApp collection remains optional and time-bounded.  The audit resolver
    is not called for discovered links; rows are stored only in the WhatsApp
    discovery table.  A durable JobCursor lets a stopped/restarted bot continue
    from the last committed message rather than repeating the whole source.
    """
    from app.services.scanner import JobCancelled, JobPaused, cutoff_for_scope, resolve_source_entity

    cutoff = cutoff_for_scope(scope)
    added = 0
    messages_seen = 0
    peer_id = None
    try:
        peer_id = int(get_peer_id(entity))
    except Exception:
        pass

    cursor_key = cursor_key or f"audit_wa:{audit_id}:peer:{peer_id or source_url}"
    cursor = await _audit_cursor_get(job_id, cursor_key)
    offset_id = int(cursor.offset_id or 0) if cursor else 0
    detail = json.dumps({"source_url": source_url, "account_id": account_id, "scope": scope}, ensure_ascii=False)
    await _audit_cursor_save(job_id, cursor_key, offset_id=offset_id, status="running", detail=detail)

    message_filter = InputMessagesFilterUrl if settings.audit_whatsapp_fast_scan else None
    reconnect_attempts = max(1, int(getattr(settings, "collector_reconnect_attempts", 3)))
    failures = 0
    while True:
        try:
            if manager is not None:
                client = await manager.ensure_connected(account_id)
                if entity is None:
                    entity = await resolve_source_entity(client, source_url)

            async for message in client.iter_messages(entity, filter=message_filter, offset_id=offset_id):
                failures = 0
                messages_seen += 1
                if messages_seen % 100 == 0:
                    await _ensure_job_active(job_id)
                if cutoff and message.date and message.date < cutoff:
                    await _audit_cursor_save(job_id, cursor_key, offset_id=offset_id, status="completed", detail=detail)
                    return added, messages_seen

                urls = extract_urls_from_message(message)
                rows: list[dict[str, Any]] = []
                for raw_url in urls:
                    inspection = inspect_collection_link(raw_url, "whatsapp")
                    if not inspection.link:
                        continue
                    rows.append({
                        "audit_id": audit_id,
                        "normalized_url": inspection.link.normalized,
                        "source_telegram_url": source_url,
                        "source_peer_id": peer_id,
                        "source_account_id": account_id,
                        "source_message_id": getattr(message, "id", None),
                        "source_message_date": getattr(message, "date", None),
                    })
                if rows:
                    async with SessionFactory() as session:
                        result = await session.execute(
                            insert(TelegramAuditWhatsapp)
                            .values(rows)
                            .on_conflict_do_nothing(
                                index_elements=[TelegramAuditWhatsapp.audit_id, TelegramAuditWhatsapp.normalized_url]
                            )
                            .returning(TelegramAuditWhatsapp.id)
                        )
                        added += len(list(result.scalars().all()))
                        await session.commit()

                offset_id = int(getattr(message, "id", 0) or offset_id)
                if messages_seen % 100 == 0:
                    await _audit_cursor_save(job_id, cursor_key, offset_id=offset_id, status="running", detail=detail)
                if settings.audit_whatsapp_message_delay_seconds > 0:
                    await asyncio.sleep(settings.audit_whatsapp_message_delay_seconds)

            await _audit_cursor_save(job_id, cursor_key, offset_id=offset_id, status="completed", detail=detail)
            return added, messages_seen
        except (JobCancelled, JobPaused):
            await _audit_cursor_save(job_id, cursor_key, offset_id=offset_id, status="paused", detail=detail)
            raise
        except Exception as exc:
            failures += 1
            if failures > reconnect_attempts:
                await _audit_cursor_save(job_id, cursor_key, offset_id=offset_id, status="error", detail=f"{detail} | {exc}"[:4000])
                raise
            logger.warning("WhatsApp discovery reconnect source=%s account=%s attempt=%s/%s: %s", source_url, account_id, failures, reconnect_attempts, exc)
            if manager is not None:
                client = await manager.ensure_connected(account_id)
                try:
                    entity = await resolve_source_entity(client, source_url)
                except Exception:
                    pass
            await asyncio.sleep(min(30.0, 2.0 ** failures))



def _telegram_discovery_detail(
    source_url: str,
    account_id: int,
    *,
    deferred_until: datetime | None = None,
    reason: str | None = None,
    method: str | None = None,
) -> str:
    payload: dict[str, Any] = {"source_url": source_url, "account_id": int(account_id)}
    if deferred_until is not None:
        if deferred_until.tzinfo is None:
            deferred_until = deferred_until.replace(tzinfo=timezone.utc)
        payload["deferred_until"] = deferred_until.isoformat()
    if reason:
        payload["defer_reason"] = str(reason)[:1000]
    if method:
        payload["defer_method"] = str(method)[:120]
    return json.dumps(payload, ensure_ascii=False)


def _telegram_discovery_deferred_seconds(detail: str | None, *, now: datetime | None = None) -> float:
    if not detail:
        return 0.0
    try:
        payload = json.loads(detail)
        raw = payload.get("deferred_until")
        if not raw:
            return 0.0
        until = datetime.fromisoformat(str(raw))
        if until.tzinfo is None:
            until = until.replace(tzinfo=timezone.utc)
        current = now or utcnow()
        if current.tzinfo is None:
            current = current.replace(tzinfo=timezone.utc)
        return max(0.0, (until - current).total_seconds())
    except Exception:
        return 0.0


def _telegram_floodwait_method(exc: BaseException) -> str:
    text = str(exc)
    if "ResolveUsername" in text:
        return "ResolveUsername"
    if "CheckChatInvite" in text:
        return "CheckChatInvite"
    if "GetHistory" in text or "iter_messages" in text:
        return "GetHistory"
    return "TelegramDiscovery"


async def _sleep_discovery_defer(job_id: int, seconds: float) -> None:
    deadline = time.monotonic() + max(0.0, float(seconds))
    while True:
        await _ensure_job_active(job_id)
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return
        await asyncio.sleep(min(5.0, max(0.1, remaining)))


def _telegram_account_method_cooldown_key(audit_id: int, account_id: int, method: str) -> str:
    safe_method = re.sub(r"[^A-Za-z0-9_-]+", "_", str(method or "Telegram"))[:80]
    return f"audit_method_cooldown:{audit_id}:{safe_method}:{int(account_id)}"


async def _telegram_account_method_cooldown_remaining(
    job_id: int, audit_id: int, account_id: int, method: str,
) -> tuple[float, datetime | None]:
    """Return a durable per-account/per-method cooldown.

    The cooldown is stored as a special JobCursor so it survives Termux/Ubuntu
    restarts but is not mistaken for a source crawl cursor.
    """
    key = _telegram_account_method_cooldown_key(audit_id, account_id, method)
    cursor = await _audit_cursor_get(job_id, key)
    if cursor is None or not cursor.detail:
        return 0.0, None
    try:
        payload = json.loads(cursor.detail)
        raw = payload.get("deferred_until")
        if not raw:
            return 0.0, None
        until = datetime.fromisoformat(str(raw))
        if until.tzinfo is None:
            until = until.replace(tzinfo=timezone.utc)
        remaining = max(0.0, (until - utcnow()).total_seconds())
        if remaining <= 0 and cursor.status != "completed":
            await _audit_cursor_save(job_id, key, offset_id=0, status="completed", detail=cursor.detail)
        return remaining, until
    except Exception:
        return 0.0, None


async def _telegram_account_method_cooldown_set(
    job_id: int, audit_id: int, account_id: int, method: str, wait_seconds: float,
) -> datetime:
    """Persist the longest known cooldown without shortening an existing one."""
    wait_seconds = max(1.0, float(wait_seconds))
    current_remaining, current_until = await _telegram_account_method_cooldown_remaining(
        job_id, audit_id, account_id, method
    )
    proposed_until = utcnow() + timedelta(seconds=wait_seconds)
    until = current_until if current_until is not None and current_remaining > 0 and current_until >= proposed_until else proposed_until
    key = _telegram_account_method_cooldown_key(audit_id, account_id, method)
    detail = json.dumps({
        "audit_id": int(audit_id),
        "account_id": int(account_id),
        "method": str(method),
        "deferred_until": until.isoformat(),
        "reason": "Telegram FloodWait account-level method cooldown",
    }, ensure_ascii=False)
    await _audit_cursor_save(job_id, key, offset_id=0, status="deferred", detail=detail)
    return until


def _telegram_dedup_key(normalized_url: str) -> str:
    """Shared durable Telegram identity used by discovery and tombstones."""
    return telegram_identity_key(normalized_url)


def _telegram_existing_match_conditions(normalized_url: str) -> list[Any]:
    public = PUBLIC_RE.fullmatch(normalized_url)
    if public:
        canonical = f"https://t.me/{public.group(1).lower()}"
        return [func.lower(Link.normalized_url) == canonical]
    invite = INVITE_RE.fullmatch(normalized_url)
    if invite:
        invite_hash = invite.group(1)
        return [Link.normalized_url.in_([
            f"https://t.me/+{invite_hash}",
            f"https://t.me/joinchat/{invite_hash}",
        ])]
    return [Link.normalized_url == normalized_url]


async def _save_telegram_discovered_links(
    audit_id: int,
    source_url: str,
    account_id: int,
    entity: Any,
    client: Any,
    scope: str,
    job_id: int,
    db_lock: asyncio.Lock,
    *,
    manager: Any | None = None,
    cursor_key: str | None = None,
) -> tuple[int, int, int]:
    """Collect globally-new Telegram links from full readable history.

    V6.2.3 deliberately *does not resolve, join or audit discovered URLs here*.
    It only performs local URL extraction/normalization/deduplication and inserts
    globally-new links into ``links`` plus the audit discovery table.  A durable
    cursor and reconnect loop make a full-history crawl resumable after network
    loss, process restart or a controlled upgrade.
    """
    from app.services.scanner import JobCancelled, JobPaused, cutoff_for_scope, resolve_source_entity

    added = 0
    skipped_existing = 0
    messages_seen = 0
    peer_id = None
    try:
        peer_id = int(get_peer_id(entity))
    except Exception:
        pass

    cursor_key = cursor_key or f"audit_tg:{audit_id}:peer:{peer_id or source_url}"
    cursor = await _audit_cursor_get(job_id, cursor_key)
    last_message_id = int(cursor.offset_id or 0) if cursor else 0
    detail = _telegram_discovery_detail(source_url, account_id)
    await _audit_cursor_save(job_id, cursor_key, offset_id=last_message_id, status="running", detail=detail)

    reconnect_attempts = max(1, int(getattr(settings, "collector_reconnect_attempts", 3)))
    failures = 0
    cutoff = cutoff_for_scope(scope)
    fast_scan = bool(getattr(settings, "audit_telegram_fast_scan", True))
    max_messages = max(0, int(getattr(settings, "audit_telegram_max_messages_per_chat_all", 0)))

    async def persist_message_links(message_obj: Any, source_chat_id: int | None) -> None:
        nonlocal added, skipped_existing
        candidates: dict[str, Any] = {}
        for raw_url in extract_urls_from_message(message_obj):
            inspection = inspect_collection_link(raw_url, "telegram")
            if not inspection.link:
                continue
            candidates.setdefault(_telegram_dedup_key(inspection.link.normalized), inspection.link)
        if not candidates:
            return
        # No CheckChatInvite/get_entity/join here; discovered URLs are stored only.
        async with db_lock:
            conditions: list[Any] = []
            for clean in candidates.values():
                conditions.extend(_telegram_existing_match_conditions(clean.normalized))
            existing_keys: set[str] = set()
            if conditions:
                async with SessionFactory() as session:
                    existing_urls = list((await session.scalars(
                        select(Link.normalized_url).where(Link.category == "telegram", or_(*conditions))
                    )).all())
                existing_keys = {_telegram_dedup_key(str(value)) for value in existing_urls}
            pending = [clean for key, clean in candidates.items() if key not in existing_keys]
            skipped_existing += len(candidates) - len(pending)
            if not pending:
                return
            registrations = await register_links_batch(
                [BatchLinkSource(
                    clean=clean, account_id=account_id, chat_id=source_chat_id,
                    message_id=getattr(message_obj, "id", None),
                    message_date=getattr(message_obj, "date", None),
                ) for clean in pending],
                origin="audit_telegram_discovery", job_id=job_id,
            )
            discovery_rows: list[dict[str, Any]] = []
            for clean, registration in zip(pending, registrations, strict=True):
                if registration.blocked or registration.link is None or not registration.created:
                    skipped_existing += 1
                    continue
                discovery_rows.append({
                    "audit_id": audit_id, "link_id": registration.link.id,
                    "normalized_url": registration.link.normalized_url,
                    "source_telegram_url": source_url, "source_peer_id": source_chat_id,
                    "source_account_id": account_id,
                    "source_message_id": getattr(message_obj, "id", None),
                    "source_message_date": getattr(message_obj, "date", None),
                })
            if discovery_rows:
                async with SessionFactory() as session:
                    result = await session.execute(
                        insert(TelegramAuditTelegramDiscovery).values(discovery_rows)
                        .on_conflict_do_nothing(index_elements=[
                            TelegramAuditTelegramDiscovery.audit_id,
                            TelegramAuditTelegramDiscovery.normalized_url,
                        ]).returning(TelegramAuditTelegramDiscovery.id)
                    )
                    added += len(list(result.scalars().all()))
                    await session.commit()
    while True:
        try:
            if manager is not None:
                client = await manager.ensure_connected(account_id)
                if entity is None:
                    entity = await resolve_source_entity(client, source_url)

            iterator_kwargs: dict[str, Any] = {}
            if fast_scan:
                iterator_kwargs["filter"] = InputMessagesFilterUrl
            if max_messages > 0:
                iterator_kwargs["limit"] = max_messages
            if cutoff is None:
                # Full/new scans move oldest -> newest and resume after the last
                # committed message id.
                iterator_kwargs.update({"reverse": True, "min_id": last_message_id})
            else:
                # Time-bounded scans move newest -> oldest.  offset_id resumes
                # below the last committed id without replaying newer messages.
                iterator_kwargs["offset_id"] = last_message_id

            async for message in client.iter_messages(entity, **iterator_kwargs):
                failures = 0
                if cutoff and getattr(message, "date", None) and message.date < cutoff:
                    break
                messages_seen += 1
                if messages_seen % 100 == 0:
                    await _ensure_job_active(job_id)

                await persist_message_links(message, peer_id)

                # V6.6 account audit discovery also scans Telegram post comments
                # / linked discussion replies when Telegram exposes them.
                replies_count = int(getattr(getattr(message, "replies", None), "replies", 0) or 0)
                if bool(getattr(settings, "audit_scan_discussion_comments", True)) and replies_count > 0:
                    try:
                        comment_seen = 0
                        async for comment in client.iter_messages(entity, reply_to=int(message.id)):
                            comment_seen += 1
                            messages_seen += 1
                            raw_chat_id = getattr(comment, "chat_id", None)
                            try:
                                comment_chat_id = int(raw_chat_id) if raw_chat_id is not None else peer_id
                            except Exception:
                                comment_chat_id = peer_id
                            await persist_message_links(comment, comment_chat_id)
                            if comment_seen % 100 == 0:
                                await _ensure_job_active(job_id)
                    except FloodWaitError:
                        raise
                    except Exception as exc:
                        logger.info(
                            "Discussion comments unavailable audit=%s source=%s message=%s: %s",
                            audit_id, source_url, getattr(message, "id", None), exc,
                        )

                last_message_id = int(getattr(message, "id", 0) or last_message_id)
                if messages_seen % 100 == 0:
                    await _audit_cursor_save(
                        job_id, cursor_key, offset_id=last_message_id, status="running", detail=detail
                    )
                if settings.audit_telegram_message_delay_seconds > 0:
                    await asyncio.sleep(settings.audit_telegram_message_delay_seconds)

            await _audit_cursor_save(
                job_id, cursor_key, offset_id=last_message_id, status="completed", detail=detail
            )
            return added, messages_seen, skipped_existing
        except (JobCancelled, JobPaused):
            await _audit_cursor_save(
                job_id, cursor_key, offset_id=last_message_id, status="paused", detail=detail
            )
            raise
        except FloodWaitError as exc:
            method = _telegram_floodwait_method(exc)
            wait_seconds = max(1.0, float(exc.seconds) + float(settings.audit_floodwait_safety_seconds))
            deferred_until = utcnow() + timedelta(seconds=wait_seconds)
            deferred_detail = _telegram_discovery_detail(
                source_url, account_id, deferred_until=deferred_until,
                reason=f"FloodWait {exc.seconds}s", method=method,
            )
            await _audit_cursor_save(
                job_id, cursor_key, offset_id=last_message_id, status="deferred", detail=deferred_detail
            )
            raise TelegramDiscoveryDeferred(
                wait_seconds, method=method,
                detail=f"FloodWait {exc.seconds}s — discovery deferred until {deferred_until.isoformat()}",
            ) from exc
        except Exception as exc:
            failures += 1
            if failures > reconnect_attempts:
                await _audit_cursor_save(
                    job_id, cursor_key, offset_id=last_message_id, status="error",
                    detail=f"{detail} | {exc}"[:4000],
                )
                raise
            logger.warning(
                "Telegram discovery reconnect source=%s account=%s attempt=%s/%s: %s",
                source_url, account_id, failures, reconnect_attempts, exc,
            )
            if manager is not None:
                client = await manager.ensure_connected(account_id)
                # Keep the already-resolved peer after a transport reconnect.
                # Re-resolving a public username here would unnecessarily call
                # contacts.resolveUsername and can create a long FloodWait even
                # though iter_messages can continue with the existing InputPeer.
                if entity is None:
                    try:
                        if peer_id is not None:
                            entity = await client.get_input_entity(int(peer_id))
                        if entity is None:
                            entity = await resolve_source_entity(client, source_url)
                    except FloodWaitError as flood_exc:
                        method = _telegram_floodwait_method(flood_exc)
                        wait_seconds = max(
                            1.0, float(flood_exc.seconds) + float(settings.audit_floodwait_safety_seconds)
                        )
                        deferred_until = utcnow() + timedelta(seconds=wait_seconds)
                        deferred_detail = _telegram_discovery_detail(
                            source_url, account_id, deferred_until=deferred_until,
                            reason=f"FloodWait {flood_exc.seconds}s", method=method,
                        )
                        await _audit_cursor_save(
                            job_id, cursor_key, offset_id=last_message_id, status="deferred", detail=deferred_detail
                        )
                        raise TelegramDiscoveryDeferred(
                            wait_seconds, method=method,
                            detail=f"FloodWait {flood_exc.seconds}s — discovery deferred",
                        ) from flood_exc
                    except Exception:
                        pass
            await asyncio.sleep(min(30.0, 2.0 ** failures))


async def _set_job_progress(job_id: int, progress: dict[str, Any]) -> None:
    async with SessionFactory() as session:
        await session.execute(
            update(Job).where(Job.id == job_id).values(progress=progress, heartbeat_at=utcnow(), updated_at=utcnow())
        )
        await session.commit()


async def _ensure_job_active(job_id: int) -> None:
    from app.services.scanner import JobCancelled, JobPaused
    async with SessionFactory() as session:
        status = await session.scalar(select(Job.status).where(Job.id == job_id))
        if status in {None, "cancel_requested", "cancelled", "stopping"}:
            raise JobCancelled("تم إلغاء فحص روابط Telegram.")
        if status in {"pause_requested", "paused"}:
            now = utcnow()
            await session.execute(
                update(Job).where(Job.id == job_id).values(status="paused", paused_at=now, updated_at=now, heartbeat_at=now)
            )
            await session.commit()
            raise JobPaused("تم إيقاف فحص Telegram مؤقتًا ويمكن استكماله لاحقًا.")


async def _job_cancelled(job_id: int) -> bool:
    async with SessionFactory() as session:
        status = await session.scalar(select(Job.status).where(Job.id == job_id))
    return status in {None, "cancel_requested", "cancelled", "stopping"}


async def _load_persisted_cooldowns(account_ids: set[int]) -> dict[int, float]:
    if not account_ids:
        return {}
    now_dt = utcnow()
    now_mono = time.monotonic()
    cooldowns: dict[int, float] = {}
    async with SessionFactory() as session:
        rows = (
            await session.execute(
                select(Account.id, Account.flood_wait_until).where(Account.id.in_(account_ids))
            )
        ).all()
    for account_id, until in rows:
        if until is None:
            continue
        if until.tzinfo is None:
            until = until.replace(tzinfo=timezone.utc)
        remaining = (until - now_dt).total_seconds()
        if remaining > 0:
            cooldowns[int(account_id)] = now_mono + remaining
    return cooldowns


async def _mark_account_success(account_id: int) -> None:
    now = utcnow()
    async with SessionFactory() as session:
        await session.execute(
            update(Account).where(Account.id == account_id).values(
                health_status="healthy", last_success_at=now, last_error=None, consecutive_errors=0,
                requests_count=Account.requests_count + 1, updated_at=now,
            )
        )
        await session.commit()


async def _mark_account_error(account_id: int, exc: BaseException, *, flood_seconds: int | None = None) -> None:
    now = utcnow()
    async with SessionFactory() as session:
        account = await session.get(Account, account_id)
        if not account:
            return
        account.requests_count = int(account.requests_count or 0) + 1
        account.errors_count = int(account.errors_count or 0) + 1
        account.consecutive_errors = int(account.consecutive_errors or 0) + 1
        account.last_error = str(exc)[:2000]
        account.last_error_at = now
        if flood_seconds is not None:
            account.health_status = "flood_wait"
            account.flood_wait_until = now + timedelta(seconds=max(0, int(flood_seconds)))
        elif account.consecutive_errors >= max(1, settings.audit_account_error_threshold):
            account.health_status = "cooldown"
            account.flood_wait_until = now + timedelta(seconds=max(1, settings.audit_account_circuit_breaker_seconds))
        else:
            account.health_status = "slow"
        await session.commit()


async def _audit_cursor_get(job_id: int, cursor_key: str) -> JobCursor | None:
    async with SessionFactory() as session:
        return await session.scalar(
            select(JobCursor).where(JobCursor.job_id == job_id, JobCursor.cursor_key == cursor_key)
        )


async def _audit_cursor_save(
    job_id: int, cursor_key: str, *, offset_id: int, status: str = "running", detail: str | None = None
) -> None:
    async with SessionFactory() as session:
        stmt = (
            insert(JobCursor)
            .values(job_id=job_id, cursor_key=cursor_key, offset_id=int(offset_id), status=status, detail=detail)
            .on_conflict_do_update(
                index_elements=[JobCursor.job_id, JobCursor.cursor_key],
                set_={"offset_id": int(offset_id), "status": status, "detail": detail, "updated_at": utcnow()},
            )
        )
        await session.execute(stmt)
        await session.commit()


async def _collect_sources_into_audit(audit_id: int, job: Job, clients: list[tuple[int, Any]]) -> dict[str, int]:
    from app.services.scanner import JobCancelled, JobPaused, resolve_source_entity

    base = dict(job.progress or {})
    counters = {
        "source_messages": int(base.get("source_messages", 0)),
        "source_links": int(base.get("source_links", 0)),
        "source_errors": int(base.get("source_errors", 0)),
    }
    for source in job.sources:
        await _ensure_job_active(job.id)
        cursor_key = f"audit-source:{audit_id}:{source}"
        cursor = await _audit_cursor_get(job.id, cursor_key)
        if cursor and cursor.status == "completed":
            continue
        offset_id = int(cursor.offset_id if cursor else 0)
        resolved = False
        last_error: BaseException | None = None
        for account_id, client in clients:
            try:
                entity = await resolve_source_entity(client, source)
                async for message in client.iter_messages(entity, filter=InputMessagesFilterUrl, offset_id=offset_id):
                    counters["source_messages"] += 1
                    if counters["source_messages"] % max(1, settings.audit_source_message_check_every) == 0:
                        await _ensure_job_active(job.id)
                    urls = _clean_telegram_urls(extract_urls_from_message(message))
                    if urls:
                        added, _ = await add_audit_urls(audit_id, urls)
                        counters["source_links"] += added
                    # Save only after all links in this message were committed.
                    offset_id = int(message.id)
                    if counters["source_messages"] % 50 == 0 or urls:
                        await _audit_cursor_save(job.id, cursor_key, offset_id=offset_id)
                await _audit_cursor_save(job.id, cursor_key, offset_id=offset_id, status="completed")
                resolved = True
                break
            except (JobCancelled, JobPaused):
                await _audit_cursor_save(job.id, cursor_key, offset_id=offset_id, status="paused")
                raise
            except FloodWaitError as exc:
                last_error = exc
                await _mark_account_error(account_id, exc, flood_seconds=int(exc.seconds))
                await _audit_cursor_save(
                    job.id, cursor_key, offset_id=offset_id, status="running", detail=f"FloodWait {exc.seconds}s"
                )
                if exc.seconds <= settings.audit_max_flood_wait_seconds:
                    await asyncio.sleep(exc.seconds + 1)
                    continue
            except Exception as exc:
                last_error = exc
                await _mark_account_error(account_id, exc)
                continue
        if not resolved:
            counters["source_errors"] += 1
            await _audit_cursor_save(job.id, cursor_key, offset_id=offset_id, status="error", detail=str(last_error)[:1000])
            logger.warning("Audit source failed %s: %s", source, last_error)
    return counters


async def _build_membership_index(
    manager: Any, job_id: int, primary_account_ids: set[int] | None = None, *, force_refresh: bool = False
) -> tuple[dict[int, MembershipInfo], dict[int, dict[str, Any]]]:
    """Build/reuse membership indexes for primary accounts in parallel.

    The cache is durable. When a rebuild is required, multiple accounts read
    their dialog lists concurrently with a bounded semaphore; each account's
    cache is replaced only after a complete successful read.
    """
    from app.services.scanner import JobCancelled, JobPaused
    membership: dict[int, MembershipInfo] = {}
    account_stats: dict[int, dict[str, Any]] = {}
    now = utcnow()
    cache_cutoff = now - timedelta(seconds=max(0, settings.membership_cache_ttl_seconds))
    selected = [
        (account_id, client)
        for account_id, client in manager.clients.items()
        if primary_account_ids is None or account_id in primary_account_ids
    ]
    semaphore = asyncio.Semaphore(min(len(selected) or 1, max(1, int(settings.audit_membership_workers))))

    async def load_one(account_id: int, client: Any) -> tuple[int, dict[int, MembershipInfo], dict[str, Any]]:
        async with semaphore:
            await _ensure_job_active(job_id)
            account = manager.account_records.get(account_id)
            label = account.label if account else f"حساب {account_id}"

            async with SessionFactory() as session:
                cached = list((await session.scalars(
                    select(AccountMembership)
                    .where(AccountMembership.account_id == account_id, AccountMembership.refreshed_at >= cache_cutoff)
                    .order_by(AccountMembership.id)
                )).all())
            if cached and not force_refresh:
                local: dict[int, MembershipInfo] = {}
                groups = channels = 0
                for row in cached:
                    local[int(row.peer_id)] = MembershipInfo(
                        account_ids={account_id}, title=row.title, username=row.username, peer_type=row.peer_type
                    )
                    if row.peer_type == "channel":
                        channels += 1
                    else:
                        groups += 1
                return account_id, local, {
                    "label": label, "dialogs": len(cached), "groups": groups, "channels": channels, "cache": "hit"
                }

            last_error: BaseException | None = None
            for attempt in range(1, 4):
                local_rows: list[dict[str, Any]] = []
                local_membership: dict[int, MembershipInfo] = {}
                stats = {"label": label, "dialogs": 0, "groups": 0, "channels": 0, "cache": "rebuilt"}
                try:
                    client = await manager.ensure_connected(account_id)
                    dialog_seen = 0
                    async for dialog in client.iter_dialogs():
                        dialog_seen += 1
                        if dialog_seen % 100 == 0:
                            await _ensure_job_active(job_id)
                        if not (dialog.is_group or dialog.is_channel):
                            continue
                        peer_id = int(get_peer_id(dialog.entity))
                        peer_type = _peer_type(dialog.entity)
                        title = getattr(dialog, "name", None) or _entity_title(dialog.entity)
                        username = getattr(dialog.entity, "username", None)
                        local_membership[peer_id] = MembershipInfo(
                            account_ids={account_id}, title=title, username=username, peer_type=peer_type
                        )
                        local_rows.append({
                            "account_id": account_id, "peer_id": peer_id, "peer_type": peer_type,
                            "title": title, "username": username, "refreshed_at": now,
                        })
                        stats["dialogs"] += 1
                        stats["channels" if peer_type == "channel" else "groups"] += 1

                    async with SessionFactory() as session:
                        await session.execute(delete(AccountMembership).where(AccountMembership.account_id == account_id))
                        if local_rows:
                            # Chunk inserts to keep SQLite parameter counts bounded.
                            for pos in range(0, len(local_rows), 500):
                                await session.execute(insert(AccountMembership).values(local_rows[pos:pos + 500]))
                        await session.commit()
                    return account_id, local_membership, stats
                except (JobCancelled, JobPaused):
                    raise
                except FloodWaitError as exc:
                    last_error = exc
                    await _mark_account_error(account_id, exc, flood_seconds=int(exc.seconds))
                    logger.warning("Dialog index FloodWait account=%s attempt=%s wait=%ss", account_id, attempt, exc.seconds)
                    if exc.seconds <= settings.audit_max_flood_wait_seconds:
                        await asyncio.sleep(exc.seconds + 1)
                    else:
                        break
                except Exception as exc:
                    last_error = exc
                    await _mark_account_error(account_id, exc)
                    logger.warning("Dialog index failed account=%s attempt=%s: %s", account_id, attempt, exc)
                    if attempt < 3:
                        await asyncio.sleep(min(
                            settings.audit_retry_max_seconds,
                            settings.audit_retry_base_seconds * (2 ** (attempt - 1)),
                        ))
            raise RuntimeError(
                f"تعذر بناء قائمة المجموعات والقنوات كاملة للحساب #{account_id} ({label}): {last_error}. "
                "تم إيقاف الفحص لمنع نتائج تصنيف غير دقيقة."
            )

    results = await asyncio.gather(*(load_one(account_id, client) for account_id, client in selected))
    for account_id, local_membership, stats in results:
        for peer_id, local_info in local_membership.items():
            info = membership.setdefault(peer_id, MembershipInfo(account_ids=set()))
            info.account_ids.add(account_id)
            info.title = info.title or local_info.title
            info.username = info.username or local_info.username
            info.peer_type = info.peer_type or local_info.peer_type
        account_stats[account_id] = stats
    return membership, account_stats

async def _check_invite(
    url: str,
    clients: list[tuple[int, Any]],
    membership: dict[int, MembershipInfo],
    account_labels: dict[int, str],
    resolver_offset: int = 0,
    options: dict[str, Any] | None = None,
    cooldowns: dict[int, float] | None = None,
    account_locks: dict[int, asyncio.Lock] | None = None,
    burst_limiter: AccountBurstLimiter | None = None,
) -> dict[str, Any]:
    match = INVITE_RE.fullmatch(url)
    if not match:
        raise ValueError("Not an invite URL")
    invite_hash = match.group(1)
    options = options or {}
    valid_invite: ChatInvite | None = None
    dead_errors: list[str] = []
    access_errors: list[str] = []
    transient_errors: list[str] = []

    cooldowns = cooldowns if cooldowns is not None else {}
    account_locks = account_locks if account_locks is not None else {}
    attempted_requests = 0
    ordered_clients = _available_clients(clients, cooldowns, resolver_offset, burst_limiter)
    for account_id, client in ordered_clients:
        try:
            lock = account_locks.setdefault(account_id, asyncio.Lock())
            async with lock:
                # Another worker may have consumed the third slot while this
                # worker waited for the account lock. Skip to another account.
                if cooldowns.get(account_id, 0.0) > time.monotonic():
                    continue
                if burst_limiter is not None and not burst_limiter.reserve(account_id):
                    continue
                attempted_requests += 1
                result = await client(CheckChatInviteRequest(invite_hash))
            if isinstance(result, ChatInviteAlready):
                entity = result.chat
                peer_id = int(get_peer_id(entity))
                info = membership.get(peer_id)
                ids = sorted(info.account_ids) if info else []
                status = "joined_duplicate" if len(ids) > 1 else "joined_unique" if len(ids) == 1 else "unjoined"
                return {
                    "status": status,
                    "peer_id": peer_id,
                    "peer_type": _peer_type(entity),
                    "title": _entity_title(entity),
                    "username": getattr(entity, "username", None),
                    "account_ids": ids,
                    "account_labels": [account_labels.get(i, f"حساب {i}") for i in ids],
                    "detail": "تم التحقق من الرابط بحساب احتياطي." if not ids else None,
                    "_client": client,
                    "_account_id": account_id,
                    "_entity": entity,
                }
            if isinstance(result, ChatInvitePeek):
                entity = result.chat
                peer_id = int(get_peer_id(entity))
                info = membership.get(peer_id)
                ids = sorted(info.account_ids) if info else []
                status = "joined_duplicate" if len(ids) > 1 else "joined_unique" if len(ids) == 1 else (
                    "join_request" if bool(getattr(entity, "join_request", False)) else "unjoined"
                )
                return {
                    "status": status,
                    "peer_id": peer_id,
                    "peer_type": _peer_type(entity),
                    "title": _entity_title(entity),
                    "username": getattr(entity, "username", None),
                    "account_ids": ids,
                    "account_labels": [account_labels.get(i, f"حساب {i}") for i in ids],
                    "detail": "Telegram سمح بمعاينة مؤقتة دون انضمام.",
                    "_client": client,
                    "_account_id": account_id,
                    "_entity": entity,
                }
            if isinstance(result, ChatInvite):
                valid_invite = result
                if bool(getattr(result, "request_needed", False)):
                    return {
                        "status": "join_request",
                        "peer_id": None,
                        "peer_type": "channel" if bool(getattr(result, "broadcast", False)) else "group",
                        "title": getattr(result, "title", None),
                        "username": None,
                        "account_ids": [],
                        "account_labels": [],
                        "detail": "الرابط صالح لكنه يتطلب موافقة مشرف على طلب الانضمام.",
                    }
        except FloodWaitError as exc:
            cooldowns[account_id] = max(cooldowns.get(account_id, 0.0), time.monotonic() + float(exc.seconds))
            await _mark_account_error(account_id, exc, flood_seconds=int(exc.seconds))
            transient_errors.append(f"account {account_id}: FloodWait {exc.seconds}s")
        except RPCError as exc:
            if _is_dead_link_error(exc):
                dead_errors.append(_rpc_code(exc)[:250])
            elif _is_access_restriction_error(exc):
                access_errors.append(f"account {account_id}: {_rpc_code(exc)[:220]}")
            else:
                transient_errors.append(str(exc)[:220])
        except Exception as exc:
            if _is_dead_link_error(exc):
                dead_errors.append(_rpc_code(exc)[:250])
            elif _is_access_restriction_error(exc):
                access_errors.append(f"account {account_id}: {_rpc_code(exc)[:220]}")
            else:
                transient_errors.append(str(exc)[:220])
        await _paced_sleep(options)

    if attempted_requests == 0:
        return {
            "status": "temporary_error", "peer_id": None, "peer_type": None, "title": None, "username": None,
            "account_ids": [], "account_labels": [], "error_class": "NoAccountAvailable",
            "detail": "كل الحسابات المتاحة دخلت فترة الراحة المنظمة قبل تنفيذ الطلب.",
            "_defer": True,
        }
    if valid_invite is not None:
        peer_type = "channel" if bool(getattr(valid_invite, "broadcast", False)) else "group"
        return {
            "status": "join_request" if bool(getattr(valid_invite, "request_needed", False)) else "unjoined",
            "peer_id": None,
            "peer_type": peer_type,
            "title": getattr(valid_invite, "title", None),
            "username": None,
            "account_ids": [],
            "account_labels": [],
            "detail": (
                "الرابط صالح ويحتاج طلب انضمام." if bool(getattr(valid_invite, "request_needed", False))
                else "رابط دعوة صالح ولم يظهر كعضوية في الحسابات الأساسية."
            ),
        }
    if access_errors:
        return {
            "status": "restricted_access", "peer_id": None, "peer_type": None, "title": None, "username": None,
            "account_ids": [], "account_labels": [], "error_class": "AccessDenied",
            "detail": "; ".join(access_errors + transient_errors)[:1000],
        }
    if dead_errors and not transient_errors:
        return {
            "status": "expired", "peer_id": None, "peer_type": None, "title": None, "username": None,
            "account_ids": [], "account_labels": [], "error_class": "InvalidInvite", "detail": "; ".join(dead_errors)[:1000],
        }
    return {
        "status": "temporary_error", "peer_id": None, "peer_type": None, "title": None, "username": None,
        "account_ids": [], "account_labels": [], "error_class": "Transient",
        "detail": "; ".join(dead_errors + transient_errors)[:1000] or "تعذر فحص الدعوة مؤقتًا.",
    }


async def _check_public(
    url: str,
    clients: list[tuple[int, Any]],
    membership: dict[int, MembershipInfo],
    account_labels: dict[int, str],
    resolver_offset: int = 0,
    options: dict[str, Any] | None = None,
    cooldowns: dict[int, float] | None = None,
    account_locks: dict[int, asyncio.Lock] | None = None,
    burst_limiter: AccountBurstLimiter | None = None,
) -> dict[str, Any]:
    match = PUBLIC_RE.fullmatch(url)
    if not match:
        return {
            "status": "unsupported", "peer_id": None, "peer_type": None, "title": None, "username": None,
            "account_ids": [], "account_labels": [], "detail": "رابط Telegram ليس رابط مستخدم/مجموعة/قناة مباشرًا.",
        }
    username = match.group(1)
    if username.lower() in RESERVED_PUBLIC_PATHS:
        return {
            "status": "unsupported", "peer_id": None, "peer_type": None, "title": None, "username": username,
            "account_ids": [], "account_labels": [], "detail": "مسار خدمة Telegram وليس مجموعة أو قناة.",
        }

    options = options or {}
    dead_errors: list[str] = []
    access_errors: list[str] = []
    transient_errors: list[str] = []
    cooldowns = cooldowns if cooldowns is not None else {}
    account_locks = account_locks if account_locks is not None else {}
    attempted_requests = 0
    ordered_clients = _available_clients(clients, cooldowns, resolver_offset, burst_limiter)
    for account_id, client in ordered_clients:
        try:
            lock = account_locks.setdefault(account_id, asyncio.Lock())
            async with lock:
                if cooldowns.get(account_id, 0.0) > time.monotonic():
                    continue
                if burst_limiter is not None and not burst_limiter.reserve(account_id):
                    continue
                attempted_requests += 1
                entity = await client.get_entity("@" + username)
            if isinstance(entity, User):
                return {
                    "status": "bot" if bool(getattr(entity, "bot", False)) else "personal",
                    "peer_id": int(get_peer_id(entity)),
                    "peer_type": _peer_type(entity),
                    "title": _entity_title(entity),
                    "username": getattr(entity, "username", username),
                    "account_ids": [],
                    "account_labels": [],
                    "detail": "الرابط يقود إلى بوت Telegram." if bool(getattr(entity, "bot", False)) else "الرابط يقود إلى مستخدم شخصي.",
                    "_client": client, "_account_id": account_id, "_entity": entity,
                }
            if isinstance(entity, (Channel, Chat)):
                peer_id = int(get_peer_id(entity))
                info = membership.get(peer_id)
                ids = sorted(info.account_ids) if info else []
                if len(ids) > 1:
                    status = "joined_duplicate"
                elif len(ids) == 1:
                    status = "joined_unique"
                elif bool(getattr(entity, "join_request", False)):
                    status = "join_request"
                else:
                    status = "unjoined"
                return {
                    "status": status,
                    "peer_id": peer_id,
                    "peer_type": _peer_type(entity),
                    "title": _entity_title(entity),
                    "username": getattr(entity, "username", username),
                    "account_ids": ids,
                    "account_labels": [account_labels.get(i, f"حساب {i}") for i in ids],
                    "detail": None,
                    "_client": client,
                    "_account_id": account_id,
                    "_entity": entity,
                }
            return {
                "status": "unsupported", "peer_id": None, "peer_type": _peer_type(entity),
                "title": _entity_title(entity), "username": username, "account_ids": [], "account_labels": [],
                "detail": "الكيان ليس مجموعة أو قناة.",
            }
        except FloodWaitError as exc:
            cooldowns[account_id] = max(cooldowns.get(account_id, 0.0), time.monotonic() + float(exc.seconds))
            await _mark_account_error(account_id, exc, flood_seconds=int(exc.seconds))
            transient_errors.append(f"account {account_id}: FloodWait {exc.seconds}s")
        except RPCError as exc:
            if _is_dead_link_error(exc):
                dead_errors.append(_rpc_code(exc)[:250])
            elif _is_access_restriction_error(exc):
                access_errors.append(f"account {account_id}: {_rpc_code(exc)[:220]}")
            else:
                transient_errors.append(str(exc)[:220])
        except Exception as exc:
            if _is_dead_link_error(exc):
                dead_errors.append(_rpc_code(exc)[:250])
            elif _is_access_restriction_error(exc):
                access_errors.append(f"account {account_id}: {_rpc_code(exc)[:220]}")
            else:
                transient_errors.append(str(exc)[:220])
        await _paced_sleep(options)

    if attempted_requests == 0:
        return {
            "status": "temporary_error", "peer_id": None, "peer_type": None, "title": None, "username": username,
            "account_ids": [], "account_labels": [], "error_class": "NoAccountAvailable",
            "detail": "كل الحسابات المتاحة دخلت فترة الراحة المنظمة قبل تنفيذ الطلب.",
            "_defer": True,
        }
    if access_errors:
        return {
            "status": "restricted_access", "peer_id": None, "peer_type": None, "title": None, "username": username,
            "account_ids": [], "account_labels": [], "error_class": "AccessDenied", "detail": "; ".join(access_errors + transient_errors)[:1000],
        }
    if dead_errors and not transient_errors:
        return {
            "status": "expired", "peer_id": None, "peer_type": None, "title": None, "username": username,
            "account_ids": [], "account_labels": [], "error_class": "InvalidInvite", "detail": "; ".join(dead_errors)[:1000],
        }
    return {
        "status": "temporary_error", "peer_id": None, "peer_type": None, "title": None, "username": username,
        "account_ids": [], "account_labels": [], "error_class": "Transient",
        "detail": "; ".join(dead_errors + transient_errors)[:1000] or "تعذر حل اسم المستخدم مؤقتًا.",
    }


async def process_telegram_audit_job(job: Job, manager: Any) -> dict[str, Any]:
    """V6 fixed-wave Telegram audit.

    User-preserved rule:
    * Active accounts are divided into groups of 10.
    * In each wave every account receives up to 4 DIFFERENT URLs.
    * Those four checks are launched concurrently for that account.
    * All account groups run their wave concurrently, then the whole audit rests
      for exactly 120 seconds before another wave when work remains.
    * A definitive dead/expired Telegram response is classified immediately as
      ``expired``; the same URL is not tried across every other account.

    The collector is intentionally separate and never calls this resolver.
    """
    from app.services.scanner import JobCancelled, JobPaused, account_items_for_operator

    audit_id = _audit_id_from_job(job)
    all_clients = sorted(
        await account_items_for_operator(manager, int(job.requested_by)), key=lambda item: item[0]
    )
    allowed_account_ids = {int(account_id) for account_id, _client in all_clients}
    if not all_clients:
        raise RuntimeError("لا توجد حسابات Telethon فعالة لفحص الروابط.")

    async with SessionFactory() as session:
        audit = await session.get(TelegramAudit, audit_id)
        if not audit:
            raise RuntimeError("سجل الفحص غير موجود.")
        options = _audit_options(audit)
        now = utcnow()
        audit.status = "running"
        audit.started_at = audit.started_at or now
        audit.updated_at = now
        audit.paused_at = None
        audit.current_phase = "preparing"
        audit.error = None

        # V6.2.4 migration-on-run: FloodWait says nothing about URL validity.
        # Older builds could exhaust three short retries and store such URLs as
        # final errors. Requeue only FloodWait-derived final errors; permanent
        # invalid/expired classifications are untouched.
        await session.execute(
            update(TelegramAuditResult)
            .where(
                TelegramAuditResult.audit_id == audit_id,
                TelegramAuditResult.status == "error",
                or_(
                    TelegramAuditResult.error_class.in_(["FloodWait", "FloodWaitError"]),
                    TelegramAuditResult.detail.ilike("%FloodWait%"),
                ),
            )
            .values(status="temporary_error", attempt_count=0, next_retry_at=now)
        )

        # V6.3.0 repair-on-run: old builds treated Telethon's plain ValueError
        # `No user has "..." as username` as transient. Convert those rows to
        # definitive expired results and release account circuit-breakers that
        # were triggered by this URL-level condition.
        dead_username_pattern = 'No user has "%" as username%'
        await session.execute(
            update(TelegramAuditResult)
            .where(
                TelegramAuditResult.audit_id == audit_id,
                TelegramAuditResult.status.in_(["temporary_error", "error"]),
                TelegramAuditResult.detail.ilike(dead_username_pattern),
            )
            .values(status="expired", error_class="Permanent", next_retry_at=None)
        )
        await session.execute(
            update(Account)
            .where(
                Account.active.is_(True),
                Account.health_status.in_(["cooldown", "slow"]),
                Account.last_error.ilike(dead_username_pattern),
            )
            .values(
                health_status="healthy",
                consecutive_errors=0,
                flood_wait_until=None,
                updated_at=now,
            )
        )
        await session.commit()

    source_counters: dict[str, int] = {}
    if audit.source_type == "sources" and job.sources:
        async with SessionFactory() as session:
            await session.execute(
                update(TelegramAudit).where(TelegramAudit.id == audit_id).values(
                    current_phase="collecting_sources", updated_at=utcnow()
                )
            )
            await session.commit()
        source_counters = await _collect_sources_into_audit(audit_id, job, all_clients)

    account_labels = {
        account_id: (
            manager.account_records.get(account_id).label
            if manager.account_records.get(account_id)
            else f"حساب {account_id}"
        )
        for account_id, _client in all_clients
    }
    active_ids = {account_id for account_id, _client in all_clients}
    from app.services.audit_roles import get_verifier_account_ids
    verifier_ids = await get_verifier_account_ids(int(job.requested_by))
    primary_ids = active_ids - verifier_ids
    if not primary_ids:
        raise RuntimeError("يجب توفر حساب أساسي فعال واحد على الأقل.")
    membership_index, membership_stats = await _build_membership_index(manager, job.id, primary_ids, force_refresh=True)

    async with SessionFactory() as session:
        total_inputs = int(
            await session.scalar(
                select(func.count(TelegramAuditInput.id)).where(TelegramAuditInput.audit_id == audit_id)
            ) or 0
        )
        status_rows = (
            await session.execute(
                select(TelegramAuditResult.status, func.count(TelegramAuditResult.id))
                .where(TelegramAuditResult.audit_id == audit_id)
                .group_by(TelegramAuditResult.status)
            )
        ).all()
        whatsapp_count = int(
            await session.scalar(
                select(func.count(TelegramAuditWhatsapp.id)).where(TelegramAuditWhatsapp.audit_id == audit_id)
            ) or 0
        )
        telegram_discovery_count = int(
            await session.scalar(
                select(func.count(TelegramAuditTelegramDiscovery.id)).where(
                    TelegramAuditTelegramDiscovery.audit_id == audit_id
                )
            ) or 0
        )
        await session.execute(
            update(TelegramAudit).where(TelegramAudit.id == audit_id).values(
                total_inputs=total_inputs, current_phase="auditing", updated_at=utcnow()
            )
        )
        await session.commit()

    group_size = max(1, int(settings.audit_account_group_size))
    per_account = max(1, int(settings.audit_links_per_account_cycle))
    rest_seconds = max(0.0, float(settings.audit_group_rest_seconds))
    cohorts = [all_clients[i:i + group_size] for i in range(0, len(all_clients), group_size)]
    wave_capacity = max(1, len(all_clients) * per_account)

    counters: dict[str, Any] = {
        "audit_id": audit_id,
        "total": total_inputs,
        "checked": sum(int(count) for _status, count in status_rows),
        **{status: 0 for status in AUDIT_STATUS_LABELS},
        "options": options,
        "active_accounts": len(all_clients),
        "account_group_size": group_size,
        "links_per_account_cycle": per_account,
        "group_rest_seconds": rest_seconds,
        "account_groups": len(cohorts),
        "wave_capacity": wave_capacity,
        "waves_completed": int((audit.summary or {}).get("waves_completed", 0)),
        "whatsapp_links": whatsapp_count,
        "whatsapp_chats_scanned": int((audit.summary or {}).get("whatsapp_chats_scanned", 0)),
        "whatsapp_chats_unavailable": int((audit.summary or {}).get("whatsapp_chats_unavailable", 0)),
        "whatsapp_scan_errors": int((audit.summary or {}).get("whatsapp_scan_errors", 0)),
        "telegram_discovered_links": telegram_discovery_count,
        "telegram_chats_scanned": int((audit.summary or {}).get("telegram_chats_scanned", 0)),
        "telegram_chats_unavailable": int((audit.summary or {}).get("telegram_chats_unavailable", 0)),
        "telegram_scan_errors": int((audit.summary or {}).get("telegram_scan_errors", 0)),
        "telegram_floodwait_deferrals": int((audit.summary or {}).get("telegram_floodwait_deferrals", 0)),
        "telegram_duplicates_skipped": int((audit.summary or {}).get("telegram_duplicates_skipped", 0)),
        "current_phase": "auditing",
        "account_report": {
            str(account_id): {"label": account_labels[account_id], "role": "audit", "checked_in_run": 0}
            for account_id, _client in all_clients
        },
        **source_counters,
    }
    for status, count in status_rows:
        counters[str(status)] = int(count)

    collect_whatsapp = bool(options.get("collect_whatsapp", False))
    whatsapp_scope = str(options.get("whatsapp_scope") or settings.whatsapp_default_scope)
    whatsapp_scanned: set[str] = set()
    whatsapp_scan_lock = asyncio.Lock()
    whatsapp_worker_semaphore = asyncio.Semaphore(max(1, int(settings.audit_whatsapp_workers)))
    whatsapp_account_locks: dict[int, asyncio.Lock] = {}

    # Link validation and recursive history collection are separate operations.
    # V7 forced a full-history crawl for every account audit, which made a simple
    # validity check unexpectedly slow.  V8 runs discovery only when the user
    # selected it and honors the requested time scope.
    collect_telegram = bool(options.get("collect_telegram", False))
    telegram_scope = str(options.get("telegram_scope") or settings.telegram_discovery_default_scope)
    options["collect_telegram"] = collect_telegram
    options["telegram_scope"] = telegram_scope if collect_telegram else "none"
    options["telegram_auto_full_history"] = False
    options["telegram_discovered_links_are_not_audited_in_same_job"] = True
    telegram_scanned: set[str] = set()
    # V6.2.9: distinguish durable/history bookkeeping from tasks that are
    # actually alive right now.  Resume must never recreate the same cursor
    # while its runner is already active.
    telegram_active_scan_keys: set[str] = set()
    telegram_scan_lock = asyncio.Lock()
    telegram_discovery_db_lock = asyncio.Lock()
    telegram_worker_semaphore = asyncio.Semaphore(max(1, int(settings.audit_telegram_workers)))
    telegram_account_locks: dict[int, asyncio.Lock] = {}

    # V6.2.4: resolving a public t.me/<username> normally reaches
    # contacts.resolveUsername, which has a materially different rate-limit
    # profile from messages.checkChatInvite used by t.me/+<hash>.  Keep method
    # cooldowns separate so a FloodWait on public-name resolution does not
    # incorrectly poison invite-link checks for the same account.
    public_resolve_locks: dict[int, asyncio.Lock] = {}
    public_resolve_cooldowns: dict[int, float] = {}
    invite_check_cooldowns: dict[int, float] = {}

    def method_cooldown_remaining(bucket: dict[int, float], account_id: int) -> float:
        remaining = float(bucket.get(account_id, 0.0)) - time.monotonic()
        if remaining <= 0:
            bucket.pop(account_id, None)
            return 0.0
        return remaining

    background_tasks: set[asyncio.Task[Any]] = set()
    background_errors: list[BaseException] = []

    def track_background(task: asyncio.Task[Any]) -> None:
        background_tasks.add(task)

        def done_callback(done: asyncio.Task[Any]) -> None:
            background_tasks.discard(done)
            try:
                exc = done.exception()
            except asyncio.CancelledError as exc:
                background_errors.append(exc)
                return
            if exc is not None:
                background_errors.append(exc)

        task.add_done_callback(done_callback)

    started_clock = time.monotonic()
    starting_checked = int(counters.get("checked", 0) or 0)

    async def refresh_counts() -> None:
        async with SessionFactory() as session:
            rows = (
                await session.execute(
                    select(TelegramAuditResult.status, func.count(TelegramAuditResult.id))
                    .where(TelegramAuditResult.audit_id == audit_id)
                    .group_by(TelegramAuditResult.status)
                )
            ).all()
            wa_count = int(
                await session.scalar(
                    select(func.count(TelegramAuditWhatsapp.id)).where(TelegramAuditWhatsapp.audit_id == audit_id)
                ) or 0
            )
            tg_count = int(
                await session.scalar(
                    select(func.count(TelegramAuditTelegramDiscovery.id)).where(
                        TelegramAuditTelegramDiscovery.audit_id == audit_id
                    )
                ) or 0
            )
        for status in AUDIT_STATUS_LABELS:
            counters[status] = 0
        counters["checked"] = 0
        for status, count in rows:
            counters[str(status)] = int(count)
            counters["checked"] += int(count)
        counters["whatsapp_links"] = wa_count
        counters["telegram_discovered_links"] = tg_count
        elapsed = max(0.001, time.monotonic() - started_clock)
        delta = max(0, int(counters["checked"]) - starting_checked)
        rate = delta / elapsed
        counters["elapsed_seconds"] = round(elapsed, 1)
        counters["links_per_minute"] = round(rate * 60.0, 2)
        remaining = max(0, int(counters["total"]) - int(counters["checked"]))
        counters["eta_seconds"] = round(remaining / rate, 1) if rate > 0 else None

    async def cache_get(url: str) -> dict[str, Any] | None:
        if not settings.audit_use_resolution_cache:
            return None
        async with SessionFactory() as session:
            row = await session.get(TelegramResolutionCache, url)
            if not row:
                return None
            now = utcnow()
            expiry = row.expires_at
            if expiry is not None and expiry.tzinfo is None:
                expiry = expiry.replace(tzinfo=timezone.utc)
            if expiry is not None and expiry <= now:
                return None
            return {
                "status": row.status, "peer_id": row.peer_id, "peer_type": row.peer_type,
                "title": row.title, "username": row.username, "account_ids": [], "account_labels": [],
                "detail": (row.detail or "") + " [cache]", "error_class": row.error_class,
                "_cache": True,
            }

    async def cache_put(url: str, result: dict[str, Any]) -> None:
        status = str(result.get("status") or "")
        if status in {"temporary_error", "error", "restricted_access", "unsupported"}:
            return
        hours = settings.audit_cache_expired_hours if status == "expired" else settings.audit_cache_valid_hours
        expires = utcnow() + timedelta(hours=max(1, int(hours)))
        async with SessionFactory() as session:
            await session.execute(
                insert(TelegramResolutionCache).values(
                    normalized_url=url, status=status, peer_id=result.get("peer_id"),
                    peer_type=result.get("peer_type"), title=result.get("title"), username=result.get("username"),
                    detail=result.get("detail"), error_class=result.get("error_class"),
                    checked_at=utcnow(), expires_at=expires,
                ).on_conflict_do_update(
                    index_elements=[TelegramResolutionCache.normalized_url],
                    set_={
                        "status": status, "peer_id": result.get("peer_id"), "peer_type": result.get("peer_type"),
                        "title": result.get("title"), "username": result.get("username"),
                        "detail": result.get("detail"), "error_class": result.get("error_class"),
                        "checked_at": utcnow(), "expires_at": expires,
                    },
                )
            )
            await session.commit()

    async def single_check(url: str, account_id: int, client: Any) -> dict[str, Any]:
        cached = await cache_get(url)
        if cached is not None:
            return cached
        request_kind = "other"
        try:
            if INVITE_RE.fullmatch(url):
                request_kind = "invite"
                invite_hash = INVITE_RE.fullmatch(url).group(1)  # type: ignore[union-attr]
                invite_wait = method_cooldown_remaining(invite_check_cooldowns, account_id)
                if invite_wait > 0:
                    return {
                        "status": "temporary_error", "peer_id": None, "peer_type": None, "title": None, "username": None,
                        "account_ids": [], "account_labels": [],
                        "detail": f"Invite-check cooldown {invite_wait:.1f}s — deferred",
                        "error_class": "FloodWait", "_account_id": account_id,
                        "_retry_after_seconds": invite_wait, "_no_attempt_penalty": True, "_defer": True,
                    }
                result = await client(CheckChatInviteRequest(invite_hash))
                await _mark_account_success(account_id)
                if isinstance(result, ChatInviteAlready):
                    entity = result.chat
                    peer_id = int(get_peer_id(entity))
                    payload = {
                        "status": "joined_unique", "peer_id": peer_id, "peer_type": _peer_type(entity),
                        "title": _entity_title(entity), "username": getattr(entity, "username", None),
                        "account_ids": [account_id], "account_labels": [account_labels[account_id]],
                        "detail": "الرابط صالح والحساب المستخدم عضو بالفعل.",
                        "_client": client, "_account_id": account_id, "_entity": entity,
                    }
                elif isinstance(result, ChatInvitePeek):
                    entity = result.chat
                    payload = {
                        "status": "join_request" if bool(getattr(entity, "join_request", False)) else "unjoined",
                        "peer_id": int(get_peer_id(entity)), "peer_type": _peer_type(entity),
                        "title": _entity_title(entity), "username": getattr(entity, "username", None),
                        "account_ids": [], "account_labels": [],
                        "detail": "الرابط صالح ويمكن معاينته دون انضمام.",
                        "_client": client, "_account_id": account_id, "_entity": entity,
                    }
                elif isinstance(result, ChatInvite):
                    payload = {
                        "status": "join_request" if bool(getattr(result, "request_needed", False)) else "unjoined",
                        "peer_id": None,
                        "peer_type": "channel" if bool(getattr(result, "broadcast", False)) else "group",
                        "title": getattr(result, "title", None), "username": None,
                        "account_ids": [], "account_labels": [],
                        "detail": "رابط دعوة صالح." if not bool(getattr(result, "request_needed", False)) else "الرابط صالح ويتطلب طلب انضمام.",
                        "_account_id": account_id,
                    }
                else:
                    payload = {
                        "status": "unjoined", "peer_id": None, "peer_type": None, "title": None, "username": None,
                        "account_ids": [], "account_labels": [], "detail": "رابط دعوة صالح.", "_account_id": account_id,
                    }
            elif PUBLIC_RE.fullmatch(url):
                request_kind = "public"
                username = PUBLIC_RE.fullmatch(url).group(1)  # type: ignore[union-attr]
                if username.lower() in RESERVED_PUBLIC_PATHS:
                    return {
                        "status": "unsupported", "peer_id": None, "peer_type": None, "title": None,
                        "username": username, "account_ids": [], "account_labels": [],
                        "detail": "مسار Telegram خدمي وليس مجموعة/قناة.", "error_class": "Permanent",
                    }
                # Public usernames are intentionally serialized per account.
                # Four audit links may still belong to the same account/wave, but
                # they must not fire four ResolveUsername requests simultaneously.
                public_lock = public_resolve_locks.setdefault(account_id, asyncio.Lock())
                async with public_lock:
                    memory_wait = method_cooldown_remaining(public_resolve_cooldowns, account_id)
                    durable_wait, _durable_until = await _telegram_account_method_cooldown_remaining(
                        job.id, audit_id, account_id, "ResolveUsername"
                    )
                    public_wait = max(memory_wait, durable_wait)
                    if public_wait > 0:
                        counters["resolve_username_account_cooldown_skips"] = int(
                            counters.get("resolve_username_account_cooldown_skips", 0)
                        ) + 1
                        return {
                            "status": "temporary_error", "peer_id": None, "peer_type": None, "title": None, "username": username,
                            "account_ids": [], "account_labels": [],
                            "detail": f"ResolveUsername account cooldown {public_wait:.1f}s — API request skipped",
                            "error_class": "FloodWait", "_account_id": account_id,
                            "_retry_after_seconds": public_wait, "_no_attempt_penalty": True, "_defer": True,
                        }
                    entity = await client.get_entity("@" + username)
                    # Keep public-name requests serialized and gently spaced. The
                    # fixed 120-second wave rest still remains unchanged.
                    min_interval = max(0.0, float(settings.audit_public_resolve_min_interval_seconds))
                    if min_interval > 0:
                        await asyncio.sleep(min_interval)
                await _mark_account_success(account_id)
                peer_type = _peer_type(entity)
                if isinstance(entity, User):
                    payload = {
                        "status": "bot" if bool(getattr(entity, "bot", False)) else "personal",
                        "peer_id": int(get_peer_id(entity)), "peer_type": peer_type, "title": _entity_title(entity),
                        "username": getattr(entity, "username", username), "account_ids": [], "account_labels": [],
                        "detail": "الرابط يعود إلى مستخدم/بوت وليس مجموعة أو قناة.", "_account_id": account_id,
                    }
                else:
                    joined = getattr(entity, "left", True) is False
                    payload = {
                        "status": "joined_unique" if joined else "unjoined",
                        "peer_id": int(get_peer_id(entity)), "peer_type": peer_type, "title": _entity_title(entity),
                        "username": getattr(entity, "username", username),
                        "account_ids": [account_id] if joined else [],
                        "account_labels": [account_labels[account_id]] if joined else [],
                        "detail": "الرابط صالح.", "_client": client, "_account_id": account_id, "_entity": entity,
                    }
            else:
                return {
                    "status": "unsupported", "peer_id": None, "peer_type": None, "title": None, "username": None,
                    "account_ids": [], "account_labels": [],
                    "detail": "صيغة رابط Telegram غير مدعومة كوجهة مجموعة/قناة.", "error_class": "Permanent",
                }
            await cache_put(url, payload)
            return payload
        except FloodWaitError as exc:
            wait_seconds = max(1.0, float(exc.seconds)) + max(0.0, float(settings.audit_floodwait_safety_seconds))
            cooldown_until = time.monotonic() + wait_seconds
            if request_kind == "public":
                public_resolve_cooldowns[account_id] = max(public_resolve_cooldowns.get(account_id, 0.0), cooldown_until)
                await _telegram_account_method_cooldown_set(
                    job.id, audit_id, account_id, "ResolveUsername", wait_seconds
                )
            elif request_kind == "invite":
                invite_check_cooldowns[account_id] = max(invite_check_cooldowns.get(account_id, 0.0), cooldown_until)
            await _mark_account_error(account_id, exc, flood_seconds=int(exc.seconds))
            return {
                "status": "temporary_error", "peer_id": None, "peer_type": None, "title": None, "username": None,
                "account_ids": [], "account_labels": [],
                "detail": f"FloodWait {exc.seconds}s — deferred; URL validity not judged",
                "error_class": "FloodWait", "_account_id": account_id,
                "_retry_after_seconds": wait_seconds,
                "_no_attempt_penalty": True,
                "_defer": True,
            }
        except RPCError as exc:
            if _is_dead_link_error(exc):
                # A dead response is definitive in the user's audit model: save it immediately.
                await _mark_account_success(account_id)
                payload = {
                    "status": "expired", "peer_id": None, "peer_type": None, "title": None, "username": None,
                    "account_ids": [], "account_labels": [], "detail": _rpc_code(exc)[:1000],
                    "error_class": "Permanent", "_account_id": account_id,
                }
                await cache_put(url, payload)
                return payload
            if _is_access_restriction_error(exc):
                await _mark_account_success(account_id)
                return {
                    "status": "restricted_access", "peer_id": None, "peer_type": None, "title": None, "username": None,
                    "account_ids": [], "account_labels": [], "detail": _rpc_code(exc)[:1000],
                    "error_class": "AccessDenied", "_account_id": account_id,
                }
            await _mark_account_error(account_id, exc)
            return {
                "status": "temporary_error", "peer_id": None, "peer_type": None, "title": None, "username": None,
                "account_ids": [], "account_labels": [], "detail": str(exc)[:1000],
                "error_class": exc.__class__.__name__, "_account_id": account_id,
            }
        except Exception as exc:
            if _is_dead_link_error(exc):
                await _mark_account_success(account_id)
                payload = {
                    "status": "expired", "peer_id": None, "peer_type": None, "title": None, "username": None,
                    "account_ids": [], "account_labels": [], "detail": _rpc_code(exc)[:1000],
                    "error_class": "Permanent", "_account_id": account_id,
                }
                await cache_put(url, payload)
                return payload
            await _mark_account_error(account_id, exc)
            return {
                "status": "temporary_error", "peer_id": None, "peer_type": None, "title": None, "username": None,
                "account_ids": [], "account_labels": [], "detail": str(exc)[:1000],
                "error_class": exc.__class__.__name__, "_account_id": account_id,
            }

    async def save_result(item: TelegramAuditInput, previous: TelegramAuditResult | None, result: dict[str, Any]) -> None:
        persisted = {key: value for key, value in result.items() if not key.startswith("_")}
        peer_id = persisted.get("peer_id")
        if peer_id is not None and persisted.get("status") in {"joined_unique", "joined_duplicate", "unjoined", "join_request"}:
            info = membership_index.get(int(peer_id))
            ids = set(info.account_ids) if info else set()
            ids.update(set(persisted.get("account_ids") or []) & primary_ids)
            persisted["account_ids"] = sorted(ids)
            persisted["account_labels"] = [account_labels[aid] for aid in sorted(ids)]
            if ids:
                persisted["status"] = "joined_duplicate" if len(ids) > 1 else "joined_unique"
            elif persisted.get("status") in {"joined_unique", "joined_duplicate"}:
                persisted["status"] = "unjoined"
        no_attempt_penalty = bool(result.get("_no_attempt_penalty", False))
        previous_attempts = int(previous.attempt_count or 0) if previous else 0
        attempt_count = previous_attempts if no_attempt_penalty else previous_attempts + 1
        status = str(persisted.get("status") or "temporary_error")

        # A Telegram FloodWait is a server pacing instruction, not evidence that
        # the URL is dead. It therefore never consumes the link's retry budget and
        # can never be promoted to the final-error bucket merely by repetition.
        if status == "temporary_error" and not no_attempt_penalty and attempt_count >= max(1, settings.audit_retry_max_attempts):
            status = "error"
            persisted["error_class"] = persisted.get("error_class") or "TransientExhausted"
        backoff = min(
            settings.audit_retry_max_seconds,
            settings.audit_retry_base_seconds * (2 ** max(0, attempt_count - 1)),
        )
        retry_after = max(0.0, float(result.get("_retry_after_seconds", 0.0) or 0.0))
        retry_delay = max(float(backoff), retry_after)
        next_retry_at = utcnow() + timedelta(seconds=retry_delay) if status == "temporary_error" else None
        now = utcnow()
        access_account_id = result.get("_account_id")
        async with SessionFactory() as session:
            stmt = insert(TelegramAuditResult).values(
                audit_id=audit_id, input_id=item.id, normalized_url=item.normalized_url,
                status=status, peer_id=persisted.get("peer_id"), peer_type=persisted.get("peer_type"),
                title=persisted.get("title"), username=persisted.get("username"),
                account_ids=persisted.get("account_ids") or [], account_labels=persisted.get("account_labels") or [],
                detail=persisted.get("detail"), error_class=persisted.get("error_class"),
                attempt_count=attempt_count, next_retry_at=next_retry_at, checked_at=now,
            ).on_conflict_do_update(
                index_elements=[TelegramAuditResult.audit_id, TelegramAuditResult.input_id],
                set_={
                    "status": status, "peer_id": persisted.get("peer_id"), "peer_type": persisted.get("peer_type"),
                    "title": persisted.get("title"), "username": persisted.get("username"),
                    "account_ids": persisted.get("account_ids") or [], "account_labels": persisted.get("account_labels") or [],
                    "detail": persisted.get("detail"), "error_class": persisted.get("error_class"),
                    "attempt_count": attempt_count, "next_retry_at": next_retry_at, "checked_at": now,
                },
            )
            await session.execute(stmt)
            audit_row = await session.get(TelegramAudit, audit_id)
            if audit_row:
                audit_row.last_processed_input_id = max(int(audit_row.last_processed_input_id or 0), int(item.id))
                audit_row.current_account_id = int(access_account_id) if access_account_id is not None else None
                audit_row.current_phase = "auditing"
                audit_row.updated_at = now

            peer_id = persisted.get("peer_id")
            if peer_id is not None:
                await session.execute(
                    insert(TelegramPeer).values(
                        peer_id=int(peer_id), peer_type=persisted.get("peer_type"), title=persisted.get("title"),
                        username=persisted.get("username"), first_seen_at=now, last_seen_at=now,
                    ).on_conflict_do_update(
                        index_elements=[TelegramPeer.peer_id],
                        set_={"peer_type": persisted.get("peer_type"), "title": persisted.get("title"),
                              "username": persisted.get("username"), "last_seen_at": now},
                    )
                )
                await session.execute(
                    insert(TelegramPeerAlias).values(
                        peer_id=int(peer_id), normalized_url=item.normalized_url,
                        first_seen_at=now, last_seen_at=now,
                    ).on_conflict_do_update(
                        index_elements=[TelegramPeerAlias.normalized_url],
                        set_={"peer_id": int(peer_id), "last_seen_at": now},
                    )
                )
            await session.commit()

        if access_account_id is not None:
            report = counters.get("account_report", {}).get(str(access_account_id))
            if isinstance(report, dict):
                report["checked_in_run"] = int(report.get("checked_in_run", 0)) + 1

    async def schedule_telegram_discovery(
        *, source_url: str, account_id: int, entity: Any | None, peer_id: int | None, input_id: int | None = None
    ) -> None:
        if not collect_telegram:
            return
        scan_key = f"peer:{peer_id}" if peer_id is not None else f"input:{input_id or source_url}"
        cursor_key = f"audit_tg:{audit_id}:{scan_key}"
        async with telegram_scan_lock:
            if scan_key in telegram_active_scan_keys:
                return
            if scan_key in telegram_scanned:
                return
            cursor = await _audit_cursor_get(job.id, cursor_key)
            if cursor is not None and cursor.status == "completed":
                telegram_scanned.add(scan_key)
                return
            telegram_scanned.add(scan_key)
            # Preserve a durable FloodWait deadline across restart/resume. Do not
            # overwrite a future deferred_until merely because the scheduler has
            # recreated the background task.
            if cursor is not None and cursor.status == "deferred" and _telegram_discovery_deferred_seconds(cursor.detail) > 0:
                detail = cursor.detail
                cursor_status = "deferred"
            else:
                detail = _telegram_discovery_detail(source_url, int(account_id))
                cursor_status = "pending"
            await _audit_cursor_save(
                job.id, cursor_key, offset_id=int(cursor.offset_id or 0) if cursor else 0,
                status=cursor_status, detail=detail,
            )

        async def runner() -> None:
            from app.services.scanner import resolve_source_entity

            account_lock = telegram_account_locks.setdefault(int(account_id), asyncio.Lock())
            live_entity = entity

            while True:
                await _ensure_job_active(job.id)
                current_cursor = await _audit_cursor_get(job.id, cursor_key)
                deferred_remaining = _telegram_discovery_deferred_seconds(
                    current_cursor.detail if current_cursor is not None else None
                )
                if deferred_remaining > 0:
                    # V6.2.7: a future durable cursor is parked in SQLite, not
                    # kept alive as a sleeping asyncio task.  Thousands of
                    # long-lived sleepers used to wake every five seconds and
                    # starve the audit loop / SQLite writer.
                    logger.debug(
                        "Telegram discovery cursor parked url=%s wait=%.1fs",
                        source_url, deferred_remaining,
                    )
                    return

                # V6.2.6: a ResolveUsername FloodWait belongs to the ACCOUNT +
                # METHOD, not to one URL.  If this source still requires public
                # name resolution and the account is cooling down, do not send
                # another ResolveUsername request.  Sleep outside all locks so
                # invite-link and cached-peer discovery can continue.
                needs_public_resolution = (
                    live_entity is None and peer_id is None and PUBLIC_RE.fullmatch(source_url) is not None
                )
                if needs_public_resolution:
                    account_wait, account_until = await _telegram_account_method_cooldown_remaining(
                        job.id, audit_id, int(account_id), "ResolveUsername"
                    )
                    if account_wait > 0:
                        await _audit_cursor_save(
                            job.id, cursor_key,
                            offset_id=int(current_cursor.offset_id or 0) if current_cursor else 0,
                            status="deferred",
                            detail=_telegram_discovery_detail(
                                source_url, int(account_id), deferred_until=account_until,
                                reason="account ResolveUsername cooldown", method="ResolveUsername",
                            ),
                        )
                        counters["telegram_account_resolve_cooldown_skips"] = int(
                            counters.get("telegram_account_resolve_cooldown_skips", 0)
                        ) + 1
                        logger.info(
                            "Telegram discovery account ResolveUsername cooldown account=%s url=%s wait=%.1fs; cursor parked, API request skipped",
                            account_id, source_url, account_wait,
                        )
                        return

                try:
                    # Locks cover only the active Telegram request work. A long
                    # FloodWait is slept *outside* both locks so the same account
                    # and the global discovery worker pool remain available.
                    async with account_lock:
                        async with telegram_worker_semaphore:
                            live_client = await manager.ensure_connected(int(account_id))
                            if live_entity is None:
                                # Restart/resume fast path: the audit already knew
                                # the peer id. Telethon persists entity/access-hash
                                # information in the session, so use that cache
                                # before ever touching contacts.resolveUsername.
                                if peer_id is not None:
                                    try:
                                        live_entity = await live_client.get_input_entity(int(peer_id))
                                        logger.info(
                                            "Telegram discovery resumed from cached peer_id=%s url=%s",
                                            peer_id, source_url,
                                        )
                                    except (ValueError, TypeError, KeyError):
                                        live_entity = None
                                if live_entity is None:
                                    # Re-check under the per-account lock.  Another
                                    # source may have just triggered FloodWait while
                                    # this task was waiting for the lock.
                                    if PUBLIC_RE.fullmatch(source_url) is not None:
                                        account_wait, account_until = await _telegram_account_method_cooldown_remaining(
                                            job.id, audit_id, int(account_id), "ResolveUsername"
                                        )
                                        if account_wait > 0:
                                            current_cursor = await _audit_cursor_get(job.id, cursor_key)
                                            await _audit_cursor_save(
                                                job.id, cursor_key,
                                                offset_id=int(current_cursor.offset_id or 0) if current_cursor else 0,
                                                status="deferred",
                                                detail=_telegram_discovery_detail(
                                                    source_url, int(account_id), deferred_until=account_until,
                                                    reason="account ResolveUsername cooldown", method="ResolveUsername",
                                                ),
                                            )
                                            raise TelegramDiscoveryDeferred(
                                                account_wait, method="ResolveUsernameAccountCooldown",
                                                detail=f"ResolveUsername account cooldown {account_wait:.1f}s",
                                            )
                                    try:
                                        live_entity = await resolve_source_entity(live_client, source_url)
                                    except FloodWaitError as resolve_exc:
                                        method = _telegram_floodwait_method(resolve_exc)
                                        wait_seconds = max(
                                            1.0, float(resolve_exc.seconds) + float(settings.audit_floodwait_safety_seconds)
                                        )
                                        deferred_until = utcnow() + timedelta(seconds=wait_seconds)
                                        if method == "ResolveUsername":
                                            deferred_until = await _telegram_account_method_cooldown_set(
                                                job.id, audit_id, int(account_id), method, wait_seconds
                                            )
                                        current_cursor = await _audit_cursor_get(job.id, cursor_key)
                                        await _audit_cursor_save(
                                            job.id, cursor_key,
                                            offset_id=int(current_cursor.offset_id or 0) if current_cursor else 0,
                                            status="deferred",
                                            detail=_telegram_discovery_detail(
                                                source_url, int(account_id), deferred_until=deferred_until,
                                                reason=f"FloodWait {resolve_exc.seconds}s", method=method,
                                            ),
                                        )
                                        raise TelegramDiscoveryDeferred(
                                            max(1.0, (deferred_until - utcnow()).total_seconds()), method=method,
                                            detail=f"FloodWait {resolve_exc.seconds}s — account method cooldown persisted",
                                        ) from resolve_exc

                            added, _messages, skipped = await _save_telegram_discovered_links(
                                audit_id, source_url, int(account_id), live_entity, live_client, telegram_scope,
                                job.id, telegram_discovery_db_lock, manager=manager, cursor_key=cursor_key,
                            )

                    counters["telegram_discovered_links"] = int(counters.get("telegram_discovered_links", 0)) + int(added)
                    counters["telegram_duplicates_skipped"] = int(counters.get("telegram_duplicates_skipped", 0)) + int(skipped)
                    counters["telegram_chats_scanned"] = int(counters.get("telegram_chats_scanned", 0)) + 1
                    return
                except (JobCancelled, JobPaused):
                    raise
                except TelegramDiscoveryDeferred as exc:
                    counters["telegram_floodwait_deferrals"] = int(
                        counters.get("telegram_floodwait_deferrals", 0)
                    ) + 1
                    # Persist account-level ResolveUsername FloodWait once.  A
                    # synthetic AccountCooldown exception already points at the
                    # durable deadline and must not extend it on every waiter.
                    if exc.method == "ResolveUsername":
                        await _telegram_account_method_cooldown_set(
                            job.id, audit_id, int(account_id), "ResolveUsername", exc.wait_seconds
                        )
                    logger.warning(
                        "Telegram discovery deferred url=%s method=%s wait=%.1fs; cursor parked; not counted as scan error",
                        source_url, exc.method, exc.wait_seconds,
                    )
                    # V6.2.7: do not keep one sleeping task per deferred URL.
                    # The durable cursor remains deferred and the coordinator
                    # reschedules it only when deferred_until becomes due.
                    return
                except FloodWaitError as exc:
                    method = _telegram_floodwait_method(exc)
                    wait_seconds = max(
                        1.0, float(exc.seconds) + float(settings.audit_floodwait_safety_seconds)
                    )
                    deferred_until = utcnow() + timedelta(seconds=wait_seconds)
                    if method == "ResolveUsername":
                        deferred_until = await _telegram_account_method_cooldown_set(
                            job.id, audit_id, int(account_id), method, wait_seconds
                        )
                    current_cursor = await _audit_cursor_get(job.id, cursor_key)
                    await _audit_cursor_save(
                        job.id, cursor_key,
                        offset_id=int(current_cursor.offset_id or 0) if current_cursor else 0,
                        status="deferred",
                        detail=_telegram_discovery_detail(
                            source_url, int(account_id), deferred_until=deferred_until,
                            reason=f"FloodWait {exc.seconds}s", method=method,
                        ),
                    )
                    counters["telegram_floodwait_deferrals"] = int(
                        counters.get("telegram_floodwait_deferrals", 0)
                    ) + 1
                    logger.warning(
                        "Telegram discovery deferred url=%s method=%s wait=%.1fs; cursor parked; not counted as scan error",
                        source_url, method, wait_seconds,
                    )
                    # V6.2.7: persist and return.  A single coordinator wakes
                    # due cursors; no per-URL sleeper survives the FloodWait.
                    return
                except Exception as exc:
                    logger.warning("Telegram discovery scan failed url=%s: %s", source_url, exc)
                    counters["telegram_scan_errors"] = int(counters.get("telegram_scan_errors", 0)) + 1
                    return

        task = asyncio.create_task(runner(), name=f"audit-tg-discovery-{audit_id}-{scan_key}")
        telegram_active_scan_keys.add(scan_key)

        def release_scan_key(_done: asyncio.Task[Any]) -> None:
            telegram_active_scan_keys.discard(scan_key)

        task.add_done_callback(release_scan_key)
        track_background(task)

    async def schedule_whatsapp_discovery(
        *, source_url: str, account_id: int, entity: Any | None, peer_id: int | None, input_id: int | None = None
    ) -> None:
        if not collect_whatsapp:
            return
        scan_key = f"peer:{peer_id}" if peer_id is not None else f"input:{input_id or source_url}"
        cursor_key = f"audit_wa:{audit_id}:{scan_key}"
        async with whatsapp_scan_lock:
            if scan_key in whatsapp_scanned:
                return
            cursor = await _audit_cursor_get(job.id, cursor_key)
            if cursor is not None and cursor.status == "completed":
                whatsapp_scanned.add(scan_key)
                return
            whatsapp_scanned.add(scan_key)
            detail = json.dumps(
                {"source_url": source_url, "account_id": int(account_id), "scope": whatsapp_scope},
                ensure_ascii=False,
            )
            await _audit_cursor_save(
                job.id, cursor_key, offset_id=int(cursor.offset_id or 0) if cursor else 0,
                status="pending", detail=detail,
            )

        async def runner() -> None:
            from app.services.scanner import resolve_source_entity

            account_lock = whatsapp_account_locks.setdefault(int(account_id), asyncio.Lock())
            async with account_lock:
                async with whatsapp_worker_semaphore:
                    try:
                        live_client = await manager.ensure_connected(int(account_id))
                        live_entity = entity
                        if live_entity is None:
                            live_entity = await resolve_source_entity(live_client, source_url)
                        added, _messages = await _save_whatsapp_links(
                            audit_id, source_url, int(account_id), live_entity, live_client, whatsapp_scope, job.id,
                            manager=manager, cursor_key=cursor_key,
                        )
                        counters["whatsapp_links"] = int(counters.get("whatsapp_links", 0)) + int(added)
                        counters["whatsapp_chats_scanned"] = int(counters.get("whatsapp_chats_scanned", 0)) + 1
                    except (JobCancelled, JobPaused):
                        raise
                    except Exception as exc:
                        logger.warning("WhatsApp audit scan failed url=%s: %s", source_url, exc)
                        counters["whatsapp_scan_errors"] = int(counters.get("whatsapp_scan_errors", 0)) + 1

        track_background(asyncio.create_task(runner(), name=f"audit-wa-discovery-{audit_id}-{scan_key}"))

    async def resume_discovery_cursors() -> None:
        """Resume durable discovery cursors without blocking the audit loop.

        V6.2.9 fixes two restart/resume amplification paths:
        1) old deferred source cursors used to perform one DB cooldown write per
           cursor (thousands of writes before the audit heartbeat could move);
        2) when many cursors became due together, all of them could be spawned
           as asyncio tasks at once even though only a small worker semaphore
           could run concurrently.

        We now aggregate inherited ResolveUsername cooldowns once per account,
        keep heartbeat/progress alive while scanning the cursor list, and start
        only a bounded number of ready Telegram discovery runners per pass.
        """
        async with SessionFactory() as session:
            rows = list((await session.scalars(
                select(JobCursor).where(
                    JobCursor.job_id == job.id,
                    or_(
                        JobCursor.cursor_key.like(f"audit_tg:{audit_id}:%"),
                        JobCursor.cursor_key.like(f"audit_wa:{audit_id}:%"),
                    ),
                    JobCursor.status != "completed",
                )
            )).all())

        # First pass is pure in-memory aggregation.  Persist at most one
        # inherited ResolveUsername deadline per account instead of one write
        # for every deferred source cursor.
        inherited_by_account: dict[int, float] = {}
        parsed_rows: list[tuple[JobCursor, dict[str, Any], str, int]] = []
        for index, cursor in enumerate(rows, start=1):
            try:
                data = json.loads(cursor.detail or "{}")
                source_url = str(data.get("source_url") or "").strip()
                account_id = int(data.get("account_id"))
            except Exception:
                continue
            if not source_url:
                continue
            parsed_rows.append((cursor, data, source_url, account_id))
            if (
                cursor.cursor_key.startswith(f"audit_tg:{audit_id}:")
                and str(data.get("defer_method") or "") == "ResolveUsername"
            ):
                inherited_wait = _telegram_discovery_deferred_seconds(cursor.detail)
                if inherited_wait > 0:
                    inherited_by_account[account_id] = max(
                        float(inherited_by_account.get(account_id, 0.0)), float(inherited_wait)
                    )
            if index % 500 == 0:
                counters["discovery_resume_cursors_seen"] = index
                counters["current_phase"] = "resuming_discovery_cursors"
                await _set_job_progress(job.id, dict(counters))
                await asyncio.sleep(0)

        for index, (account_id, inherited_wait) in enumerate(inherited_by_account.items(), start=1):
            if account_id not in allowed_account_ids:
                continue
            await _telegram_account_method_cooldown_set(
                job.id, audit_id, int(account_id), "ResolveUsername", float(inherited_wait)
            )
            logger.info(
                "Inherited ResolveUsername account cooldown from discovery cursor aggregate account=%s wait=%.1fs",
                account_id, inherited_wait,
            )
            if index % 10 == 0:
                counters["discovery_resume_cooldowns_seeded"] = index
                await _set_job_progress(job.id, dict(counters))

        # Never spawn more ready discovery work than a small multiple of the
        # actual Telegram worker count. Subsequent audit/coordinator passes pick
        # up the next batch.
        tg_schedule_budget = max(1, int(settings.audit_telegram_workers))
        tg_scheduled = 0

        for index, (cursor, data, source_url, account_id) in enumerate(parsed_rows, start=1):
            if account_id not in allowed_account_ids:
                available_ids = sorted(allowed_account_ids)
                if not available_ids:
                    continue
                logger.warning(
                    "Discovery cursor account %s unavailable; reassigning source=%s to account=%s",
                    account_id, source_url, available_ids[0],
                )
                account_id = available_ids[0]

            if collect_telegram and cursor.cursor_key.startswith(f"audit_tg:{audit_id}:"):
                cursor_wait = _telegram_discovery_deferred_seconds(cursor.detail)
                if cursor_wait > 0:
                    counters["telegram_deferred_cursors_parked"] = int(
                        counters.get("telegram_deferred_cursors_parked", 0)
                    ) + 1
                    continue
                if tg_scheduled >= tg_schedule_budget:
                    continue
                scan_key = cursor.cursor_key.split(f"audit_tg:{audit_id}:", 1)[1]
                if scan_key in telegram_active_scan_keys:
                    continue
                telegram_scanned.discard(scan_key)
                peer_value = int(scan_key.split(":", 1)[1]) if scan_key.startswith("peer:") else None
                input_value = int(scan_key.split(":", 1)[1]) if scan_key.startswith("input:") and scan_key.split(":", 1)[1].isdigit() else None
                await schedule_telegram_discovery(
                    source_url=source_url, account_id=account_id, entity=None, peer_id=peer_value,
                    input_id=input_value,
                )
                tg_scheduled += 1
            elif collect_whatsapp and cursor.cursor_key.startswith(f"audit_wa:{audit_id}:"):
                scan_key = cursor.cursor_key.split(f"audit_wa:{audit_id}:", 1)[1]
                whatsapp_scanned.discard(scan_key)
                peer_value = int(scan_key.split(":", 1)[1]) if scan_key.startswith("peer:") else None
                input_value = int(scan_key.split(":", 1)[1]) if scan_key.startswith("input:") and scan_key.split(":", 1)[1].isdigit() else None
                await schedule_whatsapp_discovery(
                    source_url=source_url, account_id=account_id, entity=None, peer_id=peer_value,
                    input_id=input_value,
                )

            if index % 500 == 0:
                counters["discovery_resume_cursors_seen"] = index
                counters["discovery_resume_tg_scheduled"] = tg_scheduled
                counters["current_phase"] = "resuming_discovery_cursors"
                await _set_job_progress(job.id, dict(counters))
                await asyncio.sleep(0)

        counters["discovery_resume_cursors_seen"] = len(parsed_rows)
        counters["discovery_resume_tg_scheduled"] = tg_scheduled

    async def telegram_discovery_pending_state() -> tuple[int, float | None]:
        """Return (remaining cursors, seconds until earliest deferred cursor).

        Ready/pending cursors report a zero-second wakeup.  This lets one
        coordinator park efficiently without spawning thousands of sleepers.
        """
        async with SessionFactory() as session:
            rows = list((await session.scalars(
                select(JobCursor).where(
                    JobCursor.job_id == job.id,
                    JobCursor.cursor_key.like(f"audit_tg:{audit_id}:%"),
                    JobCursor.status != "completed",
                )
            )).all())
        if not rows:
            return 0, None
        waits: list[float] = []
        for cursor in rows:
            wait = _telegram_discovery_deferred_seconds(cursor.detail)
            if cursor.status != "deferred" or wait <= 0:
                return len(rows), 0.0
            waits.append(wait)
        return len(rows), min(waits) if waits else 0.0

    async def idle_with_heartbeat(seconds: float) -> None:
        """Sleep cooperatively while keeping the job heartbeat fresh."""
        deadline = time.monotonic() + max(0.0, float(seconds))
        while True:
            await _ensure_job_active(job.id)
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return
            await asyncio.sleep(min(5.0, max(0.1, remaining)))
            await _set_job_progress(job.id, dict(counters))

    async def healthy_client(preferred_account_id: int) -> tuple[int, Any]:
        """Return a live client, reassigning the link if one account is temporarily down."""
        ordered_ids = [preferred_account_id] + [
            candidate_id for candidate_id, _candidate in all_clients if candidate_id != preferred_account_id
        ]
        last_error: BaseException | None = None
        for candidate_id in ordered_ids:
            try:
                return candidate_id, await manager.ensure_connected(candidate_id)
            except Exception as exc:
                last_error = exc
                continue
        raise ConnectionError(f"لا يوجد حساب Telegram متصل متاح للفحص: {last_error}") from last_error

    async def process_one(item: TelegramAuditInput, previous: TelegramAuditResult | None, account_id: int, client: Any) -> None:
        await _ensure_job_active(job.id)
        url = item.normalized_url
        try:
            actual_account_id, client = await healthy_client(account_id)
            if actual_account_id != account_id:
                counters["account_reassignments"] = int(counters.get("account_reassignments", 0)) + 1
            result = await single_check(url, actual_account_id, client)
        except (JobCancelled, JobPaused):
            raise
        except Exception as exc:
            # Never let a reconnect/manager exception escape without a durable
            # result row. Otherwise the same input can remain missing forever.
            logger.warning(
                "Audit link deferred before result save input=%s url=%s: %s",
                item.id, url, exc,
            )
            result = {
                "status": "temporary_error",
                "peer_id": None,
                "peer_type": None,
                "title": None,
                "username": None,
                "account_ids": [],
                "account_labels": [],
                "detail": str(exc)[:1000],
                "error_class": exc.__class__.__name__,
                "_retry_after_seconds": max(1.0, float(rest_seconds or 120.0)),
                "_no_attempt_penalty": True,
                "_defer": True,
            }

        # V6.3.0: the audit result is primary and is persisted before optional
        # discovery scheduling. Discovery failure can no longer block `checked`.
        await save_result(item, previous, result)

        if result.get("peer_type") in {"group", "channel"}:
            access_client = result.get("_client")
            access_entity = result.get("_entity")
            access_account_id = result.get("_account_id")
            peer_id = result.get("peer_id")
            if access_client is not None and access_entity is not None and access_account_id is not None:
                try:
                    if collect_telegram:
                        await schedule_telegram_discovery(
                            source_url=url, account_id=int(access_account_id), entity=access_entity,
                            peer_id=int(peer_id) if peer_id is not None else None, input_id=int(item.id),
                        )
                    if collect_whatsapp:
                        await schedule_whatsapp_discovery(
                            source_url=url, account_id=int(access_account_id), entity=access_entity,
                            peer_id=int(peer_id) if peer_id is not None else None, input_id=int(item.id),
                        )
                except (JobCancelled, JobPaused):
                    raise
                except Exception as exc:
                    counters["telegram_scan_errors"] = int(counters.get("telegram_scan_errors", 0)) + 1
                    logger.warning(
                        "Audit result saved; discovery scheduling failed input=%s url=%s: %s",
                        item.id, url, exc,
                    )
            else:
                if collect_telegram:
                    counters["telegram_chats_unavailable"] = int(counters.get("telegram_chats_unavailable", 0)) + 1
                if collect_whatsapp:
                    counters["whatsapp_chats_unavailable"] = int(counters.get("whatsapp_chats_unavailable", 0)) + 1

    async def load_pending(limit: int) -> list[tuple[TelegramAuditInput, TelegramAuditResult | None]]:
        now = utcnow()
        async with SessionFactory() as session:
            stmt = (
                select(TelegramAuditInput, TelegramAuditResult)
                .outerjoin(
                    TelegramAuditResult,
                    and_(
                        TelegramAuditResult.audit_id == TelegramAuditInput.audit_id,
                        TelegramAuditResult.input_id == TelegramAuditInput.id,
                    ),
                )
                .where(
                    TelegramAuditInput.audit_id == audit_id,
                    or_(
                        TelegramAuditResult.id.is_(None),
                        and_(
                            TelegramAuditResult.status == "temporary_error",
                            TelegramAuditResult.attempt_count < max(1, settings.audit_retry_max_attempts),
                            or_(TelegramAuditResult.next_retry_at.is_(None), TelegramAuditResult.next_retry_at <= now),
                        ),
                        and_(TelegramAuditResult.status == "restricted_access", TelegramAuditResult.attempt_count == 0),
                    ),
                )
                .order_by(
                    # V6.3.1: never-attempted inputs must win over historical
                    # retry rows. Without this priority, thousands of old due
                    # temporary_error rows can permanently starve a small tail
                    # of brand-new inputs at the end of a large audit.
                    case((TelegramAuditResult.id.is_(None), 0), else_=1),
                    # Among retry rows, rotate the oldest checked result first
                    # rather than repeatedly favoring the lowest input id.
                    TelegramAuditResult.checked_at.asc().nullsfirst(),
                    TelegramAuditInput.id,
                )
                .limit(limit)
            )
            return list((await session.execute(stmt)).all())

    async def unresolved_count() -> int:
        """Count inputs that still require a future audit attempt, ignoring next_retry timing."""
        async with SessionFactory() as session:
            value = await session.scalar(
                select(func.count(TelegramAuditInput.id))
                .outerjoin(
                    TelegramAuditResult,
                    and_(
                        TelegramAuditResult.audit_id == TelegramAuditInput.audit_id,
                        TelegramAuditResult.input_id == TelegramAuditInput.id,
                    ),
                )
                .where(
                    TelegramAuditInput.audit_id == audit_id,
                    or_(
                        TelegramAuditResult.id.is_(None),
                        and_(
                            TelegramAuditResult.status == "temporary_error",
                            TelegramAuditResult.attempt_count < max(1, settings.audit_retry_max_attempts),
                        ),
                    ),
                )
            )
        return int(value or 0)

    # Resume any full-history Telegram/WhatsApp crawl that had already been
    # scheduled before a network loss, process restart or controlled shutdown.
    await resume_discovery_cursors()

    # If the process was paused/restarted during the mandatory two-minute rest,
    # honor only the remaining portion of that same rest instead of starting a new wave early.
    previous_rest_until = (job.progress or {}).get("rest_until") if isinstance(job.progress, dict) else None
    if previous_rest_until:
        try:
            rest_until_dt = datetime.fromisoformat(str(previous_rest_until))
            if rest_until_dt.tzinfo is None:
                rest_until_dt = rest_until_dt.replace(tzinfo=timezone.utc)
            if rest_until_dt > utcnow():
                counters["current_phase"] = "resting_between_waves"
                counters["rest_until"] = rest_until_dt.isoformat()
                await _set_job_progress(job.id, dict(counters))
                await idle_with_heartbeat(max(0.0, (rest_until_dt - utcnow()).total_seconds()))
            counters.pop("rest_until", None)
        except (ValueError, TypeError):
            counters.pop("rest_until", None)


    while True:
        await _ensure_job_active(job.id)
        # V6.2.7: due discovery cursors are reconsidered once per audit loop;
        # future cursors remain parked in SQLite with zero live sleeper tasks.
        await resume_discovery_cursors()
        pending = await load_pending(wave_capacity)
        if not pending:
            async with SessionFactory() as session:
                next_retry = await session.scalar(
                    select(func.min(TelegramAuditResult.next_retry_at)).where(
                        TelegramAuditResult.audit_id == audit_id,
                        TelegramAuditResult.status == "temporary_error",
                        TelegramAuditResult.attempt_count < max(1, settings.audit_retry_max_attempts),
                        TelegramAuditResult.next_retry_at.is_not(None),
                    )
                )
            if next_retry is not None:
                if next_retry.tzinfo is None:
                    next_retry = next_retry.replace(tzinfo=timezone.utc)
                if next_retry > utcnow():
                    retry_wait = max(1.0, (next_retry - utcnow()).total_seconds())
                    counters["current_phase"] = "waiting_audit_retry"
                    counters["next_audit_retry_at"] = next_retry.isoformat()
                    counters["next_audit_retry_seconds"] = round(float(retry_wait), 1)
                    await _set_job_progress(job.id, dict(counters))

                    # Keep discovery moving while audit links are parked. Wake at
                    # most every normal rest interval so due discovery cursors can
                    # be reconsidered promptly without busy-looping.
                    _remaining_discovery, discovery_wake = await telegram_discovery_pending_state()
                    wake_candidates = [retry_wait, max(1.0, float(rest_seconds or 1.0))]
                    if discovery_wake is not None and discovery_wake > 0:
                        wake_candidates.append(float(discovery_wake))
                    wait_slice = max(1.0, min(wake_candidates))
                    await idle_with_heartbeat(wait_slice)
                    counters.pop("next_audit_retry_at", None)
                    counters.pop("next_audit_retry_seconds", None)
                    counters["current_phase"] = "auditing"
                    continue
            break

        position = 0
        cohort_tasks: list[asyncio.Task[Any]] = []
        for cohort_index, cohort in enumerate(cohorts):
            account_batches: list[tuple[int, Any, list[tuple[TelegramAuditInput, TelegramAuditResult | None]]]] = []
            for account_id, client in cohort:
                batch = pending[position:position + per_account]
                position += len(batch)
                if batch:
                    account_batches.append((account_id, client, batch))
                if position >= len(pending):
                    break

            async def run_cohort(
                batches: list[tuple[int, Any, list[tuple[TelegramAuditInput, TelegramAuditResult | None]]]],
                cohort_no: int = cohort_index,
            ) -> None:
                tasks: list[asyncio.Task[Any]] = []
                for account_id, client, batch in batches:
                    # Exactly up to four distinct links for this account, concurrently.
                    for item, previous in batch:
                        tasks.append(asyncio.create_task(process_one(item, previous, account_id, client)))
                if tasks:
                    results = await asyncio.gather(*tasks, return_exceptions=True)
                    for result in results:
                        if isinstance(result, (JobCancelled, JobPaused)):
                            raise result
                        if isinstance(result, Exception):
                            logger.error("Audit cohort %s task failed: %s", cohort_no + 1, result)

            if account_batches:
                cohort_tasks.append(asyncio.create_task(run_cohort(account_batches)))
            if position >= len(pending):
                break

        results = await asyncio.gather(*cohort_tasks, return_exceptions=True)
        for result in results:
            if isinstance(result, (JobCancelled, JobPaused)):
                raise result
            if isinstance(result, Exception):
                logger.error("Audit wave cohort failed: %s", result)

        counters["waves_completed"] = int(counters.get("waves_completed", 0)) + 1
        await refresh_counts()
        await _set_job_progress(job.id, dict(counters))
        async with SessionFactory() as session:
            await session.execute(
                update(TelegramAudit).where(TelegramAudit.id == audit_id).values(
                    checked_inputs=int(counters["checked"]), summary=dict(counters), updated_at=utcnow()
                )
            )
            await session.commit()

        # Every completed wave must be followed by the full fixed two-minute rest
        # whenever any input still needs a future attempt (including temporary errors).
        unresolved = await unresolved_count()
        if unresolved > 0 and rest_seconds > 0:
            counters["current_phase"] = "resting_between_waves"
            counters["unresolved"] = unresolved
            rest_until = utcnow() + timedelta(seconds=rest_seconds)
            counters["rest_until"] = rest_until.isoformat()
            await _set_job_progress(job.id, dict(counters))
            # Persist rest metadata in the audit summary too, so a restart/resume
            # cannot accidentally bypass the requested rest window.
            async with SessionFactory() as session:
                audit_row = await session.get(TelegramAudit, audit_id)
                if audit_row:
                    audit_row.summary = dict(counters)
                    audit_row.current_phase = "resting_between_waves"
                    audit_row.updated_at = utcnow()
                    await session.commit()
            await idle_with_heartbeat(max(0.0, (rest_until - utcnow()).total_seconds()))
            counters["current_phase"] = "auditing"
            counters.pop("rest_until", None)

    # Link validation is complete. Full-history discovery was intentionally
    # running in parallel with audit waves; now drain it so the final export is
    # complete and deterministic. Newly discovered Telegram URLs are still only
    # collected, never resolved/audited recursively in this same job.
    counters["current_phase"] = "draining_discovery"
    await _set_job_progress(job.id, dict(counters))
    while True:
        await _ensure_job_active(job.id)
        await resume_discovery_cursors()
        if background_tasks:
            snapshot = list(background_tasks)
            await asyncio.wait(snapshot, timeout=5.0, return_when=asyncio.FIRST_COMPLETED)
            await refresh_counts()
            counters["discovery_tasks_pending"] = len(background_tasks)
            await _set_job_progress(job.id, dict(counters))
            continue

        remaining_cursors, next_wake = await telegram_discovery_pending_state()
        counters["discovery_cursors_remaining"] = int(remaining_cursors)
        if remaining_cursors <= 0:
            break
        if next_wake is None or next_wake <= 0:
            # Ready cursor(s) should be scheduled by resume_discovery_cursors;
            # yield briefly and retry without spinning.
            await idle_with_heartbeat(0.5)
            continue

        counters["current_phase"] = "waiting_discovery_cooldown"
        counters["next_discovery_wakeup_seconds"] = round(float(next_wake), 1)
        await _set_job_progress(job.id, dict(counters))
        await idle_with_heartbeat(next_wake)
        counters["current_phase"] = "draining_discovery"
        counters.pop("next_discovery_wakeup_seconds", None)

    for exc in background_errors:
        if isinstance(exc, (JobCancelled, JobPaused)):
            raise exc

    await refresh_counts()
    # Expired findings stay in the report/quarantine by default.  A single
    # account or a web preview must never delete an active link permanently.
    counters["expired_links_deleted_from_database"] = (
        await purge_expired_links_from_main_database(audit_id)
        if bool(getattr(settings, "audit_auto_purge_expired", False))
        else 0
    )
    counters["expired_auto_purge_enabled"] = bool(getattr(settings, "audit_auto_purge_expired", False))
    counters["current_phase"] = "completed"
    has_warnings = bool(
        counters.get("error") or counters.get("temporary_error") or counters.get("restricted_access")
        or counters.get("whatsapp_scan_errors") or counters.get("telegram_scan_errors")
    )
    final_status = "completed_with_errors" if has_warnings else "completed"
    now = utcnow()
    async with SessionFactory() as session:
        await session.execute(
            update(TelegramAudit).where(TelegramAudit.id == audit_id).values(
                status=final_status, checked_inputs=int(counters["checked"]), summary=dict(counters),
                current_phase="completed", current_account_id=None, updated_at=now, finished_at=now,
            )
        )
        await session.commit()
    await _set_job_progress(job.id, dict(counters))
    return counters

async def mark_audit_failed_from_job(job: Job, error: str, *, status: str = "failed") -> None:
    try:
        audit_id = _audit_id_from_job(job)
    except Exception:
        return
    now = utcnow()
    values: dict[str, Any] = {"status": status, "error": error[:4000], "updated_at": now}
    if status == "paused":
        values.update({"paused_at": now, "finished_at": None, "current_phase": "paused"})
    elif status in {"failed", "cancelled", "completed", "completed_with_errors"}:
        values["finished_at"] = now
        values["current_phase"] = status
    async with SessionFactory() as session:
        await session.execute(update(TelegramAudit).where(TelegramAudit.id == audit_id).values(**values))
        await session.commit()


async def audit_summary(audit_id: int) -> dict[str, Any]:
    async with SessionFactory() as session:
        audit = await session.get(TelegramAudit, audit_id)
        if not audit:
            raise ValueError("تقرير الفحص غير موجود.")
        rows = (
            await session.execute(
                select(TelegramAuditResult.status, func.count(TelegramAuditResult.id))
                .where(TelegramAuditResult.audit_id == audit_id)
                .group_by(TelegramAuditResult.status)
            )
        ).all()
        peer_rows = (
            await session.execute(
                select(TelegramAuditResult.peer_type, func.count(TelegramAuditResult.id))
                .where(
                    TelegramAuditResult.audit_id == audit_id,
                    TelegramAuditResult.peer_type.in_(["channel", "group"]),
                )
                .group_by(TelegramAuditResult.peer_type)
            )
        ).all()
        telegram_discovery_count = int(
            await session.scalar(
                select(func.count(TelegramAuditTelegramDiscovery.id)).where(
                    TelegramAuditTelegramDiscovery.audit_id == audit_id
                )
            ) or 0
        )
        whatsapp_count = int(
            await session.scalar(
                select(func.count(TelegramAuditWhatsapp.id)).where(TelegramAuditWhatsapp.audit_id == audit_id)
            ) or 0
        )
        counts = dict(audit.summary or {})
        for status in AUDIT_STATUS_LABELS:
            counts[status] = 0
        checked = 0
        for status, count in rows:
            counts[str(status)] = int(count)
            checked += int(count)
        peer_counts = {str(peer_type): int(count) for peer_type, count in peer_rows}
        counts["telegram_channels"] = int(peer_counts.get("channel", 0))
        counts["telegram_groups"] = int(peer_counts.get("group", 0))
        counts["telegram_discovered_links"] = telegram_discovery_count
        counts["whatsapp_links"] = whatsapp_count
        counts.update({
            "audit_id": audit.id,
            "title": audit.title,
            "status": audit.status,
            "total": audit.total_inputs,
            "checked": checked,
            "source_type": audit.source_type,
            "last_processed_input_id": audit.last_processed_input_id,
            "current_account": audit.current_account_id,
            "current_phase": audit.current_phase,
        })
        return counts


def format_audit_summary(summary: dict[str, Any]) -> str:
    audit_title = str(summary.get("title") or "").strip()
    engine = str(summary.get("engine") or ((summary.get("options") or {}).get("engine") if isinstance(summary.get("options"), dict) else "") or "accounts")
    if engine == "web":
        heading = f"تقرير فحص المتصفح لروابط Telegram #{summary.get('audit_id')}"
        if audit_title:
            heading += f" — {audit_title}"
        return "\n".join([
            heading,
            f"الحالة: {summary.get('status', '-')}",
            f"الروابط: {summary.get('checked', 0)}/{summary.get('total', 0)}",
            f"قنوات يظهر لها subscribers: {summary.get('telegram_channels', 0)}",
            f"مجموعات يظهر لها members: {summary.get('telegram_groups', 0)}",
            f"روابط منتهية مؤكدة من صفحة الويب: {summary.get('expired', 0)}",
            f"تحتاج حسابات لمعرفة المعلومات: {summary.get('requires_account', 0)}",
            f"بوتات Telegram: {summary.get('bot', 0)}",
            f"روابط شخصية: {summary.get('personal', 0)}",
            f"بامبات/اكتتابات/استثمارات: {summary.get('pump_ipo', 0)}",
            f"أخطاء ويب مؤقتة: {summary.get('temporary_error', 0)}",
            f"عمال الفحص المتوازيون: {summary.get('web_workers', settings.web_audit_workers)}",
            "ملاحظة: النتائج الغامضة لا تُحذف من قاعدة البيانات؛ تُرسل إلى قسم تحتاج حسابات للتحقق النهائي.",
        ])
    audit_title = str(summary.get("title") or "").strip()
    heading = f"تقرير فحص روابط Telegram #{summary.get('audit_id')}"
    if audit_title:
        heading += f" — {audit_title}"
    working = (
        int(summary.get("joined_unique", 0) or 0)
        + int(summary.get("unjoined", 0) or 0)
        + int(summary.get("join_request", 0) or 0)
    )
    lines = [
        heading,
        f"الحالة: {summary.get('status', '-')}",
        f"الروابط: {summary.get('checked', 0)}/{summary.get('total', 0)}",
        f"الروابط الشغالة المؤكدة: {working}",
        f"قنوات Telegram (مشتركون): {summary.get('telegram_channels', 0)}",
        f"مجموعات Telegram (أعضاء): {summary.get('telegram_groups', 0)}",
        f"صالحة والحساب عضو فيها: {summary.get('joined_unique', 0)}",
        f"روابط منتهية/غير صالحة: {summary.get('expired', 0)}",
        f"روابط منتهية حُذفت من قاعدة الروابط: {summary.get('expired_links_deleted_from_database', 0)}",
        f"روابط شخصية: {summary.get('personal', 0)}",
        f"بوتات Telegram: {summary.get('bot', 0)}",
        f"روابط صالحة وغير منضم لها: {summary.get('unjoined', 0)}",
        f"روابط تحتاج طلب انضمام: {summary.get('join_request', 0)}",
        f"وصول مقيّد: {summary.get('restricted_access', 0)}",
        f"روابط تحتاج حسابات لمعرفة معلوماتها: {summary.get('requires_account', 0)}",
        f"روابط مرئية ومصنفة عبر المتصفح: {summary.get('web_visible', 0)}",
        f"روابط Telegram غير مباشرة/غير مدعومة: {summary.get('unsupported', 0)}",
        f"أخطاء مؤقتة: {summary.get('temporary_error', 0)}",
        f"أخطاء نهائية بعد المحاولات: {summary.get('error', 0)}",
        "",
        "نظام الفحص V6:",
        f"كل مجموعة حسابات: {summary.get('account_group_size', settings.audit_account_group_size)} حسابات",
        f"كل حساب يفحص في الدورة: {summary.get('links_per_account_cycle', settings.audit_links_per_account_cycle)} روابط مختلفة بالتوازي",
        f"الراحة بين الدورات: {int(float(summary.get('group_rest_seconds', settings.audit_group_rest_seconds) or 0))} ثانية",
        f"عدد مجموعات الحسابات: {summary.get('account_groups', 0)}",
        f"الدورات المكتملة: {summary.get('waves_completed', 0)}",
    ]
    if summary.get("links_per_minute") is not None:
        lines.append(f"السرعة التقريبية: {summary.get('links_per_minute')} رابط/دقيقة")
    if summary.get("active_accounts") is not None:
        lines.append(f"الحسابات النشطة: {summary.get('active_accounts')}")
    options = summary.get("options") or {}
    if isinstance(options, dict) and options.get("collect_whatsapp"):
        lines.extend([
            f"روابط واتساب المجمعة: {summary.get('whatsapp_links', 0)}",
            f"محادثات Telegram التي قُرئت لواتساب: {summary.get('whatsapp_chats_scanned', 0)}",
            f"محادثات تعذر قراءة سجلها: {summary.get('whatsapp_chats_unavailable', 0)}",
            f"أخطاء جمع واتساب: {summary.get('whatsapp_scan_errors', 0)}",
        ])
    if isinstance(options, dict) and options.get("collect_telegram"):
        lines.extend([
            f"روابط Telegram الجديدة المضافة لقاعدة الروابط: {summary.get('telegram_discovered_links', 0)}",
            f"روابط Telegram الموجودة مسبقًا والمتجاوزة: {summary.get('telegram_duplicates_skipped', 0)}",
            f"محادثات Telegram التي قُرئت لاكتشاف روابط جديدة: {summary.get('telegram_chats_scanned', 0)}",
            f"محادثات تعذر قراءة سجلها لاكتشاف Telegram: {summary.get('telegram_chats_unavailable', 0)}",
            f"تأجيلات FloodWait لاكتشاف Telegram: {summary.get('telegram_floodwait_deferrals', 0)}",
            f"أخطاء جمع روابط Telegram: {summary.get('telegram_scan_errors', 0)}",
        ])
    if summary.get("source_errors"):
        lines.append(f"مصادر تعذر قراءتها: {summary.get('source_errors', 0)}")
    return "\n".join(lines)


def format_account_report(summary: dict[str, Any]) -> str:
    report = summary.get("account_report") or {}
    if not isinstance(report, dict) or not report:
        return "لا يوجد تقرير حسابات محفوظ لهذا الفحص."
    lines = [
        "تقرير حسابات الفحص V6:",
        f"كل {summary.get('account_group_size', settings.audit_account_group_size)} حسابات تشكل مجموعة فحص.",
        f"كل حساب يأخذ حتى {summary.get('links_per_account_cycle', settings.audit_links_per_account_cycle)} روابط مختلفة في الدورة.",
    ]
    for account_id, row in report.items():
        if not isinstance(row, dict):
            continue
        lines.append(
            f"#{account_id} — {row.get('label', 'حساب')} | تم فحص {row.get('checked_in_run', 0)} رابط في هذا التشغيل"
        )
    return "\n".join(lines)


def _safe_cell(value: Any) -> str:
    return str(value or "").replace("\n", " ").replace("\r", " ")


def _safe_export_name(value: str | None, fallback: str, max_bytes: int = 80) -> str:
    text = " ".join(str(value or fallback).split()).strip() or fallback
    text = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", text)
    text = re.sub(r"\s+", "_", text).strip("._ ") or fallback
    encoded = text.encode("utf-8")
    if len(encoded) <= max_bytes:
        return text
    encoded = encoded[:max_bytes]
    while encoded:
        try:
            return encoded.decode("utf-8").rstrip("._ ") or fallback
        except UnicodeDecodeError:
            encoded = encoded[:-1]
    return fallback


def _write_named_telegram_record(handle: Any, row: Any) -> None:
    title = " ".join(str(getattr(row, "title", "") or "").split()).strip() or "بدون اسم ظاهر"
    handle.write(str(getattr(row, "normalized_url", "") or "").strip() + "\n")
    handle.write(f"الاسم: {title}\n")
    handle.write(f"الرابط: {str(getattr(row, 'normalized_url', '') or '').strip()}\n\n")


async def export_audit(audit_id: int, chunk_size: int | None = None) -> AuditExportBundle:
    """Stream a committed audit snapshot to a compact user-facing export.

    V6.4 export contract:
    * default -> ONE TXT file per result section;
    * optional split -> 200 or 1000 URLs per file for every link section;
    * Telegram discoveries -> ONE TXT file;
    * WhatsApp discoveries -> ONE TXT file;
    * groups that require joining/read access or a join request -> ONE TXT file;
    * final errors, temporary errors, expired URLs and pump/IPO groups -> one TXT each;
    * bot/private/unsupported URLs -> one TXT each.

    The full CSV/JSON reports remain inside the ZIP, but are not sent as dozens of
    individual TXT files.  Group/channel classification is based strictly on the
    resolved Telegram peer type so broadcast channels can never leak into the
    members-group export.
    """
    raw_chunk_size = int(chunk_size or 0)
    requested_chunk_size = raw_chunk_size if raw_chunk_size in {200, 1000} else 0
    page_size = max(250, min(5000, raw_chunk_size or int(settings.export_chunk_size)))
    # Build exactly one committed file per section first. Optional splitting is
    # applied uniformly after the snapshot is complete.

    async with SessionFactory() as session:
        audit = await session.get(TelegramAudit, audit_id)
        if not audit:
            raise ValueError("تقرير الفحص غير موجود.")
        audit_title = audit.title
        total_results = int(await session.scalar(
            select(func.count(TelegramAuditResult.id)).where(TelegramAuditResult.audit_id == audit_id)
        ) or 0)

    summary = await audit_summary(audit_id)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
    audit_name = _safe_export_name(audit_title, f"فحص_Telegram_{audit_id}")
    export_dir = settings.exports_dir / f"{audit_name}__snapshot__{stamp}"
    export_dir.mkdir(parents=True, exist_ok=False)

    text_files: list[Path] = []

    def _open_single(folder: str, stem: str):
        directory = export_dir / folder
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / f"{audit_name}__{stem}.txt"
        handle = path.open("w", encoding="utf-8")
        text_files.append(path)
        return handle, path

    # Stable compact user-facing TXT layout.  All except groups are single files.
    channels_handle, channels_txt = _open_single("01_قنوات_Telegram_مشتركون", "قنوات_Telegram_مشتركون")
    join_required_handle, join_required_txt = _open_single(
        "05_روابط_تحتاج_انضمام_او_طلب_انضمام", "روابط_تحتاج_انضمام_او_طلب_انضمام"
    )
    final_error_handle, final_error_txt = _open_single("06_اخطاء_نهائية", "اخطاء_نهائية")
    temporary_error_handle, temporary_error_txt = _open_single("07_اخطاء_مؤقتة", "اخطاء_مؤقتة")
    expired_handle, expired_txt = _open_single("08_روابط_منتهية", "روابط_منتهية")
    pump_ipo_handle, pump_ipo_txt = _open_single("09_مجموعات_البامبات_والاكتتابات", "مجموعات_البامبات_والاكتتابات")
    bots_handle, bots_txt = _open_single("10_روابط_البوتات", "روابط_البوتات")
    personal_handle, personal_txt = _open_single("11_روابط_شخصية", "روابط_شخصية")
    requires_account_handle, requires_account_txt = _open_single(
        "12_روابط_تحتاج_حسابات_لمعرفة_المعلومات", "روابط_تحتاج_حسابات_لمعرفة_المعلومات"
    )
    unsupported_handle, unsupported_txt = _open_single("13_روابط_Telegram_غير_مدعومة", "روابط_Telegram_غير_مدعومة")

    groups_handle, groups_txt = _open_single(
        "02_مجموعات_Telegram_اعضاء", "مجموعات_Telegram_اعضاء"
    )
    groups_dir = groups_txt.parent

    full_csv = export_dir / f"{audit_name}__التقرير_الكامل.csv"
    audit_json = export_dir / f"{audit_name}__النتائج.json"

    try:
        with full_csv.open("w", encoding="utf-8-sig", newline="") as csv_handle, audit_json.open("w", encoding="utf-8") as json_handle:
            writer = csv.writer(csv_handle)
            writer.writerow([
                "URL", "STATUS", "PEER_ID", "PEER_TYPE", "TITLE", "USERNAME",
                "ACCOUNT_IDS", "ACCOUNT_LABELS", "DETAIL", "ERROR_CLASS",
                "ATTEMPT_COUNT", "CHECKED_AT",
            ])
            json_handle.write("[\n")
            first_json = True
            last_id = 0
            while True:
                async with SessionFactory() as session:
                    rows = list((await session.scalars(
                        select(TelegramAuditResult)
                        .where(
                            TelegramAuditResult.audit_id == audit_id,
                            TelegramAuditResult.id > last_id,
                        )
                        .order_by(TelegramAuditResult.id)
                        .limit(page_size)
                    )).all())
                if not rows:
                    break
                for row in rows:
                    last_id = max(last_id, int(row.id))
                    writer.writerow([
                        row.normalized_url, row.status, row.peer_id or "", row.peer_type or "", row.title or "",
                        row.username or "", "|".join(str(i) for i in (row.account_ids or [])),
                        "|".join(row.account_labels or []), row.detail or "", row.error_class or "",
                        row.attempt_count or 0, row.checked_at or "",
                    ])
                    payload = {
                        "url": row.normalized_url,
                        "status": row.status,
                        "peer_id": row.peer_id,
                        "peer_type": row.peer_type,
                        "title": row.title,
                        "username": row.username,
                        "account_ids": row.account_ids or [],
                        "account_labels": row.account_labels or [],
                        "detail": row.detail,
                        "error_class": row.error_class,
                        "attempt_count": row.attempt_count,
                        "checked_at": row.checked_at.isoformat() if row.checked_at else None,
                    }
                    if not first_json:
                        json_handle.write(",\n")
                    json_handle.write(json.dumps(payload, ensure_ascii=False))
                    first_json = False

                    bucket = _strict_requested_export_bucket(row)
                    if bucket == "channels":
                        # ALL resolved broadcast/subscriber channels live here only.
                        _write_named_telegram_record(channels_handle, row)
                    elif bucket == "groups":
                        # All normal/readable member-groups, whether joined or not,
                        # including joined_unique/joined_duplicate, and NO channels.
                        _write_named_telegram_record(groups_handle, row)
                    elif bucket == "groups_join_required":
                        # Join-required + join-request groups are deliberately kept
                        # out of the normal group chunks and combined here.
                        _write_named_telegram_record(join_required_handle, row)

                    if row.status == "error":
                        final_error_handle.write(row.normalized_url + "\n")
                    elif row.status == "temporary_error":
                        temporary_error_handle.write(row.normalized_url + "\n")
                    elif row.status == "expired":
                        expired_handle.write(row.normalized_url + "\n")
                    elif row.status == "bot":
                        bots_handle.write(row.normalized_url + "\n")
                    elif row.status == "personal":
                        personal_handle.write(row.normalized_url + "\n")
                    elif row.status == "requires_account":
                        requires_account_handle.write(row.normalized_url + "\n")
                    elif row.status == "unsupported":
                        unsupported_handle.write(row.normalized_url + "\n")

                    # Supplemental thematic list; a pump/IPO group can also appear
                    # in its normal group bucket because this file is a filtered view.
                    if _is_pump_or_ipo_group(row):
                        _write_named_telegram_record(pump_ipo_handle, row)
            json_handle.write("\n]\n")
    finally:
        for handle in (
            channels_handle, groups_handle, join_required_handle, final_error_handle,
            temporary_error_handle, expired_handle, pump_ipo_handle,
            bots_handle, personal_handle, requires_account_handle, unsupported_handle,
        ):
            handle.close()

    # Telegram discoveries: exactly one TXT file, regardless of count.
    telegram_discovery_dir = export_dir / "03_روابط_Telegram_الجديدة"
    telegram_discovery_dir.mkdir(parents=True, exist_ok=True)
    telegram_discovery_txt = telegram_discovery_dir / f"{audit_name}__روابط_Telegram_الجديدة.txt"
    telegram_discovery_csv = telegram_discovery_dir / f"{audit_name}__روابط_Telegram_الجديدة.csv"
    text_files.append(telegram_discovery_txt)
    with telegram_discovery_txt.open("w", encoding="utf-8") as txt_handle, telegram_discovery_csv.open("w", encoding="utf-8-sig", newline="") as csv_handle:
        writer = csv.writer(csv_handle)
        writer.writerow([
            "Telegram URL", "source Telegram chat", "source_peer_id", "account",
            "message_id", "date", "link_id",
        ])
        last_tg_id = 0
        while True:
            async with SessionFactory() as session:
                rows = list((await session.scalars(
                    select(TelegramAuditTelegramDiscovery)
                    .where(
                        TelegramAuditTelegramDiscovery.audit_id == audit_id,
                        TelegramAuditTelegramDiscovery.id > last_tg_id,
                    )
                    .order_by(TelegramAuditTelegramDiscovery.id)
                    .limit(page_size)
                )).all())
            if not rows:
                break
            for row in rows:
                last_tg_id = max(last_tg_id, int(row.id))
                txt_handle.write(row.normalized_url + "\n")
                writer.writerow([
                    row.normalized_url, row.source_telegram_url or "", row.source_peer_id or "",
                    row.source_account_id or "", row.source_message_id or "", row.source_message_date or "",
                    row.link_id,
                ])

    # WhatsApp discoveries: exactly one TXT file, regardless of count.
    whatsapp_dir = export_dir / "04_روابط_واتساب"
    whatsapp_dir.mkdir(parents=True, exist_ok=True)
    whatsapp_txt = whatsapp_dir / f"{audit_name}__روابط_واتساب.txt"
    whatsapp_csv = whatsapp_dir / f"{audit_name}__روابط_واتساب.csv"
    text_files.append(whatsapp_txt)
    with whatsapp_txt.open("w", encoding="utf-8") as txt_handle, whatsapp_csv.open("w", encoding="utf-8-sig", newline="") as csv_handle:
        writer = csv.writer(csv_handle)
        writer.writerow([
            "WhatsApp URL", "source Telegram group", "source_peer_id", "account",
            "message_id", "date",
        ])
        last_wa_id = 0
        while True:
            async with SessionFactory() as session:
                rows = list((await session.scalars(
                    select(TelegramAuditWhatsapp)
                    .where(
                        TelegramAuditWhatsapp.audit_id == audit_id,
                        TelegramAuditWhatsapp.id > last_wa_id,
                    )
                    .order_by(TelegramAuditWhatsapp.id)
                    .limit(page_size)
                )).all())
            if not rows:
                break
            for row in rows:
                last_wa_id = max(last_wa_id, int(row.id))
                txt_handle.write(row.normalized_url + "\n")
                writer.writerow([
                    row.normalized_url, row.source_telegram_url or "", row.source_peer_id or "",
                    row.source_account_id or "", row.source_message_id or "", row.source_message_date or "",
                ])

    account_csv = export_dir / f"{audit_name}__تقرير_الحسابات.csv"
    with account_csv.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["account_id", "label", "role", "checked_in_run"])
        report = summary.get("account_report") or {}
        if isinstance(report, dict):
            for account_id, row in report.items():
                if not isinstance(row, dict):
                    continue
                writer.writerow([
                    account_id, row.get("label", ""), row.get("role", "audit"), row.get("checked_in_run", 0),
                ])

    summary_json = export_dir / f"{audit_name}__الملخص.json"
    summary_json.write_text(json.dumps(summary, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    summary_txt = export_dir / f"00_{audit_name}__الملخص.txt"
    summary_txt.write_text(
        format_audit_summary(summary) + "\n\n" + format_account_report(summary) + "\n",
        encoding="utf-8",
    )

    # V6.4 default: one file per section. If the owner explicitly chooses
    # 200/1000, split every link section consistently while leaving the summary
    # untouched.
    text_files = [
        summary_txt,
        channels_txt,
        groups_txt,
        telegram_discovery_txt,
        whatsapp_txt,
        join_required_txt,
        final_error_txt,
        temporary_error_txt,
        expired_txt,
        pump_ipo_txt,
        bots_txt,
        personal_txt,
        requires_account_txt,
        unsupported_txt,
    ]
    named_record_paths = {channels_txt, groups_txt, join_required_txt, pump_ipo_txt}

    if requested_chunk_size:
        split_files: list[Path] = [summary_txt]
        for path in [item for item in text_files if item != summary_txt]:
            part = 0
            count = 0
            handle = None
            created: list[Path] = []
            try:
                with path.open("r", encoding="utf-8") as source:
                    if path in named_record_paths:
                        record: list[str] = []
                        def flush_record() -> None:
                            nonlocal part, count, handle, record
                            if not record:
                                return
                            if count % requested_chunk_size == 0:
                                if handle is not None:
                                    handle.close()
                                part += 1
                                out = path.with_name(f"{path.stem}__part_{part:04d}.txt")
                                handle = out.open("w", encoding="utf-8")
                                created.append(out)
                            handle.write("\n".join(record) + "\n\n")
                            count += 1
                            record = []
                        for raw_line in source:
                            line = raw_line.rstrip("\n")
                            if not line.strip():
                                flush_record()
                            else:
                                record.append(line)
                        flush_record()
                    else:
                        for raw_line in source:
                            line = raw_line.strip()
                            if not line:
                                continue
                            if count % requested_chunk_size == 0:
                                if handle is not None:
                                    handle.close()
                                part += 1
                                out = path.with_name(f"{path.stem}__part_{part:04d}.txt")
                                handle = out.open("w", encoding="utf-8")
                                created.append(out)
                            handle.write(line + "\n")
                            count += 1
            finally:
                if handle is not None:
                    handle.close()
            if not created:
                out = path.with_name(f"{path.stem}__part_0001.txt")
                out.touch()
                created.append(out)
            path.unlink(missing_ok=True)
            split_files.extend(created)
        text_files = split_files

    zip_path = settings.exports_dir / f"{audit_name}__تصدير__{stamp}.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in export_dir.rglob("*"):
            if path.is_file():
                archive.write(path, arcname=str(path.relative_to(export_dir)))

    return AuditExportBundle(
        directory=export_dir,
        text_files=tuple(text_files),
        report_files=(full_csv, audit_json, summary_json, account_csv, telegram_discovery_csv, whatsapp_csv),
        zip_path=zip_path,
        total_results=total_results,
    )
