from __future__ import annotations

import asyncio
import shutil
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy import func, select
from sqlalchemy.engine import make_url

from app.config import PROJECT_ROOT, get_settings
from app.db import SessionFactory, engine, init_db
from app.models import Job
from app.runtime import reset_in_progress

settings = get_settings()


@dataclass(frozen=True, slots=True)
class BackupInfo:
    path: Path
    size_bytes: int
    created_at: datetime


def _sqlite_db_path() -> Path:
    url = make_url(settings.database_url)
    if not url.drivername.startswith("sqlite"):
        raise RuntimeError("النسخ الاحتياطي المحلي المدمج يدعم SQLite فقط. استخدم أدوات PostgreSQL عند الانتقال إليه.")
    database = url.database
    if not database or database == ":memory:":
        raise RuntimeError("لا يمكن إنشاء نسخة احتياطية لقاعدة SQLite مؤقتة.")
    path = Path(database)
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    return path.resolve()


def _backup_sync(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    source_conn = sqlite3.connect(str(source), timeout=30)
    try:
        dest_conn = sqlite3.connect(str(destination), timeout=30)
        try:
            source_conn.backup(dest_conn)
            if dest_conn.execute("PRAGMA integrity_check").fetchone() != ("ok",):
                raise RuntimeError("Backup integrity check failed")
            dest_conn.commit()
        finally:
            dest_conn.close()
    finally:
        source_conn.close()


def _restore_sync(source: Path, destination: Path) -> None:
    # Verify backup before replacing the live file.
    check = sqlite3.connect(str(source), timeout=30)
    try:
        result = check.execute("PRAGMA integrity_check").fetchone()
        if not result or str(result[0]).lower() != "ok":
            raise RuntimeError(f"فشل integrity_check للنسخة: {result}")
    finally:
        check.close()
    destination.parent.mkdir(parents=True, exist_ok=True)
    # SQLite backup replaces database content safely even when a WAL exists.
    with sqlite3.connect(str(source), timeout=30) as src:
        with sqlite3.connect(str(destination), timeout=30) as dst:
            src.backup(dst)



async def create_database_backup(prefix: str = "collector_backup", *, prune: bool = True) -> BackupInfo:
    source = _sqlite_db_path()
    if not source.exists():
        # Ensure an initialized database exists before backup.
        await init_db()
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d_%H%M%S_%f")
    destination = settings.backups_dir / f"{prefix}_{stamp}.db"
    await asyncio.to_thread(_backup_sync, source, destination)
    if prune:
        await prune_backups()
    stat = destination.stat()
    return BackupInfo(path=destination, size_bytes=stat.st_size, created_at=datetime.now(timezone.utc))


async def list_backups(limit: int = 20) -> list[BackupInfo]:
    paths = sorted(settings.backups_dir.glob("*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
    result: list[BackupInfo] = []
    for path in paths[:limit]:
        stat = path.stat()
        result.append(
            BackupInfo(
                path=path,
                size_bytes=stat.st_size,
                created_at=datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc),
            )
        )
    return result


async def prune_backups() -> None:
    keep = max(1, settings.backup_keep_count)
    paths = sorted(settings.backups_dir.glob("*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
    for path in paths[keep:]:
        path.unlink(missing_ok=True)


async def restore_latest_backup() -> BackupInfo:
    backups = await list_backups(limit=1)
    if not backups:
        raise RuntimeError("لا توجد نسخة احتياطية محفوظة.")
    backup = backups[0]
    async with SessionFactory() as session:
        active = int(
            await session.scalar(
                select(func.count(Job.id)).where(Job.status.in_(["queued", "starting", "running", "pause_requested", "stopping"]))
            ) or 0
        )
    if active:
        raise RuntimeError("لا يمكن الاستعادة أثناء وجود عملية نشطة أو في الطابور. أوقف/ألغِ العمليات أولًا.")

    destination = _sqlite_db_path()
    reset_in_progress.set()
    try:
        # Keep a safety backup of the current database before replacing it.
        await create_database_backup(prefix="pre_restore", prune=False)
        await engine.dispose()
        await asyncio.to_thread(_restore_sync, backup.path, destination)
        await init_db()
    finally:
        reset_in_progress.clear()
    return backup
