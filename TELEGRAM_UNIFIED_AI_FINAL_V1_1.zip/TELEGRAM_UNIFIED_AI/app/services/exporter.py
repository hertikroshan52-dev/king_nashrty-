from __future__ import annotations

import shutil
import zipfile
from collections import defaultdict
from pathlib import Path

from sqlalchemy import select

from app.config import get_settings
from app.db import SessionFactory
from app.export_utils import CATEGORY_FILE_LABELS, ExportBundle, safe_export_name
from app.models import Job, JobLink, Link

settings = get_settings()
CATEGORY_LABELS = {
    "whatsapp": "واتساب",
    "twitter": "تويتر_X",
    "telegram": "Telegram",
    "other": "روابط_اخرى",
}


class _StreamWriter:
    """Low-memory export writer with one live handle per active category.

    ``chunk_size=None`` means exactly one TXT file per category.  Chunked job
    exports still roll over normally, but the writer no longer opens/closes a
    file for every individual URL (important for multi-million-link exports).
    """

    def __init__(self, name: str, chunk_size: int | None) -> None:
        self.name = safe_export_name(name, "export")
        self.chunk_size = max(1, int(chunk_size)) if chunk_size is not None else None
        self.directory = settings.exports_dir / self.name
        if self.directory.exists():
            shutil.rmtree(self.directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.counts: dict[str, int] = defaultdict(int)
        self.files: dict[tuple[str, int], Path] = {}
        self.handles: dict[str, tuple[int, object]] = {}
        self.total = 0

    def _path_for(self, category: str, part: int) -> Path:
        key = (category, part)
        path = self.files.get(key)
        if path is not None:
            return path
        section = safe_export_name(CATEGORY_FILE_LABELS.get(category, category), category)
        if self.chunk_size is None:
            filename = f"{self.name}__{section}.txt"
        else:
            filename = f"{self.name}__{section}__part_{part:04d}.txt"
        path = self.directory / filename
        self.files[key] = path
        return path

    def write(self, category: str, url: str) -> None:
        category = str(category)
        url = str(url).strip()
        if not url:
            return
        index = self.counts[category]
        part = (index // self.chunk_size + 1) if self.chunk_size is not None else 1
        current = self.handles.get(category)
        if current is None or int(current[0]) != part:
            if current is not None:
                current[1].close()
            path = self._path_for(category, part)
            handle = path.open("a", encoding="utf-8")
            self.handles[category] = (part, handle)
        self.handles[category][1].write(url + "\n")
        self.counts[category] += 1
        self.total += 1

    def finish(self) -> ExportBundle:
        for _part, handle in self.handles.values():
            handle.close()
        self.handles.clear()
        text_files = tuple(self.files[key] for key in sorted(self.files, key=lambda item: (item[0], item[1])))
        zip_path = settings.exports_dir / f"{self.name}__تصدير.zip"
        zip_path.unlink(missing_ok=True)
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for path in text_files:
                archive.write(path, arcname=path.name)
        return ExportBundle(self.directory, text_files, zip_path, self.total)


async def export_job(job_id: int, chunk_size: int | None = None) -> ExportBundle:
    async with SessionFactory() as session:
        job = await session.get(Job, job_id)
    category = str(job.category or "") if job else ""
    title = (
        f"قسم_{CATEGORY_LABELS[category]}_مهمة_{job_id}"
        if category in CATEGORY_LABELS else f"مهمة_{job_id}_{(job.mode if job else 'روابط')}"
    )
    writer = _StreamWriter(title, chunk_size or settings.export_chunk_size)
    last_link_id = 0
    page = max(500, settings.export_chunk_size * 2)
    while True:
        async with SessionFactory() as session:
            rows = (
                await session.execute(
                    select(Link.id, Link.category, Link.normalized_url)
                    .join(JobLink, JobLink.link_id == Link.id)
                    .where(JobLink.job_id == job_id, Link.id > last_link_id)
                    .order_by(Link.id)
                    .limit(page)
                )
            ).all()
        if not rows:
            break
        last_link_id = int(rows[-1][0])
        for _id, cat, url in rows:
            writer.write(str(cat), str(url))
    return writer.finish()


async def export_database(chunk_size: int | None = None) -> ExportBundle:
    # Database export contract V6.4: one TXT file per category by default.
    # A very large chunk size preserves the streaming writer without splitting.
    writer = _StreamWriter("قاعدة_الروابط_الكاملة", chunk_size)
    last_id = 0
    page = max(500, settings.export_chunk_size * 2)
    while True:
        async with SessionFactory() as session:
            rows = (
                await session.execute(
                    select(Link.id, Link.category, Link.normalized_url)
                    .where(Link.id > last_id)
                    .order_by(Link.id)
                    .limit(page)
                )
            ).all()
        if not rows:
            break
        last_id = int(rows[-1][0])
        for _id, cat, url in rows:
            writer.write(str(cat), str(url))
    return writer.finish()
