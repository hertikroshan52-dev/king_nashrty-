from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import datetime
from typing import Sequence

from sqlalchemy import select, update
from sqlalchemy.dialects.sqlite import insert

from app.db import SessionFactory
from app.link_utils import CleanLink, telegram_identity_key
from app.models import Delivery, JobLink, Link, LinkOccurrence, TelegramExpiredLinkBlocklist, utcnow
from app.runtime import reset_in_progress


_LINK_WRITE_LOCK = asyncio.Lock()


@dataclass(frozen=True, slots=True)
class LinkRegistration:
    link: Link | None
    created: bool
    blocked: bool = False


@dataclass(frozen=True, slots=True)
class BatchLinkSource:
    clean: CleanLink
    account_id: int | None
    chat_id: int | None
    message_id: int | None
    message_date: datetime | None


async def register_link(
    clean: CleanLink,
    *,
    origin: str,
    job_id: int | None,
    account_id: int | None,
    chat_id: int | None,
    message_id: int | None,
    message_date: datetime | None,
) -> LinkRegistration:
    rows = await register_links_batch(
        [BatchLinkSource(clean, account_id, chat_id, message_id, message_date)],
        origin=origin,
        job_id=job_id,
    )
    if not rows:
        raise RuntimeError("فشل تسجيل الرابط في قاعدة البيانات.")
    return rows[0]


async def register_links_batch(
    items: Sequence[BatchLinkSource],
    *,
    origin: str,
    job_id: int | None,
) -> list[LinkRegistration]:
    """Register many links in one SQLite transaction.

    Collection jobs can discover thousands of links. Committing every link one by
    one turns SQLite into the main bottleneck, so this function performs one
    deduplicated INSERT/JobLink transaction for a bounded batch and returns results
    in the same order as the input.
    """
    if not items:
        return []
    if reset_in_progress.is_set():
        raise RuntimeError("إعادة ضبط البوت قيد التنفيذ؛ تم إيقاف تسجيل الروابط مؤقتًا.")

    unique_first: dict[str, BatchLinkSource] = {}
    for item in items:
        unique_first.setdefault(item.clean.url_hash, item)
    hashes = list(unique_first)

    async with _LINK_WRITE_LOCK:
        if reset_in_progress.is_set():
            raise RuntimeError("إعادة ضبط البوت قيد التنفيذ؛ تم إيقاف تسجيل الروابط مؤقتًا.")
        async with SessionFactory() as session:
            telegram_key_by_hash = {
                url_hash: telegram_identity_key(item.clean.normalized)
                for url_hash, item in unique_first.items()
                if item.clean.category == "telegram"
            }
            blocked_keys: set[str] = set()
            if telegram_key_by_hash:
                blocked_keys = set((await session.scalars(
                    select(TelegramExpiredLinkBlocklist.identity_key).where(
                        TelegramExpiredLinkBlocklist.identity_key.in_(list(telegram_key_by_hash.values()))
                    )
                )).all())
            blocked_hashes = {
                url_hash for url_hash, identity_key in telegram_key_by_hash.items()
                if identity_key in blocked_keys
            }

            existing_hashes = set(
                (await session.scalars(select(Link.url_hash).where(Link.url_hash.in_(hashes)))).all()
            )
            new_values = []
            for url_hash, item in unique_first.items():
                if url_hash in existing_hashes or url_hash in blocked_hashes:
                    continue
                clean = item.clean
                new_values.append(
                    {
                        "original_url": clean.original,
                        "normalized_url": clean.normalized,
                        "url_hash": clean.url_hash,
                        "category": clean.category,
                        "origin": origin,
                        "first_job_id": job_id,
                        "first_source_account_id": item.account_id,
                        "first_source_chat_id": item.chat_id,
                        "first_source_message_id": item.message_id,
                        "first_source_date": item.message_date,
                    }
                )
            if new_values:
                await session.execute(
                    insert(Link).values(new_values).on_conflict_do_nothing(index_elements=[Link.url_hash])
                )

            active_hashes = [value for value in hashes if value not in blocked_hashes]
            link_rows = list((await session.scalars(
                select(Link).where(Link.url_hash.in_(active_hashes))
            )).all()) if active_hashes else []
            link_map = {row.url_hash: row for row in link_rows}

            # V6 lifecycle memory: every sighting refreshes last_seen_at and increments
            # seen_count without changing collection into a Telegram validity check.
            now = utcnow()
            counts: dict[str, int] = {}
            for item in items:
                counts[item.clean.url_hash] = counts.get(item.clean.url_hash, 0) + 1
            for url_hash, count in counts.items():
                row = link_map.get(url_hash)
                if not row:
                    continue
                increment = count - (1 if url_hash not in existing_hashes else 0)
                values = {"last_seen_at": now}
                if increment > 0:
                    values["seen_count"] = Link.seen_count + increment
                await session.execute(update(Link).where(Link.id == row.id).values(**values))

            occurrence_rows = []
            for item in items:
                if item.clean.url_hash in blocked_hashes:
                    continue
                row = link_map.get(item.clean.url_hash)
                if not row:
                    continue
                occurrence_rows.append({
                    "link_id": row.id,
                    "job_id": job_id,
                    "source_account_id": item.account_id,
                    "source_chat_id": item.chat_id,
                    "source_message_id": item.message_id,
                    "source_message_date": item.message_date,
                    "seen_at": now,
                })
            if occurrence_rows:
                await session.execute(
                    insert(LinkOccurrence).values(occurrence_rows).on_conflict_do_nothing(
                        index_elements=[
                            LinkOccurrence.link_id, LinkOccurrence.source_account_id,
                            LinkOccurrence.source_chat_id, LinkOccurrence.source_message_id,
                        ]
                    )
                )

            if job_id is not None and link_rows:
                await session.execute(
                    insert(JobLink)
                    .values(
                        [
                            {"job_id": job_id, "link_id": row.id, "was_new": row.url_hash not in existing_hashes}
                            for row in link_rows
                        ]
                    )
                    .on_conflict_do_nothing(index_elements=[JobLink.job_id, JobLink.link_id])
                )

            # Keep a small durable metric showing that a dead URL resurfaced in
            # later history, while refusing to recreate an active ``links`` row.
            if blocked_keys:
                blocked_counts: dict[str, int] = {}
                for item in items:
                    if item.clean.category != "telegram":
                        continue
                    key = telegram_identity_key(item.clean.normalized)
                    if key in blocked_keys:
                        blocked_counts[key] = blocked_counts.get(key, 0) + 1
                for key, count in blocked_counts.items():
                    await session.execute(
                        update(TelegramExpiredLinkBlocklist)
                        .where(TelegramExpiredLinkBlocklist.identity_key == key)
                        .values(
                            rediscovered_count=TelegramExpiredLinkBlocklist.rediscovered_count + count,
                            last_blocked_at=now,
                        )
                    )
            await session.commit()

    seen_in_batch: set[str] = set()
    results: list[LinkRegistration] = []
    for item in items:
        if item.clean.url_hash in blocked_hashes:
            results.append(LinkRegistration(link=None, created=False, blocked=True))
            continue
        link = link_map.get(item.clean.url_hash)
        if link is None:
            raise RuntimeError("فشل تسجيل دفعة الروابط في قاعدة البيانات.")
        created = item.clean.url_hash not in existing_hashes and item.clean.url_hash not in seen_in_batch
        seen_in_batch.add(item.clean.url_hash)
        results.append(LinkRegistration(link=link, created=created, blocked=False))
    return results


async def claim_delivery(link_id: int, destination_chat_id: int, job_id: int | None) -> Delivery | None:
    if reset_in_progress.is_set():
        return None
    async with SessionFactory() as session:
        existing = await session.scalar(
            select(Delivery).where(Delivery.link_id == link_id, Delivery.destination_chat_id == destination_chat_id)
        )
        if existing and existing.status in {"sent", "sending"}:
            return None
        if existing:
            existing.status = "sending"
            existing.job_id = job_id
            existing.error = None
            await session.commit()
            return existing

        statement = (
            insert(Delivery)
            .values(link_id=link_id, destination_chat_id=destination_chat_id, job_id=job_id, status="sending")
            .on_conflict_do_nothing(index_elements=[Delivery.link_id, Delivery.destination_chat_id])
            .returning(Delivery.id)
        )
        delivery_id = (await session.execute(statement)).scalar_one_or_none()
        if delivery_id is None:
            await session.rollback()
            return None
        delivery = await session.get(Delivery, int(delivery_id))
        await session.commit()
        return delivery


async def mark_deliveries_sent(delivery_ids: list[int], telegram_message_id: int) -> None:
    if reset_in_progress.is_set() or not delivery_ids:
        return
    async with SessionFactory() as session:
        await session.execute(
            update(Delivery)
            .where(Delivery.id.in_(delivery_ids))
            .values(status="sent", telegram_message_id=telegram_message_id, error=None)
        )
        await session.commit()


async def mark_deliveries_failed(delivery_ids: list[int], error: str) -> None:
    if reset_in_progress.is_set() or not delivery_ids:
        return
    async with SessionFactory() as session:
        await session.execute(
            update(Delivery).where(Delivery.id.in_(delivery_ids)).values(status="failed", error=error[:2000])
        )
        await session.commit()
