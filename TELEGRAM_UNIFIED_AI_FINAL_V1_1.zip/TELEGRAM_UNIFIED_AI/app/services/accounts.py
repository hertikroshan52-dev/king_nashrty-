from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from sqlalchemy import func, or_, select
from sqlalchemy.dialects.sqlite import insert
from telethon import TelegramClient
from telethon.sessions import SQLiteSession, StringSession

from app.config import get_settings
from app.crypto import SessionCipher
from app.db import SessionFactory
from app.models import Account
from app.services.owners import is_primary_owner

settings = get_settings()
cipher = SessionCipher()


@dataclass(frozen=True, slots=True)
class SessionPackage:
    session: str
    api_id: int
    api_hash: str
    label: str | None = None


def _global_credentials() -> tuple[int, str] | None:
    if settings.telegram_api_id and settings.telegram_api_hash:
        return int(settings.telegram_api_id), settings.telegram_api_hash
    return None


def parse_session_packages(text: str, fallback_label: str | None = None) -> list[SessionPackage]:
    raw = text.strip()
    if not raw:
        raise ValueError("بيانات الجلسة فارغة.")

    parsed: Any = None
    if raw.startswith("{") or raw.startswith("["):
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError("ملف/نص JSON غير صالح.") from exc

    if parsed is None:
        credentials = _global_credentials()
        if not credentials:
            raise ValueError(
                "StringSession وحدها لا تحتوي API_ID وAPI_HASH. أرسل حزمة JSON تحتوي session وapi_id وapi_hash، "
                "أو ضع TELEGRAM_API_ID وTELEGRAM_API_HASH في ملف .env."
            )
        api_id, api_hash = credentials
        return [SessionPackage(raw, api_id, api_hash, fallback_label)]

    items = parsed if isinstance(parsed, list) else [parsed]
    result: list[SessionPackage] = []
    for index, item in enumerate(items, start=1):
        if not isinstance(item, dict):
            raise ValueError(f"العنصر رقم {index} في JSON يجب أن يكون كائنًا.")
        session_string = str(item.get("session") or item.get("string_session") or "").strip()
        api_id_value = item.get("api_id") or settings.telegram_api_id
        api_hash_value = item.get("api_hash") or settings.telegram_api_hash
        if not session_string or not api_id_value or not api_hash_value:
            raise ValueError(f"العنصر رقم {index} يحتاج session وapi_id وapi_hash.")
        default_label = (
            f"{fallback_label} {index}" if fallback_label and len(items) > 1 else fallback_label or f"حساب {index}"
        )
        result.append(
            SessionPackage(
                session=session_string,
                api_id=int(api_id_value),
                api_hash=str(api_hash_value),
                label=str(item.get("label") or default_label)[:120],
            )
        )
    return result


async def validate_string_session(package: SessionPackage) -> dict[str, object]:
    client = TelegramClient(StringSession(package.session.strip()), package.api_id, package.api_hash)
    try:
        await client.connect()
        if not await client.is_user_authorized():
            raise ValueError("الجلسة غير مصرح بها أو منتهية.")
        me = await client.get_me()
        if me is None:
            raise ValueError("تعذر قراءة معلومات الحساب من الجلسة.")
        saved = client.session.save()
        return {
            "session_string": saved,
            "api_id": package.api_id,
            "api_hash": package.api_hash,
            "telegram_user_id": int(me.id),
            "phone": getattr(me, "phone", None),
            "username": getattr(me, "username", None),
            "display_name": " ".join(filter(None, [getattr(me, "first_name", None), getattr(me, "last_name", None)])),
            "label": package.label,
        }
    finally:
        await client.disconnect()


async def convert_sqlite_session(path: Path, label: str | None = None) -> dict[str, object]:
    credentials = _global_credentials()
    if not credentials:
        raise ValueError("ملف .session يحتاج TELEGRAM_API_ID وTELEGRAM_API_HASH داخل ملف .env.")
    api_id, api_hash = credentials
    client = TelegramClient(SQLiteSession(str(path)), api_id, api_hash)
    try:
        await client.connect()
        if not await client.is_user_authorized():
            raise ValueError("ملف الجلسة غير مصرح به أو غير متوافق.")
        me = await client.get_me()
        if me is None:
            raise ValueError("تعذر قراءة الحساب من ملف الجلسة.")
        return {
            "session_string": StringSession.save(client.session),
            "api_id": api_id,
            "api_hash": api_hash,
            "telegram_user_id": int(me.id),
            "phone": getattr(me, "phone", None),
            "username": getattr(me, "username", None),
            "display_name": " ".join(filter(None, [getattr(me, "first_name", None), getattr(me, "last_name", None)])),
            "label": label,
        }
    finally:
        await client.disconnect()
        for suffix in ("", "-journal", "-shm", "-wal"):
            Path(str(path) + suffix).unlink(missing_ok=True)


async def _account_filter_for_operator(operator_id: int):
    # Existing pre-6.4 accounts have operator_id=NULL. Only the primary owner
    # inherits them automatically, which keeps upgrades safe and predictable.
    if await is_primary_owner(operator_id):
        return or_(Account.operator_id == int(operator_id), Account.operator_id.is_(None))
    return Account.operator_id == int(operator_id)


async def save_account(label: str, account_data: dict[str, object], operator_id: int) -> int:
    telegram_user_id = int(account_data["telegram_user_id"])
    operator_id = int(operator_id)
    async with SessionFactory() as session:
        existing = await session.scalar(select(Account).where(Account.telegram_user_id == telegram_user_id))
        if existing is not None:
            if existing.operator_id is not None and int(existing.operator_id) != operator_id:
                raise ValueError("هذا حساب Telegram مرتبط بمشرف آخر ولا يمكن نقله تلقائيًا.")
            if existing.operator_id is None and not await is_primary_owner(operator_id):
                raise ValueError("هذا حساب قديم تابع للمالك الرئيسي ولا يمكن لمشرف آخر استلامه.")
        operator_filter = await _account_filter_for_operator(operator_id)
        account_count = int(await session.scalar(select(func.count(Account.id)).where(operator_filter)) or 0)
        if existing is None and account_count >= max(1, settings.max_telethon_accounts):
            raise ValueError(f"تم الوصول إلى الحد الأقصى لهذا المشرف: {settings.max_telethon_accounts} حسابًا.")

        statement = (
            insert(Account)
            .values(
                operator_id=operator_id,
                label=(label or str(account_data.get("display_name") or "حساب")).strip()[:120],
                telegram_user_id=telegram_user_id,
                phone=account_data.get("phone"),
                username=account_data.get("username"),
                api_id=int(account_data["api_id"]),
                encrypted_api_hash=cipher.encrypt(str(account_data["api_hash"])),
                encrypted_session=cipher.encrypt(str(account_data["session_string"])),
                active=True,
                last_error=None,
            )
            .on_conflict_do_update(
                index_elements=[Account.telegram_user_id],
                set_={
                    "operator_id": operator_id,
                    "label": (label or str(account_data.get("display_name") or "حساب")).strip()[:120],
                    "phone": account_data.get("phone"),
                    "username": account_data.get("username"),
                    "api_id": int(account_data["api_id"]),
                    "encrypted_api_hash": cipher.encrypt(str(account_data["api_hash"])),
                    "encrypted_session": cipher.encrypt(str(account_data["session_string"])),
                    "active": True,
                    "last_error": None,
                },
            )
            .returning(Account.id)
        )
        account_id = (await session.execute(statement)).scalar_one()
        await session.commit()
        return int(account_id)


async def add_packages(
    packages: list[SessionPackage], operator_id: int, fallback_label: str | None = None
) -> list[tuple[int, str]]:
    results: list[tuple[int, str]] = []
    for index, package in enumerate(packages, start=1):
        data = await validate_string_session(package)
        label = package.label or fallback_label or str(data.get("display_name") or f"حساب {index}")
        account_id = await save_account(label, data, operator_id)
        results.append((account_id, label))
    return results


async def list_accounts(operator_id: int | None = None) -> list[Account]:
    async with SessionFactory() as session:
        query = select(Account).order_by(Account.id)
        if operator_id is not None:
            query = query.where(await _account_filter_for_operator(int(operator_id)))
        return list((await session.scalars(query)).all())


async def export_session_packages(operator_id: int) -> list[dict[str, object]]:
    """Return re-importable Telethon session packages for the operator's own accounts.

    Session strings and API hashes are decrypted only for this explicit export
    operation.  The caller is responsible for sending the result privately and
    deleting any temporary plaintext file immediately afterwards.
    """
    rows = await list_accounts(int(operator_id))
    exported: list[dict[str, object]] = []
    for account in rows:
        exported.append(
            {
                "label": account.label,
                "telegram_user_id": int(account.telegram_user_id),
                "username": account.username,
                "api_id": int(account.api_id),
                "api_hash": cipher.decrypt(account.encrypted_api_hash),
                "session": cipher.decrypt(account.encrypted_session),
            }
        )
    return exported


async def account_belongs_to_operator(account: Account | None, operator_id: int) -> bool:
    if account is None:
        return False
    if account.operator_id is not None:
        return int(account.operator_id) == int(operator_id)
    return await is_primary_owner(operator_id)


async def test_account_connection(account_id: int, operator_id: int | None = None) -> dict[str, object]:
    async with SessionFactory() as session:
        account = await session.get(Account, account_id)
    if account is None:
        raise ValueError("الحساب غير موجود.")
    if operator_id is not None and not await account_belongs_to_operator(account, int(operator_id)):
        raise ValueError("هذا الحساب تابع لمشرف آخر.")

    client = TelegramClient(
        StringSession(cipher.decrypt(account.encrypted_session)),
        account.api_id,
        cipher.decrypt(account.encrypted_api_hash),
        auto_reconnect=False,
        connection_retries=2,
        retry_delay=1,
    )
    try:
        await client.connect()
        if not await client.is_user_authorized():
            raise ValueError("الجلسة غير مصرح بها أو انتهت صلاحيتها.")
        me = await client.get_me()
        if me is None:
            raise ValueError("تعذر قراءة معلومات الحساب.")
        return {
            "telegram_user_id": int(me.id),
            "username": getattr(me, "username", None),
            "phone": getattr(me, "phone", None),
            "display_name": " ".join(
                filter(None, [getattr(me, "first_name", None), getattr(me, "last_name", None)])
            ),
        }
    finally:
        await client.disconnect()
