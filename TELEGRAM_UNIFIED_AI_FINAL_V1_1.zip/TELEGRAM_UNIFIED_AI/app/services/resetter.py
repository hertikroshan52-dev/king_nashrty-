from __future__ import annotations

import asyncio
import shutil
from dataclasses import dataclass
from pathlib import Path

from sqlalchemy import delete, func, select, update

from app.config import get_settings
from app.db import SessionFactory
from app.models import (
    Account,
    AccountMembership,
    CollectionCheckpoint,
    SourceStat,
    AppSetting,
    Delivery,
    DestinationConfig,
    Job,
    JobCursor,
    JobLink,
    JoinCandidate,
    Link,
    LinkOccurrence,
    WatchConfig,
    TelegramAudit,
    TelegramAuditInput,
    TelegramAuditResult,
    TelegramAuditTelegramDiscovery,
    TelegramAuditWhatsapp,
    TelegramPeer,
    TelegramPeerAlias,
    TelegramResolutionCache,
    FSMRecord,
)
from app.runtime import live_handlers_suspended, reset_in_progress
from app.services.backup import create_database_backup

settings = get_settings()
_RESET_LOCK = asyncio.Lock()


@dataclass(frozen=True, slots=True)
class ResetResult:
    mode: str
    links: int
    jobs: int
    watches: int
    deliveries: int
    accounts: int
    destinations: int
    audits: int


def _clear_directory(path: Path) -> None:
    if not path.exists():
        return
    for child in path.iterdir():
        try:
            if child.is_dir():
                shutil.rmtree(child)
            else:
                child.unlink(missing_ok=True)
        except OSError:
            # Export cleanup must never make the database reset fail.
            pass


async def reset_collected_data(*, factory: bool) -> ResetResult:
    """Delete collected operational data safely.

    ``factory=True`` also clears destinations/cache/settings that are safe to
    rebuild, but intentionally preserves Telegram accounts, encrypted sessions,
    .env and the session encryption key. Account/session deletion is a separate
    explicit action in account management.
    """
    async with _RESET_LOCK:
        reset_in_progress.set()
        live_handlers_suspended.set()
        try:
            if factory:
                await create_database_backup(prefix="pre_factory_reset")
            async with SessionFactory() as session:
                # Ask any active worker to stop before destructive deletes.
                await session.execute(
                    update(Job)
                    .where(Job.status.in_(["queued", "starting", "running", "pause_requested", "paused", "stopping", "cancel_requested"]))
                    .values(status="cancel_requested")
                )
                await session.execute(update(WatchConfig).values(enabled=False))
                await session.commit()

                counts = {
                    "links": int(await session.scalar(select(func.count(Link.id))) or 0),
                    "jobs": int(await session.scalar(select(func.count(Job.id))) or 0),
                    "watches": int(await session.scalar(select(func.count(WatchConfig.id))) or 0),
                    "deliveries": int(await session.scalar(select(func.count(Delivery.id))) or 0),
                    "accounts": int(await session.scalar(select(func.count(Account.id))) or 0),
                    "destinations": int(await session.scalar(select(func.count(DestinationConfig.owner_id))) or 0),
                    "audits": int(await session.scalar(select(func.count(TelegramAudit.id))) or 0),
                }

                # Explicit dependency order keeps reset portable and predictable.
                await session.execute(delete(TelegramAuditTelegramDiscovery))
                await session.execute(delete(TelegramAuditWhatsapp))
                await session.execute(delete(TelegramPeerAlias))
                await session.execute(delete(TelegramPeer))
                await session.execute(delete(TelegramResolutionCache))
                await session.execute(delete(TelegramAuditResult))
                await session.execute(delete(TelegramAuditInput))
                await session.execute(delete(TelegramAudit))
                await session.execute(delete(Delivery))
                await session.execute(delete(JobCursor))
                await session.execute(delete(JobLink))
                await session.execute(delete(JoinCandidate))
                await session.execute(delete(LinkOccurrence))
                await session.execute(delete(CollectionCheckpoint))
                await session.execute(delete(SourceStat))
                await session.execute(delete(WatchConfig))
                await session.execute(delete(Link))
                await session.execute(delete(Job))

                if factory:
                    await session.execute(delete(DestinationConfig))
                    await session.execute(delete(AccountMembership))
                    await session.execute(delete(FSMRecord))
                    # Accounts, encrypted sessions and AppSetting ownership/roles
                    # are intentionally preserved by safe factory reset.

                await session.commit()

            _clear_directory(settings.exports_dir)
            _clear_directory(settings.tmp_dir)

            return ResetResult(mode="factory" if factory else "collected", **counts)
        except Exception:
            live_handlers_suspended.clear()
            raise
        finally:
            reset_in_progress.clear()
