from __future__ import annotations

import asyncio
import logging
import math
import time
import re
from dataclasses import dataclass
from datetime import timedelta, timezone
from typing import Any

from sqlalchemy import and_, func, or_, select, update
from sqlalchemy.dialects.sqlite import insert
from telethon.errors import FloodWaitError
from telethon.tl.functions.channels import JoinChannelRequest, LeaveChannelRequest, GetParticipantRequest
from telethon.tl.functions.messages import CheckChatInviteRequest, DeleteChatUserRequest, ImportChatInviteRequest
from telethon.tl.types import InputMessagesFilterUrl
from telethon.utils import get_peer_id

from app.config import get_settings
from app.db import SessionFactory
from app.link_utils import extract_urls_from_message, inspect_collection_link
from app.models import CollectionCheckpoint, Link, Job, JoinAssignment, JoinCandidate, utcnow
from app.services.scanner import (
    JobCancelled,
    JobPaused,
    account_items_for_operator,
    ensure_job_active,
    resolve_source_entity,
    set_job_progress,
)

logger = logging.getLogger(__name__)
settings = get_settings()

INVITE_RE = re.compile(
    r"^https?://(?:www\.)?(?:t\.me|telegram\.me)/(?:joinchat/|\+)([A-Za-z0-9_-]+)/?$",
    re.I,
)
PUBLIC_RE = re.compile(
    r"^https?://(?:www\.)?(?:t\.me|telegram\.me)/([A-Za-z0-9_]{4,})/?$",
    re.I,
)

CLEANUP_STATUSES = {"joined"}
MEMBERSHIP_STATUSES = {"joined", "already", "legacy_joined"}
FINAL_NON_GROUP_STATUSES = {"channel", "bot", "personal", "expired", "unsupported", "restricted"}
EXPIRED_ERRORS = {
    "InviteHashEmptyError", "InviteHashExpiredError", "InviteHashInvalidError",
    "UsernameInvalidError", "UsernameNotOccupiedError",
}
ACCOUNT_LIMIT_ERRORS = {"ChannelsTooMuchError", "UserChannelsTooMuchError"}
REQUESTED_ERRORS = {"InviteRequestSentError", "InviteRequestSent"}
ALREADY_ERRORS = {"UserAlreadyParticipantError"}
TRANSIENT_ERRORS = {
    "AuthKeyError", "ConnectionError", "OSError", "PhoneMigrateError",
    "RpcCallFailError", "ServerError", "TimeoutError",
}


@dataclass(slots=True)
class TargetInspection:
    kind: str
    title: str | None = None
    peer_id: int | None = None
    entity: Any | None = None
    already_member: bool = False
    detail: str | None = None


async def _responsive_sleep(job_id: int, seconds: float) -> None:
    remaining = max(0.0, float(seconds))
    while remaining > 0:
        await ensure_job_active(job_id)
        step = min(10.0, remaining)
        await asyncio.sleep(step)
        remaining -= step


async def _load_source_high_water(operator_id: int, source: str) -> int:
    key = f"join-source:{int(operator_id)}:{source}"
    async with SessionFactory() as session:
        row = await session.scalar(
            select(CollectionCheckpoint).where(CollectionCheckpoint.source_key == key)
        )
        return int(row.high_water_message_id or 0) if row else 0


async def _save_source_high_water(
    operator_id: int, source: str, high_water: int, status: str
) -> None:
    key = f"join-source:{int(operator_id)}:{source}"
    now = utcnow()
    async with SessionFactory() as session:
        await session.execute(
            insert(CollectionCheckpoint)
            .values(
                source_key=key,
                high_water_message_id=max(0, int(high_water)),
                category="telegram",
                last_scan_at=now,
                last_status=status,
                updated_at=now,
            )
            .on_conflict_do_update(
                index_elements=[CollectionCheckpoint.source_key],
                set_={
                    "high_water_message_id": max(0, int(high_water)),
                    "category": "telegram",
                    "last_scan_at": now,
                    "last_status": status,
                    "updated_at": now,
                },
            )
        )
        await session.commit()


async def collect_join_candidates(job: Job, manager: Any) -> dict[str, int]:
    """Collect source links in batches and advance high-water only on success."""
    if not job.sources:
        raise ValueError("مهمة الانضمام لا تحتوي قناة/مجموعة مصدر.")
    source = str(job.sources[0]).strip()
    if source == "database:telegram":
        added = found = 0
        last_id = 0
        while True:
            await ensure_job_active(job.id)
            async with SessionFactory() as session:
                rows = list((await session.scalars(select(Link).where(Link.category == "telegram", Link.id > last_id).order_by(Link.id).limit(200))).all())
                if not rows:
                    break
                last_id = rows[-1].id
                found += len(rows)
                result = await session.execute(insert(JoinCandidate).values([{
                    "requested_by": int(job.requested_by), "original_url": row.original_url,
                    "normalized_url": row.normalized_url, "source_url": source, "status": "pending"
                } for row in rows]).on_conflict_do_nothing(index_elements=[JoinCandidate.requested_by, JoinCandidate.normalized_url]).returning(JoinCandidate.id))
                added += len(list(result.scalars()))
                await session.commit()
        return {"messages": 0, "found": found, "added": added}
    clients = sorted(await account_items_for_operator(manager, int(job.requested_by)), key=lambda item: item[0])
    if not clients:
        raise RuntimeError("لا توجد حسابات Telethon فعالة لهذا المشرف.")

    baseline = await _load_source_high_water(int(job.requested_by), source)
    high_water = baseline
    scanned = found = added = 0
    last_error: BaseException | None = None
    batch_size = max(50, int(getattr(settings, "collector_db_batch_links", 500)))

    async def flush(rows: list[dict[str, object]]) -> int:
        if not rows:
            return 0
        async with SessionFactory() as session:
            result = await session.execute(
                insert(JoinCandidate)
                .values(rows)
                .on_conflict_do_nothing(
                    index_elements=[JoinCandidate.requested_by, JoinCandidate.normalized_url]
                )
                .returning(JoinCandidate.id)
            )
            count = len(list(result.scalars().all()))
            await session.commit()
            return count

    for account_id, _client in clients:
        pending_rows: list[dict[str, object]] = []
        try:
            client = await manager.ensure_connected(account_id)
            entity = await resolve_source_entity(client, source)
            async for message in client.iter_messages(
                entity, filter=InputMessagesFilterUrl, min_id=max(0, baseline)
            ):
                await ensure_job_active(job.id)
                scanned += 1
                message_id = int(getattr(message, "id", 0) or 0)
                high_water = max(high_water, message_id)
                for raw_url in extract_urls_from_message(message):
                    inspection = inspect_collection_link(raw_url, "telegram")
                    if not inspection.link:
                        continue
                    clean = inspection.link
                    if clean.normalized.rstrip("/").lower() == source.rstrip("/").lower():
                        continue
                    found += 1
                    pending_rows.append({
                        "requested_by": int(job.requested_by),
                        "original_url": raw_url,
                        "normalized_url": clean.normalized,
                        "source_url": source,
                        "status": "pending",
                        "attempts": 0,
                        "created_at": utcnow(),
                        "updated_at": utcnow(),
                    })
                if len(pending_rows) >= batch_size:
                    added += await flush(pending_rows)
                    pending_rows.clear()
                if scanned % 100 == 0:
                    progress = dict(job.progress or {})
                    progress.update({
                        "phase": "collecting_join_candidates",
                        "join_source_messages": scanned,
                        "join_candidates_found": found,
                        "join_candidates_new": added,
                    })
                    await set_job_progress(job.id, progress)
            added += await flush(pending_rows)
            await _save_source_high_water(int(job.requested_by), source, high_water, "completed")
            return {"messages": scanned, "found": found, "added": added}
        except (JobCancelled, JobPaused):
            await _save_source_high_water(int(job.requested_by), source, baseline, "paused")
            raise
        except Exception as exc:
            last_error = exc
            logger.warning("Join source read failed account=%s source=%s: %s", account_id, source, exc)
            await _save_source_high_water(int(job.requested_by), source, baseline, "error")
            continue

    raise RuntimeError(f"تعذر قراءة قناة/مجموعة روابط الانضمام: {last_error}")


def _peer_fields(entity: Any) -> tuple[str, str | None, int | None]:
    name = type(entity).__name__
    title = str(getattr(entity, "title", "") or "").strip() or None
    peer_id_raw = getattr(entity, "id", None)
    try:
        peer_id = int(peer_id_raw) if peer_id_raw is not None else None
    except (TypeError, ValueError):
        peer_id = None
    if peer_id is not None:
        try:
            peer_id = int(get_peer_id(entity))
        except (TypeError, ValueError):
            pass
    if name.startswith("User") or hasattr(entity, "bot"):
        return ("bot" if bool(getattr(entity, "bot", False)) else "personal", title, peer_id)
    if bool(getattr(entity, "broadcast", False)) and not bool(getattr(entity, "megagroup", False)):
        return "channel", title, peer_id
    if name.startswith("Chat") or name.startswith("Channel") or bool(getattr(entity, "megagroup", False)):
        return "group", title, peer_id
    return "unsupported", title, peer_id


async def _inspect_join_target(client: Any, url: str) -> TargetInspection:
    invite = INVITE_RE.fullmatch(url.rstrip("/"))
    if invite:
        result = await client(CheckChatInviteRequest(invite.group(1)))
        if type(result).__name__ == "ChatInviteAlready":
            entity = getattr(result, "chat", None)
            kind, title, peer_id = _peer_fields(entity)
            return TargetInspection(kind, title, peer_id, entity, True, "already participant")
        entity = getattr(result, "chat", None) or result
        kind, title, peer_id = _peer_fields(entity)
        return TargetInspection(kind, title, peer_id, entity, False)

    public = PUBLIC_RE.fullmatch(url.rstrip("/"))
    if public:
        entity = await client.get_entity("@" + public.group(1))
        kind, title, peer_id = _peer_fields(entity)
        already = hasattr(entity, "left") and not bool(getattr(entity, "left", True))
        return TargetInspection(kind, title, peer_id, entity, already)

    return TargetInspection("unsupported", detail="unsupported Telegram join URL")


async def _join_group(client: Any, url: str, inspection: TargetInspection) -> Any | None:
    invite = INVITE_RE.fullmatch(url.rstrip("/"))
    if invite:
        updates = await client(ImportChatInviteRequest(invite.group(1)))
        chats = list(getattr(updates, "chats", None) or [])
        return chats[0] if chats else None
    public = PUBLIC_RE.fullmatch(url.rstrip("/"))
    if public:
        await client(JoinChannelRequest(inspection.entity or ("@" + public.group(1))))
        return inspection.entity
    raise ValueError("رابط Telegram غير مدعوم للانضمام.")


async def _update_candidate(candidate_id: int, **values: Any) -> None:
    values["updated_at"] = utcnow()
    async with SessionFactory() as session:
        await session.execute(update(JoinCandidate).where(JoinCandidate.id == int(candidate_id)).values(**values))
        await session.commit()


async def _update_assignment(assignment_id: int, **values: Any) -> None:
    values["updated_at"] = utcnow()
    async with SessionFactory() as session:
        await session.execute(update(JoinAssignment).where(JoinAssignment.id == int(assignment_id)).values(**values))
        await session.commit()


async def seed_legacy_assignments_for_job(job: Job) -> int:
    """Attach V7 joined rows to a V8 job so resume and cleanup stay possible."""
    if job.mode != "join_groups":
        return 0
    source = str(job.sources[0]).strip() if job.sources else None
    async with SessionFactory() as session:
        query = select(JoinCandidate).where(
            JoinCandidate.requested_by == int(job.requested_by),
            JoinCandidate.status == "joined",
            JoinCandidate.assigned_account_id.is_not(None),
            JoinCandidate.id.not_in(select(JoinAssignment.candidate_id)),
        )
        if source:
            query = query.where(JoinCandidate.source_url == source)
        rows = list((await session.scalars(query.order_by(JoinCandidate.id))).all())
        values = [{
            "job_id": int(job.id),
            "requested_by": int(job.requested_by),
            "candidate_id": int(row.id),
            "account_id": int(row.assigned_account_id),
            "status": "legacy_joined",
            "attempts": max(1, int(row.attempts or 1)),
            "detail": "Imported from V7 join_candidates",
            "legacy_imported": True,
            "joined_at": row.joined_at or row.updated_at,
            "created_at": row.created_at,
            "updated_at": utcnow(),
        } for row in rows]
        added = 0
        for offset in range(0, len(values), 200):
            result = await session.execute(
                insert(JoinAssignment).values(values[offset:offset+200]).on_conflict_do_nothing(
                    index_elements=[JoinAssignment.job_id, JoinAssignment.candidate_id]
                ).returning(JoinAssignment.id)
            )
            added += len(list(result.scalars().all()))
        # V7 marked every general exception as a terminal error.  Requeue those
        # one time (bounded by the V8 attempt limit) so temporary network errors
        # from the interrupted task can be classified correctly after upgrade.
        await session.execute(
            update(JoinCandidate).where(
                JoinCandidate.requested_by == int(job.requested_by),
                JoinCandidate.source_url == source,
                JoinCandidate.status == "error",
                JoinCandidate.attempts < max(1, int(settings.join_max_attempts)),
            ).values(status="retry", assigned_account_id=None, updated_at=utcnow())
        )
        await session.commit()
        return added


async def _prepare_join_resume(job: Job) -> None:
    now = utcnow()
    async with SessionFactory() as session:
        await session.execute(update(JoinAssignment).where(JoinAssignment.job_id == job.id, JoinAssignment.status == "allocated").values(status="ready_group"))
        candidate_ids = list((await session.scalars(select(JoinAssignment.candidate_id).where(
            JoinAssignment.job_id == int(job.id),
            JoinAssignment.status.in_(["joining", "waiting_flood"]),
        ))).all())
        await session.execute(
            update(JoinAssignment).where(
                JoinAssignment.job_id == int(job.id),
                JoinAssignment.status.in_(["joining", "waiting_flood"]),
            ).values(status="retry", attempts=0, detail="Recovered after pause/restart", updated_at=now)
        )
        await session.execute(
            update(JoinCandidate).where(JoinCandidate.id.in_(candidate_ids)).values(
                status="retry", assigned_account_id=None, updated_at=now
            )
        )
        await session.commit()


async def _account_membership_count(job_id: int, account_id: int) -> int:
    async with SessionFactory() as session:
        return int(await session.scalar(select(func.count(JoinAssignment.id)).where(
            JoinAssignment.job_id == int(job_id),
            JoinAssignment.account_id == int(account_id),
            JoinAssignment.status.in_(MEMBERSHIP_STATUSES),
            JoinAssignment.left_at.is_(None),
        )) or 0)


async def _claim_candidate(
    job: Job, account_id: int, source: str, claim_lock: asyncio.Lock, *,
    allow_ready_group: bool = True,
) -> tuple[JoinAssignment, JoinCandidate] | None:
    max_attempts = max(1, int(getattr(settings, "join_max_attempts", 3)))
    candidate_statuses = ["pending", "retry", "ready_group"] if allow_ready_group else ["pending", "retry"]
    async with claim_lock:
        async with SessionFactory() as session:
            retry_row = await session.execute(
                select(JoinAssignment, JoinCandidate)
                .join(JoinCandidate, JoinCandidate.id == JoinAssignment.candidate_id)
                .where(
                    JoinAssignment.job_id == int(job.id),
                    JoinCandidate.requested_by == int(job.requested_by),
                    JoinCandidate.source_url == source,
                    or_(
                        JoinAssignment.status == "ready_group" if allow_ready_group else False,
                        and_(
                            JoinAssignment.status == "retry",
                            JoinAssignment.attempts < max_attempts,
                            or_(JoinAssignment.next_retry_at.is_(None), JoinAssignment.next_retry_at <= utcnow()),
                        ),
                    ),
                ).order_by(JoinAssignment.id).limit(1)
            )
            pair = retry_row.first()
            if pair:
                assignment, candidate = pair
                assignment.account_id = int(account_id)
                assignment.status = "joining"
                assignment.attempts = int(assignment.attempts or 0) + 1
                assignment.updated_at = utcnow()
                candidate.status = "joining"
                candidate.assigned_account_id = int(account_id)
                candidate.attempts = int(candidate.attempts or 0) + 1
                candidate.updated_at = utcnow()
                await session.commit()
                return assignment, candidate

            assigned_ids = select(JoinAssignment.candidate_id).where(JoinAssignment.job_id == int(job.id))
            candidate = await session.scalar(
                select(JoinCandidate).where(
                    JoinCandidate.requested_by == int(job.requested_by),
                    JoinCandidate.status.in_(candidate_statuses),
                    JoinCandidate.source_url == source,
                    JoinCandidate.id.not_in(assigned_ids),
                ).order_by(JoinCandidate.id).limit(1)
            )
            if candidate is None:
                return None
            candidate.status = "joining"
            candidate.assigned_account_id = int(account_id)
            candidate.attempts = int(candidate.attempts or 0) + 1
            candidate.updated_at = utcnow()
            assignment = JoinAssignment(
                job_id=int(job.id), requested_by=int(job.requested_by),
                candidate_id=int(candidate.id), account_id=int(account_id),
                status="joining", attempts=1,
            )
            session.add(assignment)
            await session.commit()
            await session.refresh(assignment)
            return assignment, candidate


async def _verify_membership(client: Any, url: str, inspection: TargetInspection) -> bool:
    if inspection.entity is not None and type(inspection.entity).__name__.startswith('Channel'):
        result = await client(GetParticipantRequest(inspection.entity, 'me'))
        participant = getattr(result, 'participant', None)
        return participant is not None and type(participant).__name__ not in {'ChannelParticipantLeft', 'ChannelParticipantBanned'}
    checked = await _inspect_join_target(client, url)
    return checked.kind in {'group', 'channel'} and checked.already_member


async def _allocate_group_blocks(job: Job, account_ids: list[int], target: int) -> set[int]:
    """Reserve stable blocks in one transaction, deduplicating known peer IDs."""
    allocated: set[int] = set()
    async with SessionFactory() as session:
        rows = list((await session.scalars(select(JoinAssignment).where(
            JoinAssignment.job_id == job.id,
            JoinAssignment.status.in_(MEMBERSHIP_STATUSES | {'ready_group'})
        ).order_by(JoinAssignment.candidate_id))).all())
        seen = {row.peer_id for row in rows if row.status in MEMBERSHIP_STATUSES and row.peer_id is not None}
        pool = []
        for row in rows:
            if row.status != 'ready_group':
                continue
            if row.peer_id is not None and row.peer_id in seen:
                row.status = 'duplicate'
                await session.execute(update(JoinCandidate).where(JoinCandidate.id == row.candidate_id).values(status='duplicate', updated_at=utcnow()))
                continue
            if row.peer_id is not None:
                seen.add(row.peer_id)
            pool.append(row)
        offset = 0
        for account_id in account_ids:
            completed = sum(1 for row in rows if row.account_id == account_id and row.status in MEMBERSHIP_STATUSES and row.left_at is None)
            count = min(max(0, target - completed), len(pool) - offset)
            for row in pool[offset:offset + count]:
                row.account_id = account_id
                row.status = 'allocated'
                row.attempts = 0
                row.updated_at = utcnow()

            if count:
                ids = [row.candidate_id for row in pool[offset:offset + count]]
                for pos in range(0, len(ids), 500):
                    await session.execute(update(JoinCandidate).where(JoinCandidate.id.in_(ids[pos:pos+500])).values(status="allocated", assigned_account_id=account_id, updated_at=utcnow()))
                allocated.add(account_id)
            offset += count
        await session.commit()
    return allocated


async def _claim_allocated(job: Job, account_id: int) -> tuple[JoinAssignment, JoinCandidate] | None:
    async with SessionFactory() as session:
        pair = (await session.execute(select(JoinAssignment, JoinCandidate).join(
            JoinCandidate, JoinCandidate.id == JoinAssignment.candidate_id
        ).where(JoinAssignment.job_id == job.id, JoinAssignment.account_id == account_id,
                JoinAssignment.status == 'allocated').order_by(JoinAssignment.candidate_id).limit(1))).first()
        if not pair:
            return None
        assignment, candidate = pair
        assignment.status = candidate.status = 'joining'
        assignment.attempts += 1
        candidate.attempts += 1
        await session.commit()
        return assignment, candidate


async def _join_progress_snapshot(
    job: Job, source_stats: dict[str, int], account_states: dict[int, dict[str, Any]],
    per_account_limit: int, delay_seconds: int,
) -> dict[str, Any]:
    async with SessionFactory() as session:
        status_rows = (await session.execute(
            select(JoinAssignment.status, func.count(JoinAssignment.id))
            .where(JoinAssignment.job_id == int(job.id)).group_by(JoinAssignment.status)
        )).all()
        status_counts = {str(status): int(count) for status, count in status_rows}
        pending = int(await session.scalar(select(func.count(JoinCandidate.id)).where(
            JoinCandidate.requested_by == int(job.requested_by),
            JoinCandidate.source_url == str(job.sources[0]).strip(),
            JoinCandidate.status.in_(["pending", "retry", "ready_group"]),
        )) or 0)
        ready_groups = int(await session.scalar(select(func.count(JoinAssignment.id)).where(
            JoinAssignment.job_id == int(job.id),
            JoinAssignment.status == "ready_group",
        )) or 0)
        assigned = int(await session.scalar(select(func.count(JoinAssignment.id)).where(
            JoinAssignment.job_id == int(job.id)
        )) or 0)

    completed = sum(status_counts.get(key, 0) for key in MEMBERSHIP_STATUSES)
    incomplete_accounts = sum(
        1 for row in account_states.values()
        if int(row.get("completed_memberships", 0)) < per_account_limit
    )
    return {
        **dict(job.progress or {}),
        "phase": "joining",
        "join_per_account": per_account_limit,
        "join_delay_seconds": delay_seconds,
        "join_accounts": len(account_states),
        "join_source_messages": source_stats.get("messages", 0),
        "join_candidates_found": source_stats.get("found", 0),
        "join_candidates_new": source_stats.get("added", 0),
        "join_assigned": assigned,
        "join_joined": status_counts.get("joined", 0),
        "join_already": status_counts.get("already", 0) + status_counts.get("legacy_joined", 0),
        "join_completed_memberships": completed,
        "join_requested": status_counts.get("requested", 0),
        "join_channels": status_counts.get("channel", 0),
        "join_bots": status_counts.get("bot", 0),
        "join_personal": status_counts.get("personal", 0),
        "join_expired": status_counts.get("expired", 0),
        "join_unsupported": status_counts.get("unsupported", 0) + status_counts.get("restricted", 0),
        "join_errors": status_counts.get("error", 0) + sum(1 for row in account_states.values() if row.get("status") == "error"),
        "join_flood_waits": sum(int(row.get("flood_waits", 0)) for row in account_states.values()),
        "join_account_limits": sum(1 for row in account_states.values() if row.get("status") == "account_limit"),
        "join_pending": pending,
        "join_ready_groups": ready_groups,
        "join_incomplete_accounts": incomplete_accounts,
        "join_additional_accounts_estimate": math.ceil(ready_groups / per_account_limit) if ready_groups else 0,
        "account_report": {str(key): value for key, value in account_states.items()},
    }


async def _send_assignment_backup_to_saved_messages(job: Job, manager: Any, account_id: int) -> tuple[int, str | None]:
    """Persist the fixed plan in the account's Saved Messages before joining.

    Only assignments that have not previously been backed up are sent.  The
    timestamp is committed after Telegram accepts the message chunk, making a
    restart safe and preventing duplicate backup messages in normal operation.
    """
    async with SessionFactory() as session:
        pairs = (await session.execute(
            select(JoinAssignment, JoinCandidate)
            .join(JoinCandidate, JoinCandidate.id == JoinAssignment.candidate_id)
            .where(
                JoinAssignment.job_id == int(job.id),
                JoinAssignment.account_id == int(account_id),
                JoinAssignment.saved_message_sent_at.is_(None),
            )
            .order_by(JoinAssignment.id)
        )).all()
    if not pairs:
        return 0, None

    client = await manager.ensure_connected(int(account_id))
    label = getattr(manager.account_records.get(int(account_id)), "label", f"حساب {account_id}")
    sent = 0
    chunk_size = 25
    for offset in range(0, len(pairs), chunk_size):
        chunk = pairs[offset:offset + chunk_size]
        lines = [
            f"نسخة احتياطية لمهمة الانضمام #{job.id}",
            f"الحساب: {label} (#{account_id})",
            f"الدفعة: {offset + 1}-{offset + len(chunk)} من {len(pairs)}",
            "الروابط المحجوزة لهذا الحساب فقط:",
            "",
        ]
        lines.extend(candidate.normalized_url for _assignment, candidate in chunk)
        detail = None
        delivered = False
        for attempt in range(1, max(2, int(settings.join_max_attempts)) + 1):
            try:
                await client.send_message("me", "\n".join(lines), link_preview=False)
                delivered = True
                break
            except FloodWaitError as exc:
                detail = f"FloodWait {int(exc.seconds)}s while backing up Saved Messages"
                await _responsive_sleep(job.id, int(exc.seconds) + 1)
            except Exception as exc:
                detail = f"{type(exc).__name__}: {exc}"[:1000]
                if attempt < max(2, int(settings.join_max_attempts)):
                    await _responsive_sleep(job.id, 5)
        if not delivered:
            async with SessionFactory() as session:
                await session.execute(update(JoinAssignment).where(
                    JoinAssignment.id.in_([assignment.id for assignment, _candidate in chunk])
                ).values(saved_message_error=detail or "Saved Messages backup failed", updated_at=utcnow()))
                await session.commit()
            return sent, detail or "Saved Messages backup failed"
        now = utcnow()
        async with SessionFactory() as session:
            await session.execute(update(JoinAssignment).where(
                JoinAssignment.id.in_([assignment.id for assignment, _candidate in chunk])
            ).values(saved_message_sent_at=now, saved_message_error=None, updated_at=now))
            await session.commit()
        sent += len(chunk)
    return sent, None


async def _fixed_join_snapshot(job: Job, account_states: dict[int, dict[str, Any]]) -> dict[str, Any]:
    async with SessionFactory() as session:
        rows = (await session.execute(
            select(JoinAssignment.status, func.count(JoinAssignment.id))
            .where(JoinAssignment.job_id == int(job.id))
            .group_by(JoinAssignment.status)
        )).all()
        status_counts = {str(status): int(count) for status, count in rows}
        saved = int(await session.scalar(select(func.count(JoinAssignment.id)).where(
            JoinAssignment.job_id == int(job.id), JoinAssignment.saved_message_sent_at.is_not(None)
        )) or 0)
        saved_errors = int(await session.scalar(select(func.count(JoinAssignment.id)).where(
            JoinAssignment.job_id == int(job.id), JoinAssignment.saved_message_error.is_not(None)
        )) or 0)
        assigned = int(await session.scalar(select(func.count(JoinAssignment.id)).where(
            JoinAssignment.job_id == int(job.id)
        )) or 0)

    terminal = {
        "joined", "already", "legacy_joined", "requested", "expired", "channel", "bot", "personal",
        "unsupported", "restricted", "error", "banned", "removed_after_join", "account_limit",
    }
    processed = sum(status_counts.get(key, 0) for key in terminal)
    completed = sum(status_counts.get(key, 0) for key in MEMBERSHIP_STATUSES)
    incomplete = sum(1 for row in account_states.values() if int(row.get("processed", 0)) < int(row.get("assigned", 0)))
    return {
        **dict(job.progress or {}),
        "phase": "joining",
        "join_assigned": assigned,
        "join_processed": processed,
        "join_joined": status_counts.get("joined", 0),
        "join_already": status_counts.get("already", 0) + status_counts.get("legacy_joined", 0),
        "join_completed_memberships": completed,
        "join_requested": status_counts.get("requested", 0),
        "join_expired": status_counts.get("expired", 0),
        "join_banned": status_counts.get("banned", 0),
        "join_removed_after_join": status_counts.get("removed_after_join", 0),
        "join_account_limit_links": status_counts.get("account_limit", 0),
        "join_errors": status_counts.get("error", 0),
        "join_flood_waits": sum(int(row.get("flood_waits", 0)) for row in account_states.values()),
        "join_account_limits": sum(1 for row in account_states.values() if row.get("status") == "account_limit"),
        "join_incomplete_accounts": incomplete,
        "join_pending": status_counts.get("allocated", 0) + status_counts.get("joining", 0) + status_counts.get("waiting_flood", 0),
        "join_ready_groups": 0,
        "join_additional_accounts_estimate": 0,
        "join_saved_messages_backed_up": saved,
        "join_saved_messages_errors": saved_errors,
        "account_report": {str(key): value for key, value in account_states.items()},
    }


async def process_join_groups_job(job: Job, manager: Any) -> dict[str, Any]:
    """Execute a pre-planned fixed distribution from completed audit results.

    V8.2 deliberately does not collect or classify a source here.  The join
    section consumes only durable assignments created from the audit database.
    Each URL remains bound to one account for the lifetime of the job.
    """
    progress = dict(job.progress or {})
    if progress.get("join_distribution_mode") != "fixed":
        raise ValueError("هذه مهمة انضمام قديمة غير موزعة. أنشئ مهمة جديدة من قسم الانضمام بعد اكتمال فحص الروابط.")
    per_account_limit = int(progress.get("join_per_account") or 200)
    if per_account_limit not in {200, 500}:
        raise ValueError("هدف التوزيع يجب أن يكون 200 أو 500 رابط لكل حساب.")
    delay_seconds = max(180, int(progress.get("join_delay_seconds") or settings.join_delay_seconds))
    target_kind = str(progress.get("join_target_kind") or "all")
    allowed_kinds = {"group"} if target_kind == "groups" else ({"channel"} if target_kind == "channels" else {"group", "channel"})

    clients = dict(await account_items_for_operator(manager, int(job.requested_by)))
    async with SessionFactory() as session:
        assignment_rows = (await session.execute(
            select(JoinAssignment.account_id, func.count(JoinAssignment.id))
            .where(JoinAssignment.job_id == int(job.id))
            .group_by(JoinAssignment.account_id)
            .order_by(JoinAssignment.account_id)
        )).all()
    if not assignment_rows:
        raise ValueError("مهمة الانضمام لا تحتوي توزيعًا محفوظًا.")

    account_states: dict[int, dict[str, Any]] = {}
    active_statuses = {"allocated", "joining", "retry", "waiting_flood"}
    async with SessionFactory() as session:
        for account_id_raw, assigned_raw in assignment_rows:
            account_id = int(account_id_raw)
            record = manager.account_records.get(account_id)
            processed = int(await session.scalar(select(func.count(JoinAssignment.id)).where(
                JoinAssignment.job_id == int(job.id), JoinAssignment.account_id == account_id,
                ~JoinAssignment.status.in_(active_statuses),
            )) or 0)
            completed = int(await session.scalar(select(func.count(JoinAssignment.id)).where(
                JoinAssignment.job_id == int(job.id), JoinAssignment.account_id == account_id,
                JoinAssignment.status.in_(MEMBERSHIP_STATUSES),
            )) or 0)
            saved = int(await session.scalar(select(func.count(JoinAssignment.id)).where(
                JoinAssignment.job_id == int(job.id), JoinAssignment.account_id == account_id,
                JoinAssignment.saved_message_sent_at.is_not(None),
            )) or 0)
            account_states[account_id] = {
                "label": getattr(record, "label", f"حساب {account_id}"),
                "status": "pending",
                "assigned": int(assigned_raw),
                "processed": processed,
                "completed_memberships": completed,
                "target": int(assigned_raw),
                "flood_waits": 0,
                "saved_messages": saved,
                "saved_messages_error": None,
                "last_error": None,
            }

    # Back up the exact fixed distribution before any join request is attempted.
    for account_id, state in account_states.items():
        await ensure_job_active(job.id)
        if account_id not in clients:
            state["status"] = "account_unavailable"
            state["last_error"] = "الحساب غير متصل أو لم يعد تابعًا للمشرف."
            continue
        try:
            sent, error = await _send_assignment_backup_to_saved_messages(job, manager, account_id)
            state["saved_messages"] = sent
            state["saved_messages_error"] = error
            if error:
                state["status"] = "saved_messages_error"
                state["last_error"] = error
        except Exception as exc:
            state["saved_messages_error"] = f"{type(exc).__name__}: {exc}"[:1000]
            state["status"] = "saved_messages_error"
            state["last_error"] = state["saved_messages_error"]

    await set_job_progress(job.id, await _fixed_join_snapshot(job, account_states))

    banned_errors = {
        "UserBannedInChannelError", "UserKickedError", "ChannelPrivateError",
        "ChatAdminRequiredError", "UserNotMutualContactError",
    }

    async def finalize(assignment: JoinAssignment, candidate: JoinCandidate, status: str, *,
                       inspection: TargetInspection | None = None, detail: str | None = None,
                       joined: bool = False) -> None:
        values: dict[str, Any] = {"status": status, "detail": detail, "next_retry_at": None}
        if inspection:
            values.update({"peer_id": inspection.peer_id, "peer_type": inspection.kind, "title": inspection.title})
        if joined:
            values["joined_at"] = utcnow()
        async with SessionFactory() as session:
            await session.execute(update(JoinAssignment).where(JoinAssignment.id == assignment.id).values(**values, updated_at=utcnow()))
            await session.execute(update(JoinCandidate).where(JoinCandidate.id == candidate.id).values(
                status="joined" if status in MEMBERSHIP_STATUSES else status,
                assigned_account_id=int(assignment.account_id), detail=detail,
                joined_at=utcnow() if joined else candidate.joined_at, updated_at=utcnow(),
            ))
            await session.commit()

    async def mark_remaining(account_id: int, status: str, detail: str) -> None:
        async with SessionFactory() as session:
            ids = list((await session.scalars(select(JoinAssignment.id).where(
                JoinAssignment.job_id == int(job.id), JoinAssignment.account_id == int(account_id),
                JoinAssignment.status.in_(["allocated", "retry", "waiting_flood"]),
            ))).all())
            if ids:
                await session.execute(update(JoinAssignment).where(JoinAssignment.id.in_(ids)).values(
                    status=status, detail=detail, next_retry_at=None, updated_at=utcnow()
                ))
                await session.commit()

    async def claim_next(account_id: int) -> tuple[JoinAssignment, JoinCandidate] | None:
        async with SessionFactory() as session:
            pair = (await session.execute(select(JoinAssignment, JoinCandidate).join(
                JoinCandidate, JoinCandidate.id == JoinAssignment.candidate_id
            ).where(
                JoinAssignment.job_id == int(job.id), JoinAssignment.account_id == int(account_id),
                JoinAssignment.status.in_(["allocated", "retry", "waiting_flood"]),
            ).order_by(JoinAssignment.id).limit(1))).first()
            if not pair:
                return None
            assignment, candidate = pair
            if assignment.next_retry_at:
                deadline = assignment.next_retry_at
                if deadline.tzinfo is None:
                    deadline = deadline.replace(tzinfo=timezone.utc)
                if deadline > utcnow():
                    return assignment, candidate
            assignment.status = "joining"
            assignment.attempts = int(assignment.attempts or 0) + 1
            candidate.attempts = int(candidate.attempts or 0) + 1
            candidate.status = "joining"
            await session.commit()
            return assignment, candidate

    async def worker(account_id: int) -> None:
        state = account_states[account_id]
        if account_id not in clients:
            await mark_remaining(account_id, "error", "account unavailable before join")
            return
        if state.get("saved_messages_error"):
            return
        client = await manager.ensure_connected(account_id)
        state["status"] = "running"
        while True:
            await ensure_job_active(job.id)
            claimed = await claim_next(account_id)
            if claimed is None:
                state["status"] = "completed"
                return
            assignment, candidate = claimed
            if assignment.next_retry_at:
                deadline = assignment.next_retry_at
                if deadline.tzinfo is None:
                    deadline = deadline.replace(tzinfo=timezone.utc)
                if deadline > utcnow():
                    await _responsive_sleep(job.id, max(0, (deadline - utcnow()).total_seconds()))
                    continue
            inspection: TargetInspection | None = None
            should_delay = True
            try:
                inspection = await _inspect_join_target(client, candidate.normalized_url)
                if inspection.kind not in allowed_kinds:
                    await finalize(assignment, candidate, "unsupported", inspection=inspection,
                                   detail=f"نوع الرابط تغيّر بعد الفحص إلى {inspection.kind}")
                elif inspection.already_member:
                    await finalize(assignment, candidate, "already", inspection=inspection,
                                   detail="already participant", joined=True)
                    state["completed_memberships"] += 1
                else:
                    joined_entity = await _join_group(client, candidate.normalized_url, inspection)
                    if joined_entity is not None:
                        kind, title, peer_id = _peer_fields(joined_entity)
                        inspection.kind = kind
                        inspection.title = title or inspection.title
                        inspection.peer_id = peer_id or inspection.peer_id
                        inspection.entity = joined_entity
                    if not await _verify_membership(client, candidate.normalized_url, inspection):
                        await finalize(assignment, candidate, "removed_after_join", inspection=inspection,
                                       detail="Telegram did not confirm membership immediately after join")
                    else:
                        await finalize(assignment, candidate, "joined", inspection=inspection,
                                       detail="membership completed", joined=True)
                        state["completed_memberships"] += 1
            except (JobCancelled, JobPaused):
                raise
            except FloodWaitError as exc:
                state["flood_waits"] += 1
                wait_seconds = max(delay_seconds, int(exc.seconds) + 1)
                state["last_error"] = f"FloodWait {int(exc.seconds)}s"
                await _update_assignment(assignment.id, status="waiting_flood",
                                         next_retry_at=utcnow() + timedelta(seconds=wait_seconds),
                                         detail=state["last_error"])
                await _update_candidate(candidate.id, status="retry", assigned_account_id=account_id,
                                        detail=state["last_error"])
                await _responsive_sleep(job.id, wait_seconds)
                should_delay = False
            except Exception as exc:
                name = type(exc).__name__
                detail = f"{name}: {exc}"[:1000]
                state["last_error"] = detail
                if name in ALREADY_ERRORS:
                    await finalize(assignment, candidate, "already", inspection=inspection, detail=detail, joined=True)
                    state["completed_memberships"] += 1
                elif name in REQUESTED_ERRORS:
                    await finalize(assignment, candidate, "requested", inspection=inspection, detail=detail)
                elif name in EXPIRED_ERRORS:
                    await finalize(assignment, candidate, "expired", inspection=inspection, detail=detail)
                elif name in ACCOUNT_LIMIT_ERRORS:
                    await finalize(assignment, candidate, "account_limit", inspection=inspection, detail=detail)
                    state["status"] = "account_limit"
                    await mark_remaining(account_id, "account_limit", "لم تتم المحاولة: الحساب وصل إلى حد عضويات Telegram")
                    return
                elif name in banned_errors:
                    await finalize(assignment, candidate, "banned", inspection=inspection, detail=detail)
                else:
                    transient = name in TRANSIENT_ERRORS or isinstance(exc, (OSError, asyncio.TimeoutError))
                    if transient and int(assignment.attempts or 0) < max(1, int(settings.join_max_attempts)):
                        await _update_assignment(assignment.id, status="retry", detail=detail, next_retry_at=None)
                        await _update_candidate(candidate.id, status="retry", assigned_account_id=account_id, detail=detail)
                        should_delay = False
                    else:
                        await finalize(assignment, candidate, "error", inspection=inspection, detail=detail)

            async with SessionFactory() as session:
                state["processed"] = int(await session.scalar(select(func.count(JoinAssignment.id)).where(
                    JoinAssignment.job_id == int(job.id), JoinAssignment.account_id == int(account_id),
                    ~JoinAssignment.status.in_(["allocated", "joining", "retry", "waiting_flood"]),
                )) or 0)
            await set_job_progress(job.id, await _fixed_join_snapshot(job, account_states))
            if should_delay:
                await _responsive_sleep(job.id, delay_seconds)

    results = await asyncio.gather(*(worker(account_id) for account_id in account_states), return_exceptions=True)
    for account_id, result in zip(account_states, results):
        if isinstance(result, (JobCancelled, JobPaused, asyncio.CancelledError)):
            raise result
        if isinstance(result, Exception):
            account_states[account_id]["status"] = "error"
            account_states[account_id]["last_error"] = f"{type(result).__name__}: {result}"[:1000]

    final = await _fixed_join_snapshot(job, account_states)
    final["phase"] = "completed"
    await set_job_progress(job.id, final)
    return final


async def count_leave_targets(join_job_id: int) -> int:
    async with SessionFactory() as session:
        return int(await session.scalar(select(func.count(JoinAssignment.id)).where(
            JoinAssignment.job_id == int(join_job_id),
            JoinAssignment.status.in_(CLEANUP_STATUSES),
            JoinAssignment.left_at.is_(None),
        )) or 0)


async def _resolve_joined_entity(client: Any, url: str, peer_id: int | None = None) -> Any | None:
    if peer_id is not None:
        return await client.get_entity(peer_id)
    invite = INVITE_RE.fullmatch(url.rstrip("/"))
    if invite:
        result = await client(CheckChatInviteRequest(invite.group(1)))
        if type(result).__name__ != "ChatInviteAlready":
            return None
        return getattr(result, "chat", None)
    public = PUBLIC_RE.fullmatch(url.rstrip("/"))
    if public:
        return await client.get_entity("@" + public.group(1))
    return None


async def _leave_entity(client: Any, entity: Any) -> None:
    name = type(entity).__name__
    if name.startswith("Channel"):
        await client(LeaveChannelRequest(entity))
        return
    if name.startswith("Chat"):
        await client(DeleteChatUserRequest(chat_id=int(entity.id), user_id="me"))
        return
    raise ValueError("العضوية ليست مجموعة Telegram قابلة للمغادرة.")


async def process_leave_join_job(job: Job, manager: Any) -> dict[str, Any]:
    """Leave only memberships tracked by one confirmed join task."""
    source_job_id = int((job.progress or {}).get("source_join_job_id") or 0)
    if source_job_id <= 0:
        raise ValueError("مهمة التنظيف لا تحتوي رقم مهمة الانضمام الأصلية.")
    async with SessionFactory() as session:
        source_job = await session.get(Job, source_job_id)
    if (source_job is None or source_job.mode != "join_groups"
            or int(source_job.requested_by) != int(job.requested_by)):
        raise ValueError("مهمة الانضمام الأصلية غير موجودة أو لا تخص هذا المشرف.")
    await seed_legacy_assignments_for_job(source_job)

    async with SessionFactory() as session:
        rows = list((await session.execute(
            select(JoinAssignment, JoinCandidate)
            .join(JoinCandidate, JoinCandidate.id == JoinAssignment.candidate_id)
            .where(
                JoinAssignment.job_id == source_job_id,
                JoinAssignment.status.in_(CLEANUP_STATUSES),
                JoinAssignment.left_at.is_(None),
            ).order_by(JoinAssignment.account_id, JoinAssignment.id)
        )).all())
    grouped: dict[int, list[tuple[JoinAssignment, JoinCandidate]]] = {}
    for assignment, candidate in rows:
        grouped.setdefault(int(assignment.account_id), []).append((assignment, candidate))

    counters: dict[str, Any] = {
        **dict(job.progress or {}), "phase": "leaving", "leave_total": len(rows),
        "leave_completed": 0, "leave_already": 0, "leave_errors": 0,
        "leave_flood_waits": 0,
    }
    lock = asyncio.Lock()
    delay = max(30, int(settings.leave_delay_seconds))

    async def worker(account_id: int, account_rows: list[tuple[JoinAssignment, JoinCandidate]]) -> None:
        client = await manager.ensure_connected(account_id)
        for index, (assignment, candidate) in enumerate(account_rows):
            await ensure_job_active(job.id)
            try:
                entity = await _resolve_joined_entity(client, candidate.normalized_url, assignment.peer_id)
                if entity is None:
                    await _update_assignment(assignment.id, status="left",
                                             detail="already not a participant", left_at=utcnow())
                    async with lock:
                        counters["leave_already"] += 1
                else:
                    await _leave_entity(client, entity)
                    await _update_assignment(assignment.id, status="left",
                                             detail="left by confirmed cleanup job", left_at=utcnow())
                    await _update_candidate(candidate.id, status="left",
                                            detail=f"left by cleanup job #{job.id}")
                    async with lock:
                        counters["leave_completed"] += 1
            except (JobCancelled, JobPaused):
                raise
            except FloodWaitError as exc:
                async with lock:
                    counters["leave_flood_waits"] += 1
                await _responsive_sleep(job.id, max(delay, int(exc.seconds) + 1))
                try:
                    entity = await _resolve_joined_entity(client, candidate.normalized_url, assignment.peer_id)
                    if entity is not None:
                        await _leave_entity(client, entity)
                    await _update_assignment(
                        assignment.id, status="left",
                        detail="left after FloodWait" if entity is not None else "already not a participant",
                        left_at=utcnow(),
                    )
                    async with lock:
                        counters["leave_completed" if entity is not None else "leave_already"] += 1
                except (JobCancelled, JobPaused):
                    raise
                except Exception as retry_exc:
                    await _update_assignment(assignment.id,
                                             detail=f"{type(retry_exc).__name__}: {retry_exc}"[:1000])
                    async with lock:
                        counters["leave_errors"] += 1
            except Exception as exc:
                name = type(exc).__name__
                if name in {"UserNotParticipantError"}:
                    await _update_assignment(assignment.id, status="left",
                                             detail=f"already left: {name}", left_at=utcnow())
                    async with lock:
                        counters["leave_already"] += 1
                else:
                    await _update_assignment(assignment.id, detail=f"{name}: {exc}"[:1000])
                    async with lock:
                        counters["leave_errors"] += 1
            await set_job_progress(job.id, dict(counters))
            if index + 1 < len(account_rows):
                await _responsive_sleep(job.id, delay)

    results = await asyncio.gather(
        *(worker(account_id, account_rows) for account_id, account_rows in grouped.items()),
        return_exceptions=True,
    )
    for result in results:
        if isinstance(result, (JobCancelled, JobPaused)):
            raise result
        if isinstance(result, Exception):
            counters["leave_errors"] += 1
            logger.error("Leave worker failed: %s", result)
    counters["phase"] = "completed"
    await set_job_progress(job.id, counters)
    return counters
