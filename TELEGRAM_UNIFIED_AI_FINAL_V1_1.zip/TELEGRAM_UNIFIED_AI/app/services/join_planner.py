from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from sqlalchemy import func, or_, select, update
from sqlalchemy.dialects.sqlite import insert

from app.db import SessionFactory
from app.models import Account, Job, JoinAssignment, JoinCandidate, TelegramAudit, TelegramAuditResult, utcnow
from app.services.owners import get_primary_owner_id

READY_AUDIT_STATUSES = {"unjoined", "join_request"}
FINISHED_AUDIT_STATUSES = {"completed", "completed_with_errors"}


@dataclass(slots=True)
class JoinSourceOverview:
    latest_audit_id: int | None = None
    latest_audit_title: str | None = None
    all_count: int = 0
    groups_count: int = 0
    channels_count: int = 0
    database_audit_id: int | None = None
    database_count: int = 0


async def _latest_audit(operator_id: int, *, database_only: bool = False) -> TelegramAudit | None:
    async with SessionFactory() as session:
        stmt = select(TelegramAudit).where(
            TelegramAudit.requested_by == int(operator_id),
            TelegramAudit.status.in_(FINISHED_AUDIT_STATUSES),
        )
        if database_only:
            stmt = stmt.where(TelegramAudit.source_type == "database")
        return await session.scalar(stmt.order_by(TelegramAudit.id.desc()).limit(1))


async def _audit_ready_counts(audit_id: int) -> tuple[int, int, int]:
    async with SessionFactory() as session:
        rows = (await session.execute(
            select(TelegramAuditResult.peer_type, func.count(TelegramAuditResult.id))
            .where(
                TelegramAuditResult.audit_id == int(audit_id),
                TelegramAuditResult.status.in_(READY_AUDIT_STATUSES),
                TelegramAuditResult.peer_type.in_(["group", "channel"]),
            )
            .group_by(TelegramAuditResult.peer_type)
        )).all()
    counts = {str(kind): int(count) for kind, count in rows}
    groups = counts.get("group", 0)
    channels = counts.get("channel", 0)
    return groups + channels, groups, channels


async def get_join_source_overview(operator_id: int) -> JoinSourceOverview:
    latest = await _latest_audit(operator_id)
    database = await _latest_audit(operator_id, database_only=True)
    overview = JoinSourceOverview()
    if latest:
        overview.latest_audit_id = int(latest.id)
        overview.latest_audit_title = latest.title
        overview.all_count, overview.groups_count, overview.channels_count = await _audit_ready_counts(latest.id)
    if database:
        overview.database_audit_id = int(database.id)
        overview.database_count = (await _audit_ready_counts(database.id))[0]
    return overview


async def _operator_account_ids(operator_id: int) -> list[int]:
    primary = await get_primary_owner_id()
    async with SessionFactory() as session:
        ownership = Account.operator_id == int(operator_id)
        if primary is not None and int(primary) == int(operator_id):
            ownership = or_(Account.operator_id == int(operator_id), Account.operator_id.is_(None))
        return list((await session.scalars(
            select(Account.id).where(Account.active.is_(True), ownership).order_by(Account.id)
        )).all())


def _source_peer_types(source_kind: str) -> tuple[str, ...]:
    if source_kind == "groups":
        return ("group",)
    if source_kind == "channels":
        return ("channel",)
    if source_kind in {"all", "database"}:
        return ("group", "channel")
    raise ValueError("مصدر الانضمام غير صالح.")


async def stage_join_job(operator_id: int, *, audit_id: int, source_kind: str, per_account: int) -> Job:
    """Create a fixed, non-overlapping join plan from persisted audit results.

    The plan is immutable at the account/link level: each selected URL belongs to
    exactly one account in this job. Failed links are reported; they are never
    silently replaced by links reserved for another account.
    """
    if int(per_account) not in {200, 500}:
        raise ValueError("اختر 200 أو 500 رابط لكل حساب.")
    peer_types = _source_peer_types(source_kind)
    account_ids = await _operator_account_ids(operator_id)
    if not account_ids:
        raise ValueError("لا توجد حسابات Telegram فعالة لهذا المشرف.")

    async with SessionFactory() as session:
        audit = await session.get(TelegramAudit, int(audit_id))
        if not audit or int(audit.requested_by) != int(operator_id) or audit.status not in FINISHED_AUDIT_STATUSES:
            raise ValueError("الفحص المحدد غير موجود أو لم يكتمل بعد.")
        if source_kind == "database" and audit.source_type != "database":
            raise ValueError("المصدر المحدد ليس فحص قاعدة البيانات.")

        # Deduplicate by resolved peer when available; fall back to normalized URL.
        # Read in bounded pages so a very large audit never has to be loaded into RAM.
        base_filter = (
            TelegramAuditResult.audit_id == int(audit_id),
            TelegramAuditResult.status.in_(READY_AUDIT_STATUSES),
            TelegramAuditResult.peer_type.in_(peer_types),
        )
        available_raw = int(await session.scalar(select(func.count(TelegramAuditResult.id)).where(*base_filter)) or 0)
        selected: list[TelegramAuditResult] = []
        seen: set[tuple[str, Any]] = set()
        capacity = len(account_ids) * int(per_account)
        last_result_id = 0
        while len(selected) < capacity:
            page = list((await session.scalars(
                select(TelegramAuditResult).where(*base_filter, TelegramAuditResult.id > last_result_id)
                .order_by(TelegramAuditResult.id).limit(1000)
            )).all())
            if not page:
                break
            last_result_id = int(page[-1].id)
            for row in page:
                key = ("peer", int(row.peer_id)) if row.peer_id is not None else ("url", str(row.normalized_url).lower())
                if key in seen:
                    continue
                seen.add(key)
                selected.append(row)
                if len(selected) >= capacity:
                    break
        if not selected:
            raise ValueError("لا توجد روابط مفحوصة وجاهزة للانضمام في هذا القسم.")

        source_key = f"audit:{int(audit_id)}:{source_kind}"
        job = Job(
            requested_by=int(operator_id), mode="join_groups", scope="fixed", category="telegram",
            audit_id=int(audit_id), sources=[source_key], status="queued",
            progress={
                "phase": "planned",
                "join_distribution_mode": "fixed",
                "join_per_account": int(per_account),
                "join_delay_seconds": 180,
                "join_target_kind": source_kind,
                "join_source_audit_id": int(audit_id),
                "join_source_title": audit.title or f"فحص #{audit_id}",
                "join_available_at_plan": available_raw,
                "join_assigned": len(selected),
                "join_unassigned_due_capacity": max(0, available_raw - len(selected)),
            },
        )
        session.add(job)
        await session.flush()

        urls = [str(row.normalized_url) for row in selected]
        for offset in range(0, len(urls), 400):
            batch_urls = urls[offset:offset + 400]
            await session.execute(
                insert(JoinCandidate).values([
                    {
                        "requested_by": int(operator_id),
                        "original_url": url,
                        "normalized_url": url,
                        "source_url": source_key,
                        "status": "allocated",
                        "attempts": 0,
                        "created_at": utcnow(),
                        "updated_at": utcnow(),
                    }
                    for url in batch_urls
                ]).on_conflict_do_update(
                    index_elements=[JoinCandidate.requested_by, JoinCandidate.normalized_url],
                    set_={"source_url": source_key, "status": "allocated", "assigned_account_id": None, "updated_at": utcnow()},
                )
            )
        candidates: dict[str, JoinCandidate] = {}
        for offset in range(0, len(urls), 400):
            batch_urls = urls[offset:offset + 400]
            rows = (await session.scalars(select(JoinCandidate).where(
                JoinCandidate.requested_by == int(operator_id),
                JoinCandidate.normalized_url.in_(batch_urls),
            ))).all()
            candidates.update({str(row.normalized_url): row for row in rows})

        assignments: list[dict[str, Any]] = []
        per_account_counts: dict[str, int] = {}
        for index, result in enumerate(selected):
            account_index = index // int(per_account)
            account_id = int(account_ids[account_index])
            candidate = candidates[str(result.normalized_url)]
            per_account_counts[str(account_id)] = per_account_counts.get(str(account_id), 0) + 1
            assignments.append({
                "job_id": int(job.id),
                "requested_by": int(operator_id),
                "candidate_id": int(candidate.id),
                "account_id": account_id,
                "status": "allocated",
                "peer_id": result.peer_id,
                "peer_type": result.peer_type,
                "title": result.title,
                "attempts": 0,
                "detail": f"planned from audit #{audit_id}",
                "created_at": utcnow(),
                "updated_at": utcnow(),
            })
        for offset in range(0, len(assignments), 500):
            await session.execute(insert(JoinAssignment).values(assignments[offset:offset + 500]))
        for account_id, count in per_account_counts.items():
            await session.execute(update(JoinCandidate).where(
                JoinCandidate.id.in_(select(JoinAssignment.candidate_id).where(
                    JoinAssignment.job_id == int(job.id), JoinAssignment.account_id == int(account_id)
                ))
            ).values(assigned_account_id=int(account_id), updated_at=utcnow()))

        progress = dict(job.progress or {})
        progress["join_accounts_planned"] = len(per_account_counts)
        progress["join_account_plan"] = per_account_counts
        job.progress = progress
        await session.commit()
        await session.refresh(job)
        return job
