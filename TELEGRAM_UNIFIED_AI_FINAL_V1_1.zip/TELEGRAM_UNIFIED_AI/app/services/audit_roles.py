from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.dialects.sqlite import insert

from app.db import SessionFactory
from app.models import AppSetting, Account

VERIFIER_KEY = "telegram_audit_verifier_account_ids"


async def get_verifier_account_ids(operator_id: int | None = None) -> set[int]:
    async with SessionFactory() as session:
        value = await session.scalar(select(AppSetting.value).where(AppSetting.key == (f"{VERIFIER_KEY}:{operator_id}" if operator_id is not None else VERIFIER_KEY)))
    if value is None and operator_id is not None:
        # Preserve existing V8 role choices, scoped to this operator on first use.
        from app.services.accounts import list_accounts
        async with SessionFactory() as session:
            legacy = await session.scalar(select(AppSetting.value).where(AppSetting.key == VERIFIER_KEY))
        owned = {int(account.id) for account in await list_accounts(operator_id)}
        value = [int(item) for item in (legacy or []) if str(item).isdigit() and int(item) in owned] if isinstance(legacy, list) else []
    if not isinstance(value, list):
        return set()
    return {int(item) for item in value if str(item).isdigit()}


async def set_verifier_account_ids(account_ids: set[int], operator_id: int | None = None) -> None:
    values = sorted({int(item) for item in account_ids})
    async with SessionFactory() as session:
        stmt = (
            insert(AppSetting)
            .values(key=(f"{VERIFIER_KEY}:{operator_id}" if operator_id is not None else VERIFIER_KEY), value=values)
            .on_conflict_do_update(index_elements=[AppSetting.key], set_={"value": values})
        )
        await session.execute(stmt)
        await session.commit()


async def toggle_verifier_account(account_id: int, operator_id: int | None = None) -> bool:
    ids = await get_verifier_account_ids(operator_id)
    if int(account_id) in ids:
        ids.remove(int(account_id))
        enabled = False
    else:
        ids.add(int(account_id))
        enabled = True
    await set_verifier_account_ids(ids, operator_id)
    return enabled
