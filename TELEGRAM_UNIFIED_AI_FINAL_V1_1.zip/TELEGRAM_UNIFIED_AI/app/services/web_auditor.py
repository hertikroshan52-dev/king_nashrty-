from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

import aiohttp
from sqlalchemy import and_, func, or_, select, update
from sqlalchemy.dialects.sqlite import insert

from app.config import get_settings
from app.db import SessionFactory
from app.models import Job, TelegramAudit, TelegramAuditInput, TelegramAuditResult, utcnow
from app.services.scanner import ensure_job_active, set_job_progress

logger = logging.getLogger(__name__)
settings = get_settings()

from app.services.web_preview import WebClassification, classify_tme_html


class _WebRateGate:
    """Shared 429 back-pressure without serializing normal browser checks."""

    def __init__(self) -> None:
        self._until = 0.0
        self._lock = asyncio.Lock()

    async def wait(self) -> None:
        while True:
            delay = self._until - time.monotonic()
            if delay <= 0:
                return
            await asyncio.sleep(min(delay, 5.0))

    async def defer(self, seconds: float) -> None:
        async with self._lock:
            self._until = max(self._until, time.monotonic() + max(0.5, float(seconds)))


async def _fetch_and_classify(session: aiohttp.ClientSession, url: str, gate: _WebRateGate) -> WebClassification:
    last: WebClassification | None = None
    for attempt in range(3):
        try:
            await gate.wait()
            async with session.get(url, allow_redirects=True) as response:
                body = await response.text(errors="ignore")
                result = classify_tme_html(url, body, int(response.status))
                last = result
                if result.status != "temporary_error":
                    return result
                retry_after = response.headers.get("Retry-After")
                if attempt < 2:
                    try:
                        delay = float(retry_after) if retry_after else float(1 << attempt)
                    except (TypeError, ValueError):
                        delay = float(1 << attempt)
                    delay = min(30.0, max(0.5, delay))
                    if int(response.status) == 429:
                        await gate.defer(delay)
                    await asyncio.sleep(delay)
                    continue
                return result
        except asyncio.TimeoutError:
            last = WebClassification("temporary_error", detail="web_timeout", error_class="web_timeout")
        except aiohttp.ClientError as exc:
            last = WebClassification("temporary_error", detail=str(exc)[:1000], error_class=type(exc).__name__)
        except Exception as exc:
            logger.warning("Web audit fetch failed url=%s: %s", url, exc)
            return WebClassification("temporary_error", detail=str(exc)[:1000], error_class=type(exc).__name__)
        if attempt < 2:
            await asyncio.sleep(float(1 << attempt))
    return last or WebClassification("temporary_error", detail="web_unknown_error", error_class="web_unknown")


async def queue_web_audit_job(audit_id: int, owner_id: int) -> Job:
    active_states = {"queued", "starting", "running", "pause_requested", "paused", "stopping"}
    async with SessionFactory() as session:
        audit = await session.get(TelegramAudit, audit_id)
        if not audit or int(audit.requested_by) != int(owner_id):
            raise ValueError("مهمة الفحص غير موجودة.")
        input_count = int(await session.scalar(
            select(func.count(TelegramAuditInput.id)).where(TelegramAuditInput.audit_id == audit_id)
        ) or 0)
        if input_count == 0:
            raise ValueError("لا توجد روابط Telegram في هذا الفحص.")
        existing = await session.scalar(
            select(Job).where(Job.audit_id == audit_id, Job.status.in_(active_states)).order_by(Job.id.desc()).limit(1)
        )
        if existing:
            raise ValueError(f"الفحص مرتبط بالفعل بالمهمة #{existing.id} وحالتها {existing.status}.")
        audit.status = "queued"
        audit.total_inputs = input_count
        audit.error = None
        audit.finished_at = None
        audit.paused_at = None
        audit.current_phase = "web_queued"
        audit.updated_at = utcnow()
        job = Job(
            requested_by=int(owner_id), mode="telegram_web_audit", scope="all",
            category=f"web_audit:{audit_id}", audit_id=audit_id, status="queued",
            progress={"audit_id": audit_id, "inputs": input_count, "checked": int(audit.checked_inputs or 0), "engine": "web"},
        )
        session.add(job)
        await session.commit()
        await session.refresh(job)
        return job


async def process_web_audit_job(job: Job) -> dict[str, Any]:
    audit_id = int(job.audit_id or str(job.category or "").rsplit(":", 1)[-1])
    workers = max(1, int(getattr(settings, "web_audit_workers", 40)))
    per_host = max(1, min(workers, int(getattr(settings, "web_audit_per_host", 6))))
    retry_max = max(1, int(getattr(settings, "audit_retry_max_attempts", 3)))
    timeout_seconds = max(3.0, float(getattr(settings, "web_audit_timeout_seconds", 15.0)))
    batch_size = max(workers, min(1000, int(getattr(settings, "web_audit_batch_size", 400))))
    headers = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0 Mobile Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9,ar;q=0.8",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }
    timeout = aiohttp.ClientTimeout(total=timeout_seconds)
    connector = aiohttp.TCPConnector(limit=workers, limit_per_host=per_host, ttl_dns_cache=300)
    rate_gate = _WebRateGate()

    async with SessionFactory() as db:
        audit = await db.get(TelegramAudit, audit_id)
        if not audit or int(audit.requested_by) != int(job.requested_by):
            raise RuntimeError("تقرير فحص المتصفح غير موجود.")
        total = int(await db.scalar(select(func.count(TelegramAuditInput.id)).where(TelegramAuditInput.audit_id == audit_id)) or 0)
        audit.status = "running"
        audit.started_at = audit.started_at or utcnow()
        audit.current_phase = "web_auditing"
        audit.total_inputs = total
        await db.commit()

    checked_this_run = 0
    last_input_id = 0
    status_counts: dict[str, int] = {}

    async with aiohttp.ClientSession(timeout=timeout, connector=connector, headers=headers) as http:
        while True:
            await ensure_job_active(job.id)
            async with SessionFactory() as db:
                rows = (await db.execute(
                    select(
                        TelegramAuditInput.id,
                        TelegramAuditInput.normalized_url,
                        func.coalesce(TelegramAuditResult.attempt_count, 0),
                    )
                    .outerjoin(
                        TelegramAuditResult,
                        (TelegramAuditResult.audit_id == TelegramAuditInput.audit_id)
                        & (TelegramAuditResult.input_id == TelegramAuditInput.id),
                    )
                    .where(
                        TelegramAuditInput.audit_id == audit_id,
                        or_(
                            TelegramAuditResult.id.is_(None),
                            and_(
                                TelegramAuditResult.status == "temporary_error",
                                TelegramAuditResult.attempt_count < retry_max,
                            ),
                        ),
                    )
                    .order_by(TelegramAuditInput.id)
                    .limit(batch_size)
                )).all()
            if not rows:
                break
            last_input_id = int(rows[-1][0])

            semaphore = asyncio.Semaphore(workers)
            async def one(input_id: int, url: str, previous_attempts: int):
                async with semaphore:
                    result = await _fetch_and_classify(http, url, rate_gate)
                    return input_id, url, previous_attempts + 1, result

            results = await asyncio.gather(
                *(one(int(row[0]), str(row[1]), int(row[2] or 0)) for row in rows)
            )
            now = utcnow()
            payloads: list[dict[str, Any]] = []
            for input_id, url, attempt_count, result in results:
                status_counts[result.status] = status_counts.get(result.status, 0) + 1
                checked_this_run += 1
                payloads.append({
                    "audit_id": audit_id,
                    "input_id": input_id,
                    "normalized_url": url,
                    "status": result.status,
                    "peer_id": None,
                    "peer_type": result.peer_type,
                    "title": result.title,
                    "username": result.username,
                    "account_ids": [],
                    "account_labels": [],
                    "detail": result.detail,
                    "error_class": result.error_class,
                    "attempt_count": attempt_count,
                    "next_retry_at": None,
                    "checked_at": now,
                })
            async with SessionFactory() as db:
                if payloads:
                    stmt = insert(TelegramAuditResult).values(payloads)
                    stmt = stmt.on_conflict_do_update(
                        index_elements=[TelegramAuditResult.audit_id, TelegramAuditResult.input_id],
                        set_={
                            "status": stmt.excluded.status,
                            "peer_type": stmt.excluded.peer_type,
                            "title": stmt.excluded.title,
                            "username": stmt.excluded.username,
                            "detail": stmt.excluded.detail,
                            "error_class": stmt.excluded.error_class,
                            "attempt_count": stmt.excluded.attempt_count,
                            "checked_at": stmt.excluded.checked_at,
                        },
                    )
                    await db.execute(stmt)
                checked_total = int(await db.scalar(
                    select(func.count(TelegramAuditResult.id)).where(TelegramAuditResult.audit_id == audit_id)
                ) or 0)
                await db.execute(update(TelegramAudit).where(TelegramAudit.id == audit_id).values(
                    checked_inputs=checked_total,
                    last_processed_input_id=last_input_id,
                    current_phase="web_auditing",
                    updated_at=now,
                ))
                await db.commit()
            await set_job_progress(job.id, {
                "audit_id": audit_id, "engine": "web", "total": total,
                "checked": checked_total, "checked_this_run": checked_this_run,
                "web_workers": workers, **status_counts,
            })

    async with SessionFactory() as db:
        rows = (await db.execute(
            select(TelegramAuditResult.status, func.count(TelegramAuditResult.id))
            .where(TelegramAuditResult.audit_id == audit_id)
            .group_by(TelegramAuditResult.status)
        )).all()
        peer_rows = (await db.execute(
            select(TelegramAuditResult.peer_type, func.count(TelegramAuditResult.id))
            .where(TelegramAuditResult.audit_id == audit_id, TelegramAuditResult.peer_type.in_(["channel", "group"]))
            .group_by(TelegramAuditResult.peer_type)
        )).all()
        counts = {str(status): int(count) for status, count in rows}
        peers = {str(peer): int(count) for peer, count in peer_rows}
        pump_ipo_count = int(await db.scalar(
            select(func.count(TelegramAuditResult.id)).where(
                TelegramAuditResult.audit_id == audit_id,
                func.lower(func.coalesce(TelegramAuditResult.detail, "")).like("%pump_ipo_match%"),
            )
        ) or 0)
        checked_total = sum(counts.values())
        audit = await db.get(TelegramAudit, audit_id)
        summary = dict(audit.summary or {}) if audit else {}
        summary.update({
            "engine": "web", "web_workers": workers,
            "telegram_channels": peers.get("channel", 0),
            "telegram_groups": peers.get("group", 0),
            "pump_ipo": pump_ipo_count,
            **counts,
        })
        final_status = "completed_with_errors" if counts.get("temporary_error", 0) else "completed"
        if audit:
            audit.status = final_status
            audit.checked_inputs = checked_total
            audit.current_phase = "web_completed"
            audit.finished_at = utcnow()
            audit.updated_at = utcnow()
            audit.summary = summary
            await db.commit()

    result: dict[str, Any] = {
        "audit_id": audit_id, "engine": "web", "status": final_status,
        "total": total, "checked": checked_total, "checked_this_run": checked_this_run,
        "telegram_channels": peers.get("channel", 0), "telegram_groups": peers.get("group", 0),
        "pump_ipo": pump_ipo_count, "web_workers": workers, **counts,
    }
    await set_job_progress(job.id, result)
    return result


async def populate_account_audit_from_web_section(
    source_audit_id: int,
    owner_id: int,
    section: str,
) -> tuple[TelegramAudit, int]:
    """Create an account-based child audit from one browser-result section.

    Browser reports can contain millions of rows, so results are copied to the
    child audit in bounded batches instead of materializing the whole section
    in RAM.
    """
    section = str(section)
    allowed = {"channels", "groups", "requires_account", "expired", "bots", "personal", "pump_ipo"}
    if section not in allowed:
        raise ValueError("قسم فحص المتصفح غير صالح.")

    async with SessionFactory() as db:
        source = await db.get(TelegramAudit, int(source_audit_id))
        if not source or int(source.requested_by) != int(owner_id):
            raise ValueError("فحص المتصفح غير موجود.")

    from app.services.auditor import add_audit_urls, create_audit
    titles = {
        "channels": "القنوات من فحص المتصفح",
        "groups": "المجموعات من فحص المتصفح",
        "requires_account": "روابط تحتاج حسابات من فحص المتصفح",
        "expired": "إعادة تحقق المنتهية من فحص المتصفح",
        "bots": "بوتات من فحص المتصفح",
        "personal": "روابط شخصية من فحص المتصفح",
        "pump_ipo": "بامبات واكتتابات من فحص المتصفح",
    }
    audit = await create_audit(
        int(owner_id),
        source_type=f"web_section:{section}",
        options={
            "engine": "accounts",
            "collect_telegram": False,
            "telegram_scope": "all",
            "telegram_auto_full_history": False,
            "pacing": "fixed",
            "source_web_audit_id": int(source_audit_id),
            "source_web_section": section,
        },
        title=f"{titles[section]} #{source_audit_id}",
    )

    added_total = 0
    last_result_id = 0
    batch_size = 1000
    while True:
        async with SessionFactory() as db:
            query = select(TelegramAuditResult.id, TelegramAuditResult.normalized_url).where(
                TelegramAuditResult.audit_id == int(source_audit_id),
                TelegramAuditResult.id > int(last_result_id),
            )
            if section == "channels":
                query = query.where(TelegramAuditResult.peer_type == "channel")
            elif section == "groups":
                query = query.where(TelegramAuditResult.peer_type == "group")
            elif section == "requires_account":
                query = query.where(TelegramAuditResult.status == "requires_account")
            elif section == "expired":
                query = query.where(TelegramAuditResult.status == "expired")
            elif section == "bots":
                query = query.where(TelegramAuditResult.status == "bot")
            elif section == "personal":
                query = query.where(TelegramAuditResult.status == "personal")
            else:  # pump_ipo
                query = query.where(
                    TelegramAuditResult.peer_type.in_(["group", "channel"]),
                    func.lower(func.coalesce(TelegramAuditResult.detail, "")).like("%pump_ipo_match%"),
                )
            rows = (await db.execute(
                query.order_by(TelegramAuditResult.id).limit(batch_size)
            )).all()
        if not rows:
            break
        last_result_id = int(rows[-1][0])
        added, _ = await add_audit_urls(audit.id, [str(row[1]) for row in rows])
        added_total += int(added)

    return audit, added_total
