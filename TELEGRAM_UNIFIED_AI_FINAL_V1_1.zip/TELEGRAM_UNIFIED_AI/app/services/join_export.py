from __future__ import annotations

import csv
import tempfile
import zipfile
from pathlib import Path

from sqlalchemy import select

from app.config import get_settings
from app.db import SessionFactory
from app.models import Account, Job, JoinAssignment, JoinCandidate
from app.services.owners import is_primary_owner


async def export_join_job(job_id: int, requester_id: int) -> Path:
    """Export the immutable distribution plus committed results.

    The task owner may export their own task.  The primary owner may export any
    join task so operational recovery is possible even when a supervisor is
    unavailable.  No credentials or session strings are ever exported.
    """
    async with SessionFactory() as db:
        job = await db.get(Job, int(job_id))
        if not job or job.mode != "join_groups":
            raise ValueError("مهمة الانضمام غير موجودة.")
        if int(job.requested_by) != int(requester_id) and not await is_primary_owner(int(requester_id)):
            raise ValueError("لا تملك صلاحية تصدير هذه المهمة.")

    settings = get_settings()
    with tempfile.TemporaryDirectory(dir=settings.tmp_dir, prefix="join-export-") as tmp:
        root = Path(tmp)
        account_files: dict[int, object] = {}
        last_id = 0
        try:
            with (root / "accounts_and_links.csv").open("w", encoding="utf-8-sig", newline="") as stream:
                writer = csv.writer(stream)
                writer.writerow([
                    "account_id", "account_label", "status", "url", "peer_id", "peer_type", "title",
                    "attempts", "saved_messages", "saved_messages_error", "detail",
                ])
                while True:
                    async with SessionFactory() as db:
                        rows = (await db.execute(
                            select(JoinAssignment, JoinCandidate, Account)
                            .join(JoinCandidate, JoinCandidate.id == JoinAssignment.candidate_id)
                            .join(Account, Account.id == JoinAssignment.account_id)
                            .where(JoinAssignment.job_id == int(job_id), JoinAssignment.id > last_id)
                            .order_by(JoinAssignment.id).limit(500)
                        )).all()
                    if not rows:
                        break
                    for row, candidate, account in rows:
                        last_id = int(row.id)
                        title = row.title or ""
                        if title.startswith(("=", "+", "-", "@")):
                            title = "'" + title
                        writer.writerow([
                            row.account_id, account.label, row.status, candidate.normalized_url, row.peer_id,
                            row.peer_type or "", title, row.attempts,
                            "yes" if row.saved_message_sent_at else "no", row.saved_message_error or "", row.detail or "",
                        ])
                        status = row.status if row.status in {
                            "joined", "already", "legacy_joined", "requested", "expired", "channel", "bot",
                            "personal", "unsupported", "restricted", "error", "retry", "ready_group", "allocated",
                            "joining", "waiting_flood", "left", "duplicate", "banned", "removed_after_join", "account_limit",
                        } else "other"
                        with (root / f"{status}.txt").open("a", encoding="utf-8") as section:
                            section.write(candidate.normalized_url + "\n")
                        if int(row.account_id) not in account_files:
                            account_files[int(row.account_id)] = (root / f"account_{int(row.account_id)}_links.txt").open("a", encoding="utf-8")
                        account_files[int(row.account_id)].write(candidate.normalized_url + "\n")
        finally:
            for handle in account_files.values():
                handle.close()

        with (root / "README.txt").open("w", encoding="utf-8") as readme:
            readme.write(
                f"Join job #{job_id}\n"
                "account_<id>_links.txt = exact fixed distribution reserved for that account.\n"
                "accounts_and_links.csv = distribution + final status + Saved Messages backup status.\n"
            )
        destination = settings.exports_dir / f"join_job_{job_id}.zip"
        with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(root.iterdir()):
                archive.write(path, path.name)
    return destination
