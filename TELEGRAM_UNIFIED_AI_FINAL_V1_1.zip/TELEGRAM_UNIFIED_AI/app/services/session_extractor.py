from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any

from telethon import TelegramClient
from telethon.errors import PhoneCodeExpiredError, PhoneCodeInvalidError, SessionPasswordNeededError
from telethon.sessions import StringSession

from app.config import get_settings

settings = get_settings()


@dataclass(slots=True)
class PendingLogin:
    client: TelegramClient
    phone: str
    phone_code_hash: str


_PENDING: dict[int, PendingLogin] = {}
_LOCK = asyncio.Lock()


def _credentials() -> tuple[int, str]:
    if not settings.telegram_api_id or not settings.telegram_api_hash:
        raise RuntimeError("اضبط TELEGRAM_API_ID وTELEGRAM_API_HASH في ملف .env أولًا.")
    return int(settings.telegram_api_id), str(settings.telegram_api_hash)


async def cancel_login(user_id: int) -> None:
    async with _LOCK:
        pending = _PENDING.pop(int(user_id), None)
    if pending:
        try:
            await pending.client.disconnect()
        except Exception:
            pass


async def begin_login(user_id: int, phone: str) -> None:
    phone = str(phone or "").strip().replace(" ", "")
    if not phone.startswith("+") or not phone[1:].isdigit():
        raise ValueError("أرسل رقم الهاتف بالصيغة الدولية مثل +9677XXXXXXXX.")
    await cancel_login(int(user_id))
    api_id, api_hash = _credentials()
    client = TelegramClient(StringSession(), api_id, api_hash, auto_reconnect=True, connection_retries=3)
    await client.connect()
    try:
        sent = await client.send_code_request(phone)
    except Exception:
        await client.disconnect()
        raise
    async with _LOCK:
        _PENDING[int(user_id)] = PendingLogin(client=client, phone=phone, phone_code_hash=str(sent.phone_code_hash))


async def submit_code(user_id: int, code: str) -> tuple[str, dict[str, Any] | None]:
    async with _LOCK:
        pending = _PENDING.get(int(user_id))
    if not pending:
        raise RuntimeError("لا توجد عملية استخراج جلسة نشطة. ابدأ من زر استخراج جلسة جديدة.")
    code = "".join(ch for ch in str(code or "") if ch.isdigit())
    if not code:
        raise ValueError("رمز تسجيل الدخول غير صالح.")
    try:
        await pending.client.sign_in(phone=pending.phone, code=code, phone_code_hash=pending.phone_code_hash)
    except SessionPasswordNeededError:
        return "password", None
    except (PhoneCodeInvalidError, PhoneCodeExpiredError):
        raise ValueError("رمز Telegram غير صحيح أو انتهت صلاحيته.")
    return "done", await _finish(int(user_id), pending)


async def submit_password(user_id: int, password: str) -> dict[str, Any]:
    async with _LOCK:
        pending = _PENDING.get(int(user_id))
    if not pending:
        raise RuntimeError("لا توجد عملية استخراج جلسة نشطة.")
    await pending.client.sign_in(password=str(password or ""))
    return await _finish(int(user_id), pending)


async def _finish(user_id: int, pending: PendingLogin) -> dict[str, Any]:
    try:
        me = await pending.client.get_me()
        if me is None:
            raise RuntimeError("تعذر قراءة معلومات الحساب بعد تسجيل الدخول.")
        session_string = pending.client.session.save()
        if not session_string:
            raise RuntimeError("تعذر استخراج StringSession.")
        api_id, api_hash = _credentials()
        display_name = " ".join(filter(None, [getattr(me, "first_name", None), getattr(me, "last_name", None)])).strip()
        return {
            "label": display_name or getattr(me, "username", None) or f"حساب {int(me.id)}",
            "telegram_user_id": int(me.id),
            "username": getattr(me, "username", None),
            "phone": getattr(me, "phone", None),
            "api_id": api_id,
            "api_hash": api_hash,
            "session": str(session_string),
        }
    finally:
        async with _LOCK:
            _PENDING.pop(int(user_id), None)
        try:
            await pending.client.disconnect()
        except Exception:
            pass
