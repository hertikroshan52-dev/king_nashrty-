from __future__ import annotations

import html
import re
from dataclasses import dataclass

_META_RE = re.compile(
    r'<meta[^>]+(?:property|name)=["\'](?P<key>[^"\']+)["\'][^>]+content=["\'](?P<value>.*?)["\'][^>]*>',
    re.I | re.S,
)
_META_RE_REVERSED = re.compile(
    r'<meta[^>]+content=["\'](?P<value>.*?)["\'][^>]+(?:property|name)=["\'](?P<key>[^"\']+)["\'][^>]*>',
    re.I | re.S,
)
_TAG_RE = re.compile(r"<[^>]+>", re.S)
_SPACE_RE = re.compile(r"\s+")
COUNT_RE = re.compile(r"\b([0-9][0-9.,\s]*\s*[KMB]?)\s+(subscribers?|members?)\b", re.I)
PUMP_IPO_RE = re.compile(
    r"(?:بامب(?:ات)?|بمب(?:ات)?|اكتتاب(?:ات)?|طرح\s+(?:أولي|اول[يى])|"
    r"\bpump(?!kin)[a-z0-9_-]*\b|\b(?:ipo|ico|ido|ieo)\b|"
    r"\bpre[-\s]?sale\b|\btoken[-\s]?sale\b|\blaunchpad\b)",
    re.I,
)

EXPLICIT_EXPIRED_MARKERS = (
    "invite link is invalid",
    "invite link has expired",
    "this invite link is expired",
    "this link is no longer active",
    "username not found",
    "page not found",
)
GENERIC_INVITE_MARKERS = (
    "you are invited to a group chat on telegram",
    "click to join",
    "join group",
    "join channel",
)
BOT_MARKERS = ("start bot", "monthly users", "monthly user")
PERSONAL_MARKERS = ("send message", "you can contact @", "right away")


@dataclass(slots=True)
class WebClassification:
    status: str
    peer_type: str | None = None
    title: str | None = None
    username: str | None = None
    detail: str | None = None
    error_class: str | None = None


def _plain_text(raw_html: str) -> str:
    text = _TAG_RE.sub(" ", raw_html)
    return _SPACE_RE.sub(" ", html.unescape(text)).strip()


def _meta(raw_html: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for regex in (_META_RE, _META_RE_REVERSED):
        for match in regex.finditer(raw_html):
            key = html.unescape(match.group("key")).strip().lower()
            value = html.unescape(match.group("value")).strip()
            if key and value and key not in values:
                values[key] = value
    return values


def _username_from_url(url: str) -> str | None:
    path = url.split("?", 1)[0].rstrip("/").rsplit("/", 1)[-1]
    if not path or path.startswith("+") or path.lower() == "joinchat":
        return None
    if re.fullmatch(r"[A-Za-z0-9_]{4,}", path):
        return path
    return None


def classify_tme_html(url: str, raw_html: str, http_status: int = 200) -> WebClassification:
    """Classify a public t.me preview conservatively without a Telegram account.

    The browser preview is useful but not authoritative. Explicit public metadata
    is classified immediately; ambiguous previews are routed to ``requires_account``
    instead of being falsely marked dead.
    """
    if http_status in {404, 410}:
        # A t.me edge/cache response is not authoritative proof that the
        # Telegram peer or invite is dead.  Account verification is required.
        return WebClassification(
            "requires_account", detail=f"HTTP {http_status}; unconfirmed by Telegram account",
            error_class="web_not_found_unconfirmed",
        )
    if http_status == 429:
        return WebClassification("temporary_error", detail="HTTP 429", error_class="web_rate_limited")
    if http_status >= 500:
        return WebClassification("temporary_error", detail=f"HTTP {http_status}", error_class="web_server_error")

    meta = _meta(raw_html)
    text = _plain_text(raw_html)
    low = text.lower()
    title = (meta.get("og:title") or meta.get("twitter:title") or "").strip() or None
    description = (meta.get("og:description") or meta.get("description") or meta.get("twitter:description") or "").strip() or None
    username = _username_from_url(url)
    combined = " ".join(value for value in (title, description, text[:5000]) if value)
    combined_low = combined.lower()

    if any(marker in combined_low for marker in EXPLICIT_EXPIRED_MARKERS):
        return WebClassification(
            "requires_account", title=title, username=username,
            detail="web_expired_signal_requires_account_confirmation",
            error_class="web_expired_signal_unconfirmed",
        )

    # Telegram bot previews normally expose a Start Bot action or monthly-user count.
    if any(marker in combined_low for marker in BOT_MARKERS):
        return WebClassification("bot", peer_type="bot", title=title, username=username, detail=description)

    # Public user previews normally expose Send Message / contact copy.
    if any(marker in combined_low for marker in PERSONAL_MARKERS):
        return WebClassification("personal", peer_type="user", title=title, username=username, detail=description)

    counts = list(COUNT_RE.finditer(combined))
    if counts:
        # Prefer the strongest Telegram entity keyword if both appear in surrounding copy.
        kinds = [match.group(2).lower() for match in counts]
        peer_type = "channel" if any(kind.startswith("subscriber") for kind in kinds) else "group"
        status = "web_visible"
        detail = description
        if PUMP_IPO_RE.search(combined):
            detail = (detail + " | " if detail else "") + "pump_ipo_match"
        return WebClassification(status, peer_type=peer_type, title=title, username=username, detail=detail)

    # A named preview can be real while omitting the counter, so send it to account
    # verification instead of guessing channel/group.
    generic_titles = {"telegram", "telegram: contact", "telegram: join group chat", "telegram: join channel"}
    has_specific_title = bool(title and title.strip().lower() not in generic_titles)
    if has_specific_title:
        detail = description or "web_named_preview_without_entity_counter"
        return WebClassification("requires_account", title=title, username=username, detail=detail)

    # Generic invite pages are deliberately ambiguous.  Telegram often hides
    # the title/member count for valid private groups, so the web engine must
    # never turn this signal into a permanent expired classification.
    is_invite_url = bool(re.search(r"/(?:joinchat/|\+)[A-Za-z0-9_-]+/?(?:\?|$)", url, re.I))
    if is_invite_url and any(marker in low for marker in GENERIC_INVITE_MARKERS):
        return WebClassification(
            "requires_account",
            title=title,
            username=username,
            detail="web_generic_invite_requires_account_confirmation",
        )
    if any(marker in low for marker in GENERIC_INVITE_MARKERS):
        return WebClassification(
            "requires_account",
            title=title,
            username=username,
            detail="generic_preview_no_specific_metadata",
        )

    return WebClassification(
        "requires_account",
        title=title,
        username=username,
        detail=description or "public_preview_did_not_expose_enough_metadata",
    )
