from __future__ import annotations

import asyncio
import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Any

from aiogram import Bot
from sqlalchemy import select, update
from sqlalchemy.dialects.sqlite import insert
from sqlalchemy.orm import aliased
from telethon import TelegramClient, events
from telethon.errors import FloodWaitError
from telethon.tl.functions.messages import CheckChatInviteRequest
from telethon.sessions import StringSession
from telethon.tl.types import ChatInviteAlready, InputMessagesFilterUrl

from app.config import get_settings
from app.crypto import SessionCipher
from app.db import SessionFactory
from app.link_utils import extract_urls_from_message, inspect_collection_link
from app.models import Account, CollectionCheckpoint, Job, JobCursor, SourceStat, WatchConfig, utcnow
from app.services.owners import get_primary_owner_id, is_owner, is_primary_owner
from app.runtime import live_handlers_suspended, reset_in_progress
from app.services.publisher import BatchPublisher
from app.services.repository import BatchLinkSource, register_link, register_links_batch

logger = logging.getLogger(__name__)
settings = get_settings()
cipher = SessionCipher()


class JobCancelled(RuntimeError):
    pass


class JobPaused(RuntimeError):
    pass


def _is_connection_problem(exc: BaseException) -> bool:
    """Return True for transient Telethon/network disconnect conditions."""
    if isinstance(exc, (ConnectionError, TimeoutError, asyncio.TimeoutError, OSError)):
        return True
    text = str(exc).lower()
    return any(
        marker in text
        for marker in (
            "cannot send requests while disconnected",
            "not connected",
            "connection closed",
            "connection reset",
            "connection aborted",
            "connection lost",
            "timed out",
            "timeout",
            "disconnected",
        )
    )


def _collector_reconnect_delay(attempt: int) -> float:
    base = max(0.5, float(getattr(settings, "collector_reconnect_base_seconds", 2.0)))
    ceiling = max(base, float(getattr(settings, "collector_reconnect_max_seconds", 30.0)))
    return min(ceiling, base * (2 ** max(0, attempt - 1)))


def cutoff_for_scope(scope: str) -> datetime | None:
    now = datetime.now(timezone.utc)
    values = {
        "24h": timedelta(hours=24),
        "3d": timedelta(days=3),
        "7d": timedelta(days=7),
        "14d": timedelta(days=14),
        "30d": timedelta(days=30),
    }
    delta = values.get(scope)
    return now - delta if delta else None


async def set_job_progress(job_id: int, progress: dict[str, Any]) -> None:
    async with SessionFactory() as session:
        await session.execute(
            update(Job).where(Job.id == job_id).values(progress=progress, heartbeat_at=utcnow(), updated_at=utcnow())
        )
        await session.commit()


async def get_job_status(job_id: int) -> str | None:
    async with SessionFactory() as session:
        return await session.scalar(select(Job.status).where(Job.id == job_id))


async def ensure_job_active(job_id: int) -> None:
    if reset_in_progress.is_set():
        raise JobCancelled("تم إيقاف المهمة بسبب إعادة ضبط البوت.")
    status = await get_job_status(job_id)
    if status in {None, "cancel_requested", "cancelled", "stopping"}:
        raise JobCancelled("تم إلغاء المهمة بواسطة المستخدم.")
    if status in {"pause_requested", "paused"}:
        async with SessionFactory() as session:
            await session.execute(
                update(Job).where(Job.id == job_id).values(status="paused", paused_at=utcnow(), updated_at=utcnow())
            )
            await session.commit()
        raise JobPaused("تم إيقاف المهمة مؤقتًا؛ يمكن استكمالها لاحقًا من آخر نقطة محفوظة.")


async def job_cancel_requested(job_id: int) -> bool:
    if reset_in_progress.is_set():
        return True
    status = await get_job_status(job_id)
    return status in {None, "cancel_requested", "cancelled", "stopping"}


async def _load_cursor(job_id: int, cursor_key: str) -> JobCursor | None:
    async with SessionFactory() as session:
        return await session.scalar(
            select(JobCursor).where(JobCursor.job_id == job_id, JobCursor.cursor_key == cursor_key)
        )


async def _save_cursor(
    job_id: int, cursor_key: str, *, offset_id: int, status: str = "running", detail: str | None = None
) -> None:
    async with SessionFactory() as session:
        stmt = (
            insert(JobCursor)
            .values(job_id=job_id, cursor_key=cursor_key, offset_id=int(offset_id), status=status, detail=detail)
            .on_conflict_do_update(
                index_elements=[JobCursor.job_id, JobCursor.cursor_key],
                set_={"offset_id": int(offset_id), "status": status, "detail": detail, "updated_at": utcnow()},
            )
        )
        await session.execute(stmt)
        await session.execute(update(Job).where(Job.id == job_id).values(heartbeat_at=utcnow(), updated_at=utcnow()))
        await session.commit()




def _checkpoint_key(
    kind: str,
    identifier: str | int,
    category: str | None,
    operator_id: int | None = None,
) -> str:
    base = f"{kind}:{identifier}:category:{category or 'all'}"
    return f"operator:{int(operator_id)}:{base}" if operator_id is not None else base


async def _load_collection_high_water(source_key: str, fallback_key: str | None = None) -> int:
    async with SessionFactory() as session:
        value = await session.scalar(
            select(CollectionCheckpoint.high_water_message_id).where(CollectionCheckpoint.source_key == source_key)
        )
        if value is None and fallback_key and fallback_key != source_key:
            value = await session.scalar(
                select(CollectionCheckpoint.high_water_message_id).where(CollectionCheckpoint.source_key == fallback_key)
            )
        return int(value or 0)


async def _save_collection_high_water(source_key: str, high_water: int, category: str | None, status: str = "completed") -> None:
    if high_water < 0:
        return
    async with SessionFactory() as session:
        stmt = (
            insert(CollectionCheckpoint)
            .values(
                source_key=source_key, high_water_message_id=int(high_water), category=category,
                last_scan_at=utcnow(), last_status=status,
            )
            .on_conflict_do_update(
                index_elements=[CollectionCheckpoint.source_key],
                set_={
                    "high_water_message_id": int(high_water),
                    "category": category, "last_scan_at": utcnow(),
                    "last_status": status, "updated_at": utcnow(),
                },
            )
        )
        await session.execute(stmt)
        await session.commit()


async def _record_source_stat(
    source_key: str, category: str | None, *, messages: int, found: int, new_links: int, duplicates: int, errors: int
) -> None:
    label = category or "all"
    denom = max(1, int(messages))
    quality = max(0, min(100, int(round((new_links * 100.0) / denom))))
    async with SessionFactory() as session:
        existing = await session.scalar(
            select(SourceStat).where(SourceStat.source_key == source_key, SourceStat.category == label)
        )
        if existing:
            existing.scans = int(existing.scans or 0) + 1
            existing.messages_scanned = int(existing.messages_scanned or 0) + int(messages)
            existing.links_found = int(existing.links_found or 0) + int(found)
            existing.new_links = int(existing.new_links or 0) + int(new_links)
            existing.duplicate_links = int(existing.duplicate_links or 0) + int(duplicates)
            existing.errors = int(existing.errors or 0) + int(errors)
            existing.quality_score = quality
            existing.last_scan_at = utcnow()
        else:
            session.add(SourceStat(
                source_key=source_key, category=label, scans=1, messages_scanned=messages,
                links_found=found, new_links=new_links, duplicate_links=duplicates, errors=errors,
                quality_score=quality, last_scan_at=utcnow(),
            ))
        await session.commit()


async def _get_accounts() -> list[Account]:
    async with SessionFactory() as session:
        return list((await session.scalars(select(Account).where(Account.active.is_(True)).order_by(Account.id))).all())


async def account_items_for_operator(manager: "ClientManager", operator_id: int) -> list[tuple[int, TelegramClient]]:
    """Return only this operator's active Telethon clients.

    Pre-6.4 accounts have operator_id=NULL and are inherited only by the primary
    owner. This prevents supervisors from seeing or using one another's sessions.
    """
    primary = await get_primary_owner_id()
    result: list[tuple[int, TelegramClient]] = []
    for account_id, client in manager.clients.items():
        record = manager.account_records.get(account_id)
        if record is None:
            continue
        if record.operator_id is not None and int(record.operator_id) == int(operator_id):
            result.append((account_id, client))
        elif record.operator_id is None and primary is not None and int(primary) == int(operator_id):
            result.append((account_id, client))
    return result


class ClientManager:
    def __init__(self, bot: Bot) -> None:
        self.bot = bot
        self.clients: dict[int, TelegramClient] = {}
        self.account_records: dict[int, Account] = {}
        self._refresh_lock = asyncio.Lock()
        self._connect_locks: dict[int, asyncio.Lock] = {}
        self._watch_cache: list[WatchConfig] = []
        self._live_queue: asyncio.Queue[tuple[int, events.NewMessage.Event]] = asyncio.Queue(
            maxsize=max(100, int(settings.live_queue_max))
        )
        self._live_worker_tasks: list[asyncio.Task[Any]] = []

    async def start(self) -> None:
        if self._live_worker_tasks:
            return
        count = max(1, int(settings.live_workers))
        self._live_worker_tasks = [
            asyncio.create_task(self._live_worker(index + 1), name=f"live-worker-{index + 1}")
            for index in range(count)
        ]

    async def _live_worker(self, worker_no: int) -> None:
        while True:
            try:
                account_id, event = await self._live_queue.get()
                try:
                    await self._process_new_message(account_id, event)
                except asyncio.CancelledError:
                    raise
                except Exception:
                    logger.exception("Live queue worker %s failed for account %s", worker_no, account_id)
                finally:
                    self._live_queue.task_done()
            except asyncio.CancelledError:
                raise

    async def ensure_connected(
        self, account_id: int, *, attempts: int | None = None
    ) -> TelegramClient:
        """Ensure a stored Telethon client is live, reconnecting it when needed.

        V6.1 kept unchanged clients in ``self.clients`` even after Telethon had
        become disconnected.  Subsequent collection jobs therefore started
        with dead clients and ended as 0/N.  This method serializes reconnects
        per account and validates authorization before returning the client.
        """
        client = self.clients.get(account_id)
        if client is None:
            raise RuntimeError(f"حساب Telegram #{account_id} غير محمل في مدير الاتصالات.")
        lock = self._connect_locks.setdefault(account_id, asyncio.Lock())
        async with lock:
            if client.is_connected():
                return client

            max_attempts = max(1, int(
                attempts if attempts is not None
                else getattr(settings, "collector_reconnect_attempts", 3)
            ))
            last_error: BaseException | None = None
            for attempt in range(1, max_attempts + 1):
                try:
                    logger.warning(
                        "Reconnecting Telegram account=%s attempt=%s/%s",
                        account_id, attempt, max_attempts,
                    )
                    await client.connect()
                    if not await client.is_user_authorized():
                        raise RuntimeError("الجلسة غير مصرح بها.")
                    async with SessionFactory() as session:
                        await session.execute(
                            update(Account).where(Account.id == account_id).values(last_error=None)
                        )
                        await session.commit()
                    logger.info("Reconnected Telegram account=%s", account_id)
                    return client
                except Exception as exc:
                    last_error = exc
                    logger.warning(
                        "Reconnect failed account=%s attempt=%s/%s: %s",
                        account_id, attempt, max_attempts, exc,
                    )
                    if attempt < max_attempts:
                        await asyncio.sleep(_collector_reconnect_delay(attempt))

            detail = str(last_error or "تعذر الاتصال")[:2000]
            async with SessionFactory() as session:
                await session.execute(
                    update(Account).where(Account.id == account_id).values(last_error=detail)
                )
                await session.commit()
            raise ConnectionError(
                f"تعذر إعادة اتصال حساب Telegram #{account_id} بعد {max_attempts} محاولات: {detail}"
            ) from last_error

    async def refresh(self) -> None:
        async with self._refresh_lock:
            accounts = await _get_accounts()
            active_ids = {account.id for account in accounts}
            for account_id in list(self.clients):
                if account_id not in active_ids:
                    await self.clients.pop(account_id).disconnect()
                    self.account_records.pop(account_id, None)
                    self._connect_locks.pop(account_id, None)

            for account in accounts:
                previous = self.account_records.get(account.id)
                unchanged = (
                    previous is not None
                    and previous.encrypted_session == account.encrypted_session
                    and previous.encrypted_api_hash == account.encrypted_api_hash
                    and previous.api_id == account.api_id
                )
                if account.id in self.clients and unchanged:
                    self.account_records[account.id] = account
                    client = self.clients[account.id]
                    if client.is_connected():
                        continue
                    # Do not keep a dead client merely because its credentials
                    # are unchanged.  A network drop must be healed before a
                    # new collection/audit job is allowed to use the account.
                    try:
                        await self.ensure_connected(account.id)
                    except Exception as exc:
                        logger.warning("Account %s is still disconnected after refresh: %s", account.id, exc)
                    continue
                if account.id in self.clients:
                    await self.clients.pop(account.id).disconnect()
                self.account_records[account.id] = account
                try:
                    client = TelegramClient(
                        StringSession(cipher.decrypt(account.encrypted_session)),
                        account.api_id,
                        cipher.decrypt(account.encrypted_api_hash),
                        auto_reconnect=True,
                        connection_retries=5,
                        retry_delay=2,
                    )
                    await client.connect()
                    if not await client.is_user_authorized():
                        raise RuntimeError("الجلسة غير مصرح بها.")

                    async def new_message_handler(event: events.NewMessage.Event, account_id: int = account.id) -> None:
                        try:
                            # Backpressure: the Telethon callback only enqueues work; DB/publishing
                            # runs in bounded workers so bursts do not create unbounded tasks.
                            await self._live_queue.put((account_id, event))
                        except asyncio.CancelledError:
                            raise
                        except Exception:
                            logger.exception("Live message enqueue failed for account %s", account_id)

                    client.add_event_handler(new_message_handler, events.NewMessage(incoming=True))
                    self.clients[account.id] = client
                    async with SessionFactory() as session:
                        await session.execute(update(Account).where(Account.id == account.id).values(last_error=None))
                        await session.commit()
                    logger.info("Connected account %s (%s)", account.label, account.id)
                except Exception as exc:
                    logger.exception("Failed to connect account %s", account.id)
                    async with SessionFactory() as session:
                        await session.execute(
                            update(Account).where(Account.id == account.id).values(last_error=str(exc)[:2000])
                        )
                        await session.commit()
            await self.refresh_watches()

    async def refresh_watches(self) -> None:
        async with SessionFactory() as session:
            self._watch_cache = list(
                (await session.scalars(select(WatchConfig).where(WatchConfig.enabled.is_(True)))).all()
            )
        live_handlers_suspended.clear()

    async def close(self) -> None:
        for task in self._live_worker_tasks:
            task.cancel()
        if self._live_worker_tasks:
            await asyncio.gather(*self._live_worker_tasks, return_exceptions=True)
        self._live_worker_tasks.clear()
        for client in list(self.clients.values()):
            await client.disconnect()
        self.clients.clear()
        self._connect_locks.clear()

    async def _process_new_message(self, account_id: int, event: events.NewMessage.Event) -> None:
        if reset_in_progress.is_set() or live_handlers_suspended.is_set() or not self._watch_cache:
            return
        account_record = self.account_records.get(account_id)
        primary_owner_id = await get_primary_owner_id() if account_record and account_record.operator_id is None else None
        event_operator_id = (
            int(account_record.operator_id) if account_record and account_record.operator_id is not None
            else int(primary_owner_id) if primary_owner_id is not None else None
        )
        if event_operator_id is None or not await is_owner(event_operator_id):
            return
        urls = extract_urls_from_message(event.message)
        if not urls:
            return
        publisher = BatchPublisher(self.bot)
        for raw_url in urls:
            inspection = inspect_collection_link(raw_url)
            if not inspection.link:
                continue
            clean = inspection.link
            registration = await register_link(
                clean,
                origin="live",
                job_id=None,
                account_id=account_id,
                chat_id=event.chat_id,
                message_id=event.message.id,
                message_date=event.message.date,
            )
            if registration.blocked or registration.link is None:
                continue
            if not registration.created:
                continue
            destinations_seen: set[int] = set()
            for watch in self._watch_cache:
                if event_operator_id is None or int(watch.requested_by) != event_operator_id:
                    continue
                if clean.category not in watch.categories:
                    continue
                destination = watch.destinations.get(clean.category)
                if not destination or int(destination) in destinations_seen:
                    continue
                destinations_seen.add(int(destination))
                await publisher.add(int(destination), registration.link, None)
        await publisher.flush_all()


def _account_collection_score(account: Account | None) -> int:
    """Prefer healthier accounts when a shared dialog can be claimed by several accounts."""
    if account is None:
        return 0
    score = 100
    if str(account.health_status or "healthy") not in {"healthy", "ok"}:
        score -= 25
    score -= min(30, int(account.consecutive_errors or 0) * 5)
    score -= min(20, int(account.errors_count or 0) // 10)
    if account.flood_wait_until is not None:
        score -= 30
    return max(0, score)


def collection_scan_mode(job: Job) -> str:
    """Return the durable per-job collection mode.

    New jobs store ``collection_scan_mode`` in progress so the choice survives
    pause/resume and restarts. Legacy jobs fall back to .env defaults.
    """
    value = str((job.progress or {}).get("collection_scan_mode") or "").lower()
    if value in {"fast", "deep"}:
        return value
    return "fast" if settings.collector_fast_scan and not settings.exhaustive_link_scan else "deep"


async def process_accounts_job(job: Job, manager: ClientManager, bot: Bot) -> dict[str, Any]:
    """Collect links from group/channel histories using bounded account parallelism.

    Fast mode uses Telegram's server-side URL message filter, so the client does
    not download every ordinary text message just to discover that it contains
    no links. Extracted links are written to SQLite in bounded batches.
    """
    cutoff = cutoff_for_scope(job.scope)
    publisher = BatchPublisher(bot)
    account_items = sorted(
        await account_items_for_operator(manager, int(job.requested_by)),
        key=lambda item: (-_account_collection_score(manager.account_records.get(item[0])), item[0]),
    )
    if not account_items:
        raise RuntimeError("لا توجد حسابات Telethon فعالة.")
    legacy_checkpoint_fallback = await is_primary_owner(int(job.requested_by))

    worker_count = min(len(account_items), max(1, int(settings.collector_account_workers)))
    semaphore = asyncio.Semaphore(worker_count)
    base = dict(job.progress or {})
    counters: dict[str, Any] = {
        "accounts_total": len(account_items),
        "accounts_done": int(base.get("accounts_done", 0)),
        "dialogs": int(base.get("dialogs", 0)),
        "messages_scanned": int(base.get("messages_scanned", 0)),
        "messages_with_links": int(base.get("messages_with_links", 0)),
        "new_links": int(base.get("new_links", 0)),
        "duplicate_links": int(base.get("duplicate_links", 0)),
        "rejected_links": int(base.get("rejected_links", 0)),
        "dialog_errors": int(base.get("dialog_errors", 0)),
        "flood_waits": int(base.get("flood_waits", 0)),
        "reconnects": int(base.get("reconnects", 0)),
        "account_errors": int(base.get("account_errors", 0)),
        "account_report": dict(base.get("account_report", {})) if isinstance(base.get("account_report", {}), dict) else {},
        "collector_workers": worker_count,
        "collection_scan_mode": collection_scan_mode(job),
        "scan_mode": "fast_url_filter" if collection_scan_mode(job) == "fast" else "deep_all_messages",
        "incremental": job.scope == "new",
        "phase": "scanning_accounts",
    }
    counter_lock = asyncio.Lock()
    dialog_claim_lock = asyncio.Lock()
    claimed_dialogs: set[int] = set()
    for account_id, _client in account_items:
        record = manager.account_records.get(account_id)
        counters["account_report"][str(account_id)] = {
            "label": str(getattr(record, "label", None) or getattr(record, "username", None) or f"حساب {account_id}"),
            "status": "pending",
            "dialogs": 0,
            "messages": 0,
            "new_links": 0,
        }

    async def progress_tick(force: bool = False) -> None:
        every = max(1, int(settings.progress_update_every_messages))
        if force or int(counters["messages_scanned"]) % every == 0:
            await set_job_progress(job.id, dict(counters))
            await ensure_job_active(job.id)

    async def scan_account(account_id: int, client: TelegramClient) -> None:
        async with semaphore:
            completed_this_run = False
            local_dialogs_total = local_messages_total = local_new_total = 0
            async with counter_lock:
                report = counters["account_report"].setdefault(str(account_id), {})
                report["status"] = "running"
            try:
                client = await manager.ensure_connected(account_id)
                async for dialog in client.iter_dialogs():
                    await ensure_job_active(job.id)
                    if not (dialog.is_group or dialog.is_channel):
                        continue
                    dialog_key = int(dialog.id)
                    if settings.deduplicate_dialogs_across_accounts:
                        async with dialog_claim_lock:
                            if dialog_key in claimed_dialogs:
                                continue
                            claimed_dialogs.add(dialog_key)
                        cursor_key = f"dialog:{dialog_key}"
                    else:
                        cursor_key = f"account:{account_id}:dialog:{dialog_key}"

                    cursor = await _load_cursor(job.id, cursor_key)
                    if cursor and cursor.status == "completed":
                        continue
                    offset_id = int(cursor.offset_id if cursor else 0)
                    legacy_key = _checkpoint_key("dialog", dialog_key, job.category)
                    global_key = _checkpoint_key("dialog", dialog_key, job.category, int(job.requested_by))
                    baseline_high_water = (
                        await _load_collection_high_water(
                            global_key, legacy_key if legacy_checkpoint_fallback else None
                        )
                        if job.scope == "new" else 0
                    )
                    high_water_seen = baseline_high_water
                    local_messages = local_found = local_new = local_dup = 0
                    local_dialogs_total += 1
                    async with counter_lock:
                        counters["dialogs"] += 1

                    pending: list[tuple[BatchLinkSource, int | None]] = []
                    messages_since_checkpoint = 0
                    retry_count = 0
                    reconnect_count = 0

                    async def flush_pending(checkpoint_id: int, *, save_cursor: bool = True) -> None:
                        nonlocal pending, messages_since_checkpoint, local_new, local_dup
                        if pending:
                            sources = [item for item, _destination in pending]
                            registrations = await register_links_batch(sources, origin="account", job_id=job.id)
                            for registration, (_source, destination) in zip(registrations, pending):
                                if registration.blocked or registration.link is None:
                                    async with counter_lock:
                                        counters["duplicate_links"] += 1
                                        local_dup += 1
                                    continue
                                async with counter_lock:
                                    counters["new_links" if registration.created else "duplicate_links"] += 1
                                    if registration.created:
                                        local_new += 1
                                    else:
                                        local_dup += 1
                                if destination and (registration.created or registration.link.first_job_id == job.id):
                                    await publisher.add(int(destination), registration.link, job.id)
                            pending = []
                        if save_cursor:
                            await _save_cursor(job.id, cursor_key, offset_id=checkpoint_id)
                        messages_since_checkpoint = 0

                    while True:
                        try:
                            message_filter = InputMessagesFilterUrl if collection_scan_mode(job) == "fast" else None
                            iter_kwargs: dict[str, Any] = {"filter": message_filter, "offset_id": offset_id}
                            if job.scope == "new" and baseline_high_water > 0:
                                iter_kwargs["min_id"] = baseline_high_water
                            async for message in client.iter_messages(dialog.entity, **iter_kwargs):
                                await ensure_job_active(job.id)
                                if cutoff and message.date and message.date < cutoff:
                                    break

                                offset_id = int(message.id)
                                high_water_seen = max(high_water_seen, int(message.id))
                                messages_since_checkpoint += 1
                                local_messages += 1
                                async with counter_lock:
                                    counters["messages_scanned"] += 1

                                urls = extract_urls_from_message(message)
                                if urls:
                                    async with counter_lock:
                                        counters["messages_with_links"] += 1

                                for raw_url in urls:
                                    inspection = inspect_collection_link(raw_url, job.category)
                                    if not inspection.link:
                                        async with counter_lock:
                                            counters["rejected_links"] += 1
                                        continue
                                    clean = inspection.link
                                    local_found += 1
                                    destination = job.destinations.get(clean.category)
                                    pending.append(
                                        (
                                            BatchLinkSource(
                                                clean=clean,
                                                account_id=account_id,
                                                chat_id=int(dialog.id),
                                                message_id=message.id,
                                                message_date=message.date,
                                            ),
                                            int(destination) if destination else None,
                                        )
                                    )

                                if (
                                    len(pending) >= max(1, int(settings.collector_db_batch_links))
                                    or messages_since_checkpoint >= max(1, int(settings.collector_checkpoint_messages))
                                ):
                                    await flush_pending(offset_id)
                                await progress_tick()

                            await flush_pending(offset_id, save_cursor=False)
                            await _save_cursor(job.id, cursor_key, offset_id=offset_id, status="completed")
                            await _save_collection_high_water(global_key, high_water_seen, job.category, "completed")
                            await _record_source_stat(
                                global_key, job.category, messages=local_messages, found=local_found,
                                new_links=local_new, duplicates=local_dup, errors=0,
                            )
                            local_messages_total += local_messages
                            local_new_total += local_new
                            break
                        except FloodWaitError as exc:
                            async with counter_lock:
                                counters["flood_waits"] += 1
                            retry_count += 1
                            await flush_pending(offset_id)
                            await _save_cursor(
                                job.id, cursor_key, offset_id=offset_id, status="running", detail=f"FloodWait {exc.seconds}s"
                            )
                            if exc.seconds <= settings.max_flood_wait_seconds and retry_count <= 5:
                                await asyncio.sleep(exc.seconds + 1)
                                await ensure_job_active(job.id)
                                continue
                            async with counter_lock:
                                counters["dialog_errors"] += 1
                            await _save_cursor(
                                job.id, cursor_key, offset_id=offset_id, status="error", detail=f"FloodWait {exc.seconds}s"
                            )
                            if settings.deduplicate_dialogs_across_accounts:
                                async with dialog_claim_lock:
                                    claimed_dialogs.discard(dialog_key)
                            break
                        except (JobCancelled, JobPaused):
                            await flush_pending(offset_id)
                            await _save_cursor(job.id, cursor_key, offset_id=offset_id, status="paused")
                            raise
                        except Exception as exc:
                            if _is_connection_problem(exc):
                                reconnect_count += 1
                                await flush_pending(offset_id)
                                await _save_cursor(
                                    job.id, cursor_key, offset_id=offset_id, status="running",
                                    detail=f"Reconnect {reconnect_count}: {str(exc)[:500]}",
                                )
                                max_reconnects = max(1, int(getattr(settings, "collector_reconnect_attempts", 3)))
                                if reconnect_count <= max_reconnects:
                                    async with counter_lock:
                                        counters["reconnects"] += 1
                                    try:
                                        client = await manager.ensure_connected(account_id)
                                    except Exception as reconnect_exc:
                                        logger.warning(
                                            "Dialog reconnect failed account=%s dialog=%s attempt=%s: %s",
                                            account_id, dialog.id, reconnect_count, reconnect_exc,
                                        )
                                    await asyncio.sleep(_collector_reconnect_delay(reconnect_count))
                                    await ensure_job_active(job.id)
                                    continue

                            logger.warning("Dialog scan failed account=%s dialog=%s: %s", account_id, dialog.id, exc)
                            await flush_pending(offset_id)
                            async with counter_lock:
                                counters["dialog_errors"] += 1
                            await _save_cursor(job.id, cursor_key, offset_id=offset_id, status="error", detail=str(exc)[:1000])
                            if settings.deduplicate_dialogs_across_accounts:
                                async with dialog_claim_lock:
                                    claimed_dialogs.discard(dialog_key)
                            break
                completed_this_run = True
            except (JobCancelled, JobPaused):
                async with counter_lock:
                    counters["account_report"][str(account_id)].update({
                        "status": "paused", "dialogs": local_dialogs_total,
                        "messages": local_messages_total, "new_links": local_new_total,
                    })
                raise
            except Exception as exc:
                async with counter_lock:
                    counters["account_report"][str(account_id)].update({
                        "status": "error", "dialogs": local_dialogs_total,
                        "messages": local_messages_total, "new_links": local_new_total,
                        "error": str(exc)[:300],
                    })
                raise
            finally:
                if completed_this_run:
                    async with counter_lock:
                        counters["accounts_done"] = min(counters["accounts_total"], counters["accounts_done"] + 1)
                        counters["account_report"][str(account_id)].update({
                            "status": "completed", "dialogs": local_dialogs_total,
                            "messages": local_messages_total, "new_links": local_new_total,
                        })
                await set_job_progress(job.id, dict(counters))

    results = await asyncio.gather(
        *(scan_account(account_id, client) for account_id, client in account_items), return_exceptions=True
    )
    for result in results:
        if isinstance(result, (JobCancelled, JobPaused)):
            raise result
        if isinstance(result, Exception):
            logger.error("Account scan task failed: %s", result)
            counters["dialog_errors"] += 1
            counters["account_errors"] += 1

    if int(counters.get("accounts_done", 0)) == 0 and int(counters.get("account_errors", 0)) > 0:
        counters["phase"] = "connection_failed"
        await set_job_progress(job.id, dict(counters))
        raise RuntimeError(
            "تعذر تشغيل جميع حسابات Telegram بعد محاولات إعادة الاتصال. "
            "تم حفظ التقدم والـcheckpoints؛ استخدم إعادة/استكمال المهمة بعد استقرار الاتصال."
        )

    await publisher.flush_all()
    counters["sent_links"] = publisher.sent_count
    counters["delivery_skipped"] = publisher.skipped_count
    counters["delivery_failed"] = publisher.failed_count
    if publisher.errors:
        counters["delivery_errors"] = publisher.errors
    counters["phase"] = "completed"
    await progress_tick(force=True)
    return counters

INVITE_RE = re.compile(
    r"^https?://(?:www\.)?(?:t\.me|telegram\.me)/(?:joinchat/|\+)([A-Za-z0-9_-]+)/?$",
    re.I,
)
PUBLIC_RE = re.compile(
    r"^https?://(?:www\.)?(?:t\.me|telegram\.me)/([A-Za-z0-9_]{4,})/?$",
    re.I,
)


async def resolve_source_entity(client: TelegramClient, source: str):  # type: ignore[no-untyped-def]
    source = source.strip()
    if source.lstrip("-").isdigit():
        wanted_id = int(source)
        async for dialog in client.iter_dialogs():
            if int(dialog.id) == wanted_id:
                return dialog.entity
        raise ValueError(f"المصدر الرقمي {source} غير موجود ضمن محادثات الحساب.")

    invite = INVITE_RE.fullmatch(source)
    if invite:
        result = await client(CheckChatInviteRequest(invite.group(1)))
        if isinstance(result, ChatInviteAlready):
            return result.chat
        raise ValueError("الحساب ليس عضوًا في رابط الدعوة الخاص، والبوت لا ينضم تلقائيًا.")

    public = PUBLIC_RE.fullmatch(source)
    if public:
        return await client.get_entity("@" + public.group(1))
    if source.startswith("@"):
        return await client.get_entity(source)
    return await client.get_entity(source)


async def _prioritize_explicit_sources(sources: list[str], category: str | None) -> list[str]:
    """Scan historically high-yield sources first; unseen sources keep original priority."""
    if len(sources) < 2:
        return list(sources)
    keys = [(_checkpoint_key("source", source, category), source, index) for index, source in enumerate(sources)]
    async with SessionFactory() as session:
        rows = list((await session.scalars(
            select(SourceStat).where(
                SourceStat.source_key.in_([key for key, _source, _index in keys]),
                SourceStat.category == (category or "all"),
            )
        )).all())
    scores = {row.source_key: int(row.quality_score or 0) for row in rows}
    return [
        source for key, source, index in sorted(
            keys, key=lambda item: (-(scores.get(item[0], 0)), item[2])
        )
    ]


async def process_sources_job(job: Job, manager: ClientManager, bot: Bot) -> dict[str, Any]:
    """Collect links from explicitly selected Telegram groups/channels.

    V6 keeps collection read-only: URLs are recognized, normalized, deduplicated,
    stored and optionally published. No Telegram link validity/audit request is
    made here. A category may be selected, or all categories may be collected.
    """
    base = dict(job.progress or {})
    target_category = str(job.category or "").strip() or None
    cutoff = cutoff_for_scope(job.scope)
    publisher = BatchPublisher(bot)
    counters: dict[str, Any] = {
        "sources_total": len(job.sources),
        "sources_done": int(base.get("sources_done", 0)),
        "messages_scanned": int(base.get("messages_scanned", 0)),
        "messages_with_links": int(base.get("messages_with_links", 0)),
        "new_links": int(base.get("new_links", 0)),
        "duplicate_links": int(base.get("duplicate_links", 0)),
        "rejected_links": int(base.get("rejected_links", 0)),
        "source_errors": int(base.get("source_errors", 0)),
        "errors": list(base.get("errors", []))[-20:],
        "collection_scan_mode": collection_scan_mode(job),
        "scan_mode": "fast_url_filter" if collection_scan_mode(job) == "fast" else "deep_all_messages",
        "incremental": job.scope == "new",
        "category": target_category or "all",
        "phase": "scanning_sources",
    }
    clients = await account_items_for_operator(manager, int(job.requested_by))
    if not clients:
        raise RuntimeError("لا توجد حسابات Telethon فعالة لهذا المشرف للوصول إلى المصادر.")
    legacy_checkpoint_fallback = await is_primary_owner(int(job.requested_by))

    prioritized_sources = await _prioritize_explicit_sources(list(job.sources), target_category)
    for source in prioritized_sources:
        await ensure_job_active(job.id)
        cursor_key = f"source:{source}:category:{target_category or 'all'}"
        cursor = await _load_cursor(job.id, cursor_key)
        if cursor and cursor.status == "completed":
            continue
        offset_id = int(cursor.offset_id if cursor else 0)
        legacy_key = _checkpoint_key("source", source, target_category)
        global_key = _checkpoint_key("source", source, target_category, int(job.requested_by))
        baseline_high_water = (
            await _load_collection_high_water(
                global_key, legacy_key if legacy_checkpoint_fallback else None
            )
            if job.scope == "new" else 0
        )
        high_water_seen = baseline_high_water
        resolved = False
        last_error: Exception | None = None

        for account_id, client in clients:
            local_messages = local_found = local_new = local_dup = local_errors = 0
            try:
                client = await manager.ensure_connected(account_id)
                entity = await resolve_source_entity(client, source)
                retry_count = 0
                pending: list[tuple[BatchLinkSource, int | None]] = []
                messages_since_checkpoint = 0

                async def flush_pending(checkpoint_id: int, *, save_cursor: bool = True) -> None:
                    nonlocal pending, messages_since_checkpoint, local_new, local_dup
                    if pending:
                        registrations = await register_links_batch(
                            [entry for entry, _destination in pending], origin="source", job_id=job.id
                        )
                        for registration, (_entry, destination) in zip(registrations, pending):
                            if registration.blocked or registration.link is None:
                                counters["duplicate_links"] += 1
                                local_dup += 1
                                continue
                            if registration.created:
                                counters["new_links"] += 1
                                local_new += 1
                            else:
                                counters["duplicate_links"] += 1
                                local_dup += 1
                            if destination and (registration.created or registration.link.first_job_id == job.id):
                                await publisher.add(int(destination), registration.link, job.id)
                        pending = []
                    if save_cursor:
                        await _save_cursor(job.id, cursor_key, offset_id=checkpoint_id)
                    messages_since_checkpoint = 0

                while True:
                    try:
                        message_filter = InputMessagesFilterUrl if collection_scan_mode(job) == "fast" else None
                        kwargs: dict[str, Any] = {"filter": message_filter, "offset_id": offset_id}
                        if job.scope == "new" and baseline_high_water > 0:
                            kwargs["min_id"] = baseline_high_water
                        async for message in client.iter_messages(entity, **kwargs):
                            await ensure_job_active(job.id)
                            if cutoff and message.date and message.date < cutoff:
                                break
                            offset_id = int(message.id)
                            high_water_seen = max(high_water_seen, int(message.id))
                            messages_since_checkpoint += 1
                            counters["messages_scanned"] += 1
                            local_messages += 1
                            urls = extract_urls_from_message(message)
                            if urls:
                                counters["messages_with_links"] += 1
                            for raw_url in urls:
                                inspection = inspect_collection_link(raw_url, target_category)
                                if not inspection.link:
                                    counters["rejected_links"] += 1
                                    continue
                                local_found += 1
                                clean = inspection.link
                                destination = job.destinations.get(clean.category)
                                pending.append((
                                    BatchLinkSource(
                                        clean=clean,
                                        account_id=account_id,
                                        chat_id=int(getattr(entity, "id", 0) or 0),
                                        message_id=message.id,
                                        message_date=message.date,
                                    ),
                                    int(destination) if destination else None,
                                ))
                            if (
                                len(pending) >= max(1, int(settings.collector_db_batch_links))
                                or messages_since_checkpoint >= max(1, int(settings.collector_checkpoint_messages))
                            ):
                                await flush_pending(offset_id)
                            if counters["messages_scanned"] % max(1, settings.progress_update_every_messages) == 0:
                                await set_job_progress(job.id, dict(counters))
                        await flush_pending(offset_id, save_cursor=False)
                        await _save_cursor(job.id, cursor_key, offset_id=offset_id, status="completed")
                        await _save_collection_high_water(global_key, high_water_seen, target_category, "completed")
                        resolved = True
                        break
                    except FloodWaitError as exc:
                        last_error = exc
                        retry_count += 1
                        await flush_pending(offset_id)
                        await _save_cursor(
                            job.id, cursor_key, offset_id=offset_id, status="running", detail=f"FloodWait {exc.seconds}s"
                        )
                        # Prefer another already-authorized account for this source
                        # instead of turning collection into a long blocking wait.
                        if retry_count <= 1 and len(clients) > 1:
                            break
                        if exc.seconds <= settings.max_flood_wait_seconds and retry_count <= 5:
                            await asyncio.sleep(exc.seconds + 1)
                            await ensure_job_active(job.id)
                            continue
                        break
                if resolved:
                    await _record_source_stat(
                        global_key, target_category, messages=local_messages, found=local_found,
                        new_links=local_new, duplicates=local_dup, errors=local_errors,
                    )
                    break
            except (JobCancelled, JobPaused):
                await _save_cursor(job.id, cursor_key, offset_id=offset_id, status="paused")
                raise
            except Exception as exc:
                last_error = exc
                local_errors += 1
                continue

        if not resolved:
            counters["source_errors"] += 1
            if len(counters["errors"]) < 20:
                counters["errors"].append(f"{source}: {last_error}")
            await _save_cursor(job.id, cursor_key, offset_id=offset_id, status="error", detail=str(last_error)[:1000])
            await _record_source_stat(
                global_key, target_category, messages=0, found=0, new_links=0, duplicates=0, errors=1
            )
        else:
            counters["sources_done"] = min(counters["sources_total"], counters["sources_done"] + 1)
        await set_job_progress(job.id, dict(counters))

    await publisher.flush_all()
    counters["sent_links"] = publisher.sent_count
    counters["delivery_skipped"] = publisher.skipped_count
    counters["delivery_failed"] = publisher.failed_count
    if publisher.errors:
        counters["delivery_errors"] = publisher.errors
    counters["phase"] = "completed"
    await set_job_progress(job.id, dict(counters))
    return counters

async def claim_next_job() -> Job | None:
    """Atomically claim the oldest runnable job.

    V6.4 may run several worker loops so supervisors do not block one another.
    Only one active job per ``requested_by`` is allowed, which prevents two
    tasks from driving the same supervisor's Telethon accounts concurrently.
    """
    active_statuses = {"starting", "running", "pause_requested", "stopping", "cancel_requested"}
    async with SessionFactory() as session:
        other = aliased(Job)
        active_same_operator = (
            select(other.id)
            .where(
                other.requested_by == Job.requested_by,
                other.status.in_(active_statuses),
            )
            .exists()
        )
        candidate_id = await session.scalar(
            select(Job.id)
            .where(Job.status == "queued", ~active_same_operator)
            .order_by(Job.id)
            .limit(1)
        )
        if candidate_id is None:
            return None
        now = utcnow()
        # Conditional UPDATE is the second line of defense when worker loops race.
        result = await session.execute(
            update(Job)
            .where(Job.id == candidate_id, Job.status == "queued")
            .values(
                status="starting", started_at=now, updated_at=now, heartbeat_at=now,
                paused_at=None, finished_at=None, error=None,
            )
        )
        await session.commit()
        if not result.rowcount:
            return None
        job = await session.get(Job, int(candidate_id))
        if not job:
            return None
        job.status = "running"
        job.heartbeat_at = utcnow()
        job.updated_at = utcnow()
        await session.commit()
        await session.refresh(job)
        return job


async def finish_job(job_id: int, *, status: str = "completed", error: str | None = None) -> bool:
    now = utcnow()
    async with SessionFactory() as session:
        values: dict[str, Any] = {"status": status, "error": error, "updated_at": now, "heartbeat_at": now}
        if status == "paused":
            values["paused_at"] = now
            values["finished_at"] = None
        elif status in {"completed", "completed_with_errors", "failed", "cancelled"}:
            values["finished_at"] = now
        result = await session.execute(update(Job).where(Job.id == job_id).values(**values))
        await session.commit()
        return bool(result.rowcount)
