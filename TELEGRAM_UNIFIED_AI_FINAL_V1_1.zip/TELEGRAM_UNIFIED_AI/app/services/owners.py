from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.dialects.sqlite import insert

from app.config import get_settings
from app.db import SessionFactory
from app.models import AppSetting

settings = get_settings()
LEGACY_OWNER_KEY = "owner_ids"
PRIMARY_OWNER_KEY = "primary_owner_id"
SUPERVISOR_IDS_KEY = "supervisor_ids"
SESSION_SUPERVISOR_IDS_KEY = "session_supervisor_ids"


def _normalize_ids(value: object) -> list[int]:
    if not isinstance(value, list):
        return []
    result: list[int] = []
    for item in value:
        raw = str(item)
        if raw.lstrip("-").isdigit():
            result.append(int(raw))
    return list(dict.fromkeys(result))


async def get_primary_owner_id() -> int | None:
    """Return the one primary owner.

    If ADMIN_IDS is configured, its first ID is authoritative. Otherwise the
    first claimant is persisted in SQLite. Legacy owner_ids is read as a safe
    upgrade fallback so an existing Termux install keeps its owner.
    """
    if settings.admin_ids:
        return int(settings.admin_ids[0])
    async with SessionFactory() as session:
        value = await session.scalar(select(AppSetting.value).where(AppSetting.key == PRIMARY_OWNER_KEY))
        if str(value).lstrip("-").isdigit():
            return int(value)
        legacy = await session.scalar(select(AppSetting.value).where(AppSetting.key == LEGACY_OWNER_KEY))
    ids = _normalize_ids(legacy)
    return ids[0] if ids else None


async def get_supervisor_ids() -> list[int]:
    configured = [int(value) for value in settings.admin_ids[1:]] if len(settings.admin_ids) > 1 else []
    async with SessionFactory() as session:
        value = await session.scalar(select(AppSetting.value).where(AppSetting.key == SUPERVISOR_IDS_KEY))
    primary = await get_primary_owner_id()
    result = list(dict.fromkeys(configured + _normalize_ids(value)))
    return [value for value in result if primary is None or value != primary]


async def get_owner_ids() -> list[int]:
    """Compatibility helper: all authorized operators (owner + supervisors)."""
    primary = await get_primary_owner_id()
    supervisors = await get_supervisor_ids()
    return ([primary] if primary is not None else []) + supervisors


async def is_owner(user_id: int | None) -> bool:
    """Compatibility name used by old handlers; means authorized operator."""
    if user_id is None:
        return False
    return int(user_id) in await get_owner_ids()


async def is_primary_owner(user_id: int | None) -> bool:
    if user_id is None:
        return False
    primary = await get_primary_owner_id()
    return primary is not None and int(user_id) == int(primary)


async def claim_first_owner(user_id: int) -> bool:
    """Claim primary ownership once, or authorize an already-added supervisor."""
    user_id = int(user_id)
    if settings.admin_ids:
        return user_id in await get_owner_ids()

    primary = await get_primary_owner_id()
    if primary is not None:
        return user_id in await get_owner_ids()

    async with SessionFactory() as session:
        await session.execute(
            insert(AppSetting)
            .values(key=PRIMARY_OWNER_KEY, value=user_id)
            .on_conflict_do_nothing(index_elements=[AppSetting.key])
        )
        # Keep the legacy key populated for older maintenance scripts.
        await session.execute(
            insert(AppSetting)
            .values(key=LEGACY_OWNER_KEY, value=[user_id])
            .on_conflict_do_nothing(index_elements=[AppSetting.key])
        )
        await session.commit()
    return await is_primary_owner(user_id)


async def add_supervisor(user_id: int) -> bool:
    """Persist a supervisor ID. Returns False when it already exists/owner."""
    user_id = int(user_id)
    primary = await get_primary_owner_id()
    if primary is not None and user_id == primary:
        return False
    async with SessionFactory() as session:
        value = await session.scalar(select(AppSetting.value).where(AppSetting.key == SUPERVISOR_IDS_KEY))
        ids = _normalize_ids(value)
        if user_id in ids or user_id in [int(v) for v in settings.admin_ids[1:]]:
            return False
        ids.append(user_id)
        await session.execute(
            insert(AppSetting)
            .values(key=SUPERVISOR_IDS_KEY, value=ids)
            .on_conflict_do_update(index_elements=[AppSetting.key], set_={"value": ids})
        )
        await session.commit()
    return True


async def remove_supervisor(user_id: int) -> bool:
    """Remove a database-added supervisor. ADMIN_IDS entries are immutable here."""
    user_id = int(user_id)
    if user_id in [int(v) for v in settings.admin_ids[1:]]:
        return False
    async with SessionFactory() as session:
        value = await session.scalar(select(AppSetting.value).where(AppSetting.key == SUPERVISOR_IDS_KEY))
        ids = _normalize_ids(value)
        if user_id not in ids:
            return False
        ids = [value for value in ids if value != user_id]
        await session.execute(
            insert(AppSetting)
            .values(key=SUPERVISOR_IDS_KEY, value=ids)
            .on_conflict_do_update(index_elements=[AppSetting.key], set_={"value": ids})
        )
        await session.commit()
    return True


async def get_session_supervisor_ids() -> list[int]:
    async with SessionFactory() as session:
        value = await session.scalar(select(AppSetting.value).where(AppSetting.key == SESSION_SUPERVISOR_IDS_KEY))
    primary = await get_primary_owner_id()
    normal = set(await get_supervisor_ids())
    return [value for value in _normalize_ids(value) if (primary is None or value != primary) and value not in normal]


async def is_session_supervisor(user_id: int | None) -> bool:
    if user_id is None:
        return False
    return int(user_id) in await get_session_supervisor_ids()


async def add_session_supervisor(user_id: int) -> bool:
    user_id = int(user_id)
    if await is_owner(user_id):
        return False
    async with SessionFactory() as session:
        value = await session.scalar(select(AppSetting.value).where(AppSetting.key == SESSION_SUPERVISOR_IDS_KEY))
        ids = _normalize_ids(value)
        if user_id in ids:
            return False
        ids.append(user_id)
        await session.execute(
            insert(AppSetting).values(key=SESSION_SUPERVISOR_IDS_KEY, value=ids)
            .on_conflict_do_update(index_elements=[AppSetting.key], set_={"value": ids})
        )
        await session.commit()
    return True


async def remove_session_supervisor(user_id: int) -> bool:
    user_id = int(user_id)
    async with SessionFactory() as session:
        value = await session.scalar(select(AppSetting.value).where(AppSetting.key == SESSION_SUPERVISOR_IDS_KEY))
        ids = _normalize_ids(value)
        if user_id not in ids:
            return False
        ids = [item for item in ids if item != user_id]
        await session.execute(
            insert(AppSetting).values(key=SESSION_SUPERVISOR_IDS_KEY, value=ids)
            .on_conflict_do_update(index_elements=[AppSetting.key], set_={"value": ids})
        )
        await session.commit()
    return True
