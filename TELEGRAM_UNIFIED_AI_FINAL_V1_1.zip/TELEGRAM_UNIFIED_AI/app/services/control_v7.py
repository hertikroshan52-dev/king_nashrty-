from __future__ import annotations

from datetime import timedelta
from pathlib import Path
import platform
import shutil
import sys
from typing import Any

from sqlalchemy import func, or_, select, update

from app.config import get_settings
from app.db import SessionFactory
from app.models import (
    Account, AdminActionLog, EntityTag, Job, Link, ScheduledTask, SessionEvent,
    SystemError, TelegramAudit, Workflow, utcnow,
)
from app.services.accounts import account_belongs_to_operator, list_accounts, test_account_connection
from app.services.backup import create_database_backup
from app.services.owners import is_primary_owner

settings = get_settings()


async def session_event(operator_id: int, event: str, *, account_id: int | None = None, detail: str | None = None) -> None:
    async with SessionFactory() as session:
        session.add(SessionEvent(operator_id=int(operator_id), account_id=account_id, event=event[:64], detail=(detail or "")[:4000] or None))
        await session.commit()


async def session_health(operator_id: int) -> list[dict[str, Any]]:
    rows = await list_accounts(int(operator_id))
    result: list[dict[str, Any]] = []
    for account in rows:
        score = 100
        if not account.active:
            score -= 40
        if str(account.health_status or "healthy") not in {"healthy", "ok"}:
            score -= 20
        score -= min(25, int(account.consecutive_errors or 0) * 5)
        if account.flood_wait_until:
            score -= 25
        result.append({
            "id": int(account.id), "label": account.label, "username": account.username,
            "active": bool(account.active), "health_status": account.health_status or "healthy",
            "score": max(0, score), "last_error": account.last_error,
            "flood_wait_until": account.flood_wait_until,
        })
    return result


async def set_session_active(operator_id: int, account_id: int, active: bool) -> bool:
    async with SessionFactory() as session:
        account = await session.get(Account, int(account_id))
        if not account or not await account_belongs_to_operator(account, int(operator_id)):
            return False
        account.active = bool(active)
        account.last_error = None
        await session.commit()
    await session_event(operator_id, "session_enabled" if active else "session_disabled", account_id=account_id)
    return True


async def delete_session_local(operator_id: int, account_id: int) -> bool:
    from sqlalchemy import delete
    async with SessionFactory() as session:
        account = await session.get(Account, int(account_id))
        if not account or not await account_belongs_to_operator(account, int(operator_id)):
            return False
        # Delete only the local encrypted credential record. This does not claim
        # to revoke every Telegram device session; users can do that in Telegram.
        await session.delete(account)
        await session.commit()
    await session_event(operator_id, "session_deleted_local", account_id=None, detail=f"account_id={account_id}")
    return True


async def create_scheduled_task(requested_by: int, task_type: str, title: str, delay_seconds: int, *, interval_seconds: int | None = None, payload: dict[str, Any] | None = None) -> ScheduledTask:
    now = utcnow()
    row = ScheduledTask(
        requested_by=int(requested_by), task_type=task_type[:40], title=title[:160],
        payload=payload or {}, status="scheduled", next_run_at=now + timedelta(seconds=max(1, int(delay_seconds))),
        interval_seconds=int(interval_seconds) if interval_seconds else None,
    )
    async with SessionFactory() as session:
        session.add(row)
        await session.commit(); await session.refresh(row)
        return row


async def list_scheduled_tasks(requested_by: int, limit: int = 20) -> list[ScheduledTask]:
    async with SessionFactory() as session:
        return list((await session.scalars(
            select(ScheduledTask).where(ScheduledTask.requested_by == int(requested_by)).order_by(ScheduledTask.id.desc()).limit(limit)
        )).all())


async def cancel_scheduled_task(requested_by: int, task_id: int) -> bool:
    async with SessionFactory() as session:
        row = await session.get(ScheduledTask, int(task_id))
        if not row or int(row.requested_by) != int(requested_by): return False
        row.status = "cancelled"; row.updated_at = utcnow(); await session.commit(); return True


async def claim_due_tasks(limit: int = 10) -> list[ScheduledTask]:
    now = utcnow()
    async with SessionFactory() as session:
        rows = list((await session.scalars(
            select(ScheduledTask).where(ScheduledTask.status == "scheduled", ScheduledTask.next_run_at <= now).order_by(ScheduledTask.next_run_at, ScheduledTask.id).limit(limit)
        )).all())
        for row in rows:
            row.status = "running"; row.updated_at = now
        await session.commit()
        return rows


async def finish_scheduled_task(task_id: int, *, error: str | None = None) -> None:
    now = utcnow()
    async with SessionFactory() as session:
        row = await session.get(ScheduledTask, int(task_id))
        if not row: return
        row.last_run_at = now; row.last_error = (error or "")[:4000] or None
        if error:
            row.status = "failed"
        elif row.interval_seconds:
            row.status = "scheduled"; row.next_run_at = now + timedelta(seconds=max(60, int(row.interval_seconds)))
        else:
            row.status = "completed"
        row.updated_at = now; await session.commit()


async def create_workflow(requested_by: int, name: str, steps: list[dict[str, Any]]) -> Workflow:
    row = Workflow(requested_by=int(requested_by), name=name.strip()[:160] or "Workflow", steps=steps, enabled=True)
    async with SessionFactory() as session:
        session.add(row); await session.commit(); await session.refresh(row); return row


async def create_preset_workflow(requested_by: int, preset: str, name: str | None = None) -> Workflow:
    presets: dict[str, list[dict[str, Any]]] = {
        "telegram_new": [{"type":"collect_accounts","category":"telegram","scope":"new"},{"type":"notify","text":"اكتمل إطلاق Workflow تجميع Telegram الجديد."}],
        "all_new": [{"type":"collect_accounts","category":None,"scope":"new"},{"type":"notify","text":"اكتمل إطلاق Workflow تجميع كل الروابط الجديدة."}],
        "health_backup": [{"type":"health"},{"type":"backup"},{"type":"notify","text":"اكتمل Workflow الصحة والنسخ الاحتياطي."}],
    }
    if preset not in presets: raise ValueError("Preset غير معروف")
    return await create_workflow(requested_by, name or preset, presets[preset])


async def list_workflows(requested_by: int, limit: int = 20) -> list[Workflow]:
    async with SessionFactory() as session:
        return list((await session.scalars(select(Workflow).where(Workflow.requested_by == int(requested_by)).order_by(Workflow.id.desc()).limit(limit))).all())


async def delete_workflow(requested_by: int, workflow_id: int) -> bool:
    async with SessionFactory() as session:
        row = await session.get(Workflow, int(workflow_id))
        if not row or int(row.requested_by) != int(requested_by): return False
        await session.delete(row); await session.commit(); return True


async def run_workflow(workflow_id: int, requested_by: int, bot=None) -> list[str]:
    messages: list[str] = []
    async with SessionFactory() as session:
        wf = await session.get(Workflow, int(workflow_id))
        if not wf or int(wf.requested_by) != int(requested_by): raise ValueError("Workflow غير موجود")
        if not wf.enabled: raise ValueError("Workflow متوقف")
        steps = list(wf.steps or [])
    for step in steps:
        kind = str(step.get("type") or "")
        if kind == "collect_accounts":
            async with SessionFactory() as session:
                row = Job(requested_by=int(requested_by), mode="accounts", scope=str(step.get("scope") or "new"), category=step.get("category"), sources=[], destinations={}, status="queued", progress={"created_by":"v7_workflow"})
                session.add(row); await session.commit(); await session.refresh(row)
                messages.append(f"تم إنشاء مهمة جمع #{row.id}")
        elif kind == "backup":
            info = await create_database_backup(prefix="workflow")
            messages.append(f"تم إنشاء Backup: {Path(info.path).name}")
        elif kind == "health":
            health = await session_health(requested_by)
            messages.append(f"الحسابات: {len(health)} | سليمة 80+: {sum(1 for x in health if x['score'] >= 80)}")
        elif kind == "notify" and bot is not None:
            text = str(step.get("text") or "Workflow completed")
            await bot.send_message(int(requested_by), text)
    async with SessionFactory() as session:
        wf = await session.get(Workflow, int(workflow_id))
        if wf:
            wf.run_count = int(wf.run_count or 0) + 1; wf.last_run_at = utcnow(); wf.last_error = None; await session.commit()
    return messages


async def add_tag(requested_by: int, entity_type: str, entity_key: str, tag: str, note: str | None = None) -> EntityTag:
    from sqlalchemy.dialects.sqlite import insert
    values = dict(requested_by=int(requested_by), entity_type=entity_type[:32], entity_key=entity_key.strip()[:512], tag=tag.strip()[:80], note=(note or "")[:4000] or None)
    async with SessionFactory() as session:
        stmt = insert(EntityTag).values(**values).on_conflict_do_update(
            index_elements=[EntityTag.requested_by, EntityTag.entity_type, EntityTag.entity_key, EntityTag.tag], set_={"note": values["note"], "updated_at": utcnow()}
        ).returning(EntityTag.id)
        tag_id = (await session.execute(stmt)).scalar_one(); await session.commit(); return await session.get(EntityTag, int(tag_id))


async def list_tags(requested_by: int, limit: int = 30) -> list[EntityTag]:
    async with SessionFactory() as session:
        return list((await session.scalars(select(EntityTag).where(EntityTag.requested_by == int(requested_by)).order_by(EntityTag.id.desc()).limit(limit))).all())


async def global_search(requested_by: int, query: str) -> dict[str, list[str]]:
    q = query.strip(); result: dict[str, list[str]] = {"accounts":[], "links":[], "jobs":[], "tags":[]}
    like = f"%{q}%"
    async with SessionFactory() as session:
        accounts = list((await session.scalars(select(Account).where(Account.operator_id == int(requested_by), or_(Account.label.ilike(like), Account.username.ilike(like))).limit(10))).all())
        links = []
        if await is_primary_owner(int(requested_by)):
            links = list((await session.scalars(select(Link).where(or_(Link.normalized_url.ilike(like), Link.original_url.ilike(like))).limit(10))).all())
        jobs = list((await session.scalars(select(Job).where(Job.requested_by == int(requested_by), or_(Job.mode.ilike(like), Job.status.ilike(like), Job.error.ilike(like))).order_by(Job.id.desc()).limit(10))).all())
        tags = list((await session.scalars(select(EntityTag).where(EntityTag.requested_by == int(requested_by), or_(EntityTag.tag.ilike(like), EntityTag.entity_key.ilike(like), EntityTag.note.ilike(like))).limit(10))).all())
    result["accounts"] = [f"#{a.id} {a.label} @{a.username or '-'}" for a in accounts]
    result["links"] = [f"#{l.id} {l.normalized_url}" for l in links]
    result["jobs"] = [f"#{j.id} {j.mode} [{j.status}]" for j in jobs]
    result["tags"] = [f"{t.tag}: {t.entity_type}:{t.entity_key}" for t in tags]
    return result


async def record_system_error(component: str, message: str, *, requested_by: int | None = None, detail: str | None = None, severity: str = "error") -> None:
    async with SessionFactory() as session:
        session.add(SystemError(requested_by=requested_by, component=component[:80], severity=severity[:16], message=message[:4000], detail=(detail or "")[:12000] or None)); await session.commit()


async def list_system_errors(requested_by: int, *, primary: bool = False, limit: int = 20) -> list[SystemError]:
    async with SessionFactory() as session:
        query = select(SystemError).where(SystemError.resolved.is_(False))
        if not primary: query = query.where(or_(SystemError.requested_by == int(requested_by), SystemError.requested_by.is_(None)))
        return list((await session.scalars(query.order_by(SystemError.id.desc()).limit(limit))).all())


async def resolve_system_error(error_id: int, requested_by: int) -> bool:
    async with SessionFactory() as session:
        row = await session.get(SystemError, int(error_id))
        if not row: return False
        if row.requested_by != int(requested_by) and not await is_primary_owner(requested_by):
            return False
        row.resolved = True; row.resolved_at = utcnow(); await session.commit(); return True


async def admin_audit_rows(requested_by: int, *, primary: bool = False, limit: int = 30) -> list[AdminActionLog]:
    async with SessionFactory() as session:
        q = select(AdminActionLog)
        if not primary: q = q.where(AdminActionLog.user_id == int(requested_by))
        return list((await session.scalars(q.order_by(AdminActionLog.id.desc()).limit(limit))).all())


async def diagnostics(requested_by: int) -> str:
    usage = shutil.disk_usage(settings.data_dir)
    async with SessionFactory() as session:
        jobs = int(await session.scalar(select(func.count(Job.id)).where(Job.requested_by == int(requested_by), Job.status.in_(["queued","starting","running","paused"]))) or 0)
        links = int(await session.scalar(select(func.count(Link.id))) or 0)
        errors = int(await session.scalar(select(func.count(SystemError.id)).where(SystemError.resolved.is_(False))) or 0)
        schedules = int(await session.scalar(select(func.count(ScheduledTask.id)).where(ScheduledTask.requested_by == int(requested_by), ScheduledTask.status == "scheduled")) or 0)
    accounts = await session_health(requested_by)
    return "\n".join([
        "🧰 V8 Diagnostics",
        f"Python: {sys.version.split()[0]}", f"Platform: {platform.platform()}",
        f"Accounts: {len(accounts)}", f"Active jobs: {jobs}", f"Scheduled: {schedules}",
        f"Global links: {links}", f"Open errors: {errors}",
        f"Data disk used: {(usage.used/max(1,usage.total))*100:.1f}%", f"Free: {usage.free/(1024**3):.2f} GB",
        "Secrets: REDACTED (sessions/tokens/api_hash are never included)",
    ])
