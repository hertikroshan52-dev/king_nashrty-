from __future__ import annotations

import asyncio
from collections import defaultdict
from dataclasses import dataclass

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter
from aiogram.types import LinkPreviewOptions

from app.config import get_settings
from app.models import Link
from app.services.repository import claim_delivery, mark_deliveries_failed, mark_deliveries_sent

settings = get_settings()


@dataclass(slots=True)
class PendingItem:
    link_id: int
    url: str
    job_id: int | None


class BatchPublisher:
    def __init__(self, bot: Bot) -> None:
        self.bot = bot
        self.buffers: dict[int, list[PendingItem]] = defaultdict(list)
        self.sent_count = 0
        self.skipped_count = 0
        self.failed_count = 0
        self.errors: list[str] = []
        self._lock = asyncio.Lock()

    async def add(self, destination_chat_id: int, link: Link, job_id: int | None) -> None:
        async with self._lock:
            buffer = self.buffers[destination_chat_id]
            next_chars = sum(len(item.url) + 1 for item in buffer) + len(link.normalized_url)
            if buffer and (
                len(buffer) >= settings.publish_batch_max_links or next_chars > settings.publish_batch_max_chars
            ):
                await self._flush_locked(destination_chat_id)
            self.buffers[destination_chat_id].append(PendingItem(link.id, link.normalized_url, job_id))

    async def flush_all(self) -> None:
        async with self._lock:
            for destination in list(self.buffers):
                await self._flush_locked(destination)

    async def _flush_locked(self, destination_chat_id: int) -> None:
        items = self.buffers.get(destination_chat_id, [])
        if not items:
            return
        self.buffers[destination_chat_id] = []

        claimed: list[tuple[PendingItem, int]] = []
        for item in items:
            delivery = await claim_delivery(item.link_id, destination_chat_id, item.job_id)
            if delivery:
                claimed.append((item, delivery.id))
            else:
                self.skipped_count += 1
        if not claimed:
            return

        text = "\n".join(item.url for item, _ in claimed)
        delivery_ids = [delivery_id for _, delivery_id in claimed]
        try:
            sent = await self._send_with_retry(destination_chat_id, text)
            await mark_deliveries_sent(delivery_ids, sent.message_id)
            self.sent_count += len(claimed)
        except Exception as exc:
            await mark_deliveries_failed(delivery_ids, str(exc))
            self.failed_count += len(claimed)
            if len(self.errors) < 20:
                self.errors.append(f"{destination_chat_id}: {exc}")
        await asyncio.sleep(settings.publish_delay_seconds)

    async def _send_with_retry(self, destination_chat_id: int, text: str):
        last_error: Exception | None = None
        for attempt in range(5):
            try:
                return await self.bot.send_message(
                    destination_chat_id,
                    text,
                    link_preview_options=LinkPreviewOptions(is_disabled=True),
                )
            except TelegramRetryAfter as exc:
                last_error = exc
                await asyncio.sleep(float(exc.retry_after) + 1.0)
            except (TelegramForbiddenError, TelegramBadRequest):
                raise
            except Exception as exc:
                last_error = exc
                await asyncio.sleep(min(2 ** attempt, 20))
        raise RuntimeError(f"تعذر إرسال دفعة الروابط: {last_error}")
