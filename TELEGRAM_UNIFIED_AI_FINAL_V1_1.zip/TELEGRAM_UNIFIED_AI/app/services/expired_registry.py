from __future__ import annotations

from typing import Iterable

from sqlalchemy import delete, func, or_, select
from sqlalchemy.dialects.sqlite import insert
from telethon import TelegramClient
from telethon.errors import FloodWaitError
from telethon.sessions import StringSession
from telethon.tl.types import InputMessagesFilterUrl

from app.crypto import SessionCipher
from app.db import SessionFactory
from app.link_utils import inspect_collection_link, telegram_identity_key
from app.models import Link, TelegramExpiredLinkBlocklist, utcnow
from app.services.accounts import list_accounts
from app.services.scanner import resolve_source_entity
from app.link_utils import extract_urls_from_message

cipher = SessionCipher()


async def block_expired_urls(urls: Iterable[str], *, reason: str = "manual_expired_import") -> tuple[int, int, int]:
    normalized: dict[str, str] = {}
    rejected = 0
    for raw in urls:
        inspection = inspect_collection_link(str(raw), "telegram")
        if not inspection.link:
            rejected += 1
            continue
        normalized[telegram_identity_key(inspection.link.normalized)] = inspection.link.normalized
    if not normalized:
        return 0, 0, rejected

    keys = list(normalized)
    now = utcnow()
    existing_count = 0
    for pos in range(0, len(keys), 500):
        part = keys[pos:pos + 500]
        async with SessionFactory() as db:
            existing = set((await db.scalars(
                select(TelegramExpiredLinkBlocklist.identity_key).where(TelegramExpiredLinkBlocklist.identity_key.in_(part))
            )).all())
            existing_count += len(existing)
            values = [{
                "identity_key": key,
                "normalized_url": normalized[key],
                "reason": reason,
                "first_audit_id": None,
                "last_audit_id": None,
                "first_blocked_at": now,
                "last_blocked_at": now,
                "rediscovered_count": 0,
            } for key in part]
            stmt = insert(TelegramExpiredLinkBlocklist).values(values)
            stmt = stmt.on_conflict_do_update(
                index_elements=[TelegramExpiredLinkBlocklist.identity_key],
                set_={"normalized_url": stmt.excluded.normalized_url, "reason": reason, "last_blocked_at": now},
            )
            await db.execute(stmt)
            # Remove matching active Telegram rows so DB exports also stay clean.
            conditions = []
            for key in part:
                url = normalized[key]
                if key.startswith("public:"):
                    conditions.append(func.lower(Link.normalized_url) == url.lower())
                elif key.startswith("invite:"):
                    token = key.split(":", 1)[1]
                    conditions.append(Link.normalized_url.in_([f"https://t.me/+{token}", f"https://t.me/joinchat/{token}"]))
                else:
                    conditions.append(Link.normalized_url == url)
            if conditions:
                await db.execute(delete(Link).where(Link.category == "telegram", or_(*conditions)))
            await db.commit()
    return len(normalized) - existing_count, existing_count, rejected


async def expired_registry_count() -> int:
    async with SessionFactory() as db:
        return int(await db.scalar(select(func.count(TelegramExpiredLinkBlocklist.id))) or 0)


async def unblock_expired_url(raw_url: str) -> tuple[bool, str]:
    """Remove one identity from the permanent registry without deleting history."""
    inspection = inspect_collection_link(str(raw_url), "telegram")
    if not inspection.link:
        raise ValueError("أرسل رابط Telegram مباشرًا صالحًا لمجموعة أو قناة.")
    normalized_url = inspection.link.normalized
    identity_key = telegram_identity_key(normalized_url)
    async with SessionFactory() as db:
        result = await db.execute(
            delete(TelegramExpiredLinkBlocklist).where(
                TelegramExpiredLinkBlocklist.identity_key == identity_key
            )
        )
        await db.commit()
    return bool(result.rowcount), normalized_url


async def import_expired_from_source(owner_id: int, source: str) -> dict[str, int]:
    accounts = [row for row in await list_accounts(int(owner_id)) if row.active]
    if not accounts:
        raise RuntimeError("لا توجد حسابات Telethon فعالة للمالك لقراءة قناة الروابط المنتهية.")

    last_error: Exception | None = None
    for account in accounts:
        client = TelegramClient(
            StringSession(cipher.decrypt(account.encrypted_session)),
            int(account.api_id),
            cipher.decrypt(account.encrypted_api_hash),
            auto_reconnect=True,
            connection_retries=3,
        )
        try:
            await client.connect()
            if not await client.is_user_authorized():
                continue
            entity = await resolve_source_entity(client, source)
            messages = found = added = existing = rejected = 0
            batch: list[str] = []
            async for message in client.iter_messages(entity, filter=InputMessagesFilterUrl):
                messages += 1
                urls = extract_urls_from_message(message)
                found += len(urls)
                batch.extend(urls)
                if len(batch) >= 1000:
                    a, e, r = await block_expired_urls(batch)
                    added += a; existing += e; rejected += r
                    batch.clear()
            if batch:
                a, e, r = await block_expired_urls(batch)
                added += a; existing += e; rejected += r
            return {"account_id": int(account.id), "messages": messages, "found": found, "added": added, "existing": existing, "rejected": rejected}
        except FloodWaitError:
            raise
        except Exception as exc:
            last_error = exc
        finally:
            try:
                await client.disconnect()
            except Exception:
                pass
    raise RuntimeError(f"تعذر قراءة مصدر الروابط المنتهية بأي حساب متاح: {last_error}")
