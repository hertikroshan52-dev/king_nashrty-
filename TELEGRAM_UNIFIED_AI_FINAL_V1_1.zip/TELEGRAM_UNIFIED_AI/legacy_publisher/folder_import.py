"""Explicit, supervised Telegram shared-folder import with membership-preserving removal.

The operator previews one folder for one account and explicitly confirms that
account/folder pair. No unattended folder cycling, automatic account rotation,
or retries around Telegram server limits. When leaving, `peers=[]` is ALWAYS
used, so the API is never instructed to leave groups/channels.

Source: https://core.telegram.org/api/folders
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass
import re

from telethon import utils
from telethon.errors import FloodWaitError
from telethon.tl import functions, types


_FOLDER_RE = re.compile(
    r"^(?:https?://)?(?:t\.me|telegram\.me)/addlist/([A-Za-z0-9_-]{4,100})(?:[?#].*)?$",
    re.IGNORECASE,
)


def plan_folder_links(account_ids: list[int], link_ids: list[int], per_account: int) -> dict[int, list[int]]:
    """Read-only assignment preview. Never executes any join or bypasses limits."""
    if per_account not in (2, 5):
        raise ValueError("يجب اختيار مجلدين أو خمسة مجلدات")
    if not link_ids:
        return {int(a): [] for a in account_ids}
    distinct_links = list(dict.fromkeys(link_ids))
    target = min(per_account, len(distinct_links))
    return {
        int(account): [distinct_links[(index * per_account + offset) % len(distinct_links)]
                       for offset in range(target)]
        for index, account in enumerate(account_ids)
    }


def folder_slug(url: str) -> str:
    match = _FOLDER_RE.fullmatch(str(url).strip())
    if match is None:
        raise ValueError("رابط المجلد غير صالح. استخدم https://t.me/addlist/...")
    return match.group(1)


def _peer_key(peer):
    if hasattr(peer, "channel_id"):
        return "channel", int(peer.channel_id)
    if hasattr(peer, "chat_id"):
        return "chat", int(peer.chat_id)
    return None


def _is_forbidden(chat) -> bool:
    return "Forbidden" in type(chat).__name__ or bool(getattr(chat, "left", False)) and not getattr(chat, "access_hash", None)


def _convert_join_peers(invite):
    """Use entities supplied by Telegram itself, not guessed IDs/access hashes."""
    available = {}
    for chat in getattr(invite, "chats", ()):
        if _is_forbidden(chat):
            continue
        key = ("channel" if hasattr(chat, "access_hash") else "chat", int(chat.id))
        try:
            available[key] = utils.get_input_peer(chat)
        except (TypeError, ValueError):
            continue
    peers = getattr(invite, "missing_peers", None)
    if peers is None:
        peers = getattr(invite, "peers", ())
    result = []
    for peer in peers:
        val = available.get(_peer_key(peer))
        if val is not None:
            result.append(val)
    return result


def _folder_ids(filters_result):
    values = getattr(filters_result, "filters", filters_result)
    return {int(f.id) for f in values if f is not None and hasattr(f, "id") and "DialogFilter" in type(f).__name__}


@dataclass(frozen=True)
class FolderPreview:
    title: str
    slug: str
    available_count: int
    total_count: int
    already_imported: bool
    filter_id: int | None


def from_invite(invite, slug: str) -> FolderPreview:
    imported = hasattr(invite, "filter_id")
    raw_title = getattr(invite, "title", None)
    title = str(getattr(raw_title, "text", raw_title) or ("مجلد مستورد" if imported else "مجلد تيليجرام"))
    total = len(getattr(invite, "chats", []) or [])
    return FolderPreview(
        title=title[:120], slug=slug,
        available_count=len(_convert_join_peers(invite)),
        total_count=total, already_imported=imported,
        filter_id=int(invite.filter_id) if imported else None,
    )


async def preview_folder(client, url: str) -> FolderPreview:
    slug = folder_slug(url)
    invite = await client(functions.chatlists.CheckChatlistInviteRequest(slug=slug))
    return from_invite(invite, slug)


async def import_and_preserve(client, url: str, expected: FolderPreview,
                              max_peers: int = 100) -> dict:
    """Import one explicitly approved folder and remove its UI entry, leaving chats.

    If folder ID identification is ambiguous, leave it in place rather than risk
    deleting another folder. No FloodWait retry. Never pass anything but [] as
    the peers argument to LeaveChatlistRequest.
    """
    slug = folder_slug(url)
    if slug != expected.slug:
        raise ValueError("الرابط لا يطابق المعاينة المؤكدة")
    invite = await client(functions.chatlists.CheckChatlistInviteRequest(slug=slug))
    current = from_invite(invite, slug)
    if (current.already_imported != expected.already_imported or
            current.available_count != expected.available_count):
        raise ValueError("محتوى المجلد تغيّر منذ المعاينة. أعد المعاينة والتأكيد")

    if current.already_imported:
        filter_id = current.filter_id
        joined_count = 0
    else:
        peers = _convert_join_peers(invite)
        if not peers:
            raise ValueError("لا توجد مجموعات متاحة للاستيراد من هذا الرابط")
        if len(peers) > max_peers:
            raise ValueError(f"المجلد يحتوي {len(peers)} جهة متاحة، يتجاوز سقف الأمان {max_peers} للمعالجة الواحدة")
        before = _folder_ids(await client(functions.messages.GetDialogFiltersRequest()))
        # Only perform one user-confirmed import. Platform errors propagate to caller.
        await client(functions.chatlists.JoinChatlistInviteRequest(slug=slug, peers=peers))
        joined_count = len(peers)  # Requested; may differ from verified memberships.
        await asyncio.sleep(1)
        after = _folder_ids(await client(functions.messages.GetDialogFiltersRequest()))
        added = after - before
        if len(added) != 1:
            return {
                "status": "imported_keep_folder",
                "requested_peers": joined_count,
                "filter_id": None,
                "message": "تم طلب الاستيراد، لكن تعذّر تحديد المجلد الجديد بأمان؛ تُرك المجلد دون حذف. تحقق منه داخل تيليجرام.",
            }
        filter_id = next(iter(added))

    if filter_id is None:
        raise ValueError("تعذّر تحديد رقم المجلد المطلوب حذفه")
    # CRITICAL: empty peers means remove folder WITHOUT asking Telegram to
    # leave any channel/group. Never use suggestions returned by the API.
    await client(functions.chatlists.LeaveChatlistRequest(
        chatlist=types.InputChatlistDialogFilter(filter_id=filter_id), peers=[]
    ))
    return {
        "status": "folder_removed_chats_preserved",
        "requested_peers": joined_count,
        "filter_id": filter_id,
        "message": "حُذف المجلد دون طلب مغادرة أي مجموعة. راجع عضويات الحساب للتأكد من نتيجة الاستيراد.",
    }
