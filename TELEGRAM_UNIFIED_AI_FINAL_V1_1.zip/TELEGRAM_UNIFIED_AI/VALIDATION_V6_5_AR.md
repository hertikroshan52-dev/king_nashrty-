# تحقق V6.5.0

تم قبل التغليف النهائي تنفيذ الآتي على شجرة المصدر النظيفة:

- `python -m compileall -q app scripts tests` — ناجح.
- `python scripts/static_validate_v6.py` — ناجح، ويشمل اختبارات ثابتة لخصائص V6.5.
- مجموعة اختبارات Static/Parser/Compatibility المختارة — `36 passed`.

تم التحقق من أن مصنف صفحات `t.me` يفرّق في عينات الاختبار بين:

- قناة تحتوي `subscribers`.
- مجموعة تحتوي `members`.
- بوت يحتوي `Start Bot` أو `monthly users`.
- حساب شخصي يحتوي `Send Message`/contact text.
- دعوة hash عامة بدون بيانات كافية -> منتهي محتمل داخل تقرير الويب فقط.
- صفحة عامة غامضة -> `requires_account`.
- مجموعة/قناة تحتوي إشارات pump/IPO/investment.

كما تم التحقق ثابتًا من:

- استخراج جلسات المشرف من حساباته فقط.
- التصدير في Private Chat وحذف الملف المؤقت.
- إزالة إعداد قنوات التجميع الدائم من القائمة الرئيسية.
- قناة استقبال مؤقتة لكل مهمة عند التجميع من كل الحسابات.
- حفظ التجميع من المصادر مباشرة في قاعدة البيانات.
- تقرير إكمال الحسابات في مهام التجميع.
- وجود محركي Browser/Accounts للفحص.
- عدم استخدام Telethon داخل محرك فحص الويب.
- High-Water Link ID لاستكمال الجديد فقط.
- Streaming عند تحويل قسم كبير من نتائج الويب إلى فحص الحسابات.

## ملاحظة بيئة البناء

اختبارات Runtime الكاملة القديمة تعتمد على `aiogram`, `Telethon`, `aiosqlite`. بيئة البناء التي أُنشئت فيها الحزمة لا تحتوي هذه المكتبات، لذلك لم تُشغّل مجموعة Runtime كاملة هنا. بعد تثبيت `requirements.txt` في Termux يجب تشغيل:

```bash
python -m compileall -q app scripts
python scripts/static_validate_v6.py
./botctl.sh selfcheck
```

`selfcheck` يهيئ قاعدة SQLite ويختبر إعدادات التشغيل الفعلية في بيئة Termux.
