# V6.2.9

- إصلاح تعليق استكمال فحص Telegram عند وجود آلاف Discovery cursors مؤجلة.
- تجميع ResolveUsername cooldown الموروث مرة واحدة لكل حساب بدل كتابة قاعدة البيانات لكل رابط.
- Heartbeat حي أثناء استعادة cursors الكبيرة.
- حد أقصى لجدولة Discovery الجاهزة في كل دورة يساوي عدد عمال Telegram، لمنع task stampede.
- منع إعادة إنشاء runner لنفس scan key وهو ما يزال نشطًا.
- لا تغيير على قاعدة 10 حسابات × 4 روابط × راحة 120 ثانية، ولا تجاوز FloodWait.
