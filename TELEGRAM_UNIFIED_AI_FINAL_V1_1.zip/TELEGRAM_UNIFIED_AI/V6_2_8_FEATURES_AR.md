# V6.2.8 — Live Audit Retry Wait

يعالج هذا الإصدار حالة كانت تجعل مهمة فحص Telegram تظهر `running` بينما يظل `heartbeat_at` ثابتًا عندما لا توجد روابط جاهزة الآن وكل الروابط المتبقية تنتظر `next_retry_at`.

- مرحلة واضحة: `waiting_audit_retry`.
- تحديث heartbeat كل عدة ثوانٍ أثناء الانتظار الطويل.
- حفظ `next_audit_retry_at` و `next_audit_retry_seconds` في progress.
- استئناف الراحة المتبقية بعد إعادة التشغيل يستخدم heartbeat حيًا أيضًا.
- الانتظار يراعي أقرب موعد Discovery مؤجل، بحيث يعاد فحص cursors المستحقة بدون busy-loop.
- لا يغيّر نظام 10 حسابات × 4 روابط × 120 ثانية.
