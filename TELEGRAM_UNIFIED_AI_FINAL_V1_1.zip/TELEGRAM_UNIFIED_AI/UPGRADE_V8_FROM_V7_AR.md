# ترقية V7 إلى V8 على Termux دون فقد البيانات

## قبل البدء

لا تحذف مجلد V7. أوقف البوت القديم وتأكد أن حالته `stopped`:

```bash
cd /root/telegram-bot/telegram_link_collector_bot_v7_0_1_FULL_INTEGRATED_FINAL_STABLE
./botctl.sh stop
./botctl.sh status
```

## فك V8 في مجلد جديد

```bash
mkdir -p /root/telegram-bot-v8
cd /root/telegram-bot-v8
unzip /sdcard/Download/telegram_link_collector_bot_v8_0_0_SAFE.zip
cd telegram_link_collector_bot_v8_0_0_SAFE
chmod +x UPGRADE_TO_V8_TERMUX.sh
```

## تنفيذ النقل الآمن

مرر المسار الكامل لمجلد V7 القديم:

```bash
./UPGRADE_TO_V8_TERMUX.sh /root/telegram-bot/telegram_link_collector_bot_v7_0_1_FULL_INTEGRATED_FINAL_STABLE
```

السكريبت يرفض العمل إذا كان البوت القديم ما يزال يعمل، ثم:

- ينشئ نسخة احتياطية مؤرخة من قاعدة V7.
- ينسخ `.env` ومجلد `data` كاملًا، بما فيه قاعدة البيانات ومفتاح الجلسات والنسخ الاحتياطية.
- يثبت متطلبات V8.
- ينفذ ترحيلًا إضافيًا فقط؛ لا يحذف جدولًا أو جلسة.
- يشغل اختبارات السلامة.

## التشغيل

```bash
./botctl.sh selfcheck
./botctl.sh start
./botctl.sh status
tail -f data/logs/launcher.log
```

إذا كانت مهمة الانضمام القديمة متوقفة أو اكتملت بتحذيرات، افتح «المهام» واضغط «إعادة/استكمال» أو «الجديد» للمهمة نفسها. V8 يستورد الانضمامات القديمة المسجلة ويكمل من العدد الموجود لكل حساب.

لا تشغّل V7 وV8 معًا.
