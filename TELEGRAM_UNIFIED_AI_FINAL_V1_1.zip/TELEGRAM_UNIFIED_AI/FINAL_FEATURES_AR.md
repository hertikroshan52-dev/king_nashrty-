> **تنبيه V6.4.0:** هذا الملف توثيق تاريخي للنسخ القديمة متعددة التوكنات. النسخة الحالية تعمل بتوكن Bot واحد وقاعدة مشتركة، ويُضاف المشرفون من لوحة المالك. المرجع الحالي: `README_AR.md` و`V6_4_0_MULTI_SUPERVISOR_AR.md`.

# Telegram Link Collector & Auditor V6.0.1 FINAL — Full Features on Every Instance

هذه النسخة مصممة لتشغيل أي عدد من النسخ المستقلة من نفس الكود. **كل نسخة تعرض جميع وظائف البوت دائمًا**؛ لا يوجد `INSTANCE_ROLE` ولا يوجد أي تقييد برمجي يحدد أن نسخة معينة للتجميع أو للفحص. المستخدم هو الذي يقرر كيف يستخدم كل نسخة.

كل نسخة مستقلة تحتاج مجلدًا و`.env` و`BOT_TOKEN` و`data/` خاصًا بها. ويمكن للمستخدم عمليًا تخصيص نسخة للتجميع العام، وأخرى للتجميع حسب القسم، وثالثة للفحص، لكن هذا تنظيم اختياري فقط وليس قيدًا في الكود.

## القواعد الثابتة المطلوبة

### 1) التجميع لا يفحص صلاحية الروابط
في جميع أوضاع Collector، البوت يقرأ الرسائل وكيانات الروابط، يستخرج URL، يحدد القسم، يطبّع الرابط، يمنع التكرار، يسجل مصدره، يحفظه وينشره إلى قناة القسم إن كانت محددة.

**Collector لا يستخدم Resolve أو CheckChatInvite لفحص هل الرابط شغال أو منتهي.**

ينطبق ذلك على:
- التجميع العام من الحسابات.
- التجميع العام من مجموعة/قناة يحددها المستخدم.
- التجميع حسب القسم من الحسابات.
- التجميع حسب القسم من مجموعة/قناة يحددها المستخدم.

### 2) فحص Telegram ثابت 10 × 4 × 120
- كل 10 حسابات فعالة تشكل مجموعة فحص.
- كل حساب يأخذ حتى 4 روابط مختلفة عن روابط الحسابات الأخرى في الدورة.
- روابط الحساب الأربعة تبدأ بالتوازي.
- مجموعات الحسابات تعمل في الدورة نفسها بالتوازي.
- إذا بقيت روابط بعد الموجة، تكون الراحة 120 ثانية كاملة قبل الموجة التالية.
- الخطأ الدائم الواضح مثل `INVITE_HASH_EXPIRED` أو `USERNAME_NOT_OCCUPIED` يصنف الرابط مباشرة في `expired`.
- لا يوجد Auto Join ولا إرسال Join Request.

## جميع الوظائف متاحة في كل نسخة
1. إضافة وإدارة حسابات Telethon.
2. التجميع العام من الحسابات.
3. التجميع العام من مجموعات/قنوات محددة.
4. التجميع حسب القسم، من الحسابات أو مصدر محدد.
5. استقبال روابط يدويًا.
6. فحص وتصفية روابط Telegram.
7. إعداد قنوات التجميع.
8. المهام، Pause/Resume/Cancel/Retry.
9. Live Collection.
10. قاعدة الروابط والبحث.
11. Dashboard.
12. Export/Snapshot.
13. Backup/Restore/Secure Recovery.
14. Maintenance/Reset.

## أهم ميزات V6
- Fast Collection بواسطة Telegram Links Filter وDeep Collection لمسح كل الرسائل.
- خيار الجديد فقط منذ آخر تجميع ناجح.
- Crash Recovery + Job cursors.
- Global Deduplication للرابط والتسليم.
- Link Lifecycle وLink Occurrences.
- Source Statistics وQuality Score.
- Telegram Peer Registry.
- Resolution Cache اختياري ومغلق افتراضيًا حتى لا يغير نمط الفحص الثابت.
- Persistent FSM في SQLite.
- Streaming TXT/CSV Audit import.
- Streaming database/job/audit export.
- Snapshot أثناء المهمة.
- Dashboard + Search.
- نسخ احتياطي دوري وSecure encrypted recovery bundle.
- SQLite WAL + batch writes + indexes.
- تشفير StringSessions باستخدام Fernet.

## تشغيل عدة نسخ
انسخ الحزمة إلى مجلد مستقل لكل نسخة، وعدّل فقط بيانات النسخة مثل `BOT_TOKEN`, `INSTANCE_NAME`, `ADMIN_IDS`, وبيانات Telegram المطلوبة. **لا يوجد متغير Role.**

لا تشارك `data/collector.db` أو `data/.session_key` أو نفس StringSession بين نسختين تعملان في الوقت نفسه.

راجع `TERMUX_INSTALL_AR.md` و`THREE_INSTANCES_AR.md`.
