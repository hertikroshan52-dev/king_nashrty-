# V6.2.5 — إصلاح FloodWait داخل Telegram Discovery

## المشكلة

بعد V6.2.4 أصبح فحص رابط Telegram نفسه يتعامل مع FloodWait كتأجيل، لكن مسار
**اكتشاف روابط Telegram من سجل المحادثات** كان عند الاستكمال أو إعادة تشغيل البوت
يعيد حل روابط `t.me/username` عبر `ResolveUsernameRequest`. إذا كان الحساب عليه
FloodWait خاص بهذه العملية، كان السجل يظهر `Telegram discovery scan failed` رغم أن
الرابط والمحادثة صالحان.

## الإصلاح

- عند استكمال Discovery يستخدم البوت `peer_id` المحفوظ وكيان Telethon المخزن في Session أولًا.
- لا يعيد `ResolveUsername` بعد reconnect إذا كان الـentity الموجود ما زال صالحًا.
- إذا اضطر إلى طلب Telegram وظهر FloodWait، يحفظ Cursor بحالة `deferred` مع `deferred_until`.
- مدة الانتظار هي مدة Telegram الفعلية مع هامش الأمان المحدد في الإعدادات.
- FloodWait في Discovery لا يزيد `telegram_scan_errors` ولا يحوّل المصدر إلى خطأ نهائي.
- الانتظار يحدث خارج قفل الحساب وخارج Semaphore العامل، لذلك بقية المحادثات تستطيع الاستمرار.
- `deferred_until` يبقى محفوظًا بعد إطفاء الهاتف أو إعادة تشغيل Termux، ولا تضيع مدة الانتظار.
- إذا كان الحساب الأصلي للـCursor غير متاح بعد إعادة التشغيل، يمكن إعادة إسناد الـCursor إلى حساب متاح.
- نظام الفحص الأساسي لم يتغير: 10 حسابات لكل مجموعة، 4 روابط لكل حساب، وراحة 120 ثانية بين الموجات.
- روابط `t.me/+HASH` تبقى في مسارها المنفصل ولا تتأثر بحد ResolveUsername.

## النتيجة المتوقعة في السجل

بدل:

```text
Telegram discovery scan failed ... A wait of 14433 seconds is required (caused by ResolveUsernameRequest)
```

يظهر عند الحاجة:

```text
Telegram discovery deferred ... method=ResolveUsername wait=...; not counted as scan error
```

وعند الاستكمال مع وجود peer محفوظ:

```text
Telegram discovery resumed from cached peer_id=... url=...
```
