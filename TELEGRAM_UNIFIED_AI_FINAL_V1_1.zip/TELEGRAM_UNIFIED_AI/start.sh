#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if [ ! -f .env ]; then
  cp .env.example .env
  chmod 600 .env 2>/dev/null || true
  echo "تم إنشاء .env. ضع BOT_TOKEN وبيانات Telegram API ثم أعد التشغيل."
  exit 1
fi
chmod 600 .env 2>/dev/null || true
if [ ! -d .venv ]; then
  python3 -m venv .venv
fi
. .venv/bin/activate
INDEX_URL="${PIP_INDEX_URL_OVERRIDE:-https://pypi.org/simple}"
python -m pip install --index-url "$INDEX_URL" --upgrade pip setuptools wheel
python -m pip install --index-url "$INDEX_URL" --no-cache-dir -r requirements.txt
python -m scripts.unified_selfcheck
python -m app.unified_main
