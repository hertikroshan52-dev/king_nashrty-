# تثبيت Telegram Link Collector V8.0.0 على Termux

هذه التعليمات للتثبيت الجديد. للترقية من V7 استخدم ملف `UPGRADE_V8_FROM_V7_AR.md`.

## 1. تثبيت Ubuntu داخل Termux

```bash
pkg update -y
pkg upgrade -y
pkg install -y proot-distro tmux
termux-setup-storage
proot-distro install ubuntu
proot-distro login ubuntu
```

## 2. تثبيت المتطلبات

```bash
apt update
apt upgrade -y
apt install -y python3 python3-venv python3-pip python3-dev build-essential pkg-config libffi-dev libssl-dev ca-certificates curl unzip nano sqlite3
```

## 3. فك الحزمة

```bash
mkdir -p /root/telegram-bot-v8
cd /root/telegram-bot-v8
unzip /sdcard/Download/telegram_link_collector_bot_v8_0_0_SAFE.zip
cd telegram_link_collector_bot_v8_0_0_SAFE
```

## 4. التثبيت والإعداد

```bash
chmod +x install-ubuntu.sh botctl.sh start.sh UPGRADE_TO_V8_TERMUX.sh
./install-ubuntu.sh
nano .env
chmod 600 .env
```

ضع `BOT_TOKEN` و`ADMIN_IDS` وبيانات Telegram المطلوبة.

## 5. الفحص والتشغيل

```bash
./botctl.sh versioncheck
./botctl.sh tokencheck
./botctl.sh selfcheck
./botctl.sh start
./botctl.sh status
```

## 6. السجل

```bash
tail -n 100 data/logs/launcher.log
tail -f data/logs/launcher.log
```

لا تشغّل نسختين بالتوكن نفسه أو بقاعدة البيانات نفسها في الوقت ذاته.
