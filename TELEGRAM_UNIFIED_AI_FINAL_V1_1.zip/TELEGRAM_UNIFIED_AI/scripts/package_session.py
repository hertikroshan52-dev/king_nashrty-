from __future__ import annotations

import argparse
import json


def main() -> None:
    parser = argparse.ArgumentParser(description="Package a Telethon StringSession with its API credentials.")
    parser.add_argument("--session", required=True)
    parser.add_argument("--api-id", required=True, type=int)
    parser.add_argument("--api-hash", required=True)
    parser.add_argument("--label", default="حساب Telethon")
    parser.add_argument("--output", default="session_package.json")
    args = parser.parse_args()
    payload = {
        "label": args.label,
        "session": args.session,
        "api_id": args.api_id,
        "api_hash": args.api_hash,
    }
    with open(args.output, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
    print(args.output)


if __name__ == "__main__":
    main()
