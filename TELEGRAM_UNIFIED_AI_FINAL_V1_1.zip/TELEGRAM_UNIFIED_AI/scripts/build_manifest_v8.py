from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXCLUDED_PARTS = {".git", ".venv", ".venv_test", "__pycache__", ".pytest_cache", ".ruff_cache"}
EXCLUDED_NAMES = {"BUILD_MANIFEST_SHA256.txt", "BUILD_MANIFEST_V8.json"}


def included(path: Path) -> bool:
    relative = path.relative_to(ROOT)
    if any(part in EXCLUDED_PARTS for part in relative.parts):
        return False
    if path.name == ".env" or path.name == ".session_key" or path.suffix in {".session", ".db", ".pyc"}:
        return False
    if path.name in EXCLUDED_NAMES:
        return False
    if relative.parts and relative.parts[0] == "data" and relative.as_posix() != "data/.gitkeep":
        return False
    return path.is_file()


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def main() -> None:
    rows = []
    for path in sorted((item for item in ROOT.rglob("*") if included(item)), key=lambda item: item.as_posix()):
        rows.append({
            "path": path.relative_to(ROOT).as_posix(),
            "size": path.stat().st_size,
            "sha256": digest(path),
        })
    payload = {
        "version": (ROOT / "VERSION").read_text(encoding="utf-8").strip(),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "file_count": len(rows),
        "files": rows,
    }
    (ROOT / "BUILD_MANIFEST_V8.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    (ROOT / "BUILD_MANIFEST_SHA256.txt").write_text(
        "".join(f"{row['sha256']}  {row['path']}\n" for row in rows), encoding="utf-8"
    )
    print(f"V8 manifest: {len(rows)} files")


if __name__ == "__main__":
    main()
