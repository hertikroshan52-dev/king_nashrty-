"""Optional safe, copy-only transfer from existing standalone installations.

Example:
 python -m scripts.migrate_unified_data --collector-data /root/old_collector/data --publisher-data /root/old_publisher/bots_data/123 --apply

Stops if a destination file already exists; never deletes or overwrites sources.
Run while the old Telegram processes are stopped and before first unified start.
"""
from __future__ import annotations
import argparse
import os
import shutil
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / '.env')


def _files(src: Path, dst: Path):
    src = src.resolve()
    dst = dst.resolve()
    if not src.is_dir():
        raise ValueError(f'المصدر ليس مجلداً: {src}')
    if src == dst or src in dst.parents or dst in src.parents:
        raise ValueError('المصدر والوجهة متداخلان، توقفاً لمنع الكتابة فوق البيانات.')
    entries = []
    for p in src.rglob('*'):
        if p.is_symlink():
            raise ValueError(f'رابط رمزي داخل المصدر غير مدعوم: {p}')
        if p.is_file():
            target = dst / p.relative_to(src)
            if target.exists() and target.name != '.gitkeep':
                raise FileExistsError(f'ملف وجهة موجود؛ لن يتم استبداله: {target}')
            entries.append((p,target))
    return entries


def copy_data(collector_src: str | None, publisher_src: str | None, apply: bool = False):
    collector_dst = ROOT/'data'
    publisher_dst = Path(os.getenv('PUBLISHER_DATA_DIR') or ROOT/'data'/'publisher').expanduser()
    tasks = []
    if collector_src:
        tasks += [('collector', *pair) for pair in _files(Path(collector_src).expanduser(),collector_dst)]
    if publisher_src:
        tasks += [('publisher', *pair) for pair in _files(Path(publisher_src).expanduser(),publisher_dst)]
    if not tasks:
        raise ValueError('حدد مجلد المصدر القديم لأحد البوتين على الأقل.')
    print(f'Files prepared: {len(tasks)}')
    for module, source, target in tasks[:12]:
        print(f'[{module}] {source} -> {target}')
    if len(tasks) > 12:
        print(f'... and {len(tasks)-12} more files.')
    if not apply:
        print('Preview only. Re-run with --apply after stopping both old Telegram bots.')
        return 0
    old_mask = os.umask(0o077)
    try:
        for _, src, dst in tasks:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src,dst,follow_symlinks=False)
            dst.chmod(0o600)
        print('✅ نقل نسخ البيانات مكتمل. لم يتغير شيء في مجلدات المصدر.')
    finally:
        os.umask(old_mask)
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--collector-data', help='Existing collector data/ directory')
    parser.add_argument('--publisher-data', help='Existing publisher data directory (contains bot_database.db)')
    parser.add_argument('--apply',action='store_true',help='Copy files after preview')
    args = parser.parse_args()
    return copy_data(args.collector_data,args.publisher_data,args.apply)

if __name__=='__main__':
    raise SystemExit(main())
