from __future__ import annotations

import ast
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def check(name: str, ok: bool, failures: list[str]) -> None:
    print(("OK   " if ok else "FAIL ") + name)
    if not ok:
        failures.append(name)


def main() -> None:
    failures: list[str] = []
    py_files = sorted([*ROOT.glob("app/**/*.py"), *ROOT.glob("scripts/**/*.py"), *ROOT.glob("tests/**/*.py")])
    syntax_ok = True
    for path in py_files:
        try:
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except SyntaxError as exc:
            syntax_ok = False
            print(f"SYNTAX {path}: {exc}")
    check("all Python files parse", syntax_ok, failures)

    config = (ROOT / "app/config.py").read_text(encoding="utf-8")
    scanner = (ROOT / "app/services/scanner.py").read_text(encoding="utf-8")
    auditor = (ROOT / "app/services/auditor.py").read_text(encoding="utf-8")
    bot = (ROOT / "app/bot.py").read_text(encoding="utf-8")
    keyboards = (ROOT / "app/keyboards.py").read_text(encoding="utf-8")
    exporter = (ROOT / "app/services/exporter.py").read_text(encoding="utf-8")
    secure = (ROOT / "scripts/secure_bundle.py").read_text(encoding="utf-8")

    check("fixed audit group size = 10", bool(re.search(r"audit_account_group_size:\s*int\s*=\s*10\b", config)), failures)
    check("fixed audit links/account = 4", bool(re.search(r"audit_links_per_account_cycle:\s*int\s*=\s*4\b", config)), failures)
    check("fixed audit rest = 120 seconds", bool(re.search(r"audit_group_rest_seconds:\s*float\s*=\s*120\.0\b", config)), failures)
    check("audit resolution cache off by default", "audit_use_resolution_cache: bool = False" in config, failures)

    accounts_start = scanner.index("async def process_accounts_job")
    accounts_end = scanner.index("INVITE_RE =", accounts_start)
    accounts_section = scanner[accounts_start:accounts_end]
    sources_start = scanner.index("async def process_sources_job")
    sources_section = scanner[sources_start:]
    check("account collector locally inspects extracted URLs", "inspect_collection_link(raw_url" in accounts_section, failures)
    check("account collector does not call audit resolver", "process_telegram_audit_job" not in accounts_section and "single_check(" not in accounts_section, failures)
    check("source collector locally inspects extracted URLs", "inspect_collection_link(raw_url" in sources_section, failures)
    check("category collection source choice exists", "category_origin:accounts" in keyboards and "category_origin:sources" in keyboards, failures)

    check("V6 fixed-wave audit function present", "V6 fixed-wave Telegram audit" in auditor, failures)
    check("audit partitions cohorts", "cohorts = [all_clients[i:i + group_size]" in auditor, failures)
    check("audit assigns per-account distinct slices", "batch = pending[position:position + per_account]" in auditor, failures)
    check("four checks launched concurrently", "asyncio.create_task(process_one(item, previous, account_id, client))" in auditor, failures)
    check("mandatory rest persists across restart", "previous_rest_until" in auditor and "unresolved_count" in auditor, failures)
    check("dead links classified immediately expired", '"status": "expired"' in auditor and "_is_dead_link_error" in auditor, failures)
    check("no auto-join calls", "JoinChannelRequest" not in auditor and "ImportChatInviteRequest" not in auditor, failures)

    check("instance role restriction removed from config", "instance_role" not in config, failures)
    check("instance role restriction removed from main menu", "instance_role" not in keyboards, failures)
    check("general collectors removed from main menu", "callback_data=\"collect:accounts\"" not in keyboards and "callback_data=\"collect:sources\"" not in keyboards, failures)
    check("category collector remains primary collection entry", "collect:category" in keyboards and "category_origin:accounts" in keyboards and "category_origin:sources" in keyboards, failures)
    check("V6.4 supervisor and join controls visible", "supervisors:menu" in keyboards and "join:start" in keyboards, failures)
    check("persistent FSM module exists", (ROOT / "app/fsm_storage.py").exists(), failures)
    check("live bounded queue implemented", "asyncio.Queue" in scanner and "live-worker" in scanner, failures)
    check("smart source priority implemented", "_prioritize_explicit_sources" in scanner and "quality_score" in scanner, failures)
    check("streaming DB/job export implemented", "while True" in exporter and ".limit(" in exporter, failures)
    check("streaming audit export implemented", "Stream a committed audit snapshot" in auditor and "last_wa_id" in auditor, failures)
    check("streaming audit file import implemented", "add_audit_file_stream" in auditor, failures)
    check("Automatic Telegram discovery present", "_save_telegram_discovered_links" in auditor and "telegram_auto_full_history" in bot, failures)
    check("Telegram discovery honors fast scan and selected scope", 'iterator_kwargs["filter"] = InputMessagesFilterUrl' in auditor and "cutoff_for_scope(scope)" in auditor, failures)
    check("Telegram discovery does not recursively audit discovered links", "telegram_discovered_links_are_not_audited_in_same_job" in auditor and "No CheckChatInvite" in auditor, failures)
    check("Telegram discovery cursor recovery present", "audit_tg:" in auditor and "resume_discovery_cursors" in auditor, failures)
    check("maintenance commands cannot recover live jobs", "recover_interrupted: bool = False" in (ROOT / "app/db.py").read_text(encoding="utf-8") and "recover_interrupted=True" in (ROOT / "app/main.py").read_text(encoding="utf-8"), failures)
    check("Telegram discovery workers = 10", bool(re.search(r"audit_telegram_workers:\s*int\s*=\s*10\b", config)), failures)
    check("recursive discovered-links audit button present", "audit:scan_discovered:" in keyboards and "populate_audit_from_discovery" in auditor, failures)
    check("Telegram discovery global dedup present", "_telegram_dedup_key" in auditor and "audit_telegram_discovery" in auditor, failures)
    check("Telegram and WhatsApp discovery independently optional", 'collect_telegram = mode == "tg"' in bot and '"collect_whatsapp": mode == "wa"' in bot and "audit:mode:tg" in keyboards, failures)
    check("channel/group result split exported", "01_قنوات_Telegram_مشتركون" in auditor and "02_مجموعات_Telegram_اعضاء" in auditor, failures)
    check("join-required groups exported", "05_روابط_تحتاج_انضمام_او_طلب_انضمام" in auditor and "_group_requires_join_for_read" in auditor, failures)
    check("bot/private requested exports present", "10_روابط_البوتات" in auditor and "11_روابط_شخصية" in auditor, failures)
    check("pump/IPO group export present", "09_مجموعات_البامبات_والاكتتابات" in auditor and "PUMP_IPO_TITLE_RE" in auditor, failures)
    check("expired active links are purged", "purge_expired_links_from_main_database" in auditor and "expired_links_deleted_from_database" in auditor, failures)
    repository = (ROOT / "app/services/repository.py").read_text(encoding="utf-8")
    models = (ROOT / "app/models.py").read_text(encoding="utf-8")
    check("expired Telegram tombstone table present", "telegram_expired_link_blocklist" in models, failures)
    check("all registrations enforce expired Telegram tombstones", "TelegramExpiredLinkBlocklist" in repository and "blocked=True" in repository, failures)
    check("expired purge writes tombstones before delete", "TelegramExpiredLinkBlocklist" in auditor and "telegram_identity_key" in auditor, failures)
    check("V8 default audit export is one file per section", "V6.4 export contract" in auditor and "raw_chunk_size if raw_chunk_size in {200, 1000} else 0" in auditor, failures)
    check("V6.4 per-section split options present", "audit:export_section:" in bot and "audit_export_options_keyboard" in keyboards, failures)
    check("audit auto ZIP delivery present", "Could not auto-export Telegram audit" in (ROOT / "app/main.py").read_text(encoding="utf-8"), failures)
    check("dashboard implemented", "system:dashboard" in bot, failures)
    check("link search implemented", "search:start" in bot and "seen_count" in bot, failures)
    check("secure create+restore implemented", "create_bundle" in secure and "restore_bundle" in secure and "Checksum mismatch" in secure, failures)
    check("admin action logging implemented", "log_admin_action" in bot, failures)
    check("V6.2.4 public username resolution serialized per account", "public_resolve_locks" in auditor and "async with public_lock" in auditor, failures)
    check("V6.2.4 method-specific cooldowns separated", "public_resolve_cooldowns" in auditor and "invite_check_cooldowns" in auditor, failures)
    check("V6.2.4 FloodWait honors Telegram seconds", '"_retry_after_seconds": wait_seconds' in auditor and "retry_delay = max(float(backoff), retry_after)" in auditor, failures)
    check("V6.2.4 FloodWait never becomes final only by retries", '"_no_attempt_penalty": True' in auditor and "not no_attempt_penalty" in auditor, failures)
    check("V6.2.4 previous FloodWait errors requeued", 'error_class.in_(["FloodWait", "FloodWaitError"])' in auditor, failures)
    check("V6.2.5 discovery resume prefers cached peer id", "get_input_entity(int(peer_id))" in auditor and "resumed from cached peer_id" in auditor, failures)
    check("V6.2.5 discovery FloodWait uses durable deferred cursor", 'status="deferred"' in auditor and "deferred_until" in auditor, failures)
    check("V6.2.5 discovery FloodWait is not a scan error", "not counted as scan error" in auditor and "telegram_floodwait_deferrals" in auditor, failures)
    check("V6.2.5 deferred wait releases account/worker locks", "Locks cover only the active Telegram request work" in auditor and "_sleep_discovery_defer" in auditor, failures)
    check("V6.2.6 durable account ResolveUsername cooldown", "audit_method_cooldown:" in auditor and "_telegram_account_method_cooldown_set" in auditor, failures)
    check("V6.2.6 ResolveUsername API skip during cooldown", "ResolveUsername account cooldown" in auditor and "API request skipped" in auditor, failures)
    check("V6.2.6 inherits V6.2.5 deferred deadlines", "Inherited ResolveUsername account cooldown from discovery cursor" in auditor, failures)
    check("V6.2.6 invite checks remain separate", "invite_check_cooldowns" in auditor and "CheckChatInviteRequest" in auditor, failures)
    check("V6.2.9 discovery resume aggregates legacy cooldowns", "inherited_by_account: dict[int, float]" in auditor and "discovery cursor aggregate" in auditor, failures)
    check("V6.2.9 discovery resume heartbeat present", 'counters["current_phase"] = "resuming_discovery_cursors"' in auditor and "discovery_resume_cursors_seen" in auditor, failures)
    check("V6.2.9 discovery resume task budget present", "tg_schedule_budget = max(1, int(settings.audit_telegram_workers))" in auditor and "telegram_active_scan_keys" in auditor, failures)
    check("V6.3.1 missing audit inputs prioritized before retries", "case((TelegramAuditResult.id.is_(None), 0), else_=1)" in auditor, failures)
    check("V6.3.1 temporary retries rotate by oldest checked_at", "TelegramAuditResult.checked_at.asc().nullsfirst()" in auditor, failures)
    check("V6.3.2 strict group/channel export helper present", "_strict_requested_export_bucket" in auditor, failures)
    check("V6.3.2 channel/group requested exports are exclusive", 'if bucket == "channels"' in auditor and 'elif bucket == "groups"' in auditor, failures)
    check("V6.4 compact user export present", "V6.4 export contract" in auditor and "03_روابط_Telegram_الجديدة" in auditor and "04_روابط_واتساب" in auditor, failures)
    owners = (ROOT / "app/services/owners.py").read_text(encoding="utf-8")
    accounts = (ROOT / "app/services/accounts.py").read_text(encoding="utf-8")
    joiner = (ROOT / "app/services/joiner.py").read_text(encoding="utf-8")
    main = (ROOT / "app/main.py").read_text(encoding="utf-8")
    check("V6.4 one primary owner plus supervisors", "PRIMARY_OWNER_KEY" in owners and "SUPERVISOR_IDS_KEY" in owners and "add_supervisor" in owners, failures)
    check("V6.4 account ownership isolation", "operator_id" in models and "_account_filter_for_operator" in accounts and "account_items_for_operator" in scanner, failures)
    check("V6.4 primary-only export guards", "reject_non_primary" in bot and "database:export_txt" in bot and "audit:export_txt:" in bot, failures)
    check("V6.4 completed-job continuation", "continue_completed_job" in bot and "delete(JobCursor)" in bot, failures)
    check("V6.4 join queue and fixed 3-minute floor", "JoinCandidate" in models and "delay_seconds = max(180" in joiner and "FloodWait" in joiner, failures)
    check("V6.4 automatic audit export owner-only", "is_primary_owner(int(job.requested_by))" in main, failures)
    check("V6.4 DB export no default splitting", '_StreamWriter("قاعدة_الروابط_الكاملة", chunk_size)' in exporter, failures)
    check("V6.4 operator-scoped incremental checkpoints", 'operator:{int(operator_id)}:{base}' in scanner and "legacy_checkpoint_fallback" in scanner and "fallback_key" in scanner, failures)
    check("V6.4 parallel job worker pool", "job_workers: int = 8" in config and "worker_tasks" in main and "aliased(Job)" in scanner, failures)

    # V6.5 browser-audit / session-export / collection workflow
    web_preview = (ROOT / "app/services/web_preview.py").read_text(encoding="utf-8")
    web_auditor = (ROOT / "app/services/web_auditor.py").read_text(encoding="utf-8")
    check("V6.5/V7 session ownership isolation", ("export_session_packages(callback.from_user.id)" in bot or "session_center_handler" in bot) and "list_accounts(int(operator_id))" in accounts, failures)
    check("V7 secure session handling supersedes raw chat export", ("ChatType.PRIVATE" in bot and "session_center_handler" in bot and "تم إيقاف تصدير Session String الخام" in bot), failures)
    check("V6.5 permanent destination settings removed from main menu", "destinations:configure" not in keyboards and "إعداد قنوات التجميع" not in keyboards, failures)
    check("V6.5 source collection saves directly to shared DB", "سيتم حفظ روابط القسم المختار مباشرة في قاعدة البيانات المشتركة" in bot and "destinations={}" in bot, failures)
    check("V6.5 all-account category collection asks per-task destination", "category_accounts_destination" in bot and "هذه القناة تخص هذه المهمة فقط" in bot, failures)
    check("V6.5 per-account collection completion report present", "account_report" in scanner and "_collection_accounts_report" in main, failures)
    check("V6.5 Telegram audit offers browser and account engines", "audit:engine:web" in keyboards and "audit:engine:accounts" in keyboards, failures)
    check("V6.5 browser audit avoids Telethon APIs", "aiohttp" in web_auditor and "TelegramClient" not in web_auditor and "CheckChatInviteRequest" not in web_auditor, failures)
    check("V6.5 browser classifier recognizes subscribers/members/bots/personal", "subscribers" in web_preview and "members" in web_preview and "start bot" in web_preview and "send message" in web_preview, failures)
    check("V6.5 ambiguous web results go to requires-account bucket", "requires_account" in web_preview and "12_روابط_تحتاج_حسابات_لمعرفة_المعلومات" in auditor, failures)
    check("V6.5 browser report sections can be re-audited by accounts", "populate_account_audit_from_web_section" in web_auditor and "audit:web_to_accounts:" in bot, failures)
    check("V6.5 browser-to-account transfer is streamed", "last_result_id" in web_auditor and ".limit(batch_size)" in web_auditor, failures)
    check("V6.5 database continuation uses per-audit high-water", "database_high_water_link_id" in auditor and "Link.id > high_water" in auditor, failures)
    check("V6.5 browser audit workers configurable", "web_audit_workers: int =" in config and "web_audit_batch_size: int =" in config, failures)

    check("V6.6 session-only supervisor role present", "SESSION_SUPERVISOR_IDS_KEY" in owners and "add_session_supervisor" in owners, failures)
    check("V6.6 direct Telethon session extractor present", (ROOT / "app/services/session_extractor.py").exists() and "session:generate" in bot, failures)
    check("V6.6 expired registry import present", (ROOT / "app/services/expired_registry.py").exists() and "expired:import_source" in bot, failures)
    check("V6.6 expired registry excluded from audit inputs", "permanent expired registry" in auditor and "TelegramExpiredLinkBlocklist.identity_key" in auditor, failures)
    check("V6.6 audit TXT includes names with links", "_write_named_telegram_record" in auditor and "الاسم:" in auditor and "الرابط:" in auditor, failures)
    check("V6.6 account audit scans discussion comments", "reply_to=int(message.id)" in auditor and "audit_scan_discussion_comments" in config, failures)

    if failures:
        raise SystemExit("STATIC VALIDATION FAILED: " + ", ".join(failures))
    print("V6 STATIC VALIDATION PASSED")


if __name__ == "__main__":
    main()
