from __future__ import annotations

import asyncio
import sys

from aiogram import Bot
from aiogram.exceptions import TelegramAPIError, TelegramNetworkError, TelegramNotFound, TelegramUnauthorizedError
from dotenv import dotenv_values


def _load_token() -> str:
    token = (dotenv_values('.env').get('BOT_TOKEN') or '').strip()
    if not token or 'REPLACE_ME' in token or ':' not in token:
        raise SystemExit('BOT TOKEN INVALID: set a real BOT_TOKEN in .env')
    return token


async def main() -> int:
    token = _load_token()
    bot = Bot(token=token)
    try:
        me = await bot.get_me()
        username = f'@{me.username}' if me.username else '(no username)'
        print(f'BOT TOKEN OK: {username} [id={me.id}]')
        return 0
    except (TelegramUnauthorizedError, TelegramNotFound) as exc:
        print(f'BOT TOKEN REJECTED BY TELEGRAM: {exc}', file=sys.stderr)
        return 2
    except TelegramNetworkError as exc:
        print(f'TELEGRAM NETWORK ERROR DURING TOKEN CHECK: {exc}', file=sys.stderr)
        return 3
    except TelegramAPIError as exc:
        print(f'TELEGRAM API ERROR DURING TOKEN CHECK: {exc}', file=sys.stderr)
        return 4
    finally:
        await bot.session.close()


if __name__ == '__main__':
    raise SystemExit(asyncio.run(main()))
