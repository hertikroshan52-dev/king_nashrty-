from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def check(name: str, condition: bool) -> None:
    if not condition:
        raise AssertionError(name)
    print("OK  ", name)


def main() -> None:
    models = (ROOT / "app/models.py").read_text(encoding="utf-8")
    joiner = (ROOT / "app/services/joiner.py").read_text(encoding="utf-8")
    preview = (ROOT / "app/services/web_preview.py").read_text(encoding="utf-8")
    auditor = (ROOT / "app/services/auditor.py").read_text(encoding="utf-8")
    bot = (ROOT / "app/bot.py").read_text(encoding="utf-8")
    config = (ROOT / "app/config.py").read_text(encoding="utf-8")

    check("version 8.2.0", (ROOT / "VERSION").read_text().strip() == "8.2.0")
    check("durable per-job join assignments", "class JoinAssignment" in models)
    check("fixed join distribution", "join_distribution_mode" in joiner and "saved_message_sent_at" in models)
    check("V7 join resume import", "seed_legacy_assignments_for_job" in joiner)
    check("join no longer classifies a shared pool", "هذه مهمة انضمام قديمة غير موزعة" in joiner and "_send_assignment_backup_to_saved_messages" in joiner)
    check("task-scoped leave confirmation", "leave:confirm:" in bot and "process_leave_join_job" in joiner)
    check("web preview never asserts generic invite expiration", "web_generic_invite_requires_account_confirmation" in preview)
    check("automatic expiration purge disabled", "audit_auto_purge_expired: bool = False" in config)
    check("recursive discovery is optional", "if not collect_telegram" in auditor)
    check("comments disabled by default", "audit_scan_discussion_comments: bool = False" in config)
    print("V8 STATIC VALIDATION PASSED")


if __name__ == "__main__":
    main()
