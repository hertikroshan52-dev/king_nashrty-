from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def ok(name, cond):
    if not cond: raise AssertionError(name)
    print('OK  ', name)

def main():
    models=(ROOT/'app/models.py').read_text()
    bot=(ROOT/'app/bot.py').read_text()
    kb=(ROOT/'app/keyboards.py').read_text()
    main=(ROOT/'app/main.py').read_text()
    svc=(ROOT/'app/services/control_v7.py').read_text()
    ok('v8 version',(ROOT/'VERSION').read_text().strip()=='8.2.0')
    ok('safe session center','session:center' in bot and 'raw session credentials' in bot)
    ok('no raw extraction delivery','تم إيقاف تصدير Session String الخام' in bot)
    ok('scheduled tasks','class ScheduledTask' in models and 'v7_scheduler_loop' in main)
    ok('workflows','class Workflow' in models and 'run_workflow' in svc)
    ok('tags','class EntityTag' in models and 'global_search' in svc)
    ok('error center','class SystemError' in models and 'v7:errors' in bot)
    ok('audit log','v7:auditlog' in bot)
    ok('diagnostics redaction','Secrets: REDACTED' in svc)
    ok('v7 keyboard','v7_center_keyboard' in kb)
    print('V7 CONTROL-PLANE VALIDATION PASSED ON V8')

if __name__=='__main__': main()
