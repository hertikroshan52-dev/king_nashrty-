from __future__ import annotations

import argparse
import asyncio
import shutil
from datetime import datetime, timezone, timedelta
from pathlib import Path

from sqlalchemy import func, select, update

from app.config import get_settings
from app.db import SessionFactory, init_db
from app.models import Job, TelegramAudit, utcnow
from app.services.backup import create_database_backup, list_backups, restore_latest_backup

settings = get_settings()


async def cmd_migrate() -> None:
    await init_db()
    print("Database schema is ready.")


async def cmd_status() -> None:
    await init_db()
    async with SessionFactory() as session:
        rows = (
            await session.execute(
                select(Job.status, func.count(Job.id)).group_by(Job.status).order_by(Job.status)
            )
        ).all()
    if not rows:
        print("No jobs.")
        return
    for status, count in rows:
        print(f"{status}: {count}")


async def cmd_resume() -> None:
    await init_db()
    now = utcnow()
    async with SessionFactory() as session:
        jobs = list((await session.scalars(select(Job).where(Job.status == "paused"))).all())
        audit_ids = {int(job.audit_id) for job in jobs if job.audit_id}
        for job in jobs:
            job.status = "queued"
            job.paused_at = None
            job.finished_at = None
            job.error = None
            job.updated_at = now
        if audit_ids:
            await session.execute(
                update(TelegramAudit)
                .where(TelegramAudit.id.in_(audit_ids))
                .values(status="queued", paused_at=None, finished_at=None, error=None, current_phase="queued", updated_at=now)
            )
        await session.commit()
    print(f"Queued {len(jobs)} paused job(s) for resume.")


async def cmd_backup() -> None:
    await init_db()
    info = await create_database_backup()
    print(info.path)


async def cmd_restore() -> None:
    await init_db()
    info = await restore_latest_backup()
    print(f"Restored: {info.path}")


async def cmd_backups() -> None:
    for item in await list_backups():
        print(f"{item.path.name}\t{item.size_bytes}")


async def cmd_cleanup() -> None:
    """Optional retention cleanup; never touches DB, sessions, key, or backups."""
    cutoff = datetime.now(timezone.utc) - timedelta(days=max(1, int(settings.maintenance_retention_days)))
    removed_files = 0
    removed_dirs = 0

    def old(path: Path) -> bool:
        try:
            return datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc) < cutoff
        except FileNotFoundError:
            return False

    for path in settings.tmp_dir.rglob("*"):
        if path.is_file() and old(path):
            path.unlink(missing_ok=True)
            removed_files += 1
    # Exports are user-generated snapshots; cleanup is explicit only, never automatic.
    for path in list(settings.exports_dir.iterdir()):
        if not old(path):
            continue
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
            removed_dirs += 1
        elif path.is_file():
            path.unlink(missing_ok=True)
            removed_files += 1
    print(f"Cleanup complete: files={removed_files}, directories={removed_dirs}, retention_days={settings.maintenance_retention_days}")


async def amain() -> None:
    parser = argparse.ArgumentParser(description="Telegram Collector maintenance commands")
    parser.add_argument("command", choices=["migrate", "status", "resume", "backup", "restore", "backups", "cleanup"])
    args = parser.parse_args()
    commands = {
        "migrate": cmd_migrate,
        "status": cmd_status,
        "resume": cmd_resume,
        "backup": cmd_backup,
        "restore": cmd_restore,
        "backups": cmd_backups,
        "cleanup": cmd_cleanup,
    }
    await commands[args.command]()


if __name__ == "__main__":
    asyncio.run(amain())
