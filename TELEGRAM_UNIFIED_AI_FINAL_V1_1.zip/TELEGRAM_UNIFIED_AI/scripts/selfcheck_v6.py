from __future__ import annotations

import asyncio
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.config import get_settings
from app.db import init_db
from app.link_utils import inspect_collection_link, normalize_url


async def main() -> None:
    settings = get_settings()
    await init_db()

    scanner = Path("app/services/scanner.py").read_text(encoding="utf-8")
    auditor = Path("app/services/auditor.py").read_text(encoding="utf-8")
    keyboards = Path("app/keyboards.py").read_text(encoding="utf-8")

    accounts_section = scanner[scanner.index("async def process_accounts_job"):scanner.index("INVITE_RE =")]
    sources_start = scanner.index("async def process_sources_job")
    sources_section = scanner[sources_start:]

    checks: list[tuple[str, bool]] = [
        ("BOT_TOKEN loaded", bool(settings.bot_token)),
        ("V6.4 category collection is the only collection entry", "collect:category" in keyboards and 'callback_data="collect:accounts"' not in keyboards and 'callback_data="collect:sources"' not in keyboards),
        ("V6.4 supervisor and join controls exposed", "supervisors:menu" in keyboards and "join:start" in keyboards),
        ("no instance-role restriction remains", "instance_role" not in keyboards),
        ("max accounts >= 1", settings.max_telethon_accounts >= 1),
        ("collector workers >= 1", settings.collector_account_workers >= 1),
        ("V6 audit group is exactly 10 accounts", settings.audit_account_group_size == 10),
        ("V6 audit gives exactly 4 links/account/cycle", settings.audit_links_per_account_cycle == 4),
        ("V6 audit rest is exactly 120 seconds", float(settings.audit_group_rest_seconds) == 120.0),
        ("audit resolution cache disabled by default configuration", settings.audit_use_resolution_cache is False),
        ("Telegram group candidate accepted by collector", inspect_collection_link("t.me/example_group", "telegram").link is not None),
        ("Telegram message link rejected by collector", inspect_collection_link("https://t.me/example_group/123", "telegram").link is None),
        ("obvious bot link rejected by collector", inspect_collection_link("https://t.me/example_bot", "telegram").link is None),
        ("WhatsApp group accepted", inspect_collection_link("https://chat.whatsapp.com/ABCDEF123", "whatsapp").link is not None),
        ("WhatsApp personal number rejected", inspect_collection_link("https://wa.me/967777123456", "whatsapp").link is None),
        ("Telegram public username canonicalizes case", normalize_url("https://T.ME/Example_Group") == "https://t.me/example_group"),
        ("collector uses extraction inspection", "inspect_collection_link" in accounts_section and "inspect_collection_link" in sources_section),
        ("account collection does not invoke audit resolver", "CheckChatInviteRequest" not in accounts_section and "process_telegram_audit_job" not in accounts_section),
        ("source collection inspects collected URLs locally", "inspect_collection_link(raw_url" in sources_section),
        ("V6 fixed audit scheduler present", "V6 fixed-wave Telegram audit" in auditor),
        ("audit has no auto JoinChannel", "JoinChannelRequest" not in auditor and "ImportChatInviteRequest" not in auditor),
        ("audit immediate expired classification present", '"status": "expired"' in auditor and "_is_dead_link_error" in auditor),
        ("Optional Telegram discovery present", "_save_telegram_discovered_links" in auditor and "collect_telegram" in Path("app/bot.py").read_text(encoding="utf-8")),
        ("Telegram discovery honors fast scan and scope", 'iterator_kwargs["filter"] = InputMessagesFilterUrl' in auditor and "cutoff_for_scope(scope)" in auditor),
        ("Telegram discovery does not audit newly discovered URLs in same job", "telegram_discovered_links_are_not_audited_in_same_job" in auditor and "No CheckChatInvite" in auditor),
        ("Telegram discovery has durable cursors", "audit_tg:" in auditor and "status=\"completed\"" in auditor),
        ("maintenance init does not recover live jobs", "recover_interrupted: bool = False" in Path("app/db.py").read_text(encoding="utf-8") and "recover_interrupted=True" in Path("app/main.py").read_text(encoding="utf-8")),
        ("Telegram discovery workers = 10", settings.audit_telegram_workers == 10),
        ("recursive discovered-links audit button present", "audit:scan_discovered:" in keyboards and "populate_audit_from_discovery" in auditor),
        ("Telegram and WhatsApp discovery are independently optional", 'collect_telegram = mode == "tg"' in Path("app/bot.py").read_text(encoding="utf-8") and "audit:mode:tg" in keyboards),
        ("channel/group result split present", "قنوات_Telegram_مشتركون" in auditor and "مجموعات_Telegram_اعضاء" in auditor),
        ("join-required groups export present", "روابط_تحتاج_انضمام_او_طلب_انضمام" in auditor and "_group_requires_join_for_read" in auditor),
        ("bot/private requested exports present", "روابط_البوتات" in auditor and "روابط_شخصية" in auditor),
        ("pump/IPO group export present", "مجموعات_البامبات_والاكتتابات" in auditor and "PUMP_IPO_TITLE_RE" in auditor),
        ("expired link purge present", "purge_expired_links_from_main_database" in auditor),
        ("expired Telegram tombstone persistence present", "TelegramExpiredLinkBlocklist" in auditor and "telegram_identity_key" in auditor),
        ("repository blocks recollection of expired Telegram identities", "blocked=True" in Path("app/services/repository.py").read_text(encoding="utf-8")),
        ("V8 audit export supports single/200/1000", "raw_chunk_size if raw_chunk_size in {200, 1000} else 0" in auditor),
        ("audit auto ZIP delivery present", "Could not auto-export Telegram audit" in Path("app/main.py").read_text(encoding="utf-8")),
        ("V6.1.1 disconnected-client reconnect present", "async def ensure_connected" in scanner and "client.is_connected()" in scanner),
        ("collection reconnect retry present", "collector_reconnect_attempts" in scanner and 'counters["reconnects"]' in scanner),
        ("0/N false completion blocked", 'counters["phase"] = "connection_failed"' in scanner),
        ("V6.2.4 public username resolver serialized per account", "public_resolve_locks" in auditor and "async with public_lock" in auditor),
        ("V6.2.4 public/invite FloodWait cooldowns separated", "public_resolve_cooldowns" in auditor and "invite_check_cooldowns" in auditor),
        ("V6.2.4 FloodWait honors Telegram retry seconds", '"_retry_after_seconds": wait_seconds' in auditor and "retry_delay = max(float(backoff), retry_after)" in auditor),
        ("V6.2.4 FloodWait does not consume final-error retry budget", '"_no_attempt_penalty": True' in auditor and "not no_attempt_penalty" in auditor),
        ("V6.2.4 prior FloodWait final errors are requeued", 'error_class.in_(["FloodWait", "FloodWaitError"])' in auditor),
        ("V6.2.5 discovery resume prefers cached peer id", "get_input_entity(int(peer_id))" in auditor and "resumed from cached peer_id" in auditor),
        ("V6.2.5 discovery FloodWait uses durable deferred cursor", 'status="deferred"' in auditor and "deferred_until" in auditor),
        ("V6.2.5 discovery FloodWait is not a scan error", "not counted as scan error" in auditor and "telegram_floodwait_deferrals" in auditor),
        ("V6.2.5 deferred wait releases account/worker locks", "Locks cover only the active Telegram request work" in auditor and "_sleep_discovery_defer" in auditor),
        ("V6.2.6 durable account ResolveUsername cooldown", "audit_method_cooldown:" in auditor and "_telegram_account_method_cooldown_set" in auditor),
        ("V6.2.6 ResolveUsername API skip during cooldown", "ResolveUsername account cooldown" in auditor and "API request skipped" in auditor),
        ("V6.2.6 inherits V6.2.5 deferred deadlines", "Inherited ResolveUsername account cooldown from discovery cursor" in auditor),
        ("V6.2.6 invite checks remain separate", "invite_check_cooldowns" in auditor and "CheckChatInviteRequest" in auditor),
        ("V6.2.7 discovery cursors are parked instead of sleeper fan-out", "cursor parked" in auditor and "telegram_discovery_pending_state" in auditor),
        ("V6.2.7 long discovery waits use live heartbeat", "async def idle_with_heartbeat" in auditor and "waiting_discovery_cooldown" in auditor),
        ("V6.2.8 audit retry wait has live heartbeat", 'counters["current_phase"] = "waiting_audit_retry"' in auditor and "await idle_with_heartbeat(wait_slice)" in auditor),
        ("V6.2.8 resumed wave rest has live heartbeat", "await idle_with_heartbeat(max(0.0, (rest_until_dt - utcnow()).total_seconds()))" in auditor),
        ("V6.2.8 audit retry wait exposes next retry metadata", "next_audit_retry_at" in auditor and "next_audit_retry_seconds" in auditor),
        ("V6.2.9 discovery resume aggregates legacy cooldowns", "inherited_by_account: dict[int, float]" in auditor and "discovery cursor aggregate" in auditor),
        ("V6.2.9 discovery resume heartbeat present", 'counters["current_phase"] = "resuming_discovery_cursors"' in auditor and "discovery_resume_cursors_seen" in auditor),
        ("V6.2.9 discovery resume task budget present", "tg_schedule_budget = max(1, int(settings.audit_telegram_workers))" in auditor and "telegram_active_scan_keys" in auditor),
        ("V6.3.0 dead username ValueError classification", "dead_username_pattern" in auditor and "NO USER HAS" in auditor),
        ("V6.3.0 no missing result on reconnect failure", "Audit link deferred before result save" in auditor),
        ("V6.3.0 audit result persisted before discovery", auditor.index("await save_result(item, previous, result)", auditor.index("async def process_one")) < auditor.index("await schedule_telegram_discovery(", auditor.index("async def process_one"))),
        ("V6.3.1 missing audit inputs prioritized before retries", "case((TelegramAuditResult.id.is_(None), 0), else_=1)" in auditor),
        ("V6.3.1 temporary retries rotate by oldest checked_at", "TelegramAuditResult.checked_at.asc().nullsfirst()" in auditor),
        ("V6.3.2 strict group/channel export helper present", "_strict_requested_export_bucket" in auditor),
        ("V6.3.2 channel/group requested exports are exclusive", 'if bucket == "channels"' in auditor and 'elif bucket == "groups"' in auditor),
        ("V6.4 compact export contract present", "V6.4 export contract" in auditor),
        ("V8 optional split sizes present", "{200, 1000}" in auditor),
        ("V6.4 single-file categories present", all(x in auditor for x in ["01_قنوات_Telegram_مشتركون", "02_مجموعات_Telegram_اعضاء", "03_روابط_Telegram_الجديدة", "04_روابط_واتساب", "05_روابط_تحتاج_انضمام_او_طلب_انضمام", "06_اخطاء_نهائية", "07_اخطاء_مؤقتة", "08_روابط_منتهية", "09_مجموعات_البامبات_والاكتتابات"])),
        ("V6.5 session export for own accounts present", "accounts:export_sessions" in keyboards and "export_session_packages" in Path("app/services/accounts.py").read_text(encoding="utf-8")),
        ("V6.5 permanent destination setup removed from main menu", 'text="إعداد قنوات التجميع"' not in keyboards),
        ("V6.5 browser/account audit engines exposed", "audit:engine:web" in keyboards and "audit:engine:accounts" in keyboards),
        ("V6.5 browser auditor present", Path("app/services/web_auditor.py").exists() and "process_web_audit_job" in Path("app/services/web_auditor.py").read_text(encoding="utf-8")),
        ("V6.5 ambiguous web previews use account-required bucket", "requires_account" in Path("app/services/web_auditor.py").read_text(encoding="utf-8") and "12_روابط_تحتاج_حسابات_لمعرفة_المعلومات" in auditor),
        ("V6.5 database audit high-water present", "database_high_water_link_id" in auditor),
        ("V6.5 collection account completion report present", "account_report" in scanner and "تقرير حسابات التجميع" in Path("app/main.py").read_text(encoding="utf-8")),
        ("V6.6 session-only supervisor role present", "SESSION_SUPERVISOR_IDS_KEY" in Path("app/services/owners.py").read_text(encoding="utf-8") and "session_only_menu" in keyboards),
        ("V6.6 direct session generator present", "session:generate" in keyboards and Path("app/services/session_extractor.py").exists()),
        ("V6.6 expired registry import present", "expired:import_source" in keyboards and Path("app/services/expired_registry.py").exists()),
        ("V6.6 audit export writes entity names", "_write_named_telegram_record" in auditor and "الاسم:" in auditor and "الرابط:" in auditor),
        ("V6.6 discussion comments scan present", "reply_to=int(message.id)" in auditor and "audit_scan_discussion_comments" in Path("app/config.py").read_text(encoding="utf-8")),
    ]

    failed = [name for name, ok in checks if not ok]
    for name, ok in checks:
        print(("OK   " if ok else "FAIL ") + name)
    print(
        "Collector: "
        f"workers={settings.collector_account_workers}, fast_scan={settings.collector_fast_scan}, "
        f"db_batch={settings.collector_db_batch_links}"
    )
    print(
        "Audit V6 fixed: "
        f"group={settings.audit_account_group_size}, "
        f"links/account={settings.audit_links_per_account_cycle}, "
        f"rest={settings.audit_group_rest_seconds}s"
    )
    if failed:
        raise SystemExit("SELF-CHECK FAILED: " + ", ".join(failed))
    print("V6 SELF-CHECK PASSED")


if __name__ == "__main__":
    asyncio.run(main())
