from __future__ import annotations
import asyncio, subprocess, sys
from app.db import init_db

async def main():
    await init_db(recover_interrupted=False)
    subprocess.run([sys.executable,'scripts/static_validate_v6.py'],check=True)
    subprocess.run([sys.executable,'scripts/static_validate_v7.py'],check=True)
    subprocess.run([sys.executable,'scripts/static_validate_v8.py'],check=True)
    print('V8 SELF-CHECK PASSED')

if __name__=='__main__': asyncio.run(main())
