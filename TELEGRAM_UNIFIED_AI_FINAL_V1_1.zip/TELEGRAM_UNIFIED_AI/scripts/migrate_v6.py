from __future__ import annotations

import asyncio

from app.db import init_db


if __name__ == "__main__":
    asyncio.run(init_db())
    print("Migration to V6-compatible schema completed without deleting existing data.")
