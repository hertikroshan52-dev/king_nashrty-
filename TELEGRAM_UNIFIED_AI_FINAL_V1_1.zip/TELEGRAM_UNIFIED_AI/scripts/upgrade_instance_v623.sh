#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="${1:-}"

if [[ -z "$TARGET" ]]; then
  echo "Usage: $0 /path/to/existing_instance"
  exit 2
fi
TARGET="$(cd "$TARGET" 2>/dev/null && pwd || true)"
if [[ -z "$TARGET" || ! -d "$TARGET" ]]; then
  echo "Target instance not found."
  exit 2
fi
if [[ "$TARGET" == "$SOURCE_ROOT" ]]; then
  echo "Source and target are the same directory; nothing to upgrade."
  exit 2
fi
if [[ ! -f "$TARGET/.env" || ! -x "$TARGET/.venv/bin/python" || ! -x "$TARGET/botctl.sh" ]]; then
  echo "Target must contain .env, .venv and botctl.sh."
  exit 2
fi

# Safety rule: never replace code under an instance that still has work to do.
# V6.2.1 full-history discovery did not persist every in-flight crawl, so an
# active upgrade cannot honestly guarantee zero lost scan progress. Stage the
# new release separately, let this instance finish, then run this script.
DB_PATH="$TARGET/data/collector.db"
if [[ -f "$DB_PATH" ]]; then
  nonterminal="$($TARGET/.venv/bin/python - "$DB_PATH" <<'PY'
import sqlite3, sys
p=sys.argv[1]
con=sqlite3.connect(p)
try:
    rows=con.execute("SELECT status, COUNT(*) FROM jobs WHERE status IN ('queued','starting','running','pause_requested','paused','stopping') GROUP BY status ORDER BY status").fetchall()
finally:
    con.close()
if rows:
    print("; ".join(f"{s}={n}" for s,n in rows))
PY
)"
  if [[ -n "$nonterminal" ]]; then
    echo "REFUSED: this instance still has unfinished jobs: $nonterminal"
    echo "No files were changed and the running bot was not stopped."
    echo "Let this instance finish its jobs, then run the same upgrade command again."
    exit 4
  fi
fi

was_running=0
if (cd "$TARGET" && ./botctl.sh status 2>/dev/null | head -n1 | grep -q '^running PID '); then
  was_running=1
fi

stamp="$(date +%Y%m%d_%H%M%S)"
code_backup="$TARGET/data/backups/pre_v623_code_${stamp}.tar.gz"
mkdir -p "$TARGET/data/backups"

echo "[1/8] Instance is idle; preparing safe upgrade..."
if [[ "$was_running" -eq 1 ]]; then
  (cd "$TARGET" && ./botctl.sh stop)
fi

echo "[2/8] Creating SQLite backup..."
(cd "$TARGET" && ./botctl.sh backup)

echo "[3/8] Creating code rollback archive..."
tar -C "$TARGET" \
  --exclude='.env' --exclude='.venv' --exclude='data' \
  --exclude='__pycache__' --exclude='.pytest_cache' \
  -czf "$code_backup" .

echo "[4/8] Installing V6.2.3 code (preserving .env, .venv and data)..."
tar -C "$SOURCE_ROOT" \
  --exclude='.env' --exclude='.venv' --exclude='data' \
  --exclude='__pycache__' --exclude='.pytest_cache' \
  -cf - . | tar -C "$TARGET" -xf -
chmod +x "$TARGET/botctl.sh" "$TARGET/start.sh" "$TARGET/scripts/upgrade_instance_v623.sh" 2>/dev/null || true

validate() {
  echo "[5/8] Compiling and migrating..."
  (cd "$TARGET" && .venv/bin/python -m compileall -q app scripts tests)
  (cd "$TARGET" && ./botctl.sh migrate)

  echo "[6/8] Running static validation..."
  (cd "$TARGET" && .venv/bin/python scripts/static_validate_v6.py)

  echo "[7/8] Running full tests and self-check..."
  (cd "$TARGET" && .venv/bin/python -m pytest -q)
  (cd "$TARGET" && ./botctl.sh selfcheck)
}

if ! validate; then
  echo "UPGRADE VALIDATION FAILED. Restoring previous code..."
  tar -C "$TARGET" -xzf "$code_backup"
  (cd "$TARGET" && .venv/bin/python -m compileall -q app scripts tests) || true
  if [[ "$was_running" -eq 1 ]]; then
    (cd "$TARGET" && ./botctl.sh start) || true
  fi
  echo "Previous code restored. Code rollback archive: $code_backup"
  exit 1
fi

echo "[8/8] Upgrade validated successfully."
if [[ "$was_running" -eq 1 ]]; then
  (cd "$TARGET" && ./botctl.sh start)
fi

echo "V6.2.3 SAFE UPGRADE PASSED: $TARGET"
echo "Code rollback archive: $code_backup"
