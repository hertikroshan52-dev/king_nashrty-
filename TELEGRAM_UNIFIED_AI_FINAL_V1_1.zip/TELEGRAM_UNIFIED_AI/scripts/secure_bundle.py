from __future__ import annotations

import argparse
import asyncio
import base64
import getpass
import hashlib
import io
import json
import os
import sqlite3
import tarfile
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from app.config import PROJECT_ROOT, get_settings
from app.db import engine, init_db
from app.services.backup import _restore_sync, _sqlite_db_path, create_database_backup

settings = get_settings()
MAGIC = b"TLCRB6\n"
ALLOWED_FILES = {"database.db", ".session_key", ".env", "manifest.json"}


def derive(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=600_000)
    return base64.urlsafe_b64encode(kdf.derive(password.encode("utf-8")))


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def ask_password(confirm: bool = False) -> str:
    password = getpass.getpass("Recovery bundle password: ")
    if not password:
        raise SystemExit("Password cannot be empty.")
    if confirm:
        again = getpass.getpass("Confirm password: ")
        if password != again:
            raise SystemExit("Passwords do not match.")
    return password


async def create_bundle(output: Path | None = None) -> Path:
    password = ask_password(confirm=True)
    backup = await create_database_backup(prefix="secure_bundle_db")

    raw_files: dict[str, bytes] = {"database.db": backup.path.read_bytes()}
    if settings.key_file.exists():
        raw_files[".session_key"] = settings.key_file.read_bytes()
    env_path = PROJECT_ROOT / ".env"
    if env_path.exists():
        raw_files[".env"] = env_path.read_bytes()

    manifest = {
        "format": 2,
        "version": (PROJECT_ROOT / "VERSION").read_text(encoding="utf-8").strip(),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "instance_name": settings.instance_name,
        "full_features": True,
        "files": {name: {"sha256": sha256_bytes(data), "bytes": len(data)} for name, data in raw_files.items()},
    }

    payload = io.BytesIO()
    with tarfile.open(fileobj=payload, mode="w:gz") as tar:
        for name, data in raw_files.items():
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o600
            tar.addfile(info, io.BytesIO(data))
        manifest_raw = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
        info = tarfile.TarInfo("manifest.json")
        info.size = len(manifest_raw)
        info.mode = 0o600
        tar.addfile(info, io.BytesIO(manifest_raw))

    salt = os.urandom(16)
    encrypted = Fernet(derive(password, salt)).encrypt(payload.getvalue())
    if output is None:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        output = settings.backups_dir / f"secure_recovery_v6_{stamp}.tlrb"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(MAGIC + base64.urlsafe_b64encode(salt) + b"\n" + encrypted)
    try:
        os.chmod(output, 0o600)
    except OSError:
        pass
    return output


def _decrypt_bundle(path: Path, password: str) -> dict[str, bytes]:
    raw = path.read_bytes()
    if not raw.startswith(MAGIC):
        raise RuntimeError("Not a V6 secure recovery bundle.")
    remainder = raw[len(MAGIC):]
    salt_line, sep, encrypted = remainder.partition(b"\n")
    if not sep:
        raise RuntimeError("Corrupt recovery bundle header.")
    try:
        salt = base64.urlsafe_b64decode(salt_line)
        payload = Fernet(derive(password, salt)).decrypt(encrypted)
    except (ValueError, InvalidToken) as exc:
        raise RuntimeError("Wrong password or corrupted recovery bundle.") from exc

    files: dict[str, bytes] = {}
    with tarfile.open(fileobj=io.BytesIO(payload), mode="r:gz") as tar:
        for member in tar.getmembers():
            if member.name not in ALLOWED_FILES or not member.isfile():
                raise RuntimeError(f"Unexpected file in recovery bundle: {member.name}")
            handle = tar.extractfile(member)
            if handle is None:
                raise RuntimeError(f"Cannot read {member.name} from bundle.")
            files[member.name] = handle.read()
    if "database.db" not in files or "manifest.json" not in files:
        raise RuntimeError("Recovery bundle is missing database or manifest.")

    manifest = json.loads(files["manifest.json"].decode("utf-8"))
    expected = manifest.get("files") or {}
    for name, meta in expected.items():
        if name not in files:
            raise RuntimeError(f"Recovery bundle is missing {name}.")
        digest = sha256_bytes(files[name])
        if digest != str((meta or {}).get("sha256") or ""):
            raise RuntimeError(f"Checksum mismatch for {name}.")
    return files


def _check_sqlite_bytes(data: bytes) -> None:
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as tmp:
        tmp.write(data)
        path = Path(tmp.name)
    try:
        conn = sqlite3.connect(str(path), timeout=30)
        try:
            result = conn.execute("PRAGMA integrity_check").fetchone()
            if not result or str(result[0]).lower() != "ok":
                raise RuntimeError(f"Recovered database integrity_check failed: {result}")
        finally:
            conn.close()
    finally:
        path.unlink(missing_ok=True)


async def restore_bundle(path: Path) -> None:
    if not path.exists():
        raise SystemExit(f"Bundle not found: {path}")
    password = ask_password(confirm=False)
    files = _decrypt_bundle(path, password)
    _check_sqlite_bytes(files["database.db"])

    # Safety snapshot of the live database before destructive restore.
    await init_db()
    await create_database_backup(prefix="pre_secure_restore")
    destination = _sqlite_db_path()
    await engine.dispose()

    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as tmp:
        tmp.write(files["database.db"])
        temp_db = Path(tmp.name)
    try:
        await asyncio.to_thread(_restore_sync, temp_db, destination)
    finally:
        temp_db.unlink(missing_ok=True)

    if ".session_key" in files:
        settings.key_file.parent.mkdir(parents=True, exist_ok=True)
        settings.key_file.write_bytes(files[".session_key"])
        try:
            os.chmod(settings.key_file, 0o600)
        except OSError:
            pass
    if ".env" in files:
        env_path = PROJECT_ROOT / ".env"
        env_path.write_bytes(files[".env"])
        try:
            os.chmod(env_path, 0o600)
        except OSError:
            pass
    await init_db()


async def amain() -> None:
    parser = argparse.ArgumentParser(description="Encrypted V6 disaster-recovery bundle")
    sub = parser.add_subparsers(dest="command", required=False)
    create = sub.add_parser("create")
    create.add_argument("--output", type=Path)
    restore = sub.add_parser("restore")
    restore.add_argument("bundle", type=Path)
    args = parser.parse_args()
    command = args.command or "create"
    if command == "create":
        out = await create_bundle(getattr(args, "output", None))
        print(out)
    elif command == "restore":
        await restore_bundle(args.bundle)
        print(f"Secure recovery restored: {args.bundle}")


if __name__ == "__main__":
    asyncio.run(amain())
