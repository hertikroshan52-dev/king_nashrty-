#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="${1:-}"
MODE="${2:-}"

if [[ -z "$TARGET" ]]; then
  echo "Usage: $0 /path/to/existing_instance [--stop-and-resume]"
  exit 2
fi
TARGET="$(cd "$TARGET" 2>/dev/null && pwd || true)"
if [[ -z "$TARGET" || ! -d "$TARGET" ]]; then
  echo "Target instance not found."
  exit 2
fi
if [[ "$TARGET" == "$SOURCE_ROOT" ]]; then
  echo "Source and target are the same directory; nothing to upgrade."
  exit 2
fi
if [[ ! -f "$TARGET/.env" || ! -x "$TARGET/.venv/bin/python" || ! -x "$TARGET/botctl.sh" ]]; then
  echo "Target must contain .env, .venv and botctl.sh."
  exit 2
fi

is_running=0
if (cd "$TARGET" && ./botctl.sh status 2>/dev/null | head -n1 | grep -q '^running PID '); then
  is_running=1
fi

if [[ "$is_running" -eq 1 && "$MODE" != "--stop-and-resume" ]]; then
  echo "REFUSED: target is currently running."
  echo "Let its current jobs finish, or rerun with --stop-and-resume for a controlled stop/upgrade/restart."
  exit 3
fi

stamp="$(date +%Y%m%d_%H%M%S)"
code_backup="$TARGET/data/backups/pre_v61_code_${stamp}.tar.gz"
mkdir -p "$TARGET/data/backups"

echo "[1/8] Preparing controlled upgrade..."
if [[ "$is_running" -eq 1 ]]; then
  (cd "$TARGET" && ./botctl.sh stop)
fi

echo "[2/8] Creating SQLite backup..."
(cd "$TARGET" && ./botctl.sh backup)

echo "[3/8] Creating code rollback archive..."
tar -C "$TARGET" \
  --exclude='.env' --exclude='.venv' --exclude='data' \
  --exclude='__pycache__' --exclude='.pytest_cache' \
  -czf "$code_backup" .

echo "[4/8] Installing V6.1 code (preserving .env, .venv and data)..."
tar -C "$SOURCE_ROOT" \
  --exclude='.env' --exclude='.venv' --exclude='data' \
  --exclude='__pycache__' --exclude='.pytest_cache' \
  -cf - . | tar -C "$TARGET" -xf -
chmod +x "$TARGET/botctl.sh" "$TARGET/start.sh" "$TARGET/scripts/upgrade_instance_v61.sh" 2>/dev/null || true

validate() {
  echo "[5/8] Compiling and migrating..."
  (cd "$TARGET" && .venv/bin/python -m compileall -q app scripts tests)
  (cd "$TARGET" && ./botctl.sh migrate)

  echo "[6/8] Running static validation..."
  (cd "$TARGET" && .venv/bin/python scripts/static_validate_v6.py)

  echo "[7/8] Running full tests and self-check..."
  (cd "$TARGET" && .venv/bin/python -m pytest -q)
  (cd "$TARGET" && ./botctl.sh selfcheck)
}

if ! validate; then
  echo "UPGRADE VALIDATION FAILED. Restoring previous code..."
  tar -C "$TARGET" -xzf "$code_backup"
  (cd "$TARGET" && .venv/bin/python -m compileall -q app scripts tests) || true
  if [[ "$is_running" -eq 1 ]]; then
    (cd "$TARGET" && ./botctl.sh start) || true
  fi
  echo "Previous code restored. Code rollback archive: $code_backup"
  exit 1
fi

echo "[8/8] Upgrade validated successfully."
if [[ "$is_running" -eq 1 ]]; then
  (cd "$TARGET" && ./botctl.sh start)
fi

echo "V6.1 UPGRADE PASSED: $TARGET"
echo "Code rollback archive: $code_backup"
