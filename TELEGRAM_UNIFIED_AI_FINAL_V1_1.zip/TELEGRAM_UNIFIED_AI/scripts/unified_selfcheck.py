"""Offline preflight. Never print credentials or user sessions."""
from __future__ import annotations
import os
import sys
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / '.env', override=False)


def check() -> int:
    errors = []
    warnings = []
    token = os.environ.get('BOT_TOKEN', '').strip()
    owner = os.environ.get('OWNER_ID', '').strip()
    admin_ids = [p.strip() for p in os.environ.get('ADMIN_IDS', '').split(',') if p.strip()]
    if not token or ':' not in token or 'REPLACE_ME' in token:
        errors.append('BOT_TOKEN غير مضبوط.')
    if not owner.isdecimal():
        errors.append('OWNER_ID غير رقمي أو غير مضبوط.')
    elif admin_ids and owner not in admin_ids:
        errors.append('OWNER_ID غير موجود ضمن ADMIN_IDS.')
    if os.environ.get('TELEGRAM_API_ID','').strip() in ('', '1') or not os.environ.get('TELEGRAM_API_HASH','').strip():
        warnings.append('TELEGRAM_API_ID / TELEGRAM_API_HASH مطلوبان لبعض وظائف حسابات Telethon.')
    collector = (ROOT / 'data' / 'collector.db').resolve()
    pub_data = Path(os.environ.get('PUBLISHER_DATA_DIR') or ROOT/'data'/'publisher').expanduser()
    if not pub_data.is_absolute():
        pub_data = (ROOT / pub_data).resolve()
    pub_db = Path(os.environ.get('PUBLISHER_DB_NAME') or (pub_data/'bot_database.db')).expanduser()
    if not pub_db.is_absolute():
        pub_db = (ROOT / pub_db).resolve()
    if pub_db == collector:
        errors.append('قاعدة النشر لا يمكن أن تكون data/collector.db نفسها.')
    if not pub_db.exists():
        warnings.append('قاعدة بيانات النشر غير موجودة هنا بعد؛ تأكد من نقل البيانات القديمة قبل التشغيل إن أردت الحفاظ عليها.')
    if not collector.exists():
        warnings.append('قاعدة بيانات التجميع غير موجودة هنا بعد؛ هذا طبيعي للتثبيت الجديد فقط.')
    if not os.environ.get('OPENAI_API_KEY', '').strip():
        warnings.append('الذكاء الاصطناعي غير مفعّل حتى تضيف OPENAI_API_KEY.')
    if sys.version_info < (3, 12):
        errors.append('يلزم Python 3.12 أو أحدث.')
    if not (ROOT/'legacy_publisher'/'telegram_ai_pro_main.py').is_file():
        errors.append('ملف النشر غير موجود.')
    if not (ROOT/'app'/'unified_main.py').is_file():
        errors.append('ملف التشغيل الموحد غير موجود.')
    print('=== Unified Telegram preflight ===')
    print('Collector data:', collector.parent)
    print('Publisher data:', pub_data)
    print('Publisher DB:', pub_db)
    print('Python:', sys.version.split()[0])
    for warn in warnings:
        print('⚠️',warn)
    for error in errors:
        print('❌',error)
    if errors:
        return 1
    print('✅ فحوصات الإعداد الأساسية سليمة. هذا لا يؤكد الاتصال الحي بالخدمات.')
    return 0


if __name__ == '__main__':
    raise SystemExit(check())
