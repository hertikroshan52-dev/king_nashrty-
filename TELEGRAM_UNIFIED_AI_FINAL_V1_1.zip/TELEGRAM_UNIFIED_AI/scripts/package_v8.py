from __future__ import annotations

import json
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = ROOT.parent / "telegram_link_collector_bot_v8_2_0_FIXED_JOIN_FINAL.zip"


def main() -> None:
    output = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else DEFAULT_OUTPUT
    manifest_path = ROOT / "BUILD_MANIFEST_V8.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    relative_paths = [Path(row["path"]) for row in manifest["files"]]
    relative_paths.extend([Path("BUILD_MANIFEST_V8.json"), Path("BUILD_MANIFEST_SHA256.txt")])
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for relative in relative_paths:
            source = ROOT / relative
            if not source.is_file():
                raise FileNotFoundError(source)
            archive.write(source, (Path(ROOT.name) / relative).as_posix())
    print(output)


if __name__ == "__main__":
    main()
