# V7.0.1 Stable Fixes

- إصلاح مشكلة ظهور `Started PID` ثم `stopped` عند BOT_TOKEN مرفوض.
- `tokencheck` يستخدم aiogram `get_me()` ضد Telegram API قبل التشغيل.
- لا يطبع BOT_TOKEN ولا API_HASH ولا Session String.
- `start` لا يبدأ الخلفية إلا بعد نجاح tokencheck.
