# ابدأ هنا — Telegram Link Collector 8.2.0

الحزمة الكاملة تحتوي الكود والمتطلبات والأزرار والمحركات والاختبارات ودليل التحديث. اقرأ RELEASE_8_1_AR.md لمعرفة ما اختُبر وحدود التشغيل الفعلي.

## تحديث النسخة الحالية مع الحفاظ على البيانات

هذه الأوامر داخل Ubuntu في Termux، كما في طريقة تثبيت النسخة المرفقة. استبدل /root/OLD_BOT بالمسار الحقيقي لمجلد البوت القديم. لا تنفذ مُثبت النسخة الجديدة قبل سكربت التحديث لأنه سيُنشئ .env فيرفض السكربت الكتابة فوقه.

```bash
cd /root/OLD_BOT
./botctl.sh stop
./botctl.sh status
mkdir -p /root/telegram-v810
cd /root/telegram-v810
unzip /sdcard/Download/telegram_link_collector_bot_v8_1_0_REVIEWED.zip
cd telegram_link_collector_bot_v8_1_0_REVIEWED
sh UPGRADE_TO_V8_TERMUX.sh /root/OLD_BOT
./botctl.sh start
./botctl.sh status
```

إذا اختلف اسم ملف ZIP الذي نزّلته، استخدم اسمه الفعلي في أمر unzip. السكربت ينسخ قاعدة البيانات والإعدادات ومفتاح الجلسات، ويحتفظ بالمجلد القديم والنسخ الاحتياطية فيه. يجب إيقاف أي تشغيل قديم يدوي عبر python أيضًا؛ ففحص PID لا يستطيع التعرف على كل طرق التشغيل الخارجية.

من قائمة «المهام» اختر استكمال المهمة القديمة نفسها. لا تشغّل نسختين بالتوكن أو قاعدة البيانات نفسها. بعد تأكيد سلامة التشغيل يمكنك الاحتفاظ بالنسخة القديمة للرجوع إليها.

## تثبيت جديد فقط

من Termux:

```bash
pkg update -y
pkg install -y proot-distro tmux
termux-setup-storage
proot-distro install ubuntu
proot-distro login ubuntu
```

ثم داخل Ubuntu:

```bash
apt update
apt install -y unzip python3 python3-venv python3-pip
mkdir -p /root/telegram-v810
cd /root/telegram-v810
unzip /sdcard/Download/telegram_link_collector_bot_v8_1_0_REVIEWED.zip
cd telegram_link_collector_bot_v8_1_0_REVIEWED
sh install-ubuntu.sh
nano .env
./botctl.sh selfcheck
./botctl.sh start
```

ضع التوكن الصحيح في BOT_TOKEN ومعرّفك في ADMIN_IDS. متطلبات المشروع تستهدف Python 3.12 فأحدث داخل Ubuntu؛ التثبيت المباشر في Android ليس البيئة التي اختُبرت هنا.

## التشغيل بعد إعادة تشغيل الهاتف

من Termux:

```bash
proot-distro login ubuntu
cd /root/telegram-v810/telegram_link_collector_bot_v8_1_0_REVIEWED
./botctl.sh start
./botctl.sh status
```

## الاستخدام

- من «قاعدة البيانات» يمكن بدء توزيع وانضمام من روابط Telegram المحفوظة.
- أو من «الانضمام» أرسل قناة/مجموعة مصدر ثم اختر 200.
- مرحلة الفحص تسبق الانضمام، ثم يعمل الحساب الأول والثاني وبقية الحسابات بالتوازي على حصصها المحجوزة.
- نتائج كل حالة موجودة عبر زر نتائج الانضمام في قائمة المهام للمالك الأساسي.
- الإيقاف المؤقت يحتاج وقتًا حتى يكمل العامل طلبه الجاري ويحفظ النتيجة. انتظر حالة «متوقفة» ثم استكمل.
- المغادرة تتطلب تأكيدًا وتستهدف ما سجله الإصدار كعضويات جديدة مؤكدة للمهمة فقط.

لفحص السجل:

```bash
tail -n 100 data/logs/launcher.log
```
