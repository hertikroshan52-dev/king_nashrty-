#!/usr/bin/env sh
set -eu

NEW_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
OLD_INPUT=${1:-}

if [ -z "$OLD_INPUT" ]; then
  echo "Usage: $0 /absolute/path/to/V7-folder"
  exit 2
fi
case "$OLD_INPUT" in
  /*) ;;
  *) echo "ERROR: use the absolute path of the V7 folder"; exit 2 ;;
esac

OLD_DIR=$(CDPATH= cd -- "$OLD_INPUT" 2>/dev/null && pwd -P) || {
  echo "ERROR: V7 folder not found: $OLD_INPUT"
  exit 1
}

if [ "$OLD_DIR" = "$NEW_DIR" ]; then
  echo "ERROR: V7 and V8 must be separate folders"
  exit 1
fi
case "$NEW_DIR/" in "$OLD_DIR/"*) echo "ERROR: new folder must be outside old folder"; exit 1 ;; esac
if [ -e "$NEW_DIR/data/collector.db" ] || [ -e "$NEW_DIR/.env" ]; then
  echo "ERROR: destination already has data/configuration; use a fresh release folder"
  exit 1
fi
if [ ! -f "$OLD_DIR/data/collector.db" ]; then
  echo "ERROR: collector.db was not found in $OLD_DIR/data"
  exit 1
fi
if [ ! -f "$OLD_DIR/.env" ]; then
  echo "ERROR: V7 .env was not found"
  exit 1
fi

PID_FILE="$OLD_DIR/data/bot.pid"
if [ -f "$PID_FILE" ]; then
  OLD_PID=$(sed -n '1p' "$PID_FILE" 2>/dev/null || true)
  if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
    echo "ERROR: V7 is still running (PID $OLD_PID). Run ./botctl.sh stop in V7 first."
    exit 1
  fi
fi

STAMP=$(date -u +%Y%m%d_%H%M%S)
BACKUP_DIR="$OLD_DIR/data/backups/v8_upgrade_$STAMP"
mkdir -p "$BACKUP_DIR"

python3 - "$OLD_DIR" "$NEW_DIR" "$BACKUP_DIR" <<'PYTHON'
import pathlib, shutil, sqlite3, sys
old, new, backup = map(pathlib.Path, sys.argv[1:])
with sqlite3.connect(str(old/'data/collector.db')) as src:
    with sqlite3.connect(str(backup/'collector.db')) as dst:
        src.backup(dst)
        if dst.execute('PRAGMA integrity_check').fetchone() != ('ok',):
            raise SystemExit('Backup integrity check failed')
shutil.copy2(old/'.env', backup/'env.backup')
if (old/'data/.session_key').exists():
    shutil.copy2(old/'data/.session_key', backup/'session_key.backup')
shutil.copytree(old/'data',new/'data',dirs_exist_ok=True,
    ignore=shutil.ignore_patterns('backups','collector.db','collector.db-wal','collector.db-shm','bot.pid','*.lock'))
shutil.copy2(backup/'collector.db',new/'data/collector.db')
PYTHON
cp -p "$OLD_DIR/.env" "$NEW_DIR/.env"
chmod 600 "$NEW_DIR/.env" 2>/dev/null || true
if [ -f "$NEW_DIR/data/.session_key" ]; then chmod 600 "$NEW_DIR/data/.session_key" 2>/dev/null || true; fi

cd "$NEW_DIR"
chmod +x install-ubuntu.sh botctl.sh start.sh UPGRADE_TO_V8_TERMUX.sh
./install-ubuntu.sh
./botctl.sh migrate
./botctl.sh selfcheck

echo "V8 UPGRADE COMPLETE"
echo "Backup: $BACKUP_DIR"
echo "Next: cd '$NEW_DIR' && ./botctl.sh start"
