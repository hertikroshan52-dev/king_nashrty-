#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
PID_FILE="data/bot.pid"
LOG_FILE="data/logs/launcher.log"
mkdir -p data/logs

ensure_env() {
  if [ ! -f .env ]; then
    cp .env.example .env
    echo "Created .env. Set BOT_TOKEN and Telegram credentials first."
    exit 1
  fi
  if [ ! -x .venv/bin/python ]; then
    echo "Missing .venv. Run: ./start.sh once to create/install it."
    exit 1
  fi
}

is_running() {
  [ -f "$PID_FILE" ] || return 1
  pid="$(cat "$PID_FILE" 2>/dev/null || true)"
  [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null
}

tokencheck() {
  ensure_env
  .venv/bin/python -m scripts.check_bot_token
}

start_bot() {
  ensure_env
  if is_running; then
    echo "Bot already running (PID $(cat "$PID_FILE"))."
    return 0
  fi
  .venv/bin/python -m scripts.unified_selfcheck
  echo "Checking BOT_TOKEN with Telegram..."
  tokencheck
  nohup .venv/bin/python -m app.unified_main >>"$LOG_FILE" 2>&1 &
  pid=$!
  echo "$pid" > "$PID_FILE"
  sleep 2
  if ! kill -0 "$pid" 2>/dev/null; then
    rm -f "$PID_FILE"
    echo "START FAILED: process exited during startup."
    echo "--- last launcher log lines ---"
    tail -n 60 "$LOG_FILE" 2>/dev/null || true
    exit 1
  fi
  echo "Started PID $pid and startup check passed."
}

stop_bot() {
  if ! is_running; then
    rm -f "$PID_FILE"
    echo "Bot is not running."
    return 0
  fi
  pid="$(cat "$PID_FILE")"
  kill -TERM "$pid" 2>/dev/null || true
  i=0
  while kill -0 "$pid" 2>/dev/null && [ "$i" -lt 30 ]; do
    sleep 1
    i=$((i + 1))
  done
  if kill -0 "$pid" 2>/dev/null; then
    echo "Grace period exceeded; sending KILL. Database recovery will resume committed work."
    kill -KILL "$pid" 2>/dev/null || true
  fi
  rm -f "$PID_FILE"
  echo "Stopped."
}


versioncheck() {
  py="${PYTHON_BIN:-python3}"
  command -v "$py" >/dev/null 2>&1 || { echo "PYTHON MISSING"; exit 1; }
  "$py" - <<'PY'
import sys
v = sys.version_info[:2]
print("PYTHON", sys.version.split()[0])
if v < (3, 12):
    raise SystemExit("Python 3.12+ required")
if v >= (3, 15):
    print("WARNING Python 3.15+ is not validated for this release")
else:
    print("PYTHON RUNTIME OK")
PY
}

case "${1:-}" in
  start) start_bot ;;
  stop) stop_bot ;;
  restart) stop_bot; start_bot ;;
  status)
    if is_running; then echo "running PID $(cat "$PID_FILE")"; else echo "stopped"; fi
    ensure_env
    .venv/bin/python -m scripts.manage status
    ;;
  resume) ensure_env; .venv/bin/python -m scripts.manage resume ;;
  backup) ensure_env; .venv/bin/python -m scripts.manage backup ;;
  restore) ensure_env; .venv/bin/python -m scripts.manage restore ;;
  migrate) ensure_env; .venv/bin/python -m scripts.manage migrate ;;
  cleanup) ensure_env; .venv/bin/python -m scripts.manage cleanup ;;
  selfcheck) ensure_env; .venv/bin/python -m scripts.unified_selfcheck; .venv/bin/python -m scripts.selfcheck_v7 ;;
  secure-backup) ensure_env; .venv/bin/python -m scripts.secure_bundle create ;;
  versioncheck) versioncheck ;;
  tokencheck) tokencheck ;;
  secure-restore) ensure_env; if is_running; then echo "Stop the bot before secure restore."; exit 1; fi; [ -n "${2:-}" ] || { echo "Usage: $0 secure-restore /path/to/file.tlrb"; exit 2; }; .venv/bin/python -m scripts.secure_bundle restore "$2" ;;
  *) echo "Usage: $0 {start|stop|restart|status|resume|backup|restore|migrate|cleanup|selfcheck|versioncheck|tokencheck|secure-backup|secure-restore}"; exit 2 ;;
esac
