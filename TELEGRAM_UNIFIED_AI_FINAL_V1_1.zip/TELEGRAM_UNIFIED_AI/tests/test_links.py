from app.link_utils import (
    clean_link,
    classify_url,
    contains_phone_number,
    inspect_link,
    is_telegram_message_link,
    normalize_url,
)


def test_categories() -> None:
    assert classify_url("https://chat.whatsapp.com/AbCdEf") == "whatsapp"
    assert classify_url("https://x.com/example/status/1") == "twitter"
    assert classify_url("https://t.me/example") == "telegram"
    assert classify_url("https://example.com/path") == "other"


def test_reject_phone_number() -> None:
    assert contains_phone_number("https://wa.me/967777123456")
    assert clean_link("https://wa.me/967777123456") is None
    assert inspect_link("https://example.com/contact/+967-777-123-456").reason == "phone"


def test_keep_numeric_non_phone_ids() -> None:
    assert clean_link("https://x.com/example/status/1823456789012345678") is not None
    assert clean_link("https://example.com/items/1234567890") is not None


def test_reject_telegram_message_links() -> None:
    assert is_telegram_message_link("https://t.me/ta7silihemma/1414")
    assert is_telegram_message_link("https://t.me/c/123456/77")
    assert is_telegram_message_link("https://t.me/s/example/99")
    assert clean_link("https://t.me/ta7silihemma/1582") is None


def test_allow_channel_and_invite_links() -> None:
    assert clean_link("https://t.me/example_channel") is not None
    assert clean_link("https://t.me/+AbCdEfGhIj") is not None
    assert clean_link("https://chat.whatsapp.com/AbCdEfGhIj") is not None


def test_normalization_and_aliases() -> None:
    assert normalize_url("http://Example.com/path/?utm_source=x&a=1#top") == "https://example.com/path?a=1"
    assert normalize_url("https://telegram.me/TestChannel/") == "https://t.me/testchannel"
    assert normalize_url("https://t.me/TESTCHANNEL?single=1") == "https://t.me/testchannel"
    assert normalize_url("https://twitter.com/name/status/1") == "https://x.com/name/status/1"


def test_fast_collection_accepts_bare_telegram_and_group_whatsapp() -> None:
    from app.link_utils import inspect_collection_link
    tg = inspect_collection_link("t.me/example_group", "telegram")
    wa = inspect_collection_link("chat.whatsapp.com/AbCdEf123", "whatsapp")
    assert tg.link is not None and tg.link.normalized == "https://t.me/example_group"
    assert wa.link is not None and wa.link.normalized == "https://chat.whatsapp.com/AbCdEf123"


def test_collection_rejects_obvious_bot_service_and_personal_whatsapp() -> None:
    from app.link_utils import inspect_collection_link
    assert inspect_collection_link("https://t.me/example_bot", "telegram").link is None
    assert inspect_collection_link("https://t.me/share/url?url=https://example.com", "telegram").link is None
    assert inspect_collection_link("https://wa.me/967777123456", "whatsapp").link is None
    assert inspect_collection_link("https://api.whatsapp.com/send?phone=967777123456", "whatsapp").link is None
