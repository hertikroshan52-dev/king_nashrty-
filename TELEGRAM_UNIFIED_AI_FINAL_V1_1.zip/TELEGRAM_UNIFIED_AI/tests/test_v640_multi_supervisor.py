from pathlib import Path


def _read(name: str) -> str:
    return Path(name).read_text(encoding="utf-8")


def test_one_token_multi_supervisor_architecture_present():
    owners = _read("app/services/owners.py")
    models = _read("app/models.py")
    accounts = _read("app/services/accounts.py")
    scanner = _read("app/services/scanner.py")
    assert "PRIMARY_OWNER_KEY" in owners
    assert "SUPERVISOR_IDS_KEY" in owners
    assert "add_supervisor" in owners
    assert "operator_id" in models
    assert "_account_filter_for_operator" in accounts
    assert "account_items_for_operator" in scanner


def test_general_collection_buttons_removed_but_category_choices_remain():
    keyboards = _read("app/keyboards.py")
    main_menu = keyboards[keyboards.index("def main_menu") : keyboards.index("def back_menu")]
    assert 'callback_data="collect:accounts"' not in main_menu
    assert 'callback_data="collect:sources"' not in main_menu
    assert 'callback_data="collect:category"' in main_menu
    assert "category_origin:accounts" in keyboards
    assert "category_origin:sources" in keyboards


def test_primary_only_link_exports_and_search():
    bot = _read("app/bot.py")
    for callback in ["database:export_txt", "database:export_zip", "search:start", "audit:export_txt:"]:
        assert callback in bot
    assert bot.count("reject_non_primary") >= 10


def test_incremental_continuation_and_join_floor_present():
    bot = _read("app/bot.py")
    joiner = _read("app/services/joiner.py")
    assert "continue_completed_job" in bot
    assert "delete(JobCursor)" in bot
    assert 'job.scope = "new"' in bot
    assert "delay_seconds = max(180" in joiner
    assert "FloodWait" in joiner
    assert "per_account_limit != 200" in joiner
    assert "JoinAssignment" in joiner


def test_database_export_defaults_to_one_file_per_category():
    exporter = _read("app/services/exporter.py")
    assert 'writer = _StreamWriter("قاعدة_الروابط_الكاملة", chunk_size)' in exporter
    assert "chunk_size=None" in exporter


def test_operator_scoped_incremental_checkpoints_with_legacy_owner_fallback():
    scanner = _read("app/services/scanner.py")
    assert 'return f"operator:{int(operator_id)}:{base}"' in scanner
    assert "fallback_key" in scanner
    assert "legacy_checkpoint_fallback = await is_primary_owner(int(job.requested_by))" in scanner
    assert '_checkpoint_key("dialog", dialog_key, job.category, int(job.requested_by))' in scanner
    assert '_checkpoint_key("source", source, target_category, int(job.requested_by))' in scanner


def test_parallel_workers_but_one_active_job_per_operator():
    main = _read("app/main.py")
    scanner = _read("app/services/scanner.py")
    config = _read("app/config.py")
    assert "job_workers: int = 8" in config
    assert "worker_tasks" in main
    assert "Job.requested_by == candidate.requested_by" in scanner or "requested_by" in scanner
    assert "aliased(Job)" in scanner
