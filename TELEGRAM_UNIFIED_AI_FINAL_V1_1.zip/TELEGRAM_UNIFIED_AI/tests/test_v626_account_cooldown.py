from __future__ import annotations

from pathlib import Path


def test_v626_has_durable_account_method_cooldown() -> None:
    auditor = Path("app/services/auditor.py").read_text(encoding="utf-8")
    assert "audit_method_cooldown:" in auditor
    assert "_telegram_account_method_cooldown_remaining" in auditor
    assert "_telegram_account_method_cooldown_set" in auditor


def test_v626_skips_resolveusername_api_during_account_cooldown() -> None:
    auditor = Path("app/services/auditor.py").read_text(encoding="utf-8")
    assert "ResolveUsername account cooldown" in auditor
    assert "API request skipped" in auditor
    assert "telegram_account_resolve_cooldown_skips" in auditor


def test_v626_resume_inherits_v625_deferred_deadline() -> None:
    auditor = Path("app/services/auditor.py").read_text(encoding="utf-8")
    assert "Inherited ResolveUsername account cooldown from discovery cursor" in auditor
    assert 'data.get("defer_method")' in auditor


def test_v626_invite_path_remains_separate() -> None:
    auditor = Path("app/services/auditor.py").read_text(encoding="utf-8")
    assert "invite_check_cooldowns" in auditor
    assert '"ResolveUsername"' in auditor
    assert "CheckChatInviteRequest" in auditor
