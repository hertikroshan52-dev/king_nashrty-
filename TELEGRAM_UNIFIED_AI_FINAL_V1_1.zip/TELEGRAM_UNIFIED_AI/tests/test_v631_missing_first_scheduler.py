from pathlib import Path


def _source() -> str:
    return Path('app/services/auditor.py').read_text(encoding='utf-8')


def test_load_pending_prioritizes_missing_results_before_retries():
    src = _source()
    section = src[src.index('async def load_pending'):src.index('async def unresolved_count')]
    assert 'case((TelegramAuditResult.id.is_(None), 0), else_=1)' in section
    order = section[section.index('.order_by('):section.index('.limit(limit)')]
    assert order.index('case((TelegramAuditResult.id.is_(None), 0), else_=1)') < order.rindex('TelegramAuditInput.id')


def test_retry_rotation_uses_oldest_checked_result():
    src = _source()
    section = src[src.index('async def load_pending'):src.index('async def unresolved_count')]
    assert 'TelegramAuditResult.checked_at.asc().nullsfirst()' in section


def test_sqlalchemy_case_imported():
    src = _source()
    assert 'from sqlalchemy import and_, case, delete, func, or_, select, update' in src
