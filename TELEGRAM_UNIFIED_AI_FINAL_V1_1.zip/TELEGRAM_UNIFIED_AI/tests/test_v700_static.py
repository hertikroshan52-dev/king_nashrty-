from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def test_v7_control_plane_static():
    models=(ROOT/'app/models.py').read_text()
    bot=(ROOT/'app/bot.py').read_text()
    main=(ROOT/'app/main.py').read_text()
    kb=(ROOT/'app/keyboards.py').read_text()
    assert 'class ScheduledTask' in models
    assert 'class Workflow' in models
    assert 'class EntityTag' in models
    assert 'class SystemError' in models
    assert 'session:center' in bot
    assert 'v7_scheduler_loop' in main
    assert 'v7_center_keyboard' in kb
    assert 'تم إيقاف تصدير Session String الخام' in bot
