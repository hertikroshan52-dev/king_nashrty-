from pathlib import Path


def _auditor_source() -> str:
    return Path('app/services/auditor.py').read_text(encoding='utf-8')


def test_plain_valueerror_dead_username_marker_present():
    src = _auditor_source()
    assert "NO USER HAS" in src
    assert "AS USERNAME" in src


def test_process_one_persists_before_discovery_schedule():
    src = _auditor_source()
    section = src[src.index('async def process_one'):src.index('async def load_pending')]
    assert 'Audit link deferred before result save' in section
    assert section.index('await save_result(item, previous, result)') < section.index('await schedule_telegram_discovery(')


def test_historical_dead_username_repair_present():
    src = _auditor_source()
    assert 'V6.3.0 repair-on-run' in src
    assert 'dead_username_pattern' in src
    assert '.values(status="expired", error_class="Permanent", next_retry_at=None)' in src


def test_connection_failure_does_not_consume_retry_budget():
    src = _auditor_source()
    section = src[src.index('async def process_one'):src.index('async def load_pending')]
    assert '"_no_attempt_penalty": True' in section
    assert '"_retry_after_seconds"' in section
