"""Resolve generated callbacks against real aiogram router filters (no RPC)."""
import inspect
from types import SimpleNamespace

import pytest
from aiogram.types import CallbackQuery, User
from app import keyboards
from app.bot import router


@pytest.mark.asyncio
async def test_all_generated_buttons_have_handlers():
    sample = SimpleNamespace(id=1, active=True, enabled=True,label='A',name='W',title='T',status='scheduled',mode='join_groups',audit_id=1,category='audit:1',tag='tag',entity_type='account',entity_key='1',component='test')
    values = dict(accounts=[sample]*12,watches=[sample],jobs=[SimpleNamespace(**{**vars(sample),'status':status}) for status in ['running','queued','paused','completed','failed','cancelled','completed_with_errors']],tasks=[sample],workflows=[sample],tags=[sample],errors=[sample],audits=[sample],supervisor_ids=[1],session_supervisor_ids=[2],verifier_ids={1},account_id=1,job_id=1,join_job_id=1,audit_id=1,active=True,mode='plain',scope='all',pacing='fixed',prefix='scope_accounts')
    callbacks=set()
    for name, fn in inspect.getmembers(keyboards,inspect.isfunction):
        if fn.__module__ != keyboards.__name__: continue
        args={key:values[key] for key,param in inspect.signature(fn).parameters.items() if param.default is inspect.Parameter.empty}
        result=fn(**args)
        for row in result.inline_keyboard:
            for button in row:
                if button.callback_data: callbacks.add(button.callback_data)
    missing=[]
    for data in sorted(callbacks):
        assert 1 <= len(data.encode()) <= 64
        query=CallbackQuery(id='test',from_user=User(id=1,is_bot=False,first_name='Test'),chat_instance='test',data=data)
        matches=[]
        for handler in router.callback_query.handlers:
            ok,_=await handler.check(query)
            if ok: matches.append(handler.callback.__name__)
        if not matches: missing.append(data)
    assert not missing, missing
    print(f'Validated {len(callbacks)} distinct callback payloads')
