from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

from app.services.auditor import (
    _telegram_discovery_deferred_seconds,
    _telegram_discovery_detail,
)


def test_v625_discovery_cursor_persists_deferred_until() -> None:
    now = datetime(2026, 8, 17, 0, 0, 0, tzinfo=timezone.utc)
    detail = _telegram_discovery_detail(
        "https://t.me/example_public",
        7,
        deferred_until=now + timedelta(seconds=14400),
        reason="FloodWait 14398s",
        method="ResolveUsername",
    )
    remaining = _telegram_discovery_deferred_seconds(detail, now=now)
    assert 14399.0 <= remaining <= 14401.0


def test_v625_discovery_resume_uses_peer_cache_before_username_resolution() -> None:
    auditor = Path("app/services/auditor.py").read_text(encoding="utf-8")
    assert "get_input_entity(int(peer_id))" in auditor
    assert "Telegram discovery resumed from cached peer_id=" in auditor


def test_v625_discovery_floodwait_is_deferred_not_scan_error() -> None:
    auditor = Path("app/services/auditor.py").read_text(encoding="utf-8")
    assert 'status="deferred"' in auditor
    assert "deferred_until" in auditor
    assert "not counted as scan error" in auditor
    assert "telegram_floodwait_deferrals" in auditor
