"""Behavioral regression tests: SQLite plus simulated Telegram responses."""
import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from sqlalchemy import select, delete

from app.db import SessionFactory, init_db
from app.models import Account, Job, JoinAssignment, JoinCandidate, utcnow
from app.services import joiner


async def fixture_job(owner, count=3):
    await init_db()
    async with SessionFactory() as db:
        await db.execute(delete(Job).where(Job.requested_by == owner))
        await db.execute(delete(JoinCandidate).where(JoinCandidate.requested_by == owner))
        await db.execute(delete(Account).where(Account.operator_id == owner))
        accounts = [Account(operator_id=owner, label=f'A{i}', telegram_user_id=owner*10+i,
                            api_id=1, encrypted_api_hash='x', encrypted_session='x') for i in range(count)]
        db.add_all(accounts)
        await db.flush()
        job = Job(requested_by=owner, mode='join_groups', status='running', sources=['https://t.me/source810'], progress={'join_per_account':200,'join_distribution_mode':'fixed','join_target_kind':'all','join_delay_seconds':180})
        db.add(job)
        await db.commit()
        return job, accounts


async def add_rows(job, account, count, status='ready_group', start=0):
    async with SessionFactory() as db:
        for i in range(start, start+count):
            candidate=JoinCandidate(requested_by=job.requested_by, original_url=f'https://t.me/group{i}', normalized_url=f'https://t.me/group{i}', source_url=job.sources[0],status=status)
            db.add(candidate)
            await db.flush()
            db.add(JoinAssignment(job_id=job.id,requested_by=job.requested_by,candidate_id=candidate.id,account_id=account.id,status=status,peer_id=-(i+1),attempts=1))
        await db.commit()


@pytest.mark.asyncio
async def test_stable_450_group_blocks():
    job, accounts=await fixture_job(881001)
    await add_rows(job, accounts[0],450)
    assert await joiner._allocate_group_blocks(job,[a.id for a in accounts],200)=={a.id for a in accounts}
    async with SessionFactory() as db:
        rows=list((await db.scalars(select(JoinAssignment).where(JoinAssignment.job_id==job.id).order_by(JoinAssignment.candidate_id))).all())
    assert [r.account_id for r in rows]==[accounts[0].id]*200+[accounts[1].id]*200+[accounts[2].id]*50
    # An account cannot steal another account's first block.
    assignment,_=await joiner._claim_allocated(job,accounts[2].id)
    assert assignment.candidate_id==rows[400].candidate_id


@pytest.mark.asyncio
async def test_reserve_deduplicates_same_peer_and_leaves_extra_accounts_empty():
    job, accounts=await fixture_job(881002)
    await add_rows(job,accounts[0],3)
    async with SessionFactory() as db:
        rows=list((await db.scalars(select(JoinAssignment).where(JoinAssignment.job_id==job.id).order_by(JoinAssignment.id))).all())
        rows[1].peer_id=rows[0].peer_id
        await db.commit()
    assert await joiner._allocate_group_blocks(job,[a.id for a in accounts],200)=={accounts[0].id}
    async with SessionFactory() as db:
        assert (await db.get(JoinAssignment,rows[1].id)).status=='duplicate'


@pytest.mark.asyncio
async def test_resume_updates_candidate_and_assignment_together():
    job,accounts=await fixture_job(881003,1)
    await add_rows(job,accounts[0],1,'joining')
    await joiner._prepare_join_resume(job)
    async with SessionFactory() as db:
        a=await db.scalar(select(JoinAssignment).where(JoinAssignment.job_id==job.id))
        c=await db.get(JoinCandidate,a.candidate_id)
        assert a.status==c.status=='retry'
    assert await joiner._claim_candidate(job,accounts[0].id,job.sources[0],asyncio.Lock()) is not None


@pytest.mark.asyncio
async def test_cleanup_excludes_preexisting_and_ambiguous_legacy_membership():
    job,accounts=await fixture_job(881004,1)
    for i,status in enumerate(['joined','already','legacy_joined']):
        await add_rows(job,accounts[0],1,status,start=i)
    assert await joiner.count_leave_targets(job.id)==1


@pytest.mark.asyncio
async def test_fixed_engine_keeps_exact_account_distribution(monkeypatch):
    job,accounts=await fixture_job(881005,2)
    await add_rows(job,accounts[0],2,'allocated')
    await add_rows(job,accounts[1],1,'allocated',start=1000)
    manager=SimpleNamespace(account_records={a.id:a for a in accounts})
    monkeypatch.setattr(joiner,'account_items_for_operator',AsyncMock(return_value=[(a.id,a.id) for a in accounts]))
    manager.ensure_connected=AsyncMock(side_effect=lambda aid:aid)
    monkeypatch.setattr(joiner,'_send_assignment_backup_to_saved_messages',AsyncMock(side_effect=[(2,None),(1,None)]))
    monkeypatch.setattr(joiner,'_responsive_sleep',AsyncMock())
    async def inspect(client,url):
        return joiner.TargetInspection('channel' if url.endswith('group1') else 'group',peer_id=-abs(hash(url))%100000)
    class InviteRequestSentError(Exception): pass
    async def join(client,url,inspection):
        if url.endswith('group0'):
            raise InviteRequestSentError()
        return None
    monkeypatch.setattr(joiner,'_inspect_join_target',inspect)
    monkeypatch.setattr(joiner,'_join_group',join)
    monkeypatch.setattr(joiner,'_verify_membership',AsyncMock(return_value=True))
    result=await joiner.process_join_groups_job(job,manager)
    assert result['join_assigned']==3
    assert result['join_requested']==1
    assert result['join_joined']==2
    report=list(result['account_report'].values())
    assert [r['assigned'] for r in report]==[2,1]
    # A failure/request never steals a link reserved for the other account.
    async with SessionFactory() as db:
        rows=list((await db.scalars(select(JoinAssignment).where(JoinAssignment.job_id==job.id).order_by(JoinAssignment.id))).all())
    assert [r.account_id for r in rows]==[accounts[0].id,accounts[0].id,accounts[1].id]


@pytest.mark.asyncio
async def test_expired_invite_does_not_prove_left():
    class InviteHashExpiredError(Exception): pass
    client=AsyncMock(side_effect=InviteHashExpiredError())
    with pytest.raises(InviteHashExpiredError):
        await joiner._resolve_joined_entity(client,'https://t.me/+deadInvite')


@pytest.mark.asyncio
async def test_verifier_roles_are_scoped():
    from app.services.audit_roles import set_verifier_account_ids,get_verifier_account_ids
    await init_db()
    await set_verifier_account_ids({1},1001)
    await set_verifier_account_ids({2},1002)
    assert await get_verifier_account_ids(1001)=={1}
    assert await get_verifier_account_ids(1002)=={2}


def test_opaque_invite_hashes_are_not_phone_numbers():
    from app.link_utils import inspect_collection_link, normalize_url
    for url in ['https://t.me/+12345678Ab_c','https://t.me/joinchat/1234-5678-90AB','https://chat.whatsapp.com/1234-5678-90AB']:
        assert inspect_collection_link(url).link is not None
    assert normalize_url('https://www.t.me/ExampleName')=='https://t.me/examplename'


@pytest.mark.asyncio
async def test_long_report_is_split():
    from app.main import _send_long_text
    bot=SimpleNamespace(send_message=AsyncMock())
    text='\n'.join(f'حساب {i} '+('س'*70) for i in range(100))
    await _send_long_text(bot,1,text)
    chunks=[call.args[1] for call in bot.send_message.await_args_list]
    assert len(chunks)>1 and all(len(c)<=3500 for c in chunks)
    assert '\n'.join(chunks)==text


@pytest.mark.asyncio
async def test_export_join_sections_and_owner_guard():
    import zipfile
    from app.services.join_export import export_join_job
    job,accounts=await fixture_job(881007,1)
    await add_rows(job,accounts[0],1,'joined')
    await add_rows(job,accounts[0],1,'channel',start=1)
    with pytest.raises(ValueError):
        await export_join_job(job.id,881008)
    path=await export_join_job(job.id,job.requested_by)
    with zipfile.ZipFile(path) as z:
        names=set(z.namelist())
        assert {'accounts_and_links.csv','joined.txt','channel.txt','README.txt',f'account_{accounts[0].id}_links.txt'} <= names
        assert z.read('channel.txt').decode().strip()=='https://t.me/group1'


def test_restore_sqlite_snapshot_with_wal(tmp_path):
    import sqlite3
    from app.services.backup import _backup_sync,_restore_sync
    db=tmp_path/'live.db'; backup=tmp_path/'copy.db'
    with sqlite3.connect(db) as connection:
        connection.execute('PRAGMA journal_mode=WAL')
        connection.execute('CREATE TABLE sample(value INTEGER)')
        connection.execute('INSERT INTO sample VALUES(1)')
        connection.commit()
        _backup_sync(db,backup)
        connection.execute('UPDATE sample SET value=2')
        connection.commit()
        _restore_sync(backup,db)
        assert connection.execute('SELECT value FROM sample').fetchone()==(1,)


@pytest.mark.asyncio
async def test_membership_index_detects_two_accounts_in_same_group():
    from app.services.auditor import _build_membership_index
    from telethon.tl.types import Chat
    job,accounts=await fixture_job(881009,2)
    entity=Chat(id=998877,title='Shared',photo=None,participants_count=2,date=utcnow(),version=1)
    class Client:
        async def iter_dialogs(self):
            yield SimpleNamespace(entity=entity,name='Shared',is_group=True,is_channel=False)
    clients={a.id:Client() for a in accounts}
    manager=SimpleNamespace(clients=clients,account_records={a.id:a for a in accounts},ensure_connected=AsyncMock(side_effect=lambda aid:clients[aid]))
    index,stats=await _build_membership_index(manager,job.id,set(clients),force_refresh=True)
    assert index[-998877].account_ids==set(clients)
    assert len(stats)==2


@pytest.mark.asyncio
async def test_hundred_accounts_only_first_three_receive_401_groups():
    job,accounts=await fixture_job(881010,100)
    await add_rows(job,accounts[0],401)
    assert await joiner._allocate_group_blocks(job,[a.id for a in accounts],200)=={a.id for a in accounts[:3]}
    async with SessionFactory() as db:
        rows=list((await db.scalars(select(JoinAssignment).where(JoinAssignment.job_id==job.id))).all())
    counts=[sum(r.account_id==a.id for r in rows) for a in accounts]
    assert counts==[200,200,1]+[0]*97
