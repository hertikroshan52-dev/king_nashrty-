"""Offline, no network or Telegram credentials, for the opt-in folder operation."""
from __future__ import annotations
import importlib.util
import os
from pathlib import Path
import sys
import types
import asyncio


def _module_under_test(monkeypatch):
    telethon = types.ModuleType('telethon')
    telethon.utils = types.ModuleType('telethon.utils')
    telethon.utils.get_input_peer = lambda chat: ('input', chat.id)
    errors = types.ModuleType('telethon.errors')
    errors.FloodWaitError = type('FloodWaitError', (Exception,), {})
    tl = types.ModuleType('telethon.tl')
    funcs = types.ModuleType('telethon.tl.functions')
    types_mod = types.ModuleType('telethon.tl.types')
    for cname in ('CheckChatlistInviteRequest','JoinChatlistInviteRequest','LeaveChatlistRequest'):
        setattr(funcs, cname, None)
    class CheckChatlistInviteRequest:
        def __init__(self, slug): self.slug = slug
    class JoinChatlistInviteRequest:
        def __init__(self, slug, peers): self.slug,self.peers = slug,peers
    class LeaveChatlistRequest:
        def __init__(self, chatlist, peers): self.chatlist,self.peers = chatlist,peers
    class GetDialogFiltersRequest: pass
    class InputChatlistDialogFilter:
        def __init__(self, filter_id): self.filter_id = filter_id
    funcs.chatlists = types.SimpleNamespace(CheckChatlistInviteRequest=CheckChatlistInviteRequest,
        JoinChatlistInviteRequest=JoinChatlistInviteRequest,
        LeaveChatlistRequest=LeaveChatlistRequest)
    funcs.messages = types.SimpleNamespace(GetDialogFiltersRequest=GetDialogFiltersRequest)
    types_mod.InputChatlistDialogFilter = InputChatlistDialogFilter
    for name,module in [('telethon',telethon),('telethon.utils',telethon.utils),('telethon.errors',errors),('telethon.tl',tl),('telethon.tl.functions',funcs),('telethon.tl.types',types_mod)]:
        monkeypatch.setitem(sys.modules, name, module)
    tl.functions,tl.types = funcs,types_mod
    src = Path(__file__).resolve().parents[1] / 'legacy_publisher' / 'folder_import.py'
    spec = importlib.util.spec_from_file_location('_safe_folder_import_test', src)
    module = importlib.util.module_from_spec(spec)
    monkeypatch.setitem(sys.modules,spec.name,module)
    spec.loader.exec_module(module)
    return module, CheckChatlistInviteRequest, JoinChatlistInviteRequest, LeaveChatlistRequest, GetDialogFiltersRequest


def test_slug_validation(monkeypatch):
    m,*_= _module_under_test(monkeypatch)
    assert m.folder_slug('https://t.me/addlist/abcD_1') == 'abcD_1'
    for bad in ('https://evil.example/addlist/abcD_1', 'https://t.me/other/abcD_1','https://t.me/addlist/xx'):
        try: m.folder_slug(bad)
        except ValueError: pass
        else: assert False, 'invalid link accepted'


def test_import_removes_folder_without_leaving_groups(monkeypatch):
    m,Check,Join,Leave,Filters = _module_under_test(monkeypatch)
    class PeerChannel:
        channel_id=42
    class Channel:
        id=42
        access_hash=123
        left=True
    class Invite:
        title='Folder ABC'
        chats=[Channel()]
        peers=[PeerChannel()]
    class DialogFilterChatlist:
        def __init__(self, id):self.id=id
    class FakeClient:
        def __init__(self):
            self.operations=[]
            self.did_join=False
        async def __call__(self, req):
            self.operations.append(req)
            if isinstance(req,Check): return Invite()
            if isinstance(req,Filters):
                return types.SimpleNamespace(filters=[DialogFilterChatlist(3)] + ([DialogFilterChatlist(10)] if self.did_join else []))
            if isinstance(req,Join):self.did_join=True;return True
            if isinstance(req,Leave):return True
            raise AssertionError(type(req))
    client=FakeClient()
    async def test():
        preview=await m.preview_folder(client,'https://t.me/addlist/abcdef')
        assert preview.available_count==1
        result=await m.import_and_preserve(client,'https://t.me/addlist/abcdef',preview)
        return result
    result=asyncio.run(test())
    assert result['status']=='folder_removed_chats_preserved'
    leave=[r for r in client.operations if isinstance(r,Leave)]
    assert len(leave)==1
    assert leave[0].peers == []
    assert leave[0].chatlist.filter_id==10


def test_ambiguous_folder_id_never_deletes(monkeypatch):
    m,Check,Join,Leave,Filters = _module_under_test(monkeypatch)
    class PeerChannel:channel_id=42
    class Channel:id=42;access_hash=1
    class Invite: chats=[Channel()];peers=[PeerChannel()];title='x'
    class DialogFilterChatlist:
        def __init__(self,id):self.id=id
    class FakeClient:
        def __init__(self): self.ops=[];self.joined=False
        async def __call__(self,req):
            self.ops.append(req)
            if isinstance(req,Check): return Invite()
            if isinstance(req,Filters):
                # Simulate concurrent newly-created filters; ID cannot be trusted.
                return types.SimpleNamespace(filters=[DialogFilterChatlist(1)] + ([DialogFilterChatlist(5),DialogFilterChatlist(6)] if self.joined else []))
            if isinstance(req,Join): self.joined=True
            if isinstance(req,Leave):raise AssertionError('must not delete when ambiguous')
    c=FakeClient()
    async def run():
        prev=await m.preview_folder(c,'https://t.me/addlist/abcdef')
        return await m.import_and_preserve(c,'https://t.me/addlist/abcdef',prev)
    result=asyncio.run(run())
    assert result['status']=='imported_keep_folder'
    assert not [r for r in c.ops if isinstance(r,Leave)]
