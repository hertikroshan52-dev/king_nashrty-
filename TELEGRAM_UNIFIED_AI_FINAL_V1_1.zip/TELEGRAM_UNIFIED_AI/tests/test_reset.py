from __future__ import annotations

import pytest
from sqlalchemy import delete, func, select

from app.db import SessionFactory, init_db
from app.models import Account, AccountMembership, AppSetting, Delivery, DestinationConfig, Job, JobCursor, JobLink, Link, WatchConfig, TelegramAudit, TelegramAuditInput, TelegramAuditResult, TelegramAuditTelegramDiscovery
from app.runtime import live_handlers_suspended, reset_in_progress
from app.services.resetter import reset_collected_data


async def _clean_all() -> None:
    async with SessionFactory() as session:
        for model in (TelegramAuditTelegramDiscovery, TelegramAuditResult, TelegramAuditInput, TelegramAudit, Delivery, JobCursor, JobLink, WatchConfig, Link, Job, AccountMembership, DestinationConfig, Account, AppSetting):
            await session.execute(delete(model))
        await session.commit()


@pytest.mark.asyncio
async def test_clear_links_keeps_accounts_and_destinations() -> None:
    await init_db()
    await _clean_all()
    async with SessionFactory() as session:
        session.add(Account(
            label="test",
            telegram_user_id=1001,
            api_id=1,
            encrypted_api_hash="x",
            encrypted_session="y",
            active=True,
        ))
        session.add(DestinationConfig(owner_id=1, destinations={"telegram": -1001}))
        job = Job(requested_by=1, mode="sources", status="completed")
        session.add(job)
        await session.flush()
        session.add(Link(
            original_url="https://t.me/test_channel",
            normalized_url="https://t.me/test_channel",
            url_hash="a" * 64,
            category="telegram",
            origin="seed",
            first_job_id=job.id,
        ))
        await session.commit()

    result = await reset_collected_data(factory=False)
    assert result.links == 1
    assert reset_in_progress.is_set() is False
    assert live_handlers_suspended.is_set() is True
    async with SessionFactory() as session:
        assert int(await session.scalar(select(func.count(Link.id))) or 0) == 0
        assert int(await session.scalar(select(func.count(Job.id))) or 0) == 0
        assert int(await session.scalar(select(func.count(Account.id))) or 0) == 1
        assert int(await session.scalar(select(func.count(DestinationConfig.owner_id))) or 0) == 1
    live_handlers_suspended.clear()


@pytest.mark.asyncio
async def test_factory_reset_preserves_accounts_and_owner_settings() -> None:
    await init_db()
    await _clean_all()
    async with SessionFactory() as session:
        session.add(Account(
            label="test",
            telegram_user_id=1002,
            api_id=1,
            encrypted_api_hash="x",
            encrypted_session="y",
            active=True,
        ))
        session.add(DestinationConfig(owner_id=2, destinations={"telegram": -1002}))
        session.add(AppSetting(key="owner_ids", value=[2]))
        await session.commit()

    await reset_collected_data(factory=True)
    assert reset_in_progress.is_set() is False
    async with SessionFactory() as session:
        assert int(await session.scalar(select(func.count(Account.id))) or 0) == 1
        assert int(await session.scalar(select(func.count(DestinationConfig.owner_id))) or 0) == 0
        assert int(await session.scalar(select(func.count(AppSetting.key))) or 0) == 1
    live_handlers_suspended.clear()
