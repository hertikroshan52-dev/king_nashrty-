import pytest
from sqlalchemy import delete, func, select

from app.db import SessionFactory, init_db
from app.models import Account, Job, JoinAssignment, JoinCandidate, TelegramAudit, TelegramAuditInput, TelegramAuditResult
from app.services.join_planner import stage_join_job


@pytest.mark.asyncio
async def test_v820_planner_distributes_200_200_remainder_without_overlap():
    await init_db()
    owner = 8820001
    async with SessionFactory() as db:
        await db.execute(delete(Job).where(Job.requested_by == owner))
        await db.execute(delete(JoinCandidate).where(JoinCandidate.requested_by == owner))
        await db.execute(delete(Account).where(Account.operator_id == owner))
        audit = TelegramAudit(requested_by=owner, source_type="database", status="completed", total_inputs=450, checked_inputs=450)
        db.add(audit)
        db.add_all([
            Account(operator_id=owner, label=f"A{i}", telegram_user_id=8821000+i, api_id=1, encrypted_api_hash="x", encrypted_session="x")
            for i in range(3)
        ])
        await db.flush()
        for i in range(450):
            inp = TelegramAuditInput(audit_id=audit.id, original_url=f"https://t.me/v820group{i}", normalized_url=f"https://t.me/v820group{i}")
            db.add(inp); await db.flush()
            db.add(TelegramAuditResult(
                audit_id=audit.id, input_id=inp.id, normalized_url=f"https://t.me/v820group{i}",
                status="unjoined", peer_id=-(900000+i), peer_type="group", title=f"G{i}",
            ))
        await db.commit()
        audit_id = audit.id

    job = await stage_join_job(owner, audit_id=audit_id, source_kind="groups", per_account=200)
    async with SessionFactory() as db:
        rows = list((await db.scalars(select(JoinAssignment).where(JoinAssignment.job_id == job.id).order_by(JoinAssignment.id))).all())
    account_ids = []
    for row in rows:
        if row.account_id not in account_ids:
            account_ids.append(row.account_id)
    counts = [sum(r.account_id == aid for r in rows) for aid in account_ids]
    assert counts == [200, 200, 50]
    assert len({r.candidate_id for r in rows}) == 450
    assert all(r.status == "allocated" for r in rows)


@pytest.mark.asyncio
async def test_v820_planner_accepts_500_and_excludes_non_ready_results():
    await init_db()
    owner = 8820002
    async with SessionFactory() as db:
        await db.execute(delete(Job).where(Job.requested_by == owner))
        await db.execute(delete(JoinCandidate).where(JoinCandidate.requested_by == owner))
        await db.execute(delete(Account).where(Account.operator_id == owner))
        account = Account(operator_id=owner, label="A", telegram_user_id=8822001, api_id=1, encrypted_api_hash="x", encrypted_session="x")
        audit = TelegramAudit(requested_by=owner, source_type="database", status="completed", total_inputs=3, checked_inputs=3)
        db.add_all([account, audit]); await db.flush()
        for i, status in enumerate(["unjoined", "join_request", "joined_unique"]):
            inp = TelegramAuditInput(audit_id=audit.id, original_url=f"https://t.me/v820ready{i}", normalized_url=f"https://t.me/v820ready{i}")
            db.add(inp); await db.flush()
            db.add(TelegramAuditResult(
                audit_id=audit.id, input_id=inp.id, normalized_url=f"https://t.me/v820ready{i}",
                status=status, peer_id=-(910000+i), peer_type="channel", title=f"C{i}",
            ))
        await db.commit(); audit_id=audit.id
    job = await stage_join_job(owner, audit_id=audit_id, source_kind="channels", per_account=500)
    async with SessionFactory() as db:
        count = int(await db.scalar(select(func.count(JoinAssignment.id)).where(JoinAssignment.job_id == job.id)) or 0)
    assert count == 2
    assert job.progress["join_per_account"] == 500
