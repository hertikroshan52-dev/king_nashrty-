from pathlib import Path


def test_v640_compact_export_contract_is_present():
    text = Path("app/services/auditor.py").read_text(encoding="utf-8")
    assert "V6.4 export contract" in text
    assert "raw_chunk_size if raw_chunk_size in {200, 1000} else 0" in text
    for section in [
        "01_قنوات_Telegram_مشتركون",
        "02_مجموعات_Telegram_اعضاء",
        "03_روابط_Telegram_الجديدة",
        "04_روابط_واتساب",
        "05_روابط_تحتاج_انضمام_او_طلب_انضمام",
        "06_اخطاء_نهائية",
        "07_اخطاء_مؤقتة",
        "08_روابط_منتهية",
        "09_مجموعات_البامبات_والاكتتابات",
    ]:
        assert section in text


def test_v640_group_channel_separation_remains_strict():
    text = Path("app/services/auditor.py").read_text(encoding="utf-8")
    body = text[text.index("async def export_audit("):]
    assert 'if bucket == "channels"' in body
    assert 'elif bucket == "groups"' in body
    assert 'elif bucket == "groups_join_required"' in body
    assert "_strict_requested_export_bucket(row)" in body


def test_v640_per_section_optional_splitting_is_exposed():
    keyboard = Path("app/keyboards.py").read_text(encoding="utf-8")
    bot = Path("app/bot.py").read_text(encoding="utf-8")
    assert "audit:export_section:" in keyboard
    assert "audit:export_section:" in bot
    assert "200" in keyboard and "1000" in keyboard
