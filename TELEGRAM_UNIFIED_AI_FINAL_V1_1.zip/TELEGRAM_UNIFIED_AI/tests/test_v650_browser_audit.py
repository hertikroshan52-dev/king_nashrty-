from pathlib import Path

from app.services.web_preview import classify_tme_html


def test_web_preview_classifies_subscribers_members_bot_and_personal():
    channel = classify_tme_html(
        "https://t.me/NewsExample",
        '<meta property="og:title" content="News"><div>125,000 subscribers</div>',
    )
    group = classify_tme_html(
        "https://t.me/GroupExample",
        '<meta property="og:title" content="Group"><div>4,200 members</div>',
    )
    bot = classify_tme_html(
        "https://t.me/HelperBot",
        '<meta property="og:title" content="Helper"><a>Start Bot</a><div>10K monthly users</div>',
    )
    personal = classify_tme_html(
        "https://t.me/PersonName",
        '<meta property="og:title" content="Ali"><a>Send Message</a><div>If you have Telegram, you can contact @PersonName right away.</div>',
    )
    assert (channel.status, channel.peer_type) == ("web_visible", "channel")
    assert (group.status, group.peer_type) == ("web_visible", "group")
    assert bot.status == "bot" and bot.peer_type == "bot"
    assert personal.status == "personal" and personal.peer_type == "user"


def test_generic_invite_and_public_ambiguity_need_account_confirmation():
    body = '<meta property="og:title" content="Telegram: Join Group Chat"><div>You are invited to a group chat on Telegram. Click to join:</div><a>Join Group</a>'
    invite = classify_tme_html("https://t.me/+AbCdEf12345", body)
    public = classify_tme_html("https://t.me/UnknownPublic", body)
    assert invite.status == "requires_account"
    assert invite.detail == "web_generic_invite_requires_account_confirmation"
    assert public.status == "requires_account"


def test_v650_surface_and_high_water_are_wired():
    keyboards = Path("app/keyboards.py").read_text(encoding="utf-8")
    bot = Path("app/bot.py").read_text(encoding="utf-8")
    auditor = Path("app/services/auditor.py").read_text(encoding="utf-8")
    scanner = Path("app/services/scanner.py").read_text(encoding="utf-8")
    assert "session:center" in keyboards  # V8.1 directs to the working session manager
    assert "audit:engine:web" in keyboards and "audit:engine:accounts" in keyboards
    assert "audit:web_to_accounts:" in bot
    assert "database_high_water_link_id" in auditor
    assert "account_report" in scanner
    assert "12_روابط_تحتاج_حسابات_لمعرفة_المعلومات" in auditor


def test_web_preview_invite_counts_and_pump_marker():
    invite_group = classify_tme_html(
        "https://t.me/+InviteHash123",
        '<meta property="og:title" content="Crypto Investment Club"><meta property="og:description" content="IPO and investment group"><div>8,750 members</div><a>Join Group</a>',
    )
    invite_channel = classify_tme_html(
        "https://t.me/+ChannelHash123",
        '<meta property="og:title" content="Market News"><div>95K subscribers</div><a>Join Channel</a>',
    )
    assert (invite_group.status, invite_group.peer_type) == ("web_visible", "group")
    assert "pump_ipo_match" in (invite_group.detail or "")
    assert (invite_channel.status, invite_channel.peer_type) == ("web_visible", "channel")
