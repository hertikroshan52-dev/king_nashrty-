from pathlib import Path

AUDITOR = Path('app/services/auditor.py').read_text(encoding='utf-8')


def test_v629_resume_aggregates_account_cooldowns():
    assert 'inherited_by_account: dict[int, float]' in AUDITOR
    assert 'Inherited ResolveUsername account cooldown from discovery cursor aggregate' in AUDITOR
    assert 'max(' in AUDITOR


def test_v629_resume_has_live_progress_heartbeat():
    assert 'current_phase"] = "resuming_discovery_cursors"' in AUDITOR
    assert 'await _set_job_progress(job.id, dict(counters))' in AUDITOR
    assert 'index % 500 == 0' in AUDITOR


def test_v629_bounds_ready_discovery_tasks():
    assert 'tg_schedule_budget = max(1, int(settings.audit_telegram_workers))' in AUDITOR
    assert 'if tg_scheduled >= tg_schedule_budget:' in AUDITOR
    assert 'telegram_active_scan_keys' in AUDITOR
    assert 'release_scan_key' in AUDITOR
