from pathlib import Path

import pytest
from sqlalchemy import delete, func, select

from app.db import SessionFactory, init_db
from app.link_utils import clean_link
from app.models import Job, JobLink, Link
from app.services.repository import register_link


@pytest.mark.asyncio
async def test_global_deduplication() -> None:
    await init_db()
    async with SessionFactory() as session:
        await session.execute(delete(JobLink))
        await session.execute(delete(Link))
        await session.execute(delete(Job))
        job = Job(requested_by=1, mode="sources", status="queued")
        session.add(job)
        await session.commit()
        await session.refresh(job)

    link = clean_link("https://t.me/example_channel")
    assert link is not None
    first = await register_link(
        link,
        origin="seed",
        job_id=job.id,
        account_id=None,
        chat_id=None,
        message_id=None,
        message_date=None,
    )
    second = await register_link(
        link,
        origin="account",
        job_id=None,
        account_id=None,
        chat_id=None,
        message_id=None,
        message_date=None,
    )
    assert first.created is True
    assert second.created is False
    async with SessionFactory() as session:
        assert int(await session.scalar(select(func.count(Link.id))) or 0) == 1
