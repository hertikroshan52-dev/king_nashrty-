from __future__ import annotations

from app.services.auditor import (
    _telegram_dedup_key,
    extract_telegram_urls_from_text,
    format_account_report,
    format_audit_summary,
)


def test_extract_telegram_urls_only_and_deduplicates() -> None:
    text = """
    https://t.me/example_group
    https://t.me/example_group
    https://example.com/page
    https://t.me/+InviteHashABC
    https://t.me/example_group/123
    """
    values = extract_telegram_urls_from_text(text)
    assert values == ["https://t.me/example_group", "https://t.me/+InviteHashABC"]


def test_audit_summary_contains_requested_buckets() -> None:
    text = format_audit_summary({
        "audit_id": 7,
        "status": "completed",
        "checked": 20,
        "total": 20,
        "joined_unique": 7,
        "expired": 3,
        "personal": 2,
        "bot": 1,
        "unjoined": 5,
        "join_request": 2,
        "unsupported": 0,
        "error": 0,
        "account_group_size": 10,
        "links_per_account_cycle": 4,
        "group_rest_seconds": 120,
    })
    assert "روابط منتهية/غير صالحة: 3" in text
    assert "روابط شخصية: 2" in text
    assert "روابط صالحة وغير منضم لها: 5" in text
    assert "روابط تحتاج طلب انضمام: 2" in text


def test_audit_summary_shows_fixed_v6_schedule() -> None:
    text = format_audit_summary({
        "audit_id": 1,
        "status": "running",
        "checked": 40,
        "total": 100,
        "account_group_size": 10,
        "links_per_account_cycle": 4,
        "group_rest_seconds": 120,
        "account_groups": 2,
        "waves_completed": 1,
    })
    assert "كل مجموعة حسابات: 10 حسابات" in text
    assert "كل حساب يفحص في الدورة: 4 روابط مختلفة بالتوازي" in text
    assert "الراحة بين الدورات: 120 ثانية" in text


def test_account_report_shows_v6_checked_workload() -> None:
    text = format_account_report({
        "account_group_size": 10,
        "links_per_account_cycle": 4,
        "account_report": {
            "1": {"label": "A1", "role": "audit", "checked_in_run": 12},
        },
    })
    assert "كل 10 حسابات تشكل مجموعة فحص" in text
    assert "حتى 4 روابط مختلفة" in text
    assert "تم فحص 12 رابط" in text


def test_audit_summary_contains_title() -> None:
    text = format_audit_summary({
        "audit_id": 9,
        "title": "القسم الثالث - روابط اليمن",
        "status": "running",
        "checked": 1,
        "total": 10,
    })
    assert "القسم الثالث - روابط اليمن" in text


def test_telegram_discovery_dedup_identity() -> None:
    assert _telegram_dedup_key("https://t.me/TestChannel") == _telegram_dedup_key("https://t.me/testchannel")
    assert _telegram_dedup_key("https://t.me/+AbCd123") == _telegram_dedup_key("https://t.me/joinchat/AbCd123")
    assert _telegram_dedup_key("https://t.me/+AbCd123") != _telegram_dedup_key("https://t.me/+abcd123")


def test_audit_summary_separates_channels_groups_and_discovery() -> None:
    text = format_audit_summary({
        "audit_id": 11,
        "status": "completed",
        "checked": 9,
        "total": 9,
        "telegram_channels": 4,
        "telegram_groups": 5,
        "telegram_discovered_links": 7,
        "telegram_duplicates_skipped": 3,
        "telegram_chats_scanned": 2,
        "telegram_chats_unavailable": 0,
        "telegram_scan_errors": 0,
        "options": {"collect_telegram": True},
    })
    assert "قنوات Telegram (مشتركون): 4" in text
    assert "مجموعات Telegram (أعضاء): 5" in text
    assert "روابط Telegram الجديدة المضافة لقاعدة الروابط: 7" in text
    assert "الموجودة مسبقًا والمتجاوزة: 3" in text
