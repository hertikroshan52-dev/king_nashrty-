from pathlib import Path

AUDITOR = Path("app/services/auditor.py").read_text(encoding="utf-8")


def test_pending_audit_retry_uses_live_heartbeat():
    assert 'counters["current_phase"] = "waiting_audit_retry"' in AUDITOR
    assert 'await idle_with_heartbeat(wait_slice)' in AUDITOR
    assert 'next_audit_retry_at' in AUDITOR
    assert 'next_audit_retry_seconds' in AUDITOR


def test_resumed_wave_rest_uses_live_heartbeat():
    assert 'await idle_with_heartbeat(max(0.0, (rest_until_dt - utcnow()).total_seconds()))' in AUDITOR


def test_pending_retry_wait_is_discovery_aware():
    assert 'await telegram_discovery_pending_state()' in AUDITOR
    assert 'wake_candidates.append(float(discovery_wake))' in AUDITOR
