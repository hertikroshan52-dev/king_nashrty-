"""Smoke tests for the unified launcher and its dispatcher bridge."""
from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _text(path):
    return (ROOT / path).read_text(encoding='utf-8')


def test_unified_compiles():
    for rel in ['app/unified_main.py','app/unified_hub.py','legacy_publisher/telegram_ai_pro_main.py']:
        ast.parse(_text(rel), filename=rel)


def test_single_telegram_poller():
    unified = _text('app/unified_main.py')
    hub = _text('app/unified_hub.py')
    assert 'await dp.start_polling(bot, close_bot_session=False)' in unified
    assert 'self.ptb.process_update(translated)' in hub
    assert 'self.ptb.run_polling' not in hub
    assert '.updater.start_polling' not in hub
    assert 'app.unified_main' in _text('botctl.sh')
    assert 'app.unified_main' in _text('start.sh')


def test_both_panels_and_assistants():
    hub = _text('app/unified_hub.py')
    collector_menu = _text('app/keyboards.py')
    pub = _text('legacy_publisher/telegram_ai_pro_main.py')
    assert 'بوت النشر والترتيب' in hub
    assert 'بوت التجميع والتصفية' in hub
    assert 'hub:collector_ai' in collector_menu
    assert 'pro_ai_begin' in pub
    assert 'hub:home' in hub
    assert 'self.states.set(user_id, "home")' in hub
    assert 'OPENAI_API_KEY' in hub
    assert 'OPENAI_API_KEY' in pub


def test_isolated_data_and_authorization():
    entry = _text('app/unified_main.py')
    publisher = _text('legacy_publisher/telegram_ai_pro_main.py')
    assert 'PUBLISHER_DATA_DIR' in publisher and 'PUBLISHER_DB_NAME' in publisher
    assert 'OWNER_ID' in entry and 'ADMIN_IDS' in entry
    assert 'PUBLISHER_DB_NAME' in entry
    assert 'os.umask(0o077)' in entry
    assert 'if not publisher_ok and not collector_ok' in _text('app/unified_hub.py')


def test_legacy_publishing_path_is_present():
    tree = ast.parse(_text('legacy_publisher/telegram_ai_pro_main.py'))
    manager = next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='TelegramBotManager')
    methods={n.name for n in manager.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    assert {'publish_to_groups','start_publishing','stop_publishing','join_groups'} <= methods


def test_no_auto_folder_join_inherited():
    pub = _text('legacy_publisher/telegram_ai_pro_main.py')
    assert 'def pro_folder_menu' in pub
    assert 'def pro_folder_save' in pub
    assert 'هذه قائمة تنظيمية فقط' in pub


def test_ptb_payload_preserves_telegram_unix_dates():
    from datetime import datetime, timezone
    from enum import Enum
    from typing import Any
    tree = ast.parse(_text('app/unified_hub.py'))
    fn = next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='ptb_payload')
    env = {'datetime': datetime, 'Enum':Enum, 'Any':Any}
    exec(compile(ast.Module(body=[fn],type_ignores=[]),'payload-unit','exec'), env)
    original = {'message':{'date':datetime(2026,11,8,tzinfo=timezone.utc),'text':'مرحبا','reply_to_message':None}}
    result = env['ptb_payload'](original)
    assert result == {'message':{'date':1794096000,'text':'مرحبا'}}


def test_hub_state_survives_process_restart(tmp_path):
    import sqlite3
    from contextlib import contextmanager
    tree = ast.parse(_text('app/unified_hub.py'))
    cls = next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='HubStateStore')
    env={'sqlite3':sqlite3,'contextmanager':contextmanager,'Path':Path}
    exec(compile(ast.Module(body=[cls],type_ignores=[]),'hub-state-unit','exec'),env)
    path=tmp_path/'hub.sqlite3'
    state=env['HubStateStore'](path)
    state.set(123,'collector',ai_pending=True)
    after_restart=env['HubStateStore'](path)
    assert after_restart.get(123)==('collector',True)
    after_restart.set(123,'publisher')
    assert state.get(123)==('publisher',False)
