from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def text(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_session_only_role_is_separate():
    owners = text("app/services/owners.py")
    bot = text("app/bot.py")
    keyboards = text("app/keyboards.py")
    assert "SESSION_SUPERVISOR_IDS_KEY" in owners
    assert "add_session_supervisor" in owners
    assert "session_only_menu" in keyboards
    assert "reject_non_session_tool" in bot


def test_direct_session_generator_private_flow():
    bot = text("app/bot.py")
    service = text("app/services/session_extractor.py")
    assert 'F.data == "session:generate"' in bot
    assert "ChatType.PRIVATE" in bot
    assert "send_code_request" in service
    assert "SessionPasswordNeededError" in service
    assert "StringSession" in service


def test_expired_registry_prevents_future_audits():
    auditor = text("app/services/auditor.py")
    registry = text("app/services/expired_registry.py")
    repository = text("app/services/repository.py")
    assert "permanent expired registry" in auditor
    assert "TelegramExpiredLinkBlocklist.identity_key" in auditor
    assert "block_expired_urls" in registry
    assert "blocked=True" in repository


def test_audit_export_keeps_name_with_url():
    auditor = text("app/services/auditor.py")
    assert "_write_named_telegram_record" in auditor
    assert 'handle.write(f"الاسم: {title}' in auditor
    assert 'handle.write(f"الرابط:' in auditor
    assert "named_record_paths" in auditor
    assert "flush_record" in auditor


def test_account_audit_scans_comments():
    auditor = text("app/services/auditor.py")
    config = text("app/config.py")
    assert "reply_to=int(message.id)" in auditor
    assert "audit_scan_discussion_comments" in config
    assert "persist_message_links(comment" in auditor


def test_web_and_deep_performance_defaults():
    config = text("app/config.py")
    assert "web_audit_workers: int = 12" in config
    assert "web_audit_per_host: int = 6" in config
    assert "web_audit_batch_size: int = 250" in config
    assert "collector_db_batch_links: int = 500" in config
    assert "collector_checkpoint_messages: int = 500" in config
