from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _function_source(path: Path, name: str) -> str:
    text = path.read_text(encoding="utf-8")
    tree = ast.parse(text)
    lines = text.splitlines()
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name:
            return "\n".join(lines[node.lineno - 1 : node.end_lineno])
    raise AssertionError(f"function not found: {name}")


def test_discovered_telegram_links_are_collected_not_resolved_recursively() -> None:
    src = _function_source(ROOT / "app/services/auditor.py", "_save_telegram_discovered_links")
    assert "inspect_collection_link" in src
    assert "register_links_batch" in src
    assert "CheckChatInviteRequest" not in src
    assert ".get_entity(" not in src
    assert "ImportChatInviteRequest" not in src
    assert "JoinChannelRequest" not in src


def test_full_history_discovery_has_resume_cursor_and_oldest_to_newest_scan() -> None:
    src = _function_source(ROOT / "app/services/auditor.py", "_save_telegram_discovered_links")
    assert 'iterator_kwargs.update({"reverse": True, "min_id": last_message_id})' in src
    assert "_audit_cursor_save" in src
    assert 'status="completed"' in src


def test_maintenance_db_init_does_not_recover_running_jobs() -> None:
    db = (ROOT / "app/db.py").read_text(encoding="utf-8")
    main = (ROOT / "app/main.py").read_text(encoding="utf-8")
    assert "recover_interrupted: bool = False" in db
    assert "if recover_interrupted:" in db
    assert "init_db(recover_interrupted=True)" in main


def test_safe_upgrade_refuses_unfinished_jobs() -> None:
    script = (ROOT / "scripts/upgrade_instance_v622.sh").read_text(encoding="utf-8")
    assert "REFUSED: this instance still has unfinished jobs" in script
    assert "No files were changed" in script
    assert "queued','starting','running','pause_requested','paused','stopping" in script
