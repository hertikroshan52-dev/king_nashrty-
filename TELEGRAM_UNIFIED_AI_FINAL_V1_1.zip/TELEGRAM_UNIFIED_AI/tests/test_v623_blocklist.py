from __future__ import annotations

import pytest
from sqlalchemy import delete, select

from app.db import SessionFactory, init_db
from app.link_utils import inspect_collection_link, telegram_identity_key
from app.models import Link, TelegramExpiredLinkBlocklist
from app.services.repository import BatchLinkSource, register_links_batch


@pytest.mark.asyncio
async def test_expired_tombstone_blocks_public_alias_recollection() -> None:
    await init_db()
    key = telegram_identity_key("https://t.me/DeadCaseName")
    async with SessionFactory() as session:
        await session.execute(delete(Link).where(Link.normalized_url.in_(["https://t.me/DeadCaseName", "https://t.me/deadcasename"])))
        await session.execute(delete(TelegramExpiredLinkBlocklist).where(TelegramExpiredLinkBlocklist.identity_key == key))
        session.add(TelegramExpiredLinkBlocklist(
            identity_key=key, normalized_url="https://t.me/DeadCaseName", reason="expired"
        ))
        await session.commit()

    clean = inspect_collection_link("https://telegram.me/deadcasename", "telegram").link
    assert clean is not None
    result = (await register_links_batch([BatchLinkSource(clean, 1, -1001, 55, None)], origin="account", job_id=None))[0]
    assert result.blocked is True
    assert result.created is False
    assert result.link is None

    async with SessionFactory() as session:
        assert await session.scalar(select(Link).where(Link.category == "telegram")) is None
        row = await session.scalar(select(TelegramExpiredLinkBlocklist).where(TelegramExpiredLinkBlocklist.identity_key == key))
        assert row is not None and int(row.rediscovered_count) >= 1


def test_invite_aliases_share_one_blocklist_identity() -> None:
    assert telegram_identity_key("https://t.me/+AbCdEf123") == telegram_identity_key("https://t.me/joinchat/AbCdEf123")
