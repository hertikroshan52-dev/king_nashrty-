import asyncio

import pytest
from sqlalchemy import delete

from app.db import SessionFactory, init_db
from app.link_utils import normalize_url
from app.models import Account, Job, JoinAssignment, JoinCandidate
from app.services.joiner import _claim_candidate, _peer_fields
from app.services.web_preview import classify_tme_html


class _Group:
    id = 101
    title = "Members Group"
    megagroup = True
    broadcast = False


class _Channel:
    id = 102
    title = "Broadcast"
    megagroup = False
    broadcast = True


class _Bot:
    id = 103
    title = None
    bot = True


def test_v8_peer_classification_separates_joinable_groups():
    assert _peer_fields(_Group())[0] == "group"
    assert _peer_fields(_Channel())[0] == "channel"
    assert _peer_fields(_Bot())[0] == "bot"


def test_v8_web_not_found_is_not_authoritative_expiration():
    result = classify_tme_html("https://t.me/+ExampleInvite", "page not found", 404)
    assert result.status == "requires_account"
    assert result.error_class == "web_not_found_unconfirmed"


def test_v8_public_username_identity_is_case_insensitive():
    assert normalize_url("https://t.me/ExampleName") == "https://t.me/examplename"
    assert normalize_url("https://t.me/examplename") == "https://t.me/examplename"


def test_v8_assignment_has_task_account_and_cleanup_fields():
    columns = JoinAssignment.__table__.columns
    assert {"job_id", "candidate_id", "account_id", "status", "joined_at", "left_at"} <= set(columns.keys())


@pytest.mark.asyncio
async def test_v8_ready_group_can_move_to_a_new_account():
    await init_db()
    owner = 88000001
    async with SessionFactory() as session:
        await session.execute(delete(Job).where(Job.requested_by == owner))
        await session.execute(delete(JoinCandidate).where(JoinCandidate.requested_by == owner))
        await session.execute(delete(Account).where(Account.operator_id == owner))
        first = Account(
            operator_id=owner, label="A1", telegram_user_id=88000101,
            api_id=1, encrypted_api_hash="x", encrypted_session="x",
        )
        second = Account(
            operator_id=owner, label="A2", telegram_user_id=88000102,
            api_id=1, encrypted_api_hash="x", encrypted_session="x",
        )
        session.add_all([first, second])
        await session.flush()
        job = Job(
            requested_by=owner, mode="join_groups", status="running",
            sources=["https://t.me/source_for_v8_test"], progress={"join_per_account": 200},
        )
        session.add(job)
        await session.flush()
        candidate = JoinCandidate(
            requested_by=owner,
            original_url="https://t.me/example_v8_group",
            normalized_url="https://t.me/example_v8_group",
            source_url="https://t.me/source_for_v8_test",
            status="ready_group",
        )
        session.add(candidate)
        await session.flush()
        session.add(JoinAssignment(
            job_id=job.id, requested_by=owner, candidate_id=candidate.id,
            account_id=first.id, status="ready_group", attempts=3,
        ))
        await session.commit()
        job_id, second_id = int(job.id), int(second.id)

    async with SessionFactory() as session:
        job = await session.get(Job, job_id)
    claimed = await _claim_candidate(
        job, second_id, "https://t.me/source_for_v8_test", asyncio.Lock()
    )
    assert claimed is not None
    assignment, claimed_candidate = claimed
    assert assignment.account_id == second_id
    assert assignment.status == "joining"
    assert claimed_candidate.status == "joining"
