from types import SimpleNamespace

from telethon.tl.types import KeyboardButtonUrl, MessageEntityTextUrl

from app.link_utils import extract_urls_from_message


def test_hidden_text_url_is_extracted() -> None:
    message = SimpleNamespace(
        message="اضغط هنا",
        text="اضغط هنا",
        entities=[MessageEntityTextUrl(offset=0, length=8, url="https://t.me/example_group")],
        reply_markup=None,
        media=None,
    )
    assert "https://t.me/example_group" in extract_urls_from_message(message)


def test_url_button_is_extracted() -> None:
    button = KeyboardButtonUrl(text="دخول المجموعة", url="https://t.me/+InviteHash")
    markup = SimpleNamespace(rows=[SimpleNamespace(buttons=[button])])
    message = SimpleNamespace(message="", text="", entities=[], reply_markup=markup, media=None)
    assert "https://t.me/+InviteHash" in extract_urls_from_message(message)


def test_hyperlinked_paperclip_is_extracted() -> None:
    message = SimpleNamespace(
        message="📎",
        text="📎",
        entities=[MessageEntityTextUrl(offset=0, length=2, url="https://t.me/paperclip_group")],
        reply_markup=None,
        media=None,
    )
    assert "https://t.me/paperclip_group" in extract_urls_from_message(message)
