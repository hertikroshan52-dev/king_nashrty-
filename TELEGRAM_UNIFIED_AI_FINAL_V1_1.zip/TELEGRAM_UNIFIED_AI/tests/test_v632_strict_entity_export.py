from __future__ import annotations

import shutil

import pytest

from app.db import SessionFactory, init_db
from app.models import TelegramAudit, TelegramAuditInput, TelegramAuditResult
from app.services.auditor import export_audit


def _read_urls(directory):
    urls = set()
    if directory.exists():
        for path in directory.glob("*.txt"):
            urls.update(line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip())
    return urls


@pytest.mark.asyncio
async def test_v632_groups_and_channels_are_strictly_separate_exports() -> None:
    await init_db()
    async with SessionFactory() as session:
        audit = TelegramAudit(
            requested_by=632001,
            source_type="database",
            title="V632 strict split",
            status="completed",
            total_inputs=6,
            checked_inputs=6,
            summary={},
        )
        session.add(audit)
        await session.flush()

        fixtures = [
            ("https://t.me/V632Broadcast", "unjoined", "channel", -100632001),
            ("https://t.me/V632RestrictedBroadcast", "restricted_access", "channel", -100632002),
            ("https://t.me/V632MegaGroup", "joined_unique", "group", -100632003),
            ("https://t.me/V632OpenGroup", "unjoined", "group", -100632004),
            ("https://t.me/+V632JoinRequired", "unjoined", "group", None),
            ("https://t.me/V632Personal", "personal", "user", 632006),
        ]
        for url, status, peer_type, peer_id in fixtures:
            inp = TelegramAuditInput(audit_id=audit.id, original_url=url, normalized_url=url)
            session.add(inp)
            await session.flush()
            session.add(TelegramAuditResult(
                audit_id=audit.id,
                input_id=inp.id,
                normalized_url=url,
                status=status,
                peer_id=peer_id,
                peer_type=peer_type,
                title=url.rsplit('/', 1)[-1],
                account_ids=[1] if status == "joined_unique" else [],
                account_labels=["A1"] if status == "joined_unique" else [],
            ))
        await session.commit()
        audit_id = int(audit.id)

    bundle = await export_audit(audit_id, chunk_size=1000)
    try:
        channels = _read_urls(bundle.directory / "01_قنوات_Telegram_مشتركون")
        groups = _read_urls(bundle.directory / "02_مجموعات_Telegram_اعضاء")
        join_required = _read_urls(bundle.directory / "05_روابط_تحتاج_انضمام_او_طلب_انضمام")

        assert "https://t.me/V632Broadcast" in channels
        assert "https://t.me/V632RestrictedBroadcast" in channels
        assert "https://t.me/V632MegaGroup" in groups
        assert "https://t.me/V632OpenGroup" in groups
        assert "https://t.me/+V632JoinRequired" in join_required

        # Strict entity partition: channels never appear in any group export,
        # and groups never appear in the subscriber/channel export.
        assert channels.isdisjoint(groups)
        assert channels.isdisjoint(join_required)
        assert groups.isdisjoint(join_required)
        assert not any("V632MegaGroup" in u or "V632OpenGroup" in u or "V632JoinRequired" in u for u in channels)
        assert not any("V632Broadcast" in u or "V632RestrictedBroadcast" in u for u in groups | join_required)
    finally:
        shutil.rmtree(bundle.directory, ignore_errors=True)
        bundle.zip_path.unlink(missing_ok=True)
