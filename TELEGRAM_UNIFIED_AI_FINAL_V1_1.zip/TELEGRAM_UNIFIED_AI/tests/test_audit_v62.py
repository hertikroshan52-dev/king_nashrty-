from __future__ import annotations

import shutil

import pytest
from sqlalchemy import select

from app.db import SessionFactory, init_db
from app.link_utils import telegram_identity_key
from app.models import (
    Link,
    TelegramAudit,
    TelegramAuditInput,
    TelegramAuditResult,
    TelegramPeer,
    TelegramPeerAlias,
    TelegramResolutionCache,
    TelegramExpiredLinkBlocklist,
)
from app.services.auditor import export_audit, purge_expired_links_from_main_database


@pytest.mark.asyncio
async def test_v62_requested_classification_exports_and_1000_chunking() -> None:
    await init_db()
    async with SessionFactory() as session:
        audit = TelegramAudit(
            requested_by=777620,
            source_type="database",
            title="V62 classification test",
            status="completed",
            total_inputs=1005,
            checked_inputs=1005,
            summary={},
        )
        session.add(audit)
        await session.flush()

        rows: list[TelegramAuditResult] = []
        for index in range(1001):
            url = f"https://t.me/V62Bot{index:04d}_bot"
            inp = TelegramAuditInput(audit_id=audit.id, original_url=url, normalized_url=url)
            session.add(inp)
            await session.flush()
            rows.append(TelegramAuditResult(
                audit_id=audit.id,
                input_id=inp.id,
                normalized_url=url,
                status="bot",
                peer_id=6200000 + index,
                peer_type="bot",
                title=f"Bot {index}",
            ))

        fixtures = [
            ("https://t.me/V62Channel", "unjoined", "channel", -100620001, "News Channel"),
            ("https://t.me/V62Group", "joined_unique", "group", -100620002, "Normal Group"),
            ("https://t.me/+V62JoinRequired", "unjoined", "group", None, "Private Members Group"),
            ("https://t.me/V62PumpIPO", "joined_unique", "group", -100620003, "Crypto Pump IPO Club"),
        ]
        for url, status, peer_type, peer_id, title in fixtures:
            inp = TelegramAuditInput(audit_id=audit.id, original_url=url, normalized_url=url)
            session.add(inp)
            await session.flush()
            rows.append(TelegramAuditResult(
                audit_id=audit.id,
                input_id=inp.id,
                normalized_url=url,
                status=status,
                peer_id=peer_id,
                peer_type=peer_type,
                title=title,
                account_ids=[1] if status == "joined_unique" else [],
                account_labels=["A1"] if status == "joined_unique" else [],
            ))

        session.add_all(rows)
        await session.commit()
        audit_id = int(audit.id)

    bundle = await export_audit(audit_id, chunk_size=5000)
    try:
        bot_files = sorted((bundle.directory / "10_روابط_البوتات").glob("*.txt"))
        # V6.3.3 compact export: bots are a single-file category regardless of count.
        assert len(bot_files) == 1
        assert len(bot_files[0].read_text(encoding="utf-8").splitlines()) == 1001

        channel_text = "\n".join(
            p.read_text(encoding="utf-8")
            for p in (bundle.directory / "01_قنوات_Telegram_مشتركون").glob("*.txt")
        )
        group_text = "\n".join(
            p.read_text(encoding="utf-8")
            for p in (bundle.directory / "02_مجموعات_Telegram_اعضاء").glob("*.txt")
        )
        join_text = "\n".join(
            p.read_text(encoding="utf-8")
            for p in (bundle.directory / "05_روابط_تحتاج_انضمام_او_طلب_انضمام").glob("*.txt")
        )
        pump_text = "\n".join(
            p.read_text(encoding="utf-8")
            for p in (bundle.directory / "09_مجموعات_البامبات_والاكتتابات").glob("*.txt")
        )

        assert "https://t.me/V62Channel" in channel_text
        assert "https://t.me/V62Group" in group_text
        assert "https://t.me/+V62JoinRequired" in join_text
        assert "https://t.me/+V62JoinRequired" not in group_text
        assert "https://t.me/V62PumpIPO" in pump_text
    finally:
        shutil.rmtree(bundle.directory, ignore_errors=True)
        bundle.zip_path.unlink(missing_ok=True)


@pytest.mark.asyncio
async def test_v62_expired_url_is_purged_from_active_link_database() -> None:
    await init_db()
    url = "https://t.me/V62DefinitelyExpired"
    async with SessionFactory() as session:
        audit = TelegramAudit(
            requested_by=777621,
            source_type="database",
            title="V62 purge test",
            status="running",
            total_inputs=1,
            checked_inputs=1,
            summary={},
        )
        session.add(audit)
        await session.flush()
        inp = TelegramAuditInput(audit_id=audit.id, original_url=url, normalized_url=url)
        session.add(inp)
        await session.flush()
        session.add(TelegramAuditResult(
            audit_id=audit.id,
            input_id=inp.id,
            normalized_url=url,
            status="expired",
            error_class="Permanent",
        ))
        link = Link(
            original_url=url,
            normalized_url=url,
            url_hash="62" * 32,
            category="telegram",
            origin="account",
        )
        session.add(link)
        peer_id = -100629999 - int(audit.id)
        session.add(TelegramPeer(peer_id=peer_id, peer_type="group", title="Expired Group"))
        session.add(TelegramPeerAlias(peer_id=peer_id, normalized_url=url))
        session.add(TelegramResolutionCache(normalized_url=url, status="expired"))
        await session.commit()
        audit_id = int(audit.id)

    deleted = await purge_expired_links_from_main_database(audit_id)
    assert deleted == 1

    async with SessionFactory() as session:
        assert await session.scalar(select(Link).where(Link.normalized_url == url)) is None
        assert await session.scalar(select(TelegramPeerAlias).where(TelegramPeerAlias.normalized_url == url)) is None
        assert await session.scalar(select(TelegramResolutionCache).where(TelegramResolutionCache.normalized_url == url)) is None
        # Audit history remains so the report still states why the link disappeared.
        result = await session.scalar(select(TelegramAuditResult).where(TelegramAuditResult.audit_id == audit_id))
        assert result is not None and result.status == "expired"
        tombstone = await session.scalar(select(TelegramExpiredLinkBlocklist).where(
            TelegramExpiredLinkBlocklist.identity_key == telegram_identity_key(url)
        ))
        assert tombstone is not None and tombstone.reason == "expired"
