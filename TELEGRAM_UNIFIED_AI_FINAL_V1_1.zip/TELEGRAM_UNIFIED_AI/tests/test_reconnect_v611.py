from pathlib import Path


def test_v611_connection_recovery_is_wired() -> None:
    scanner = Path("app/services/scanner.py").read_text(encoding="utf-8")
    main = Path("app/main.py").read_text(encoding="utf-8")
    auditor = Path("app/services/auditor.py").read_text(encoding="utf-8")

    assert "async def ensure_connected" in scanner
    assert "if client.is_connected():" in scanner
    assert "collector_reconnect_attempts" in scanner
    assert 'counters["phase"] = "connection_failed"' in scanner
    assert "client = await manager.ensure_connected(account_id)" in scanner
    assert "client = await manager.ensure_connected(account_id)" in auditor
    assert "sum(1 for client in manager.clients.values() if client.is_connected())" in main
