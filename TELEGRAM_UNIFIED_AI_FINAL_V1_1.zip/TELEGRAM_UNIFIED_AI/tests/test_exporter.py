from pathlib import Path
import zipfile

from app.export_utils import build_export


def test_export_splits_every_1000_and_deduplicates(tmp_path: Path) -> None:
    rows = [("telegram", f"https://t.me/group_{i}") for i in range(2501)]
    rows += [("telegram", "https://t.me/group_0")]
    rows += [("twitter", f"https://x.com/user/status/{i}") for i in range(3)]

    bundle = build_export(rows, "test", 1000, export_root=tmp_path)

    telegram_files = sorted(bundle.directory.glob("*قسم_Telegram*.txt"))
    twitter_files = sorted(bundle.directory.glob("*قسم_تويتر_X*.txt"))

    assert len(telegram_files) == 3
    assert len(twitter_files) == 1
    assert len(telegram_files[0].read_text(encoding="utf-8").splitlines()) == 1000
    assert len(telegram_files[1].read_text(encoding="utf-8").splitlines()) == 1000
    assert len(telegram_files[2].read_text(encoding="utf-8").splitlines()) == 501
    assert bundle.total_links == 2504

    with zipfile.ZipFile(bundle.zip_path) as archive:
        assert sorted(archive.namelist()) == sorted(path.name for path in bundle.text_files)
