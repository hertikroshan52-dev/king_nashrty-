from __future__ import annotations

import shutil

import pytest

from app.db import SessionFactory, init_db
from app.models import (
    Link,
    TelegramAudit,
    TelegramAuditInput,
    TelegramAuditResult,
    TelegramAuditTelegramDiscovery,
)
from app.services.auditor import audit_summary, export_audit


@pytest.mark.asyncio
async def test_v61_channel_group_split_and_telegram_discovery_export() -> None:
    await init_db()
    async with SessionFactory() as session:
        audit = TelegramAudit(
            requested_by=777001,
            source_type="database",
            title="V61 integration test",
            status="completed",
            total_inputs=2,
            checked_inputs=2,
            summary={"options": {"collect_telegram": True, "telegram_scope": "7d"}},
        )
        session.add(audit)
        await session.flush()

        channel_input = TelegramAuditInput(
            audit_id=audit.id,
            original_url="https://t.me/V61ChannelTest",
            normalized_url="https://t.me/V61ChannelTest",
        )
        group_input = TelegramAuditInput(
            audit_id=audit.id,
            original_url="https://t.me/V61GroupTest",
            normalized_url="https://t.me/V61GroupTest",
        )
        session.add_all([channel_input, group_input])
        await session.flush()
        session.add_all([
            TelegramAuditResult(
                audit_id=audit.id,
                input_id=channel_input.id,
                normalized_url=channel_input.normalized_url,
                status="unjoined",
                peer_id=-100777001,
                peer_type="channel",
                title="Channel",
            ),
            TelegramAuditResult(
                audit_id=audit.id,
                input_id=group_input.id,
                normalized_url=group_input.normalized_url,
                status="joined_unique",
                peer_id=-100777002,
                peer_type="group",
                title="Group",
                account_ids=[1],
                account_labels=["A1"],
            ),
        ])

        link = Link(
            original_url="https://t.me/V61DiscoveredNew",
            normalized_url="https://t.me/V61DiscoveredNew",
            url_hash="61" * 32,
            category="telegram",
            origin="audit_telegram_discovery",
        )
        session.add(link)
        await session.flush()
        session.add(TelegramAuditTelegramDiscovery(
            audit_id=audit.id,
            link_id=link.id,
            normalized_url=link.normalized_url,
            source_telegram_url=group_input.normalized_url,
            source_peer_id=-100777002,
            source_message_id=55,
        ))
        await session.commit()
        audit_id = int(audit.id)

    summary = await audit_summary(audit_id)
    assert summary["telegram_channels"] == 1
    assert summary["telegram_groups"] == 1
    assert summary["telegram_discovered_links"] == 1

    bundle = await export_audit(audit_id, chunk_size=100)
    try:
        channel_files = list((bundle.directory / "01_قنوات_Telegram_مشتركون").glob("*.txt"))
        group_files = list((bundle.directory / "02_مجموعات_Telegram_اعضاء").glob("*.txt"))
        discovered_file = bundle.directory / "03_روابط_Telegram_الجديدة" / "V61_integration_test__روابط_Telegram_الجديدة.txt"
        assert channel_files and "https://t.me/V61ChannelTest" in channel_files[0].read_text(encoding="utf-8")
        assert group_files and "https://t.me/V61GroupTest" in group_files[0].read_text(encoding="utf-8")
        assert discovered_file.exists()
        assert "https://t.me/V61DiscoveredNew" in discovered_file.read_text(encoding="utf-8")
    finally:
        shutil.rmtree(bundle.directory, ignore_errors=True)
        bundle.zip_path.unlink(missing_ok=True)
