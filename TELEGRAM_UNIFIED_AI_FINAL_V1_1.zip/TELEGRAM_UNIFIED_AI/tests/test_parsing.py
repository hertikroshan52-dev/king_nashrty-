import json

import pytest

from app.bot import parse_sources
from app.services import accounts as accounts_service
from app.services.accounts import parse_session_packages


def test_parse_sources() -> None:
    values = parse_sources("https://t.me/example\n@example2\n-1001234567890\nhttps://t.me/+InviteHash")
    assert "@example" in values
    assert "@example2" in values
    assert "-1001234567890" in values
    assert "https://t.me/+InviteHash" in values
    assert "@c" not in parse_sources("https://t.me/c/123456/77")
    assert "@example" not in parse_sources("https://t.me/example/1414")
    assert "@example" not in parse_sources("https://t.me/s/example")


def test_parse_json_session_package() -> None:
    payload = json.dumps({"session": "abc", "api_id": 123, "api_hash": "hash", "label": "A"})
    packages = parse_session_packages(payload)
    assert packages[0].session == "abc"
    assert packages[0].api_id == 123
    assert packages[0].label == "A"


def test_raw_session_requires_global_credentials(monkeypatch) -> None:
    # Isolate this test from a real .env on the machine running pytest.
    monkeypatch.setattr(accounts_service.settings, "telegram_api_id", None)
    monkeypatch.setattr(accounts_service.settings, "telegram_api_hash", None)
    with pytest.raises(ValueError):
        parse_session_packages("raw-session-value")
