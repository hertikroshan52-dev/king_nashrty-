# بيان V7 النهائي

V7.0.0 مبنية على V6.6.1 FULL MERGED FINAL، والتي كانت Superset لجميع النسخ المرسلة من V6.3.0 حتى V6.6.0.

لم تُحذف خدمات التجميع أو التدقيق أو Browser Audit أو Multi-Supervisor أو Join أو Export أو Backup/Restore أو Checkpoints أو FloodWait/Cooldown.

أضيفت طبقة V7: Session Center آمن، Scheduler دائم، Workflows، Tags، Global Search مع عزل الصلاحيات، Error Center، Audit Log وDiagnostics.

تغيير أمني مقصود: تصدير Session String/API_HASH الخام عبر محادثة Telegram أُلغي. الجلسات تُحفظ مشفرة وتُدار بواسطة صاحبها فقط.
