# V6.2.6 — Account-Level ResolveUsername Cooldown

هذه النسخة تغلق مسار FloodWait المتبقي في Telegram Discovery.

## الإصلاح
- أي FloodWait من `ResolveUsername` يُحفظ كـ cooldown دائم مرتبط بـ **الحساب + نوع الطلب**.
- التخزين يتم داخل `job_cursors` بمفتاح مستقل، لذلك يبقى بعد إطفاء الهاتف/Termux/Ubuntu.
- أي رابط `t.me/username` جديد مخصص لنفس الحساب خلال المهلة لا يرسل API request؛ يتم تأجيله مباشرة.
- روابط الدعوة `t.me/+HASH` و`joinchat` لا تتأثر بـ ResolveUsername cooldown.
- الفحص الأساسي وTelegram Discovery يشتركان في نفس cooldown، فلا يضرب أحدهما Telegram بعد أن حدده الآخر.
- عند استكمال مهمة قديمة من V6.2.5، يتم توريث `deferred_until` من cursors القديمة إلى cooldown الحساب تلقائيًا.
- `FloodWait` لا يزيد scan errors ولا retry penalty ولا يتحول إلى final error.
- بعد انتهاء المهلة يعود الحساب تلقائيًا لطلبات ResolveUsername دون Resume يدوي.
