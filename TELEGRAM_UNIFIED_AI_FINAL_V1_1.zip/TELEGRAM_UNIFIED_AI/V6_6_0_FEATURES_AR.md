# Telegram Link Collector & Auditor V6.6.0 — النسخة المتكاملة

هذه النسخة مبنية فوق V6.5.0 وتحافظ على قاعدة روابط واحدة، مشرفين مستقلين، فحص المتصفح، وفحص الحسابات 10×4×120.

## الجديد في V6.6.0

### 1. استخراج جلسة Telethon من نفس البوت
- زر `🔐 استخراج جلسة Telethon جديدة` يطلب رقم الهاتف ثم كود Telegram ثم 2FA عند وجودها.
- الناتج ملف JSON قابل لإعادة الاستيراد من زر إضافة حسابات Telethon.
- العملية في الخاص فقط، والملف المؤقت يحذف من السيرفر بعد الإرسال.
- زر `📦 تصدير جلسات حساباتي المضافة` ما زال يصدّر فقط حسابات المشرف نفسه.

### 2. مشرف جلسات فقط
- المالك يستطيع إضافة `مشرف جلسات فقط` من إدارة المشرفين.
- هذا المستخدم يرى واجهة استخراج الجلسات فقط.
- لا يملك صلاحية التجميع أو الفحص أو قاعدة البيانات أو التصدير أو حسابات المشرفين الآخرين.

### 3. سجل الروابط المنتهية الدائم
- زر `🗑️ سجل الروابط المنتهية — للمالك`.
- يرسل المالك رابط/معرف قناة أو مجموعة تحتوي روابط الفحص القديمة المنتهية.
- البوت يقرأ رسائل الروابط فقط باستخدام Telegram URL filter، ويضيف هوياتها إلى `telegram_expired_link_blocklist`.
- الروابط الموجودة في السجل لا تعاد إضافتها إلى قاعدة الروابط، ولا تدخل أي فحص جديد من قاعدة البيانات أو الملفات أو اللصق أو الاكتشاف.
- الروابط النشطة المطابقة تزال من جدول الروابط حتى لا تظهر في التصدير العام.

### 4. الاسم مع الرابط في تصدير الفحص
ملفات القنوات والمجموعات والمجموعات التي تحتاج انضمامًا وملف البامبات/الاكتتابات تكتب السجل هكذا:

```text
الاسم: اسم القناة أو المجموعة
الرابط: https://t.me/xxxxx

```

وعند تقسيم 200/1000 يبقى الاسم والرابط معًا كسجل واحد ولا ينفصلان بين ملفين.

### 5. فحص تعليقات Telegram أثناء فحص الحسابات
عندما يفحص الحساب قناة قابلة للقراءة ويقوم بمسح تاريخها لاكتشاف روابط Telegram، إذا كان للمنشور قسم تعليقات/Discussion متاح للحساب، يفحص البوت الردود أيضًا ويستخرج روابط Telegram الموجودة فيها.

- لا يتم Auto Join للتعليقات أو القنوات.
- إذا كانت المناقشة غير متاحة للحساب، يستمر فحص القناة ولا يفشل التقرير.
- أي FloodWait صادر من Telegram يبقى محترمًا.

### 6. تحسينات الأداء
الإعدادات الافتراضية الجديدة:

```env
WEB_AUDIT_WORKERS=64
WEB_AUDIT_BATCH_SIZE=1000
WEB_AUDIT_TIMEOUT_SECONDS=15
COLLECTOR_DB_BATCH_LINKS=500
COLLECTOR_CHECKPOINT_MESSAGES=500
PROGRESS_UPDATE_EVERY_MESSAGES=1000
AUDIT_DB_BATCH_SIZE=500
AUDIT_SCAN_DISCUSSION_COMMENTS=true
```

فحص المتصفح يستخدم HTTP متوازيًا بدون Telethon، مع بوابة Back-pressure مشتركة عند HTTP 429. التجميع العميق يستخدم دفعات SQLite أكبر ونقاط حفظ أقل تكرارًا لتقليل I/O، مع استمرار الحفظ الدوري والاستكمال بعد الانقطاع.

## ملاحظات مهمة
- السرعة القصوى في Telethon ليست تجاهل حدود Telegram؛ `FloodWait` يُحترم دائمًا حتى لا تتحول السرعة إلى تعطيل للحسابات.
- فحص المتصفح يظل محافظًا: البيانات غير الكافية تذهب إلى `تحتاج حسابات لمعرفة المعلومات` بدل تخمين نوع خاطئ.
- المنتهية التي يستوردها المالك يدويًا تعتبر موثوقة وتدخل Blocklist دائم؛ لذلك لا تستورد إلى هذا القسم إلا الروابط التي تأكدت أنها منتهية من فحصك السابق.

## ترقية من V6.5.0

أوقف النسخة القديمة واحفظ الإعدادات والبيانات:

```bash
cd /root/telegram-bot/telegram_link_collector_bot_v6_5_0_browser_audit
./botctl.sh stop
cp .env /root/v65.env.backup
cp -a data /root/v65_data.backup
```

بعد فك V6.6.0:

```bash
cd /root/telegram-bot/telegram_link_collector_bot_v6_6_0_integrated
cp /root/v65.env.backup .env
rm -rf data
cp -a /root/v65_data.backup data

python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install --no-cache-dir -r requirements.txt
```

للاستفادة من قيم الأداء الجديدة في `.env` القديمة:

```bash
sed -i 's/^WEB_AUDIT_WORKERS=.*/WEB_AUDIT_WORKERS=64/' .env
sed -i 's/^WEB_AUDIT_BATCH_SIZE=.*/WEB_AUDIT_BATCH_SIZE=1000/' .env
sed -i 's/^COLLECTOR_DB_BATCH_LINKS=.*/COLLECTOR_DB_BATCH_LINKS=500/' .env
sed -i 's/^COLLECTOR_CHECKPOINT_MESSAGES=.*/COLLECTOR_CHECKPOINT_MESSAGES=500/' .env
sed -i 's/^PROGRESS_UPDATE_EVERY_MESSAGES=.*/PROGRESS_UPDATE_EVERY_MESSAGES=1000/' .env
sed -i 's/^AUDIT_DB_BATCH_SIZE=.*/AUDIT_DB_BATCH_SIZE=500/' .env
grep -q '^AUDIT_SCAN_DISCUSSION_COMMENTS=' .env || echo 'AUDIT_SCAN_DISCUSSION_COMMENTS=true' >> .env
```

ثم:

```bash
python -m compileall -q app scripts
python scripts/static_validate_v6.py
./botctl.sh selfcheck
```

إذا انتهى selfcheck بنجاح:

```bash
./botctl.sh start
./botctl.sh status
```
