# تثبيت Telegram Link Collector & Auditor V6.6.1 FULL MERGED FINAL على Termux + Ubuntu

هذه الحزمة Python فقط ولا تحتاج Node.js أو npm.

## 1) داخل Termux

```bash
pkg update -y
pkg upgrade -y
pkg install -y proot-distro unzip nano tmux
termux-setup-storage
proot-distro install ubuntu
proot-distro login ubuntu
```

## 2) داخل Ubuntu

```bash
export DEBIAN_FRONTEND=noninteractive
export TZ=Asia/Aden
apt update
apt upgrade -y
apt install -y \
  python3 python3-pip python3-venv python3-dev \
  build-essential pkg-config libffi-dev libssl-dev \
  ca-certificates curl unzip nano sqlite3
ln -snf /usr/share/zoneinfo/Asia/Aden /etc/localtime
echo Asia/Aden >/etc/timezone
```

تحقق من Python:

```bash
python3 --version
```

النسخة مصممة للعمل على Python 3.12 و3.13، وتم تجهيز التثبيت أيضًا لبيئات Ubuntu الحديثة التي تستخدم Python 3.14 متى توفرت Wheels المتوافقة لحزم requirements.

## 3) فك الحزمة

```bash
mkdir -p /root/telegram-bot
cd /root/telegram-bot

ZIP="$(find /sdcard/Download -maxdepth 1 -type f -name 'telegram_link_collector_bot_v6_6_1_FULL_MERGED_FINAL*.zip' -print -quit)"
test -n "$ZIP" || { echo "ZIP NOT FOUND"; exit 1; }

unzip -o "$ZIP" -d /root/telegram-bot/
cd /root/telegram-bot/telegram_link_collector_bot_v6_6_1_FULL_MERGED_FINAL
chmod +x botctl.sh start.sh install-ubuntu.sh
```

## 4) التثبيت التلقائي

```bash
./install-ubuntu.sh
```

أو يدويًا:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install --no-cache-dir -r requirements.txt
python -m compileall -q app scripts tests
python scripts/static_validate_v6.py
```

## 5) إعداد .env

إذا لم يكن موجودًا:

```bash
cp .env.example .env
chmod 600 .env
nano .env
```

اضبط على الأقل:

```env
BOT_TOKEN=ضع_توكن_بوت_تيليجرام
ADMIN_IDS=ضع_Telegram_User_ID_للمالك
INSTANCE_NAME=Telegram Link V6.6.1 FULL MERGED FINAL
```

ولإضافة/استخراج جلسات Telethon يفضل أيضًا ضبط:

```env
TELEGRAM_API_ID=ضع_API_ID
TELEGRAM_API_HASH=ضع_API_HASH
```

أول ID في `ADMIN_IDS` هو المالك الرئيسي. بقية المشرفين يمكن إضافتهم من واجهة البوت.

لا تشارك `.env` ولا ملفات الجلسات مع أي شخص.

## 6) التحقق

```bash
source .venv/bin/activate
./botctl.sh versioncheck
python scripts/static_validate_v6.py
./botctl.sh selfcheck
```

`selfcheck` يحتاج BOT_TOKEN صحيحًا داخل `.env`.

## 7) التشغيل في الخلفية

```bash
./botctl.sh start
./botctl.sh status
```

`botctl.sh start` يستخدم `nohup`، لذلك يعمل البوت في الخلفية.

للسجلات:

```bash
tail -f data/logs/launcher.log
```

للإيقاف:

```bash
./botctl.sh stop
```

لإعادة التشغيل:

```bash
./botctl.sh restart
```

## 8) ثبات Termux

اخرج من Ubuntu ثم:

```bash
termux-wake-lock
```

ويمكن تشغيل Ubuntu داخل tmux:

```bash
tmux new -s telegrambot
proot-distro login ubuntu
cd /root/telegram-bot/telegram_link_collector_bot_v6_6_1_FULL_MERGED_FINAL
source .venv/bin/activate
./botctl.sh status
```

لفصل tmux بدون إيقافه: `Ctrl+B` ثم `D`.
